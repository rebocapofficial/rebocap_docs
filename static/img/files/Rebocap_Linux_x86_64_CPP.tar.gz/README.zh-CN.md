# Rebocap WebSocket C++ SDK

[English](README.md) | 简体中文 | [日本語](README.ja.md)

从 Rebocap Host 接收骨盆平移、24 个关节旋转和脚底接触数据。提供 Windows x64 与 Linux x86-64 独立发布包；示例需要 C++17。

- **Windows：**安装 Microsoft Visual C++ 2015–2022 x64 运行库，并将 `rebocap_ws_sdk.dll` 放在程序旁或 DLL 搜索路径中。
- **Linux：**发布包在 Ubuntu 22.04 x86-64 上构建和测试，至少需要 `GLIBC_2.34` 和 `GLIBCXX_3.4.29`。将 `librebocap_ws_sdk_cpp.so` 放在示例程序旁。

## 运行示例

在 Rebocap 中启用 WebSocket 输出并确认端口，通常为 `7690`。解压后运行：

```powershell
.\rebocap_ws_sdk_cpp_example.exe --host 127.0.0.1 --port 7690
.\rebocap_ws_sdk_cpp_example.exe --host 192.168.1.100 --port 7690 --seconds 10
```

Linux 命令为 `./rebocap_ws_sdk_cpp_example --host HOST --port 7690`。将 `HOST` 换成运行 Rebocap 的电脑名或 IP。远程连接时，请确认服务监听可访问的网络接口且防火墙允许该端口；WSL2 可使用 Windows 主机的 WSL 网关地址。示例还支持 `--uid N`；`--register-avatar` 会注册包内的示例角色。

重新构建包内示例：

```bash
cmake -S . -B build
cmake --build build --config Release
```

## 使用 SDK

```cpp
#include "rebocap_ws_sdk_cpp.h"
#include <chrono>
#include <thread>

int main() {
    rebocap::RebocapWsSdk sdk(UnityCoordinate, true);
    sdk.SetPoseMsgCallback([](const QuatMsg* msg, rebocap::RebocapWsSdk*) {
        // msg->trans[0..2]、msg->quat[0..95]、msg->tp
    });
    int result = sdk.OpenRemote("192.168.1.100", 7690);
    if (result == 0) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        QuatMsg latest{};
        if (sdk.GetLastMsg(&latest) == 0) { /* 使用最近一帧 */ }
    }
    sdk.Close();
}
```

`OpenRemote(host, port, name, uid)` 为单个实例指定主机。`Open(port)` 优先使用环境变量 `REBOCAP_WS_HOST`，未设置时使用 `localhost`。UID 为 `0` 时每次连接自动生成随机正整数；非零 UID 按传入值使用。同时在线的客户端应使用不同 UID。

`Open` 返回 `0` 表示成功，`1` 表示连接状态错误，`2` 表示连接失败，`3` 表示认证失败。协议没有独立的认证成功应答：返回成功表示服务端在短暂等待期间未拒绝连接。请通过回调或 `GetLastMsg` 确认是否收到姿态数据。

回调由 SDK 工作线程执行，可能在 `Open` 返回前触发。请将界面更新以及关闭或释放 SDK 的操作交回调用线程。

## 姿态数据

`trans[3]` 是骨盆位置，`quat[96]` 包含 24 个按 `[x, y, z, w]` 排列的四元数，`tp` 是 Unix 毫秒时间戳。构造参数用于选择坐标系和全局或局部旋转。关节顺序如下：

```text
Pelvis, L_Hip, R_Hip, Spine1, L_Knee, R_Knee, Spine2, L_Ankle,
R_Ankle, Spine3, L_Foot, R_Foot, Neck, L_Collar, R_Collar, Head,
L_Shoulder, R_Shoulder, L_Elbow, R_Elbow, L_Wrist, R_Wrist, L_Hand, R_Hand
```

`static_index=-1` 表示未检测到接触点；`0–5` 对应左脚，`6–11` 对应右脚。每只脚按前掌左、中、右以及后跟左、中、右排列。
