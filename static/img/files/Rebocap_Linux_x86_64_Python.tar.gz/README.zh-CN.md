# Rebocap WebSocket Python SDK

[English](README.md) | 简体中文 | [日本語](README.ja.md)

从 Rebocap Host 接收骨盆平移、24 个关节旋转和脚底接触数据。发布包支持 **标准 64 位 CPython 3.6–3.14**；每个平台只使用一个稳定 ABI 扩展，无需为每个 Python 版本准备一套 SDK。自由线程版 Python、其他架构和 macOS 尚未测试。

- **Windows x64：**需要 Microsoft Visual C++ 2015–2022 x64 运行库。包内包含一个扩展和对应的原生 DLL。
- **Linux x86-64：**在 Ubuntu 22.04 上构建和测试，至少需要 `GLIBC_2.34` 和 `GLIBCXX_3.4.29`。包内包含一个 `abi3` 扩展。

## 运行示例

在 Rebocap 中启用 WebSocket 输出并确认端口，通常为 `7690`。解压后运行：

```bash
python rebocap_ws_sdk_example.py --host 127.0.0.1 --port 7690
python rebocap_ws_sdk_example_with_class.py --host 192.168.1.100 --port 7690 --seconds 10
```

将 `--host` 换成运行 Rebocap 的电脑名或 IP。远程连接时，请确认服务监听可访问的网络接口且防火墙允许该端口；WSL2 可使用 Windows 主机的 WSL 网关地址。持续输出 `pose` 表示正在接收动作数据。

## 使用 SDK

将 `rebocap_ws_sdk` 目录复制到项目中，或将其父目录加入 `PYTHONPATH`：

```python
import time
import rebocap_ws_sdk

def on_pose(sdk, trans, pose24, static_index, timestamp_s):
    print(timestamp_s, trans, pose24[0])

sdk = rebocap_ws_sdk.RebocapWsSdk(
    rebocap_ws_sdk.CoordinateType.UnityCoordinate, use_global_rotation=True)
sdk.set_pose_msg_callback(on_pose)
sdk.set_exception_close_callback(lambda sdk: print("连接异常中断"))
result = sdk.open(7690, host="192.168.1.100", uid=0)
if result != 0:
    raise RuntimeError("连接失败: {}".format(result))
try:
    time.sleep(10)
    latest = sdk.get_last_msg()  # 收到第一帧之前为 None
finally:
    sdk.close()
```

`host=None` 时优先使用环境变量 `REBOCAP_WS_HOST`，未设置时使用 `localhost`。UID 为 `0` 或未指定时，每次连接自动生成随机正整数；非零 UID 按传入值使用。同时在线的客户端应使用不同 UID。`name` 默认为 `reborn_app`。

`open()` 返回 `0` 表示成功，`1` 表示连接状态错误，`2` 表示连接失败，`3` 表示认证失败。协议没有独立的认证成功应答：返回成功表示服务端在短暂等待期间未拒绝连接。请通过回调或 `get_last_msg()` 确认是否收到姿态数据。

回调由 SDK 工作线程执行，可能在 `open()` 返回前触发。请将界面更新以及关闭或释放 SDK 的操作交回调用线程。

## 姿态数据

- `trans`：所选 `CoordinateType` 坐标系中的骨盆位置 `[x, y, z]`。
- `pose24`：24 个四元数，每个按 `[x, y, z, w]` 排列。`use_global_rotation` 用于选择全局或局部旋转；关节顺序见 `rebocap_ws_sdk.REBOCAP_JOINT_NAMES`。
- `static_index`：`-1` 表示未检测到接触点；`0–5` 对应左脚，`6–11` 对应右脚。每只脚按前掌左、中、右以及后跟左、中、右排列。
- 回调中的 `timestamp_s` 为 Unix 秒。`get_last_msg()` 返回 `(trans, pose24, static_index, timestamp_ms)`，其中时间戳为 Unix 毫秒；收到第一帧之前返回 `None`。

Host 正在播放动作时，可运行 `python verify_live.py --host HOST --port 7690` 检查回调、四元数和时间戳。脚本会连接、接收一小段数据并断开。
