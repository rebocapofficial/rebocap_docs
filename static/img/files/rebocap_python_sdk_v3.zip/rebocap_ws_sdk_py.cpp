#include "rebocap_ws_sdk.h"
#include <Python.h>
#include <string_view>


class WebsocketClientPyWrapper {
 public:
  explicit WebsocketClientPyWrapper(PyObject* self, PyObject* pose_msg_callback, PyObject* unexcept_close_callback, int coordinate_type=0, int use_global_quat=0)
      : self_(self), pose_msg_callback_(pose_msg_callback), unexcept_close_callback_(unexcept_close_callback) {
    CoordinateSpaceType coordinateSpaceType = DefaultCoordinate;
    if (coordinate_type <= UECoordinate && coordinate_type >= 0) {
      coordinateSpaceType = static_cast<CoordinateSpaceType>(coordinate_type);
    }

    handle_ = rebocap_ws_sdk_new(coordinateSpaceType, use_global_quat);
    rebocap_ws_sdk_set_pose_msg_callback(handle_, this, WebsocketClientPyWrapper::pose_msg_callback);
    rebocap_ws_sdk_set_exception_close_callback(handle_, this, WebsocketClientPyWrapper::unexcept_close_callback);
  }

  ~WebsocketClientPyWrapper() {
    rebocap_ws_sdk_release(handle_);
  }

  int Open(uint16_t port, std::string_view name, int64_t uid) {
    return rebocap_ws_sdk_open(handle_, port, name.data(), name.size(), uid);
  }

  void Close() {
    rebocap_ws_sdk_close(handle_);
  }

  int GetLastMsg(QuatMsg& msg) {
    return rebocap_ws_sdk_get_last_msg(handle_, &msg);
  }
 private:
  void* handle_;
  PyObject* self_;
  PyObject* pose_msg_callback_;
  PyObject* unexcept_close_callback_;


  static void pose_msg_callback(const QuatMsg* msg, void* extra) {
    auto* that = reinterpret_cast<WebsocketClientPyWrapper*>(extra);
    if (that->pose_msg_callback_ == nullptr) return;

    PyGILState_STATE state = PyGILState_Ensure();
    auto *trans = PyList_New(3);
    PyList_SetItem(trans, 0, PyFloat_FromDouble(msg->trans[0]));
    PyList_SetItem(trans, 1, PyFloat_FromDouble(msg->trans[1]));
    PyList_SetItem(trans, 2, PyFloat_FromDouble(msg->trans[2]));
    auto* pose24 = PyList_New(24);
    for(size_t i = 0, j = 0; i < 24; i++, j+=4) {
      auto *arr = PyList_New(4);
      PyList_SetItem(arr, 0, PyFloat_FromDouble(msg->quat[j]));
      PyList_SetItem(arr, 1, PyFloat_FromDouble(msg->quat[j + 1]));
      PyList_SetItem(arr, 2, PyFloat_FromDouble(msg->quat[j + 2]));
      PyList_SetItem(arr, 3, PyFloat_FromDouble(msg->quat[j + 3]));
      PyList_SetItem(pose24, static_cast<Py_ssize_t>(i), arr);
    }
    auto *arg_list = Py_BuildValue("(OOOiK)", that->self_, trans, pose24, msg->static_index, msg->tp);
    auto *result = PyObject_CallObject(that->pose_msg_callback_, arg_list);
    Py_DECREF(arg_list);
    if (result != nullptr) {
      Py_DECREF(result);
    }
    PyGILState_Release(state);
  }

  static void unexcept_close_callback(void* extra) {
    auto* that = reinterpret_cast<WebsocketClientPyWrapper*>(extra);
    PyGILState_STATE state = PyGILState_Ensure();
    auto *arg_list = Py_BuildValue("(O)", that->self_);
    auto *result = PyObject_CallObject(that->unexcept_close_callback_, arg_list);
    Py_DECREF(arg_list);
    if (result != nullptr) {
      Py_DECREF(result);
    }
    PyGILState_Release(state);
  }
};

static PyObject* rebocap_ws_sdk_new(PyObject *, PyObject *args) {
  PyObject* self;
  PyObject* pose_msg_callback;
  PyObject* unexcept_close_callback;
  PyObject* coordinate_type_0;
  PyObject* global_quat_0;
  PyArg_ParseTuple(args, "OOOOO", &self, &pose_msg_callback, &unexcept_close_callback, &coordinate_type_0, &global_quat_0);
  int coordinate_type = PyLong_AsLong(coordinate_type_0);
  int global_quat = PyLong_AsLong(global_quat_0);
  auto* handle = new WebsocketClientPyWrapper(self, pose_msg_callback, unexcept_close_callback, coordinate_type, global_quat);
  return PyLong_FromVoidPtr(handle);
}

static PyObject* rebocap_ws_sdk_release(PyObject *, PyObject *args) {
  PyObject* handle;
  PyArg_ParseTuple(args, "O", &handle);
  delete reinterpret_cast<WebsocketClientPyWrapper*>(PyLong_AsVoidPtr(handle));
  Py_INCREF(Py_None);
  return Py_None;
}

static PyObject* rebocap_ws_sdk_open(PyObject *, PyObject *args) {
  PyObject* handle;
  PyObject* port;
  const char* name;
  PyObject* uid;
  PyArg_ParseTuple(args, "OOsO", &handle, &port, &name, &uid);
  auto res = reinterpret_cast<WebsocketClientPyWrapper*>(PyLong_AsVoidPtr(handle))->Open(PyLong_AsLong(port), name, PyLong_AsLongLong(uid));
  return PyLong_FromLong(res);
}

static PyObject* rebocap_ws_sdk_close(PyObject *, PyObject *args) {
  PyObject* handle;
  PyArg_ParseTuple(args, "O", &handle);
  reinterpret_cast<WebsocketClientPyWrapper*>(PyLong_AsVoidPtr(handle))->Close();
  Py_INCREF(Py_None);
  return Py_None;
}

static PyObject* rebocap_ws_sdk_get_last_msg(PyObject *, PyObject *args) {
  PyObject* handle;
  PyArg_ParseTuple(args, "O", &handle);
  QuatMsg msg{};
  int ret = reinterpret_cast<WebsocketClientPyWrapper*>(PyLong_AsVoidPtr(handle))->GetLastMsg(msg);
  if (ret != 0) {
    Py_INCREF(Py_None);
    return Py_None;
  }
  auto* res = PyTuple_New(4);
  auto *trans = PyList_New(3);
  PyList_SetItem(trans, 0, PyFloat_FromDouble(msg.trans[0]));
  PyList_SetItem(trans, 1, PyFloat_FromDouble(msg.trans[1]));
  PyList_SetItem(trans, 2, PyFloat_FromDouble(msg.trans[2]));
  auto* pose24 = PyList_New(24);
  for(size_t i = 0, j = 0; i < 24; i++, j+=4) {
    auto *arr = PyList_New(4);
    PyList_SetItem(arr, 0, PyFloat_FromDouble(msg.quat[j]));
    PyList_SetItem(arr, 1, PyFloat_FromDouble(msg.quat[j+1]));
    PyList_SetItem(arr, 2, PyFloat_FromDouble(msg.quat[j+2]));
    PyList_SetItem(arr, 3, PyFloat_FromDouble(msg.quat[j+3]));
    PyList_SetItem(pose24, static_cast<Py_ssize_t>(i), arr);
  }
  PyTuple_SetItem(res, 0, trans);
  PyTuple_SetItem(res, 1, pose24);
  PyTuple_SetItem(res, 2, PyLong_FromLong(msg.static_index));
  PyTuple_SetItem(res, 3, PyLong_FromUnsignedLongLong(msg.tp));
  return res;
}


extern "C" {
static PyMethodDef rebocap_ws_sdk_ext_methods[] = {
        {"rebocap_ws_sdk_new", (PyCFunction) rebocap_ws_sdk_new, METH_VARARGS, nullptr},
        {"rebocap_ws_sdk_release", (PyCFunction) rebocap_ws_sdk_release, METH_VARARGS, nullptr},
        {"rebocap_ws_sdk_open", (PyCFunction) rebocap_ws_sdk_open, METH_VARARGS, nullptr},
        {"rebocap_ws_sdk_close", (PyCFunction) rebocap_ws_sdk_close, METH_VARARGS, nullptr},
        {"rebocap_ws_sdk_get_last_msg", (PyCFunction) rebocap_ws_sdk_get_last_msg, METH_VARARGS, nullptr},
        {nullptr, nullptr, 0, nullptr},
};

static PyModuleDef rebocap_ws_sdk_ext_module = {
        PyModuleDef_HEAD_INIT,
        "rebocap_ws_sdk_ext",
        "",
        0,
        rebocap_ws_sdk_ext_methods};

PyMODINIT_FUNC PyInit_rebocap_ws_sdk_ext() {return PyModule_Create(&rebocap_ws_sdk_ext_module); }
}
