# Rebocap WebSocket SDK：Linux x86_64

基于 Ubuntu 22.04 构建，支持 glibc 2.35 及更高版本。Python 扩展已使用 CPython 3.12 测试。其他 Python 版本尚未测试。

## 文件

- `cpp/librebocap_ws_sdk_cpp.so`、`cpp/rebocap_ws_sdk_cpp.h`、`cpp/include/`：C++ 接口及头文件。
- `cpp/rebocap_ws_sdk_cpp_example`、示例源码及 `cpp/sample_data/`：C++ 示例。请从 `cpp` 目录运行示例。
- `lib/librebocap_ws_sdk.so`：C ABI 动态库，可用于自行编写语言绑定。
- `python/rebocap_ws_sdk/`：Python 封装及本地扩展；`python/` 中包含调用示例。

## 使用

在 SDK 根目录启动 Python 示例（请先启动 Rebocap 并开启对应 WebSocket 端口）：

```bash
PYTHONPATH="$PWD/python" python3.12 python/rebocap_ws_sdk_example.py
```

C++ 示例：

```bash
cd cpp
./rebocap_ws_sdk_cpp_example
```

使用 C++ 头文件的程序需要包含 `cpp/` 和 `cpp/include/`，并链接 `librebocap_ws_sdk_cpp.so`。动态库依赖系统的 `libstdc++`、`libgcc_s`、`libm` 和 `libc`；protobuf 已静态链接。

如需连接不同的主机，可在启动程序前设置 `REBOCAP_WS_HOST`；默认连接 localhost。
