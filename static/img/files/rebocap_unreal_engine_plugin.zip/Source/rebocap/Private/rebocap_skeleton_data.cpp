#include "rebocap_skeleton_data.h"

namespace rebocap_bones {
const FName pelvis = "pelvis";
const FName l_hip = "l_hip";
const FName r_hip = "r_hip";
const FName spine1 = "spine1";
const FName l_knee = "l_knee";
const FName r_knee = "r_knee";
const FName spine2 = "spine2";
const FName l_ankle = "l_ankle";
const FName r_ankle = "r_ankle";
const FName spine3 = "spine3";
const FName l_foot = "l_foot";
const FName r_foot = "r_foot";
const FName neck = "neck";
const FName l_collar = "l_collar";
const FName r_collar = "r_collar";
const FName head = "head";
const FName l_shoulder = "l_shoulder";
const FName r_shoulder = "r_shoulder";
const FName l_elbow = "l_elbow";
const FName r_elbow = "r_elbow";
const FName l_wrist = "l_wrist";
const FName r_wrist = "r_wrist";
const FName l_hand = "l_hand";
const FName r_hand = "r_hand";
}  // namespace rebocap_bones