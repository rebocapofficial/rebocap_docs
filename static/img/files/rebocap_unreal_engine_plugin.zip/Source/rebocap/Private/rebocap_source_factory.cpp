#include "rebocap_source_factory.h"

#include "Internationalization/Text.h"
#include "rebocap_source.h"
#include "rebocap_source_editor.h"

#define LOCTEXT_NAMESPACE "RebocapSourceFactory"

FText URebocapSourceFactory::GetSourceDisplayName() const { return LOCTEXT("SourceDisplayName", "Rebocap Source"); }

FText URebocapSourceFactory::GetSourceTooltip() const { return LOCTEXT("SourceTooltip", "Creates a connection to a Rebocap Source"); }

TSharedPtr<SWidget> URebocapSourceFactory::BuildCreationPanel(FOnLiveLinkSourceCreated OnLiveLinkSourceCreated) const {
  return SNew(SRebocapSourceEditor)
      .OnRebocapSourceClickConnect(SRebocapSourceEditor::FOnRebocapSourceClickConnect::CreateUObject(
          this, &URebocapSourceFactory::OnSourceSelected, OnLiveLinkSourceCreated));
}

URebocapSourceFactory::EMenuType URebocapSourceFactory::GetMenuType() const { return EMenuType::SubPanel; }

void URebocapSourceFactory::OnSourceSelected(uint16_t port, FOnLiveLinkSourceCreated OnLiveLinkSourceCreated) const {
  auto source = MakeShared<FRebocapSource>(port);
  FRebocapSource::SetInstance(source);
  FString ConnectionString = FString::Printf(TEXT("Name=\"rebocap\""));
  OnLiveLinkSourceCreated.ExecuteIfBound(source, MoveTemp(ConnectionString));
}

#undef LOCTEXT_NAMESPACE