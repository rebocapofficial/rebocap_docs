#pragma once

#include "CoreMinimal.h"
#include "LiveLinkSourceFactory.h"
#include "rebocap_source_factory.generated.h"

UCLASS()
class URebocapSourceFactory final : public ULiveLinkSourceFactory {
  GENERATED_BODY()

  FText GetSourceDisplayName() const final;
  FText GetSourceTooltip() const final;
  TSharedPtr<SWidget> BuildCreationPanel(FOnLiveLinkSourceCreated OnLiveLinkSourceCreated) const final;
  EMenuType GetMenuType() const final;
  // virtual TSharedPtr<ILiveLinkSource>
  // CreateSource(const FString &ConnectionString) const override;
  //
 private:
  void OnSourceSelected(uint16_t port, FOnLiveLinkSourceCreated OnLiveLinkSourceCreated) const;
};
