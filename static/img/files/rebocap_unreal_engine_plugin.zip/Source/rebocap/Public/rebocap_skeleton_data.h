#pragma once

#include "UObject/NameTypes.h"

namespace rebocap_bones {
extern const FName pelvis;
extern const FName l_hip;
extern const FName r_hip;
extern const FName spine1;
extern const FName l_knee;
extern const FName r_knee;
extern const FName spine2;
extern const FName l_ankle;
extern const FName r_ankle;
extern const FName spine3;
extern const FName l_foot;
extern const FName r_foot;
extern const FName neck;
extern const FName l_collar;
extern const FName r_collar;
extern const FName head;
extern const FName l_shoulder;
extern const FName r_shoulder;
extern const FName l_elbow;
extern const FName r_elbow;
extern const FName l_wrist;
extern const FName r_wrist;
extern const FName l_hand;
extern const FName r_hand;
}  // namespace rebocap_bones