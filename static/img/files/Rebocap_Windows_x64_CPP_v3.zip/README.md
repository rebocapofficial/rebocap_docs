# Rebocap WebSocket C++ SDK

English | [简体中文](README.zh-CN.md) | [日本語](README.ja.md)

Receive pelvis translation, 24 joint rotations, and foot-contact data from the Rebocap Host. Separate packages are provided for Windows x64 and Linux x86-64; the example requires C++17.

- **Windows:** install the Microsoft Visual C++ 2015–2022 x64 runtime. Place `rebocap_ws_sdk.dll` beside the application or in its DLL search path.
- **Linux:** the package was built and tested on Ubuntu 22.04 x86-64. It requires at least `GLIBC_2.34` and `GLIBCXX_3.4.29`. Keep `librebocap_ws_sdk_cpp.so` beside the example.

## Run the example

Enable WebSocket output in Rebocap and check its port, normally `7690`. From the extracted package, run:

```powershell
.\rebocap_ws_sdk_cpp_example.exe --host 127.0.0.1 --port 7690
.\rebocap_ws_sdk_cpp_example.exe --host 192.168.1.100 --port 7690 --seconds 10
```

On Linux, run `./rebocap_ws_sdk_cpp_example --host HOST --port 7690`. Replace `HOST` with the Rebocap computer's hostname or IP. For a remote host, make sure its service listens on a reachable interface and the firewall permits the port. A WSL2 client can use the Windows host's WSL gateway address. The example also accepts `--uid N` and `--register-avatar`, which registers the included sample avatar.

To rebuild the example from the package:

```bash
cmake -S . -B build
cmake --build build --config Release
```

## Use the SDK

```cpp
#include "rebocap_ws_sdk_cpp.h"
#include <chrono>
#include <thread>

int main() {
    rebocap::RebocapWsSdk sdk(UnityCoordinate, true);
    sdk.SetPoseMsgCallback([](const QuatMsg* msg, rebocap::RebocapWsSdk*) {
        // msg->trans[0..2], msg->quat[0..95], msg->tp
    });
    int result = sdk.OpenRemote("192.168.1.100", 7690);
    if (result == 0) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        QuatMsg latest{};
        if (sdk.GetLastMsg(&latest) == 0) { /* use the latest frame */ }
    }
    sdk.Close();
}
```

`OpenRemote(host, port, name, uid)` selects the host for one instance. `Open(port)` uses `REBOCAP_WS_HOST` if set, otherwise `localhost`. A UID of `0` selects a fresh random positive UID for each connection; nonzero UIDs are used as supplied. Concurrent clients should use different UIDs.

`Open` returns `0` for success, `1` for an invalid connection state, `2` for a connection failure, and `3` for authentication failure. The protocol does not send a separate authentication-success response: success means the server did not reject the connection during a short wait. Confirm that pose data is arriving through the callback or `GetLastMsg`.

Callbacks run on an SDK worker thread and may occur before `Open` returns. Dispatch UI updates and SDK close or release operations to the calling thread.

## Pose data

`trans[3]` is the pelvis position. `quat[96]` contains 24 quaternions in `[x, y, z, w]` order. `tp` is a Unix timestamp in milliseconds. The constructor selects the coordinate system and global or local rotation. Joint order:

```text
Pelvis, L_Hip, R_Hip, Spine1, L_Knee, R_Knee, Spine2, L_Ankle,
R_Ankle, Spine3, L_Foot, R_Foot, Neck, L_Collar, R_Collar, Head,
L_Shoulder, R_Shoulder, L_Elbow, R_Elbow, L_Wrist, R_Wrist, L_Hand, R_Hand
```

`static_index` is `-1` when no contact is detected. Values `0–5` identify left-foot points and `6–11` right-foot points; within each foot the order is forefoot left/center/right, then heel left/center/right.
