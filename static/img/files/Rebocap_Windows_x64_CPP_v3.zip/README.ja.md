# Rebocap WebSocket C++ SDK

[English](README.md) | [简体中文](README.zh-CN.md) | 日本語

Rebocap Host から骨盤の位置、24 関節の回転、足裏の接地データを受信します。Windows x64 と Linux x86-64 用のパッケージを用意しています。サンプルのビルドには C++17 が必要です。

- **Windows:** Microsoft Visual C++ 2015–2022 x64 ランタイムをインストールし、`rebocap_ws_sdk.dll` をアプリケーションの隣か DLL 検索パスに配置してください。
- **Linux:** パッケージは Ubuntu 22.04 x86-64 でビルド・テストしており、`GLIBC_2.34` と `GLIBCXX_3.4.29` 以上が必要です。`librebocap_ws_sdk_cpp.so` をサンプルの隣に配置してください。

## サンプルの実行

Rebocap で WebSocket 出力を有効にし、ポート番号を確認します。通常は `7690` です。パッケージを展開して実行します。

```powershell
.\rebocap_ws_sdk_cpp_example.exe --host 127.0.0.1 --port 7690
.\rebocap_ws_sdk_cpp_example.exe --host 192.168.1.100 --port 7690 --seconds 10
```

Linux では `./rebocap_ws_sdk_cpp_example --host HOST --port 7690` を実行します。`HOST` には Rebocap を実行するコンピューターのホスト名または IP を指定してください。リモート接続では、サービスが到達可能なインターフェースで待ち受け、ファイアウォールがポートを許可している必要があります。WSL2 から Windows Host に接続する場合は WSL のゲートウェイアドレスを使用できます。サンプルでは `--uid N` と、同梱のサンプルアバターを登録する `--register-avatar` も指定できます。

パッケージ内のサンプルを再ビルドするには、次を実行します。

```bash
cmake -S . -B build
cmake --build build --config Release
```

## SDK の使用

```cpp
#include "rebocap_ws_sdk_cpp.h"
#include <chrono>
#include <thread>

int main() {
    rebocap::RebocapWsSdk sdk(UnityCoordinate, true);
    sdk.SetPoseMsgCallback([](const QuatMsg* msg, rebocap::RebocapWsSdk*) {
        // msg->trans[0..2], msg->quat[0..95], msg->tp
    });
    int result = sdk.OpenRemote("192.168.1.100", 7690);
    if (result == 0) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        QuatMsg latest{};
        if (sdk.GetLastMsg(&latest) == 0) { /* 最新フレームを使用 */ }
    }
    sdk.Close();
}
```

`OpenRemote(host, port, name, uid)` はインスタンスごとに接続先を指定します。`Open(port)` は環境変数 `REBOCAP_WS_HOST` を優先し、未設定の場合は `localhost` を使用します。UID が `0` の場合は接続ごとに正の乱数を生成し、0 以外は指定どおりに使用します。同時接続するクライアントには異なる UID を指定してください。

`Open` の戻り値は、成功が `0`、接続状態のエラーが `1`、接続失敗が `2`、認証失敗が `3` です。プロトコルに認証成功の個別応答はなく、成功は短い待機時間内にサーバーから拒否されなかったことを意味します。姿勢データの到着はコールバックまたは `GetLastMsg` で確認してください。

コールバックは SDK のワーカースレッドで実行され、`Open` が戻る前に呼ばれる場合があります。UI の更新や SDK の切断・解放は呼び出し元のスレッドで行ってください。

## 姿勢データ

`trans[3]` は骨盤位置、`quat[96]` は `[x, y, z, w]` 順の 24 個のクォータニオン、`tp` は Unix ミリ秒のタイムスタンプです。コンストラクターで座標系とグローバル／ローカル回転を選択します。関節の順序は次のとおりです。

```text
Pelvis, L_Hip, R_Hip, Spine1, L_Knee, R_Knee, Spine2, L_Ankle,
R_Ankle, Spine3, L_Foot, R_Foot, Neck, L_Collar, R_Collar, Head,
L_Shoulder, R_Shoulder, L_Elbow, R_Elbow, L_Wrist, R_Wrist, L_Hand, R_Hand
```

`static_index` は接地が検出されない場合に `-1`、左足が `0～5`、右足が `6～11` です。各足の順序は前足部の左・中央・右、かかとの左・中央・右です。
