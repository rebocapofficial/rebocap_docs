﻿#include "rebocap_ws_sdk_cpp.h"
#include <chrono>
#include <thread>
#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include <filesystem>
#include <string>
#include "nlohmann/json.hpp"

void parseVertexData(const std::string& filePath,
               std::vector<std::array<float, 3>>& all_left_vertex,
               std::vector<std::array<float, 3>>& all_left_normals,
               std::vector<std::array<float, 3>>& all_right_vertex,
               std::vector<std::array<float, 3>>& all_right_normals,
               std::vector<std::array<float, 3>>& skeletons) {
    // 读取json文件
    std::ifstream file(filePath);
    nlohmann::json j;
    file >> j;

    // 解析left_foot_vertex
    for (const auto& item : j["left_foot_vertex"].items()) {
        auto temp_v = item.value().get<std::vector<std::array<float, 3>>>();
        all_left_vertex.push_back(temp_v[0]);
        all_left_normals.push_back(temp_v[1]);
    }

    // 解析right_foot_vertex
    for (const auto& item : j["right_foot_vertex"].items()) {
        auto temp_v = item.value().get<std::vector<std::array<float, 3>>>();
        all_right_vertex.push_back(temp_v[0]);
        all_right_normals.push_back(temp_v[1]);
    }

    // 解析skeleton
    for (const auto& array : j["skeleton"]) {
        skeletons.push_back({array[0], array[1], array[2]});
    }
}

int main(int argc, char** argv) {
  std::string host = "localhost";
  unsigned port = 7690;
  int seconds = 10;
  int64_t uid = 0;
  bool register_avatar = false;
  try {
    for (int i = 1; i < argc; ++i) {
      std::string arg = argv[i];
      if (arg == "--host" && i + 1 < argc) host = argv[++i];
      else if (arg == "--port" && i + 1 < argc) port = std::stoul(argv[++i]);
      else if (arg == "--seconds" && i + 1 < argc) seconds = std::stoi(argv[++i]);
      else if (arg == "--uid" && i + 1 < argc) uid = std::stoll(argv[++i]);
      else if (arg == "--register-avatar") register_avatar = true;
      else { std::cerr << "Usage: example [--host HOST] [--port PORT] [--seconds N] [--uid N] [--register-avatar]\n"; return 2; }
    }
    if (port == 0 || port > 65535 || seconds < 1) throw std::invalid_argument("invalid port or duration");
    rebocap::RebocapWsSdk sdk(DefaultCoordinate, true);
    sdk.SetPoseMsgCallback([](const QuatMsg *msg, rebocap::RebocapWsSdk *) {
      static unsigned count = 0;
      if (count++ % 60 == 0) {
        std::cout << "pose trans=[" << msg->trans[0] << ", " << msg->trans[1] << ", " << msg->trans[2]
                  << "] root_quat_xyzw=[" << msg->quat[0] << ", " << msg->quat[1] << ", "
                  << msg->quat[2] << ", " << msg->quat[3] << "] timestamp_ms=" << msg->tp << std::endl;
      }
    });
    sdk.SetExceptionCloseCallback([](rebocap::RebocapWsSdk *) { std::cerr << "Connection closed unexpectedly" << std::endl; });
    int result = sdk.OpenRemote(host, port, "reborn_app", uid);
    if (result != 0) { std::cerr << "Connection failed: " << result << std::endl; return 1; }
    std::cout << "Connected to " << host << ":" << port << std::endl;
    if (register_avatar) {
      std::vector<std::array<float, 3>> lv, ln, rv, rn, skeleton, feet;
      auto path = std::filesystem::absolute(argv[0]).parent_path() / "sample_data" / "avatar_parsed_data.json";
      parseVertexData(path.string(), lv, ln, rv, rn, skeleton);
      result = sdk.CalculateAndRegisterToRebocap(lv, ln, rv, rn, skeleton, "-xy-z", feet);
      std::cout << "Avatar registration result: " << result << ", vertices: " << feet.size() << std::endl;
    }
    std::this_thread::sleep_for(std::chrono::seconds(seconds));
    QuatMsg latest{};
    if (sdk.GetLastMsg(&latest) == 0) std::cout << "Last frame timestamp_ms=" << latest.tp << std::endl;
    else std::cout << "No pose frame received yet" << std::endl;
    sdk.Close();
    return 0;
  } catch (const std::exception& e) { std::cerr << "Error: " << e.what() << std::endl; return 2; }
}
