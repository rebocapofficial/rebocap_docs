# Rebocap WebSocket Python SDK

[English](README.md) | [简体中文](README.zh-CN.md) | 日本語

Rebocap Host から骨盤の位置、24 関節の回転、足裏の接地データを受信します。パッケージは **標準の 64 ビット CPython 3.6～3.14** に対応します。Python のバージョンごとに SDK を用意する必要はなく、各プラットフォームにつき一つの安定 ABI 拡張を使用します。フリースレッド版 Python、その他のアーキテクチャー、macOS は未検証です。

- **Windows x64:** Microsoft Visual C++ 2015–2022 x64 ランタイムが必要です。パッケージには拡張と対応するネイティブ DLL が一つずつ含まれます。
- **Linux x86-64:** Ubuntu 22.04 でビルド・テストしており、`GLIBC_2.34` と `GLIBCXX_3.4.29` 以上が必要です。パッケージには一つの `abi3` 拡張が含まれます。

## サンプルの実行

Rebocap で WebSocket 出力を有効にし、ポート番号を確認します。通常は `7690` です。パッケージを展開して実行します。

```bash
python rebocap_ws_sdk_example.py --host 127.0.0.1 --port 7690
python rebocap_ws_sdk_example_with_class.py --host 192.168.1.100 --port 7690 --seconds 10
```

`--host` には Rebocap を実行するコンピューターのホスト名または IP を指定してください。リモート接続では、サービスが到達可能なインターフェースで待ち受け、ファイアウォールがポートを許可している必要があります。WSL2 から Windows Host に接続する場合は WSL のゲートウェイアドレスを使用できます。`pose` が継続して表示されれば、モーションデータを受信しています。

## SDK の使用

`rebocap_ws_sdk` ディレクトリをプロジェクトにコピーするか、その親ディレクトリを `PYTHONPATH` に追加してください。

```python
import time
import rebocap_ws_sdk

def on_pose(sdk, trans, pose24, static_index, timestamp_s):
    print(timestamp_s, trans, pose24[0])

sdk = rebocap_ws_sdk.RebocapWsSdk(
    rebocap_ws_sdk.CoordinateType.UnityCoordinate, use_global_rotation=True)
sdk.set_pose_msg_callback(on_pose)
sdk.set_exception_close_callback(lambda sdk: print("接続が切断されました"))
result = sdk.open(7690, host="192.168.1.100", uid=0)
if result != 0:
    raise RuntimeError("接続失敗: {}".format(result))
try:
    time.sleep(10)
    latest = sdk.get_last_msg()  # 最初のフレームを受信するまでは None
finally:
    sdk.close()
```

`host=None` の場合は環境変数 `REBOCAP_WS_HOST` を優先し、未設定の場合は `localhost` を使用します。UID が `0` または未指定の場合は接続ごとに正の乱数を生成し、0 以外は指定どおりに使用します。同時接続するクライアントには異なる UID を指定してください。`name` の既定値は `reborn_app` です。

`open()` の戻り値は、成功が `0`、接続状態のエラーが `1`、接続失敗が `2`、認証失敗が `3` です。プロトコルに認証成功の個別応答はなく、成功は短い待機時間内にサーバーから拒否されなかったことを意味します。姿勢データの到着はコールバックまたは `get_last_msg()` で確認してください。

コールバックは SDK のワーカースレッドで実行され、`open()` が戻る前に呼ばれる場合があります。UI の更新や SDK の切断・解放は呼び出し元のスレッドで行ってください。

## 姿勢データ

- `trans`: 選択した `CoordinateType` における骨盤位置 `[x, y, z]`。
- `pose24`: `[x, y, z, w]` 順の 24 個のクォータニオン。`use_global_rotation` でグローバルまたはローカル回転を選択します。関節の順序は `rebocap_ws_sdk.REBOCAP_JOINT_NAMES` を参照してください。
- `static_index`: 接地が検出されない場合は `-1`、左足は `0～5`、右足は `6～11` です。各足の順序は前足部の左・中央・右、かかとの左・中央・右です。
- コールバックの `timestamp_s` は Unix 秒です。`get_last_msg()` は `(trans, pose24, static_index, timestamp_ms)` を返し、タイムスタンプは Unix ミリ秒です。最初のフレームを受信するまでは `None` を返します。

Host でモーションを再生中に `python verify_live.py --host HOST --port 7690` を実行すると、コールバック、クォータニオン、タイムスタンプを確認できます。スクリプトは接続して短時間データを受信した後、切断します。
