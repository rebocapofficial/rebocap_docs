import argparse
import time
import rebocap_ws_sdk


counter = 0

def pose_callback(sdk, trans, pose24, static_index, timestamp):
    global counter
    counter += 1
    if counter % 60 != 1:
        return
    print("pose time_s={} trans={} root_quat_xyzw={} contact={}".format(
        timestamp, trans, pose24[0], static_index), flush=True)


def main():
    parser = argparse.ArgumentParser(description="Rebocap WebSocket SDK example")
    parser.add_argument("--host", default="localhost", help="Rebocap computer hostname or IP")
    parser.add_argument("--port", type=int, default=7690)
    parser.add_argument("--seconds", type=float, default=10)
    args = parser.parse_args()
    sdk = rebocap_ws_sdk.RebocapWsSdk(rebocap_ws_sdk.CoordinateType.UnityCoordinate, use_global_rotation=True)
    sdk.set_pose_msg_callback(pose_callback)
    sdk.set_exception_close_callback(lambda sdk: print("Connection closed unexpectedly", flush=True))
    result = sdk.open(args.port, host=args.host)
    if result != 0:
        print("Connection failed:", result)
        return 1
    try:
        print("Connected to {}:{}".format(args.host, args.port), flush=True)
        time.sleep(args.seconds)
        latest = sdk.get_last_msg()
        print("Last frame timestamp_ms={}".format(latest[3]) if latest else "No pose frame received yet")
    finally:
        sdk.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
