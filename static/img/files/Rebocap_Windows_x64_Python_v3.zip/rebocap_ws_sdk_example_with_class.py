import argparse
import time
import rebocap_ws_sdk


class SDKManager:
    def __init__(self, host="localhost", port=7690):
        self.host, self.port = host, port
        self.connected = False
        self.counter = 0
        self.sdk = rebocap_ws_sdk.RebocapWsSdk(rebocap_ws_sdk.CoordinateType.UnityCoordinate)
        self.sdk.set_pose_msg_callback(self.on_msg_recv)
        self.sdk.set_exception_close_callback(self.on_exception_close)

    def on_exception_close(self, sdk):
        self.connected = False
        print("Connection closed unexpectedly", flush=True)

    def on_msg_recv(self, sdk, trans, pose24, static_index, timestamp):
        self.counter += 1
        if self.counter % 60 != 1:
            return
        print("pose time_s={} trans={} root_quat_xyzw={}".format(timestamp, trans, pose24[0]), flush=True)

    def open_connect(self):
        if self.connected:
            return -10
        result = self.sdk.open(self.port, host=self.host)
        self.connected = result == 0
        return result

    def stop_connect(self):
        self.sdk.close()
        self.connected = False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=7690)
    parser.add_argument("--seconds", type=float, default=10)
    args = parser.parse_args()
    manager = SDKManager(args.host, args.port)
    result = manager.open_connect()
    if result:
        print("Connection failed:", result)
        return 1
    try:
        print("Connected to {}:{}".format(args.host, args.port), flush=True)
        time.sleep(args.seconds)
    finally:
        manager.stop_connect()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
