"""Exercise an installed SDK against a running Rebocap WebSocket host."""

import argparse
import json
import math
import sys
import threading
import time

import rebocap_ws_sdk


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=7690)
    parser.add_argument("--seconds", type=float, default=1.2)
    parser.add_argument("--cycles", type=int, default=1)
    args = parser.parse_args()
    lock = threading.Lock()
    frames = []
    disconnects = []

    def on_pose(sdk, trans, pose, contact, timestamp):
        with lock:
            frames.append((trans, pose, contact, timestamp))

    sdk = rebocap_ws_sdk.RebocapWsSdk(
        rebocap_ws_sdk.CoordinateType.UnityCoordinate, use_global_rotation=True)
    sdk.set_pose_msg_callback(on_pose)
    sdk.set_exception_close_callback(lambda sdk: disconnects.append(True))
    if sdk.get_last_msg() is not None:
        raise AssertionError("new client unexpectedly has a frame")

    for cycle in range(args.cycles):
        with lock:
            frames.clear()
        result = sdk.open(args.port, host=args.host)
        if result != 0:
            raise AssertionError("open returned {} on cycle {}".format(result, cycle))
        try:
            if sdk.open(args.port, host=args.host) != 1:
                raise AssertionError("opening an already connected client should fail")
            time.sleep(args.seconds)
            latest = sdk.get_last_msg()
            with lock:
                received = list(frames)
            if len(received) < 10 or latest is None:
                raise AssertionError("insufficient pose data: {} frames".format(len(received)))
            if disconnects:
                raise AssertionError("connection closed unexpectedly")
            for trans, pose, contact, timestamp in (received[0], received[-1]):
                if len(trans) != 3 or len(pose) != 24 or any(len(q) != 4 for q in pose):
                    raise AssertionError("unexpected pose dimensions")
                if not all(math.isfinite(v) for v in trans + [v for q in pose for v in q]):
                    raise AssertionError("pose contains a non-finite value")
                if any(abs(sum(v * v for v in q) - 1.0) > 0.01 for q in pose):
                    raise AssertionError("pose quaternion is not normalized")
                if abs(time.time() - timestamp) > 30:
                    raise AssertionError("callback timestamp is not current seconds")
            if received[-1][3] <= received[0][3]:
                raise AssertionError("frame timestamps did not advance")
            if not any(a != b for a, b in zip(received[0][1][0], received[-1][1][0])):
                raise AssertionError("root rotation did not change during playback")
            if len(latest[0]) != 3 or len(latest[1]) != 24 or abs(time.time() - latest[3] / 1000.0) > 30:
                raise AssertionError("latest frame has an invalid shape or timestamp")
            print(json.dumps({"python": sys.version.split()[0], "host": args.host,
                              "cycle": cycle + 1, "frames": len(received),
                              "first_timestamp_s": received[0][3],
                              "last_timestamp_s": received[-1][3],
                              "latest_timestamp_ms": latest[3]}), flush=True)
        finally:
            sdk.close()


if __name__ == "__main__":
    main()
