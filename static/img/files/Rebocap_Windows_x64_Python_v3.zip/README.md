# Rebocap WebSocket Python SDK

English | [简体中文](README.zh-CN.md) | [日本語](README.ja.md)

Receive pelvis translation, 24 joint rotations, and foot-contact data from the Rebocap Host. The packages support **standard 64-bit CPython 3.6–3.14**. Each platform uses one stable-ABI extension rather than a separate SDK for each Python version. Free-threaded Python, other architectures, and macOS have not been tested.

- **Windows x64:** requires the Microsoft Visual C++ 2015–2022 x64 runtime. The package contains one extension and its native DLL.
- **Linux x86-64:** built and tested on Ubuntu 22.04; requires at least `GLIBC_2.34` and `GLIBCXX_3.4.29`. The package contains one `abi3` extension.

## Run the examples

Enable WebSocket output in Rebocap and check its port, normally `7690`. From the extracted package, run:

```bash
python rebocap_ws_sdk_example.py --host 127.0.0.1 --port 7690
python rebocap_ws_sdk_example_with_class.py --host 192.168.1.100 --port 7690 --seconds 10
```

Replace `--host` with the hostname or IP of the computer running Rebocap. For a remote host, make sure the service listens on a reachable interface and the firewall permits the port. A WSL2 client can use the Windows host's WSL gateway address. Repeated `pose` lines indicate that motion data is arriving.

## Use the SDK

Copy the `rebocap_ws_sdk` directory into your project or add its parent directory to `PYTHONPATH`:

```python
import time
import rebocap_ws_sdk

def on_pose(sdk, trans, pose24, static_index, timestamp_s):
    print(timestamp_s, trans, pose24[0])

sdk = rebocap_ws_sdk.RebocapWsSdk(
    rebocap_ws_sdk.CoordinateType.UnityCoordinate, use_global_rotation=True)
sdk.set_pose_msg_callback(on_pose)
sdk.set_exception_close_callback(lambda sdk: print("Connection lost"))
result = sdk.open(7690, host="192.168.1.100", uid=0)
if result != 0:
    raise RuntimeError("Connection failed: {}".format(result))
try:
    time.sleep(10)
    latest = sdk.get_last_msg()  # None until the first pose frame arrives
finally:
    sdk.close()
```

When `host=None`, the SDK uses `REBOCAP_WS_HOST` if set, otherwise `localhost`. When `uid=0` or the UID is omitted, each connection receives a fresh random positive UID; nonzero UIDs are used as supplied. Concurrent clients should use different UIDs. The default `name` is `reborn_app`.

`open()` returns `0` for success, `1` for an invalid connection state, `2` for a connection failure, and `3` for authentication failure. The protocol does not send a separate authentication-success response: success means the server did not reject the connection during a short wait. Confirm that pose data is arriving through the callback or `get_last_msg()`.

Callbacks run on an SDK worker thread and may occur before `open()` returns. Dispatch UI updates and SDK close or release operations to the calling thread.

## Pose data

- `trans`: pelvis position `[x, y, z]` in the selected `CoordinateType`.
- `pose24`: 24 quaternions, each in `[x, y, z, w]` order. `use_global_rotation` selects global or local rotations. See `rebocap_ws_sdk.REBOCAP_JOINT_NAMES` for the joint order.
- `static_index`: `-1` means no contact; `0–5` are left-foot points and `6–11` are right-foot points. Within each foot the order is forefoot left/center/right, then heel left/center/right.
- The callback's `timestamp_s` is Unix seconds. `get_last_msg()` returns `(trans, pose24, static_index, timestamp_ms)`, where the timestamp is Unix milliseconds, or `None` before the first frame.

With the host playing motion, run `python verify_live.py --host HOST --port 7690` to check callbacks, quaternions, and timestamps. The script connects, receives a short stream, and disconnects.
