# Rebocap WebSocket C# SDK

English | [简体中文](README.zh-CN.md) | [日本語](README.ja.md)

Receive pelvis translation, 24 joint rotations, and foot-contact data from the Rebocap Host. This package targets **Windows x64**. The example uses .NET Framework 4.8 and requires the Microsoft Visual C++ 2015–2022 x64 runtime. Run your application as x64 and place `rebocap_ws_sdk.dll` in its output directory.

## Run the example

Enable WebSocket output in Rebocap and check its port, normally `7690`. From the extracted package, run:

```powershell
.\RebocapWsSdkExample.exe --host 127.0.0.1 --port 7690
.\RebocapWsSdkExample.exe --host 192.168.1.100 --port 7690 --seconds 10
```

Replace `--host` with the hostname or IP of the computer running Rebocap. For a remote host, make sure the service listens on a reachable interface and the firewall permits the port. The example accepts `--uid N`; `--register-avatar` registers the included sample avatar. Open the included `.csproj` in Visual Studio to rebuild the example.

## Use the SDK

Add `RebocapWsSdk.cs` to your project and copy `rebocap_ws_sdk.dll` to the application output directory:

```csharp
using System;
using System.Threading;
using RebocapWsSdk;

class Example
{
    static void Main()
    {
        using (var sdk = new RebocapWsSdk.RebocapWsSdk(CoordinateSpaceType.UnityCoordinate, true))
        {
            sdk.SetPoseMsgCallback((msg, self) =>
                Console.WriteLine("{0:o}: {1}", msg.Tp, msg.Trans[0]));
            sdk.SetExceptionCloseCallback(self => Console.WriteLine("Connection lost"));
            int result = sdk.Open(7690, host: "192.168.1.100", uid: 0);
            if (result != 0) throw new Exception("Connection failed: " + result);
            Thread.Sleep(10000);
            var latest = new PoseMsg();
            if (sdk.GetLastMsg(ref latest) == 0) { /* use the latest frame */ }
        }
    }
}
```

When `host` is omitted, the SDK uses `REBOCAP_WS_HOST` if set, otherwise `localhost`. A UID of `0` selects a fresh random positive UID for each connection; nonzero UIDs are used as supplied. Concurrent clients should use different UIDs. The default `name` is `reborn_app`.

`Open` returns `0` for success, `1` for an invalid connection state, `2` for a connection failure, and `3` for authentication failure. The protocol does not send a separate authentication-success response: success means the server did not reject the connection during a short wait. Confirm that pose data is arriving through the callback or `GetLastMsg`.

Callbacks run on an SDK worker thread and may occur before `Open` returns. Dispatch UI updates and SDK close or disposal operations to the calling thread.

## Pose data

`Trans` is the pelvis position `[x, y, z]`. `Pose24` contains 24 quaternions in `[x, y, z, w]` order. `Tp` is a UTC `DateTime`. The constructor selects the coordinate system and global or local rotation. Joint order:

```text
Pelvis, L_Hip, R_Hip, Spine1, L_Knee, R_Knee, Spine2, L_Ankle,
R_Ankle, Spine3, L_Foot, R_Foot, Neck, L_Collar, R_Collar, Head,
L_Shoulder, R_Shoulder, L_Elbow, R_Elbow, L_Wrist, R_Wrist, L_Hand, R_Hand
```

`StaticIndex` is `-1` when no contact is detected. Values `0–5` identify left-foot points and `6–11` right-foot points; within each foot the order is forefoot left/center/right, then heel left/center/right.
