using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Web.Script.Serialization;
using RebocapWsSdk;

namespace RebocapWsSdkExample
{
    internal static class Program
    {
        private static UVector3 ReadVector(object value)
        {
            var a = (IList)value;
            return new UVector3(Convert.ToDouble(a[0]), Convert.ToDouble(a[1]), Convert.ToDouble(a[2]));
        }
        private static void ReadFoot(object value, List<UVector3> vertices, List<UVector3> normals)
        {
            var dict = (Dictionary<string, object>)value;
            foreach (var pair in dict)
            {
                var item = (IList)pair.Value;
                vertices.Add(ReadVector(item[0]));
                normals.Add(ReadVector(item[1]));
            }
        }
        private static int RegisterSample(RebocapWsSdk.RebocapWsSdk sdk)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "avatar_parsed_data.json");
            var parser = new JavaScriptSerializer { MaxJsonLength = 16 * 1024 * 1024 };
            var data = parser.Deserialize<Dictionary<string, object>>(File.ReadAllText(path));
            var left = new List<UVector3>(); var leftNormals = new List<UVector3>();
            var right = new List<UVector3>(); var rightNormals = new List<UVector3>();
            var skeleton = new List<UVector3>(); var output = new List<UVector3>();
            ReadFoot(data["left_foot_vertex"], left, leftNormals);
            ReadFoot(data["right_foot_vertex"], right, rightNormals);
            foreach (object item in (IList)data["skeleton"]) skeleton.Add(ReadVector(item));
            int result = sdk.CalculateFootVertexAndRegisterAvatar(skeleton, left, right, leftNormals, rightNormals, output, "-xy-z");
            Console.WriteLine("Avatar registration result: {0}, vertices: {1}", result, output.Count);
            return result;
        }
        private static int Main(string[] args)
        {
            string host = "localhost"; uint port = 7690; int seconds = 10; bool registerAvatar = false;
            long uid = 0;
            try
            {
                for (int i = 0; i < args.Length; i++)
                {
                    if (args[i] == "--host" && i + 1 < args.Length) host = args[++i];
                    else if (args[i] == "--port" && i + 1 < args.Length) port = uint.Parse(args[++i]);
                    else if (args[i] == "--seconds" && i + 1 < args.Length) seconds = int.Parse(args[++i]);
                    else if (args[i] == "--uid" && i + 1 < args.Length) uid = long.Parse(args[++i]);
                    else if (args[i] == "--register-avatar") registerAvatar = true;
                    else { Console.Error.WriteLine("Usage: example [--host HOST] [--port PORT] [--seconds N] [--uid N] [--register-avatar]"); return 2; }
                }
                if (port == 0 || port > 65535 || seconds < 1) throw new ArgumentException("Invalid port or duration");
                using (var sdk = new RebocapWsSdk.RebocapWsSdk(CoordinateSpaceType.UnityCoordinate, true))
                {
                    int count = 0;
                    sdk.SetPoseMsgCallback((msg, self) => {
                        if (count++ % 60 == 0)
                            Console.WriteLine("pose trans=[{0}, {1}, {2}] root_quat_xyzw=[{3}, {4}, {5}, {6}] timestamp={7:o}",
                                msg.Trans[0], msg.Trans[1], msg.Trans[2], msg.Pose24[0,0], msg.Pose24[0,1], msg.Pose24[0,2], msg.Pose24[0,3], msg.Tp);
                    });
                    sdk.SetExceptionCloseCallback(self => Console.WriteLine("Connection closed unexpectedly"));
                    int result = sdk.Open(port, uid: uid, host: host);
                    if (result != 0) { Console.Error.WriteLine("Connection failed: " + result); return 1; }
                    Console.WriteLine("Connected to {0}:{1}", host, port);
                    if (registerAvatar) RegisterSample(sdk);
                    Thread.Sleep(checked(seconds * 1000));
                    var latest = new PoseMsg();
                    if (sdk.GetLastMsg(ref latest) == 0) Console.WriteLine("Last frame: " + latest.Tp.ToString("o"));
                    else Console.WriteLine("No pose frame received yet");
                }
                return 0;
            }
            catch (Exception e) { Console.Error.WriteLine("Error: " + e.Message); return 2; }
        }
    }
}
