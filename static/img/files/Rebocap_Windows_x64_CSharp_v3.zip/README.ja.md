# Rebocap WebSocket C# SDK

[English](README.md) | [简体中文](README.zh-CN.md) | 日本語

Rebocap Host から骨盤の位置、24 関節の回転、足裏の接地データを受信します。このパッケージは **Windows x64** 向けです。サンプルは .NET Framework 4.8 を使用し、Microsoft Visual C++ 2015–2022 x64 ランタイムが必要です。アプリケーションを x64 で実行し、`rebocap_ws_sdk.dll` を出力ディレクトリに配置してください。

## サンプルの実行

Rebocap で WebSocket 出力を有効にし、ポート番号を確認します。通常は `7690` です。パッケージを展開して実行します。

```powershell
.\RebocapWsSdkExample.exe --host 127.0.0.1 --port 7690
.\RebocapWsSdkExample.exe --host 192.168.1.100 --port 7690 --seconds 10
```

`--host` には Rebocap を実行するコンピューターのホスト名または IP を指定してください。リモート接続では、サービスが到達可能なインターフェースで待ち受け、ファイアウォールがポートを許可している必要があります。サンプルでは `--uid N` と、同梱のサンプルアバターを登録する `--register-avatar` を指定できます。同梱の `.csproj` を Visual Studio で開くと、サンプルを再ビルドできます。

## SDK の使用

`RebocapWsSdk.cs` をプロジェクトに追加し、`rebocap_ws_sdk.dll` をアプリケーションの出力ディレクトリにコピーします。

```csharp
using System;
using System.Threading;
using RebocapWsSdk;

class Example
{
    static void Main()
    {
        using (var sdk = new RebocapWsSdk.RebocapWsSdk(CoordinateSpaceType.UnityCoordinate, true))
        {
            sdk.SetPoseMsgCallback((msg, self) =>
                Console.WriteLine("{0:o}: {1}", msg.Tp, msg.Trans[0]));
            sdk.SetExceptionCloseCallback(self => Console.WriteLine("接続が切断されました"));
            int result = sdk.Open(7690, host: "192.168.1.100", uid: 0);
            if (result != 0) throw new Exception("接続失敗: " + result);
            Thread.Sleep(10000);
            var latest = new PoseMsg();
            if (sdk.GetLastMsg(ref latest) == 0) { /* 最新フレームを使用 */ }
        }
    }
}
```

`host` を省略すると環境変数 `REBOCAP_WS_HOST` を優先し、未設定の場合は `localhost` を使用します。UID が `0` の場合は接続ごとに正の乱数を生成し、0 以外は指定どおりに使用します。同時接続するクライアントには異なる UID を指定してください。`name` の既定値は `reborn_app` です。

`Open` の戻り値は、成功が `0`、接続状態のエラーが `1`、接続失敗が `2`、認証失敗が `3` です。プロトコルに認証成功の個別応答はなく、成功は短い待機時間内にサーバーから拒否されなかったことを意味します。姿勢データの到着はコールバックまたは `GetLastMsg` で確認してください。

コールバックは SDK のワーカースレッドで実行され、`Open` が戻る前に呼ばれる場合があります。UI の更新や SDK の切断・解放は呼び出し元のスレッドで行ってください。

## 姿勢データ

`Trans` は骨盤位置 `[x, y, z]`、`Pose24` は `[x, y, z, w]` 順の 24 個のクォータニオン、`Tp` は UTC の `DateTime` です。コンストラクターで座標系とグローバル／ローカル回転を選択します。関節の順序は次のとおりです。

```text
Pelvis, L_Hip, R_Hip, Spine1, L_Knee, R_Knee, Spine2, L_Ankle,
R_Ankle, Spine3, L_Foot, R_Foot, Neck, L_Collar, R_Collar, Head,
L_Shoulder, R_Shoulder, L_Elbow, R_Elbow, L_Wrist, R_Wrist, L_Hand, R_Hand
```

`StaticIndex` は接地が検出されない場合に `-1`、左足が `0～5`、右足が `6～11` です。各足の順序は前足部の左・中央・右、かかとの左・中央・右です。
