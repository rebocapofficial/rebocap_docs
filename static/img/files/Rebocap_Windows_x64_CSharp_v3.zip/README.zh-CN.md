# Rebocap WebSocket C# SDK

[English](README.md) | 简体中文 | [日本語](README.ja.md)

从 Rebocap Host 接收骨盆平移、24 个关节旋转和脚底接触数据。本包适用于 **Windows x64**。示例使用 .NET Framework 4.8，需要 Microsoft Visual C++ 2015–2022 x64 运行库。应用应以 x64 运行，并将 `rebocap_ws_sdk.dll` 放入输出目录。

## 运行示例

在 Rebocap 中启用 WebSocket 输出并确认端口，通常为 `7690`。解压后运行：

```powershell
.\RebocapWsSdkExample.exe --host 127.0.0.1 --port 7690
.\RebocapWsSdkExample.exe --host 192.168.1.100 --port 7690 --seconds 10
```

将 `--host` 换成运行 Rebocap 的电脑名或 IP。远程连接时，请确认服务监听可访问的网络接口且防火墙允许该端口。示例支持 `--uid N`；`--register-avatar` 会注册包内的示例角色。可在 Visual Studio 中打开包内 `.csproj` 重新构建示例。

## 使用 SDK

将 `RebocapWsSdk.cs` 加入项目，并将 `rebocap_ws_sdk.dll` 复制到应用输出目录：

```csharp
using System;
using System.Threading;
using RebocapWsSdk;

class Example
{
    static void Main()
    {
        using (var sdk = new RebocapWsSdk.RebocapWsSdk(CoordinateSpaceType.UnityCoordinate, true))
        {
            sdk.SetPoseMsgCallback((msg, self) =>
                Console.WriteLine("{0:o}: {1}", msg.Tp, msg.Trans[0]));
            sdk.SetExceptionCloseCallback(self => Console.WriteLine("连接异常中断"));
            int result = sdk.Open(7690, host: "192.168.1.100", uid: 0);
            if (result != 0) throw new Exception("连接失败: " + result);
            Thread.Sleep(10000);
            var latest = new PoseMsg();
            if (sdk.GetLastMsg(ref latest) == 0) { /* 使用最近一帧 */ }
        }
    }
}
```

未指定 `host` 时优先使用环境变量 `REBOCAP_WS_HOST`，未设置时使用 `localhost`。UID 为 `0` 时每次连接自动生成随机正整数；非零 UID 按传入值使用。同时在线的客户端应使用不同 UID。`name` 默认为 `reborn_app`。

`Open` 返回 `0` 表示成功，`1` 表示连接状态错误，`2` 表示连接失败，`3` 表示认证失败。协议没有独立的认证成功应答：返回成功表示服务端在短暂等待期间未拒绝连接。请通过回调或 `GetLastMsg` 确认是否收到姿态数据。

回调由 SDK 工作线程执行，可能在 `Open` 返回前触发。请将界面更新以及关闭或释放 SDK 的操作交回调用线程。

## 姿态数据

`Trans` 是骨盆位置 `[x, y, z]`，`Pose24` 包含 24 个按 `[x, y, z, w]` 排列的四元数，`Tp` 是 UTC `DateTime`。构造参数用于选择坐标系和全局或局部旋转。关节顺序如下：

```text
Pelvis, L_Hip, R_Hip, Spine1, L_Knee, R_Knee, Spine2, L_Ankle,
R_Ankle, Spine3, L_Foot, R_Foot, Neck, L_Collar, R_Collar, Head,
L_Shoulder, R_Shoulder, L_Elbow, R_Elbow, L_Wrist, R_Wrist, L_Hand, R_Hand
```

`StaticIndex=-1` 表示未检测到接触点；`0–5` 对应左脚，`6–11` 对应右脚。每只脚按前掌左、中、右以及后跟左、中、右排列。
