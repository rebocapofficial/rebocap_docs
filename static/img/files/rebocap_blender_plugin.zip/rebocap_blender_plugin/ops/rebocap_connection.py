import time
from threading import Thread

import atexit
import bpy
from mathutils import Vector, Matrix, Quaternion, Euler
from ..rebocap_api import *
from typing import Optional
from ..rebocap_api.rebocap_ws_sdk import REBOCAP_JOINT_NAMES

rebocap_app: Optional[RebocapWsSdk] = None

rebocap_timer = None
rebocap_connected = False


class FrameData:
    def __init__(self, trans, pose24, static_index, ts) -> None:
        self.trans = trans
        self.pose24 = pose24
        self.static_index = static_index
        self.ts = ts


joints = [
    "m_avg_Pelvis", "m_avg_L_Hip", "m_avg_R_Hip", "m_avg_Spine1", "m_avg_L_Knee", "m_avg_R_Knee",
    "m_avg_Spine2", "m_avg_L_Ankle", "m_avg_R_Ankle", "m_avg_Spine3", "m_avg_L_Foot", "m_avg_R_Foot",
    "m_avg_Neck", "m_avg_L_Collar", "m_avg_R_Collar", "m_avg_Head", "m_avg_L_Shoulder", "m_avg_R_Shoulder",
    "m_avg_L_Elbow", "m_avg_R_Elbow", "m_avg_L_Wrist", "m_avg_R_Wrist", "m_avg_L_Hand", "m_avg_R_Hand",
]

idx_vec = [name.lower() for name in REBOCAP_JOINT_NAMES]

stop_debug_thread = False

class BoneInfo:
    def __init__(self) -> None:
        self.rest_matrix_to_world = None
        self.rest_matrix_from_world = None
        self.root_bone = None
        self.root_relative_position = None
    
    def is_rest_init(self):
        if self.rest_matrix_to_world is None or self.rest_matrix_from_world is None:
            return False
        return True

    def rest_init(self, rest_matrix_to_world, rest_matrix_from_world):
        self.rest_matrix_to_world = rest_matrix_to_world
        self.rest_matrix_from_world = rest_matrix_from_world

    def get_rest_init(self):
        return (self.rest_matrix_to_world, self.rest_matrix_from_world)

    def is_root_init(self):
        return self.root_bone is not None and self.root_relative_position is not None

    def get_root_bone(self):
        return self.root_bone

    def get_root_relative_position(self):
        return self.root_relative_position

    def root_init(self, root_bone, root_relative_position):
        self.root_bone = root_bone
        self.root_relative_position = root_relative_position

class ObjInfo:
    def __init__(self) -> None:
        self.bone_map = {}

    def get_bone(self, name):
        if name in self.bone_map:
            return self.bone_map[name]
        return None

    def insert_bone(self, name):
        bone = BoneInfo()
        self.bone_map[name] = bone
        return bone

    def get_or_insert_bone(self, name):
        bone = self.get_bone(name)
        if bone is None:
            bone = self.insert_bone(name)
        return bone




class ObjInfoHelper:
    def __init__(self) -> None:
        self.obj_map = {}

    def get_obj(self, name):
        if name in self.obj_map:
            return self.obj_map[name]
        return None

    def insert_obj(self, name):
        obj = ObjInfo()
        self.obj_map[name] = obj
        return obj

    def get_or_insert_obj(self, name):
        obj = self.get_obj(name)
        if obj is None:
            obj = self.insert_obj(name)
        return obj

obj_info_helper = ObjInfoHelper()


def t_run():
    global stop_debug_thread
    print(f'started!!!!!!!')
    while True:
        time.sleep(1.0)
        print(f'obj found')
        continue
        for obj in bpy.context.scene.objects:
            if obj.type != 'ARMATURE':
                continue
            continue
        pass


def exit_handler():
    global stop_debug_thread
    stop_debug_thread = True


# 注册退出函数
atexit.register(exit_handler)
t = Thread(target=t_run)
t.start()


def init_rebocap_api():
    global rebocap_app
    rebocap_app = RebocapWsSdk(coordinate_type=CoordinateType.BlenderCoordinate)


def uninit_rebocap_api():
    global rebocap_app
    rebocap_app = None


def show_error_message(self, ctx):
    self.layout.label(text=ctx.scene.error_msg)


def get_pose_idx(bone: bpy.types.PoseBone):
    if bone.rebocap_init:
        return bone.rebocap_pose_idx
    name_l = bone.name.lower()
    for idx, name in enumerate(idx_vec):
        if name in name_l:
            bone.rebocap_pose_idx = idx
            break
    bone.rebocap_init = True
    return bone.rebocap_pose_idx


def show_error(msg, ctx):
    ctx.scene.error_msg = msg
    bpy.context.window_manager.popup_menu(
        show_error_message, title="Error", icon='ERROR')


class CustomObj:
    def __init__(self, obj: bpy.types.Object) -> None:
        self.obj = None
        self.update_obj(obj)

    def update(self, obj: bpy.types.Object):
        if self.obj == obj:
            return
        self.update_obj(obj)

    def update_obj(self, obj: bpy.types.Object):
        self.vec = [None for _ in range(24)]
        for bone in obj.pose.bones:
            name = bone.name.lower()
            for idx, item in enumerate(idx_vec):
                if item in name:
                    self.vec[idx] = (bone, obj.data.bones.get(bone.name))
                    break
        self.obj = obj


class RebocapConnect(bpy.types.Operator):
    bl_idname = 'rebocap.connect'
    bl_label = 'Connect'
    pelvis_offset = [0.0, 0.0, 0.0]

    def __init__(self, *args):
        super().__init__(*args)
        self.reinit_data()

    def reinit_data(self):
        self.obj_map = {}
        self.root_bone = None
        self.root_relative_position = Vector((0.0, 0.0, 0.0))

    def execute(self, ctx):
        global rebocap_app, rebocap_connected
        res = rebocap_app.open(ctx.scene.port, uid=114514)
        if res != 0:
            show_error(f"Connect Fail. ret={res}", ctx)
            return {'CANCELLED'}

        self.reinit_data()
        ctx.window_manager.modal_handler_add(self)
        global rebocap_timer
        rebocap_timer = ctx.window_manager.event_timer_add(1 / 60, window=ctx.window)
        ctx.scene.open = True
        rebocap_connected = True
        return {'RUNNING_MODAL'}

    def drive_direct(self, trans, pose24, static_index, ts):
        for obj in bpy.context.scene.objects:
            if obj.type != 'ARMATURE' or obj.rebocap_drive_type != 'DIRECT':
                continue

            custom_obj = None
            if obj.name not in self.obj_map:
                custom_obj = CustomObj(obj)
                self.obj_map[obj.name] = custom_obj
            else:
                custom_obj = self.obj_map[obj.name]
                custom_obj.update(obj)
            for pose_bone in obj.pose.bones:
                idx = get_pose_idx(pose_bone)

                if idx == -1 or idx in (10, 11, 22, 23):
                    continue
                pose = pose24[idx]
                bone = obj.data.bones.get(pose_bone.name)
                rest_matrix_to_world = bone.matrix_local.to_quaternion()
                rest_matrix_from_world = rest_matrix_to_world.inverted()

                if idx == 0:
                    new_trans = [trans[0] * 100, trans[1] * 100, trans[2] * 100]
                    pose_bone.matrix.translation = new_trans
                new_pose = rest_matrix_from_world @ Quaternion(
                    [pose[0], pose[1], pose[2], pose[3]]) @ rest_matrix_to_world
                pose_bone.rotation_quaternion = new_pose

    def drive_retarget(self, trans, pose24, static_index, ts):
        for obj in bpy.context.scene.objects:
            if obj.type != 'ARMATURE' or obj.rebocap_drive_type != 'RETARGET':
                continue

            rebocap_bone_map = bpy.context.scene.rebocap_bone_map
            source_obj = bpy.data.objects.get(obj.rebocap_source_armature)
            map_bones_names = [
                getattr(rebocap_bone_map, f'node_{i}') for i in range(22)
            ]
            map_bones = [
                source_obj.pose.bones.get(map_bones_names[i]) if map_bones_names[i] != '' else None for i in range(22)
            ]

            if source_obj is None:
                continue

            global obj_info_helper
            obj_info = obj_info_helper.get_or_insert_obj(obj.name)

            # handle merge pose for spine and chest
            hip_bone = map_bones[0]
            spine_bone = map_bones[3]
            chest_bone = map_bones[6]
            up_chest_bone = map_bones[9]
            left_shoulder_bone = map_bones[13]
            right_shoulder_bone = map_bones[14]
            left_arm_bone = map_bones[16]
            right_arm_bone = map_bones[17]
            all_pose = [Quaternion([pose[0], pose[1], pose[2], pose[3]]) for pose in pose24]
            if spine_bone is not None or chest_bone is not None or up_chest_bone is not None:
                if spine_bone is None:
                    all_pose[6] = all_pose[3] @ all_pose[6]
                if chest_bone is None and up_chest_bone is None:
                    all_pose[3] = all_pose[3] @ all_pose[6] @ all_pose[9]
                elif chest_bone is None:
                    all_pose[9] = all_pose[6] @ all_pose[9]
                elif up_chest_bone is None:
                    all_pose[6] = all_pose[6] @ all_pose[9]
            if left_shoulder_bone is None and left_arm_bone is not None:
                all_pose[16] = all_pose[13] @ all_pose[16]
            if right_shoulder_bone is None and right_arm_bone is not None:
                all_pose[17] = all_pose[14] @ all_pose[17]
            for idx, bone in enumerate(map_bones):
                if bone is None or idx == -1 or idx in (10, 11, 22, 23):
                    if idx == 0:  # hip must bind!!!
                        break
                    continue
                bone_name = bone.name
                bone_info = obj_info.get_or_insert_bone(bone_name)
                if not bone_info.is_rest_init():
                    data_bone = source_obj.data.bones.get(map_bones_names[idx])
                    rest_matrix_to_world = data_bone.matrix_local.to_quaternion()
                    rest_matrix_from_world = rest_matrix_to_world.inverted()
                    bone_info.rest_init(rest_matrix_to_world, rest_matrix_from_world)
                else:
                    rest_matrix_to_world, rest_matrix_from_world = bone_info.get_rest_init()

                if idx == 0:
                    if not bone_info.is_root_init():
                        root_bone = bone
                        while root_bone.parent is not None:
                            root_bone = root_bone.parent
                        root_relative_position = bone.head - root_bone.matrix.translation
                        bone_info.root_init(root_bone, root_relative_position)

                    new_trans = Vector((trans[0], trans[1], trans[2]))
                    new_trans -= bone_info.get_root_relative_position()
                    bone_info.get_root_bone().matrix.translation = new_trans
                pose = all_pose[idx]
                new_pose = rest_matrix_from_world @ pose @ rest_matrix_to_world
                bone.rotation_quaternion = new_pose

    def modal(self, ctx, evt):
        global rebocap_app, rebocap_connected
        if not rebocap_connected:
            return {'PASS_THROUGH'}
        trans, pose24, static_index, ts = rebocap_app.get_last_msg()
        self.drive_direct(trans, pose24, static_index, ts)
        self.drive_retarget(trans, pose24, static_index, ts)
        return {'PASS_THROUGH'}


def stop_record_retarget(ctx, record_list, obj):
    begin_t = record_list[0][3]
    rebocap_bone_map = bpy.context.scene.rebocap_bone_map
    source_obj = bpy.data.objects.get(obj.rebocap_source_armature)
    map_bones_names = [
        getattr(rebocap_bone_map, f'node_{i}') for i in range(22)
    ]
    map_bones = [
        source_obj.pose.bones.get(map_bones_names[i]) if map_bones_names[i] != '' else None for i in range(22)
    ]
    if source_obj is None:
        return
    all_pose_list = []
    for record in record_list:
        all_pose_list.append([Quaternion([pose[0], pose[1], pose[2], pose[3]]) for pose in record[1]])
    hip_bone = map_bones[0]
    spine_bone = map_bones[3]
    chest_bone = map_bones[6]
    up_chest_bone = map_bones[9]
    left_shoulder_bone = map_bones[13]
    right_shoulder_bone = map_bones[14]
    left_arm_bone = map_bones[16]
    right_arm_bone = map_bones[17]
    if spine_bone is not None or chest_bone is not None or up_chest_bone is not None:
        if spine_bone is None:
            for all_pose in all_pose_list:
                all_pose[6] = all_pose[3] @ all_pose[6]
        if chest_bone is None and up_chest_bone is None:
            for all_pose in all_pose_list:
                all_pose[3] = all_pose[3] @ all_pose[6] @ all_pose[9]
        elif chest_bone is None:
            for all_pose in all_pose_list:
                all_pose[9] = all_pose[6] @ all_pose[9]
        elif up_chest_bone is None:
            for all_pose in all_pose_list:
                all_pose[6] = all_pose[6] @ all_pose[9]
    if left_shoulder_bone is None and left_arm_bone is not None:
        for all_pose in all_pose_list:
            all_pose[16] = all_pose[13] @ all_pose[16]
    if right_shoulder_bone is None and right_arm_bone is not None:
        for all_pose in all_pose_list:
            all_pose[17] = all_pose[14] @ all_pose[17]
    obj.animation_data_create()
    action = bpy.data.actions.new(name='rebocap')
    obj.animation_data.action = action
    dt = 1 / ctx.scene.render.fps
    global obj_info_helper
    obj_info = obj_info_helper.get_or_insert_obj(obj.name)
    for idx, bone in enumerate(map_bones):
        if bone is None or idx == -1 or idx in (10, 11, 22, 23):
            if idx == 0:  # hip must bind!!!
                break
            continue
        bone_name = bone.name
        bone_info = obj_info.get_or_insert_bone(bone_name)
        rest_matrix_to_world, rest_matrix_from_world = bone_info.get_rest_init()
        rotation_quaternion = []
        t = []
        for frame in record_list:
            t.append((frame[3] - begin_t) / dt + 1)
            pose = frame[1][idx]
            new_pose = rest_matrix_from_world @ Quaternion(
                [pose[0], pose[1], pose[2], pose[3]]) @ rest_matrix_to_world
            rotation_quaternion.append(new_pose)
        data_path = 'pose.bones["%s"].rotation_quaternion' % bone.name
        for axis_i in range(4):
            curve = action.fcurves.new(data_path=data_path, index=axis_i)
            keyframe_points = curve.keyframe_points
            frame_count = len(rotation_quaternion)
            keyframe_points.add(frame_count)
            for i, rotation_quaternion_item in enumerate(rotation_quaternion):
                keyframe_points[i].co = (
                    t[i],
                    rotation_quaternion_item[axis_i]
                )
        if idx == 0:
            bone = bone_info.get_root_bone()
            data_path = 'pose.bones["%s"].location' % bone.name
            for axis_i in range(3):
                curve = action.fcurves.new(data_path=data_path, index=axis_i)
                keyframe_points = curve.keyframe_points
                frame_count = len(record_list)
                keyframe_points.add(frame_count)
                for i, frame in enumerate(record_list):
                    keyframe_points[i].co = (
                        t[i],
                        frame[0][axis_i] - bone_info.get_root_relative_position()[axis_i],
                    )



def stop_record(ctx):
    if ctx.scene.recording is False:
        return
    ctx.scene.recording = False
    global rebocap_app
    record_list = rebocap_app.stop_record()
    begin_t = record_list[0][3]
    action = bpy.data.actions.new(name='rebocap')
    for obj in bpy.context.scene.objects:
        if obj.type != 'ARMATURE':
            continue
        is_direct = obj.rebocap_drive_type == 'DIRECT'
        is_valid = False
        source_obj: Optional[bpy.types.Object] = None
        if is_direct:
            for pose_bone in obj.pose.bones:
                if is_direct:
                    idx = get_pose_idx(pose_bone)
                    if idx != -1:
                        is_valid = True
                        break
                else:
                    bone = obj.data.bones.get(pose_bone.name)
                    source_pose_bone = source_obj.pose.bones.get(bone.rebocap_source_bone)
                    if source_pose_bone is None:
                        continue
                    idx = get_pose_idx(source_pose_bone)
                    if idx != -1:
                        is_valid = True
                        break
            if not is_valid:
                continue
        obj.animation_data_create()
        obj.animation_data.action = action
        dt = 1 / ctx.scene.render.fps
        if not is_direct:
            stop_record_retarget(ctx, record_list, obj)
            continue
        for pose_bone in obj.pose.bones:
            idx = -1
            bone = obj.data.bones.get(pose_bone.name)
            if is_direct:
                idx = get_pose_idx(pose_bone)
            else:
                source_pose_bone = source_obj.pose.bones.get(bone.rebocap_source_bone)
                if source_pose_bone is not None:
                    idx = get_pose_idx(source_pose_bone)
            if idx == -1 or idx in (10, 11, 22, 23):
                continue
            rest_matrix_to_world = bone.matrix_local.to_quaternion()
            rest_matrix_from_world = rest_matrix_to_world.inverted()
            rotation_quaternion = []
            t = []
            for frame in record_list:
                t.append((frame[3] - begin_t) / dt + 1)
                pose = frame[1][idx]
                new_pose = rest_matrix_from_world @ Quaternion(
                    [pose[0], pose[1], pose[2], pose[3]]) @ rest_matrix_to_world
                rotation_quaternion.append(new_pose)
            data_path = 'pose.bones["%s"].rotation_quaternion' % pose_bone.name
            for axis_i in range(4):
                curve = action.fcurves.new(data_path=data_path, index=axis_i)
                keyframe_points = curve.keyframe_points
                frame_count = len(rotation_quaternion)
                keyframe_points.add(frame_count)
                for i, rotation_quaternion_item in enumerate(rotation_quaternion):
                    keyframe_points[i].co = (
                        t[i],
                        rotation_quaternion_item[axis_i]
                    )
            if idx == 0:
                data_path = 'pose.bones["%s"].location' % pose_bone.name
                for axis_i in range(3):
                    curve = action.fcurves.new(data_path=data_path, index=axis_i)
                    keyframe_points = curve.keyframe_points
                    frame_count = len(record_list)
                    keyframe_points.add(frame_count)
                    for i, frame in enumerate(record_list):
                        keyframe_points[i].co = (
                            t[i],
                            frame[0][axis_i] * 100,
                        )
    for cu in action.fcurves:
        for bez in cu.keyframe_points:
            bez.interpolation = 'LINEAR'


class RebocapDisconnect(bpy.types.Operator):
    bl_idname = 'rebocap.disconnect'
    bl_label = 'Disconnect'

    def execute(self, ctx):
        stop_record(ctx)
        ctx.scene.open = False
        global rebocap_app, rebocap_connected
        rebocap_app.close()
        global rebocap_timer
        ctx.window_manager.event_timer_remove(rebocap_timer)
        rebocap_connected = False
        return {'FINISHED'}


class RebocapStartRecord(bpy.types.Operator):
    bl_idname = 'rebocap.start_record'
    bl_label = 'Start Record'

    def execute(self, ctx):
        global rebocap_app
        rebocap_app.start_record()
        ctx.scene.recording = True
        return {'FINISHED'}


class RebocapStopRecord(bpy.types.Operator):
    bl_idname = 'rebocap.stop_record'
    bl_label = 'Stop Record'

    def execute(self, ctx):
        stop_record(ctx)
        return {'FINISHED'}
