import bpy


class RebocapBones(bpy.types.PropertyGroup):
    node_0: bpy.props.StringProperty()
    node_1: bpy.props.StringProperty()
    node_2: bpy.props.StringProperty()
    node_3: bpy.props.StringProperty()
    node_4: bpy.props.StringProperty()
    node_5: bpy.props.StringProperty()
    node_6: bpy.props.StringProperty()
    node_7: bpy.props.StringProperty()
    node_8: bpy.props.StringProperty()
    node_9: bpy.props.StringProperty()
    node_10: bpy.props.StringProperty()
    node_11: bpy.props.StringProperty()
    node_12: bpy.props.StringProperty()
    node_13: bpy.props.StringProperty()
    node_14: bpy.props.StringProperty()
    node_15: bpy.props.StringProperty()
    node_16: bpy.props.StringProperty()
    node_17: bpy.props.StringProperty()
    node_18: bpy.props.StringProperty()
    node_19: bpy.props.StringProperty()
    node_20: bpy.props.StringProperty()
    node_21: bpy.props.StringProperty()
    node_22: bpy.props.StringProperty()
    node_23: bpy.props.StringProperty()

    foot_idx_0: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_1: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_2: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_3: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_4: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_5: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_6: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_7: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_8: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_9: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_10: bpy.props.IntProperty(name='indices id', default=-1, min=-1)
    foot_idx_11: bpy.props.IntProperty(name='indices id', default=-1, min=-1)

def register_types():
    bpy.types.Scene.port = bpy.props.IntProperty(
        name='Port',
        default=7690,
        max=65535,
        min=0
    )
    bpy.types.Scene.open = bpy.props.BoolProperty(
        name='Open',
        default=False,
    )
    bpy.types.Scene.error_msg = bpy.props.StringProperty(
        name='error_msg',
    )
    bpy.types.Scene.recording = bpy.props.BoolProperty(
        name='Recording',
        default=False,
    )
    bpy.types.Object.rebocap_source_armature = bpy.props.StringProperty(
        name='Armature Source'
    )
    bpy.types.Object.rebocap_drive_type = bpy.props.EnumProperty(
        items=[('DIRECT', 'Direct', '', 1), ('RETARGET', 'Retarget', '', 2)],
        name='Drive Type',
        default='DIRECT'
    )
    bpy.types.Bone.rebocap_source_bone = bpy.props.StringProperty(
        name='Bone Source'
    )
    bpy.types.PoseBone.rebocap_init = bpy.props.BoolProperty(
        name="PoseBone Init",
        default=False,
    )
    bpy.types.PoseBone.rebocap_pose_idx = bpy.props.IntProperty(
        name="Pose Idx",
        default=-1,
    )

    bpy.types.Scene.rebocap_bone_map = bpy.props.PointerProperty(type=RebocapBones)
