import bpy
from . import core
from . import ops
from . import ui
from .rebocap_api.rebocap_ws_sdk import REBOCAP_JOINT_NAMES

bl_info = {
    "name": "REBOCAP BLENDER PLUGIN",
    "author": "Rebocap",
    "description": "",
    "blender": (2, 82, 0),
    "version": (0, 0, '0 (BETA)'),
    "location": "",
    "warning": "",
    "doc_url": "https://github.com/pnmocap/neuron_mocap_live-blender",
    "tracker_url": "https://github.com/pnmocap/neuron_mocap_live-blender/issues",
    "category": "Rebocap"
}

class_list = [
    ops.RebocapConnect,
    ops.RebocapDisconnect,
    ops.RebocapStartRecord,
    ops.RebocapStopRecord,
    ops.AutoMapBone,
    ops.SaveBone,
    core.RebocapBones,
    ui.ConnectionPanel,
]

joints = [
    "m_avg_Pelvis", "m_avg_L_Hip", "m_avg_R_Hip", "m_avg_Spine1", "m_avg_L_Knee", "m_avg_R_Knee",
    "m_avg_Spine2", "m_avg_L_Ankle", "m_avg_R_Ankle", "m_avg_Spine3", "m_avg_L_Foot", "m_avg_R_Foot",
    "m_avg_Neck", "m_avg_L_Collar", "m_avg_R_Collar", "m_avg_Head", "m_avg_L_Shoulder", "m_avg_R_Shoulder",
    "m_avg_L_Elbow", "m_avg_R_Elbow", "m_avg_L_Wrist", "m_avg_R_Wrist", "m_avg_L_Hand", "m_avg_R_Hand",
]


@bpy.app.handlers.persistent
def reset_property_values(_):
    bpy.context.scene.open = False
    bpy.context.scene.recording = False
    # bind_bones = bpy.context.scene.bind_bones
    # bind_bones.clear()
    # for i in range(len(joints)):
    #     bone = bind_bones.add()
    #     bone.key = REBOCAP_JOINT_NAMES[i]
    #     bone.value = joints[i]


def register():
    bpy.app.handlers.load_post.append(reset_property_values)
    ops.init_rebocap_api()
    for item in class_list:
        bpy.utils.register_class(item)

    core.register_types()


def unregister():
    if reset_property_values in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(reset_property_values)
    ops.uninit_rebocap_api()
    for item in class_list:
        bpy.utils.unregister_class(item)
