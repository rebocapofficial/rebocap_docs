﻿#include "rebocap_runtime.h"
#include "Framework/Application/SlateApplication.h"
#include "RebocapLivelinkManagerDemoWidget.h"
#include "Kismet/GameplayStatics.h"


#if USE_REBOCAP_LIVELINK_MANAGER_DEMO
void Frebocap_runtimeModule::CreateUI()
{
  if (GEngine && GEngine->GameViewport)
  {
    TSharedRef<SWidget> Widget = SNew(SRebocapLivelinkManagerDemoWidget);
    GEngine->GameViewport->AddViewportWidgetContent(Widget);

    APlayerController* PC = UGameplayStatics::GetPlayerController(GWorld, 0);
    if (PC)
    {
      PC->bShowMouseCursor = true;
      PC->bEnableClickEvents = true;
      PC->bEnableMouseOverEvents = true;
    }
  }
}

#endif