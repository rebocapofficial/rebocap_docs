﻿#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "RebocapLivelinkBluePrintManager.generated.h"

UCLASS()
class URebocapLivelinkBluePrintManager : public UBlueprintFunctionLibrary {
  GENERATED_BODY()
public:
  UFUNCTION(BlueprintCallable, Category = "LiveLink")
  static void ConnectToRebocapLivelinkSource(int Port = 7690);

  UFUNCTION(BlueprintCallable, Category = "LiveLink")
  static void DisconnectToRebocapLivelinkSource();

private:
  static bool bIsConnected;
};
