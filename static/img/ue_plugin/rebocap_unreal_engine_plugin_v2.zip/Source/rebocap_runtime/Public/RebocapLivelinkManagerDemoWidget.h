﻿#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "LiveLinkSourceFactory.h"

class SRebocapLivelinkManagerDemoWidget : public SCompoundWidget
{
public:
  SLATE_BEGIN_ARGS(SRebocapLivelinkManagerDemoWidget) {}
  SLATE_END_ARGS()

  void Construct(const FArguments& InArgs);

private:
  FReply OnButtonClicked();
  void ConnectLiveLink();
  void DisconnectLiveLink();
  FText GetButtonText() const;

  bool bIsConnected = false;
};
