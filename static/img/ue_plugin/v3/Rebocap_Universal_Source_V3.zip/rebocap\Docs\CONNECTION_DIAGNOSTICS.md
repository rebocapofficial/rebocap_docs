# 连接稳定性诊断与复现（`-RebocapTrace` / `-RebocapTest`）

用于排查"连接过程中丢信号闪动、姿势冻结、坐标抖动"这类问题。两个开关都**默认关闭**，不写日志、不改变行为。

## 1. 打开埋点

```bat
UnrealEditor.exe "MyProject.uproject" -RebocapTrace -RebocapTest
```

| 开关 | 作用 |
| --- | --- |
| `-RebocapTrace` | 输出 `[RTrace]` 日志（源端 + 节点端） |
| `-RebocapTest` | 编辑器内按固定时间表自动跑一遍：生成角色 → PIE → 断开 → 重连 → 连错端口 → 恢复 |

## 2. 日志内容

源端（`rebocap_source.cpp`）：

| 日志 | 含义 |
| --- | --- |
| `open_ok port=7690` | socket 建立成功 |
| `open_fail port=7777 ret=2` | 连接失败（ret 为 SDK 返回码） |
| `subject_add rebocap` | 向 LiveLink 注册 subject |
| `subject_remove n=1` | 移除 subject（断开 / 关机 / 切换端口） |
| `packet_gap=10.03` | 距上一包超过 120 ms，值是空窗秒数 |
| `badquat bone=3 total=7` | 收到零/异常四元数（会被替换成 identity），>5 次后每 60 次记一条 |

节点端（`rebocap_pose_node.cpp`）：

| 日志 | 含义 |
| --- | --- |
| `node_state=NO_SUBJECT(->base pose)` | 没有 subject（连接前 / 断开后）→ 输出基础姿势 |
| `node_state=LIVE` | 正常收帧 |
| `node_state=HOLD(cached pose)` | 掉帧但仍在 `DropoutTimeout` 内，保持上一帧 |
| `node_state=DROPOUT(->base pose)` | 超过 `DropoutTimeout`，放开姿势 |
| `stats live=.. hold=.. maxstep=..` | 每 60 帧一次：收帧数 / 保持数 / 该窗口内最大单帧旋转步长（度） |

## 3. 判定方法

| 现象 | 看什么 |
| --- | --- |
| 稳态抖动 | `stats` 的 `maxstep`；60 FPS 下正常范围约 **3°–15°**，明显更大或伴随 `badquat` 才是异常 |
| 丢帧 | `hold` 是否增长；稳态应恒为 0 |
| 连接闪动 | `node_state` 是否在 `LIVE → NO_SUBJECT → LIVE` 之间跳变，以及间隔时长 |
| 断开被"撤销" | 断开后是否出现 `node_state=LIVE` + `open_ok`（0.3 秒内）——已修复，正常应一直停在 `NO_SUBJECT` |
| 端口回退耗时 | `open_fail` 到下一个 `open_ok` 的间隔（当前约 **4.5 秒**） |

## 4. 实测基线（UE 5.8）

```
+ 5.2s  open_ok port=7690
+ 7.5s  node_state=LIVE
+35.4s  action=disconnect → subject_remove n=1
+35.8s  node_state=NO_SUBJECT(->base pose)   ← 断开后立即放开姿势
        （等待显式重连，不再自动连）
+50.1s  action=connect_7690
+50.4s  node_state=LIVE
+65.4s  action=connect_7777_badport
+65.8s  node_state=HOLD(cached pose)          ← 保持 2.0 秒
+67.8s  node_state=DROPOUT(->base pose)
+69.9s  packet_gap=4.48                       ← 回退到 7690 耗时
+70.1s  node_state=LIVE
```

## 5. 注意

- Persona 预览在编辑器窗口失焦/后台时会降频甚至暂停求值，测节点状态机请用 **PIE**（`-RebocapTest` 会自动生成角色并进入 PIE）。
- PIE 在本机可能只有 5–10 FPS，此时 `maxstep` 会偏大（每帧间隔长），不要拿它判断抖动；稳态抖动请用编辑器预览满帧跑出来的数据。
