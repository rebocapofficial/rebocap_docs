﻿# 为 4.27~5.9 逐版本编译插件（构建矩阵）
#
# 用法：
#   powershell -File Tools\BuildReleaseMatrix.ps1 -Versions 4.27,5.0,5.9
#   powershell -File Tools\BuildReleaseMatrix.ps1                 # 全量
#
# 说明：
#   - 4.27 用 UE4 树的源码，5.x 用 UE5 树的源码；
#   - 4.x 需要 VS2019，5.x 需要 VS2022，脚本按版本自动切换全局 UBT 配置并在结束时还原；
#   - 每个版本一个独立的 host 工程，避免 Intermediate/Binaries 互相污染；
#   - 编译成功后把 Binaries/Win64 收进 插件发布包_V3/<版本>/rebocap/Binaries/Win64。

param(
    [string]$Versions = "4.27,5.0,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9",
    [string]$UE5Tree = "D:\rebocap\03 ue plugins\插件迭代开发源码\rebocap",
    [string]$UE4Tree = "D:\rebocap\03 ue plugins\插件迭代开发源码_UE4",
    [string]$WorkRoot = "D:\rebocap\03 ue plugins\build_matrix",
    [string]$PackageRoot = "D:\rebocap\03 ue plugins\插件发布包_V3",
    [switch]$NoPackage
)

$ErrorActionPreference = "Continue"
$engines = @{
    "4.26" = "E:\Epic Games\UE_4.26"; "4.27" = "D:\Epic Games\UE_4.27"
    "5.0" = "E:\Epic Games\UE_5.0";   "5.1" = "E:\Epic Games\UE_5.1"; "5.2" = "E:\Epic Games\UE_5.2"
    "5.3" = "D:\Epic Games\UE_5.3";   "5.4" = "D:\Epic Games\UE_5.4"; "5.5" = "D:\Epic Games\UE_5.5"
    "5.6" = "D:\Epic Games\UE_5.6";   "5.7" = "D:\Epic Games\UE_5.7"; "5.8" = "D:\Epic Games\UE_5.8"
    "5.9" = "E:\Epic Games\UE_5.9"
}

$cfgPath = Join-Path $env:APPDATA "Unreal Engine\UnrealBuildTool\BuildConfiguration.xml"
$cfgBackup = "$cfgPath.matrix-backup"
function Set-Compiler([string]$compiler, [string]$compilerVersion = "") {
    $verElement = if ($compilerVersion) { "    <CompilerVersion>$compilerVersion</CompilerVersion>" } else { "" }
    $xml = @"
<?xml version="1.0" encoding="utf-8" ?>
<Configuration xmlns="https://www.unrealengine.com/BuildConfiguration">
  <WindowsPlatform>
    <Compiler>$compiler</Compiler>
$verElement
  </WindowsPlatform>
</Configuration>
"@
    [System.IO.File]::WriteAllText($cfgPath, $xml, (New-Object System.Text.UTF8Encoding($false)))
}

$VersionList = $Versions -split "\s*,\s*" | Where-Object { $_ }
$results = New-Object System.Collections.ArrayList

function New-HostProject([string]$dir) {
    if (Test-Path -LiteralPath $dir) { Remove-Item -LiteralPath $dir -Recurse -Force }
    New-Item -ItemType Directory -Path "$dir\Source\Host" -Force | Out-Null
    $enc = New-Object System.Text.UTF8Encoding($false)
    $uproject = '{ "FileVersion": 3, "Plugins": [ { "Name": "rebocap", "Enabled": true } ] }'
    $isUE5 = ($v -notlike "4.*")
    # Settings must match each engine's own defaults, otherwise UBT refuses with
    # "HostEditor modifies the value of ...". EngineIncludeOrderVersion exists from 5.1,
    # Cpp20 is only the default from 5.3 on.
    $majorVer, $minorVer = 0, 0
    if ($v -match '^(\d+)\.(\d+)$') { $majorVer = [int]$Matches[1]; $minorVer = [int]$Matches[2] }
    $settings = "        DefaultBuildSettings = BuildSettingsVersion.Latest;`n"
    if ($majorVer -gt 5 -or ($majorVer -eq 5 -and $minorVer -ge 1)) {
        $settings += "        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;`n"
    }
    if ($majorVer -gt 5 -or ($majorVer -eq 5 -and $minorVer -ge 3)) {
        $settings += "        CppStandard = CppStandardVersion.Cpp20;`n"
    }
    $extraSettings = $settings
    $target = @"
using UnrealBuildTool;
public class HostTarget : TargetRules
{
    public HostTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
$extraSettings        ExtraModuleNames.Add("Host");
    }
}
"@
    $editorTarget = @"
using UnrealBuildTool;
public class HostEditorTarget : TargetRules
{
    public HostEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
$extraSettings        ExtraModuleNames.Add("Host");
    }
}
"@
    $buildCs = @'
using UnrealBuildTool;
public class Host : ModuleRules
{
    public Host(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore" });
    }
}
'@
    $cpp = @'
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, Host, "Host");
'@
    [System.IO.File]::WriteAllText("$dir\Host.uproject", $uproject, $enc)
    [System.IO.File]::WriteAllText("$dir\Source\Host.Target.cs", $target, $enc)
    [System.IO.File]::WriteAllText("$dir\Source\HostEditor.Target.cs", $editorTarget, $enc)
    [System.IO.File]::WriteAllText("$dir\Source\Host\Host.Build.cs", $buildCs, $enc)
    [System.IO.File]::WriteAllText("$dir\Source\Host\Host.cpp", $cpp, $enc)
}

if (Test-Path -LiteralPath $cfgPath) { Copy-Item -LiteralPath $cfgPath -Destination $cfgBackup -Force }

try {
    foreach ($v in $VersionList) {
        $engineRoot = $engines[$v]
        Write-Host ""
        Write-Host "################ $v ################"
        if (-not $engineRoot -or -not (Test-Path -LiteralPath $engineRoot)) {
            Write-Host "  引擎不存在，跳过"
            [void]$results.Add([pscustomobject]@{ Version = $v; Result = "NoEngine"; Errors = 0; FirstError = "" })
            continue
        }
        $tree = if ($v -like "4.*") { $UE4Tree } else { $UE5Tree }
        $work = Join-Path $WorkRoot "host_$v"
        New-HostProject $work
        New-Item -ItemType Directory -Path "$work\Plugins" -Force | Out-Null
        $null = robocopy $tree "$work\Plugins\rebocap" /MIR /NFL /NDL /NJH /NJS /NP /XD (Join-Path $tree "Binaries\Win64") (Join-Path $tree "Intermediate") (Join-Path $tree "Saved") (Join-Path $tree "DerivedDataCache")
        # 兜底：源树里的旧 DLL 绝不能参与构建（否则会"看起来已编译"）
        foreach ($stale in @("Binaries\Win64", "Intermediate")) {
            $staleDir = Join-Path "$work\Plugins\rebocap" $stale
            if (Test-Path -LiteralPath $staleDir) { Remove-Item -LiteralPath $staleDir -Recurse -Force }
        }
        $copied = @(Get-ChildItem -LiteralPath "$work\Plugins\rebocap" -ErrorAction SilentlyContinue).Count
        Write-Host "  源码树: $tree"
        Write-Host "  已复制顶层项: $copied"
        if ($copied -eq 0) { Write-Host "  !! 插件复制失败，跳过"; [void]$results.Add([pscustomobject]@{ Version = $v; Result = "NoCopy"; Errors = 0; FirstError = "" }); continue }

        $compiler = if ($v -like "4.*") { "VisualStudio2019" } else { "VisualStudio2022" }
        # UE 5.3 在装了 VS2019+VS2022 的机器上会误选 14.29 工具链（引擎要求 14.34+），显式钉版本
        $compilerVersion = if ($v -eq "5.3") { "14.38.33130" } else { "" }
        Set-Compiler $compiler $compilerVersion
        Write-Host "  编译器: $compiler $compilerVersion"

        $buildBat = Join-Path $engineRoot "Engine\Build\BatchFiles\Build.bat"
        if (-not (Test-Path -LiteralPath $buildBat)) { $buildBat = Join-Path $engineRoot "Engine\Build\BatchFiles\Build.bat" }
        $prj = "-Project=" + (Join-Path $work "Host.uproject")
        $logFile = Join-Path $WorkRoot "build_$v.log"
        $out = & $buildBat HostEditor Win64 Development $prj -WaitMutex -FromMsBuild 2>&1
        $out | Out-File -LiteralPath $logFile -Encoding utf8
        $resultLine = ($out | Select-String -Pattern 'Result:') | Select-Object -Last 1
        $errs = @($out | Select-String -Pattern 'error C|error LNK|fatal error|error CS|ERROR:|must be compiled|not allowed|Failed \(')
        $sawFailure = ($resultLine -and $resultLine.Line -match 'Failed') -or ($errs.Count -gt 0)
        $result = if ($sawFailure) { "FAIL" } else { "OK" }
        $first = if ($errs.Count -gt 0) { $errs[0].Line.Trim() } else { "" }
        Write-Host "  结果: $result  错误数: $($errs.Count)"
        if ($errs.Count -gt 0) { Write-Host "  首个错误: $first" }
        [void]$results.Add([pscustomobject]@{ Version = $v; Result = $result; Errors = $errs.Count; FirstError = $first })

        if ($result -eq "OK" -and -not $NoPackage) {
            $binSrc = Join-Path $work "Plugins\rebocap\Binaries\Win64"
            $dst = Join-Path $PackageRoot "$v\rebocap"
            if (Test-Path -LiteralPath $binSrc) {
                robocopy $tree $dst /MIR /NFL /NDL /NJH /NJS /NP /XD Binaries\Win64 Intermediate | Out-Null
                New-Item -ItemType Directory -Path "$dst\Binaries\Win64" -Force | Out-Null
                Copy-Item -Path "$binSrc\*Editor-rebocap*.dll" -Destination "$dst\Binaries\Win64" -Force -ErrorAction SilentlyContinue
                Copy-Item -Path "$binSrc\*.modules" -Destination "$dst\Binaries\Win64" -Force -ErrorAction SilentlyContinue
                Copy-Item -Path "$binSrc\rebocap_ws_sdk.dll" -Destination "$dst\Binaries\Win64" -Force -ErrorAction SilentlyContinue
                Write-Host "  已收包: $dst"
            }
        }
    }
}
finally {
    if (Test-Path -LiteralPath $cfgBackup) { Copy-Item -LiteralPath $cfgBackup -Destination $cfgPath -Force; Remove-Item -LiteralPath $cfgBackup -Force }
    Write-Host ""
    Write-Host "== 汇总 =="
    $results | Format-Table -AutoSize | Out-String | Write-Host
}
