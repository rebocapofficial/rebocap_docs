using UnrealBuildTool;

public class rebocap_editor : ModuleRules
{
    public rebocap_editor(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        if (Target.Version.MajorVersion < 5)
        {
            CppStandard = CppStandardVersion.Cpp17;
        }
        else
        {
            CppStandard = CppStandardVersion.Cpp20;
        }

        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core",
            "CoreUObject",
            "Engine",
            "AnimGraphRuntime",
            "LiveLinkInterface",
            "rebocap_runtime"
        });

        // UE5.0 already ships LiveLinkAnimationCore (ULiveLinkRemapAsset lives there), not only 5.1+.
        if (Target.Version.MajorVersion >= 5)
        {
            PublicDependencyModuleNames.Add("LiveLinkAnimationCore");
        }
        else
        {
            PublicDependencyModuleNames.Add("LiveLink");
            PrivateDependencyModuleNames.Add("EditorStyle");
        }

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "AnimGraph",
            "BlueprintGraph",
            "UnrealEd",
            "KismetCompiler",
            "GraphEditor",
            "PropertyEditor",
            "Slate",
            "SlateCore",
            "DesktopPlatform"
        });

        // Mirrors RebocapEditorStyleCompat.h: FAppStyle exists from 5.1 on, FEditorStyle before that.
        if (!(Target.Version.MajorVersion > 5 || (Target.Version.MajorVersion == 5 && Target.Version.MinorVersion >= 1)))
        {
            PrivateDependencyModuleNames.Add("EditorStyle");
        }
    }
}
