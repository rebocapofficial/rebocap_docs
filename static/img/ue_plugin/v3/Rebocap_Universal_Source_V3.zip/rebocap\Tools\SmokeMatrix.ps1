﻿# 逐版本加载冒烟测试：启动编辑器 → 轮询日志 → 关闭
#
# 判定三项（host 工程没有 ABP/面板，所以不会创建 LiveLink source）：
#   1) Mounting plugin rebocap
#   2) Rebocap SDK DLL loaded successfully
#   3) RebocapEditor module started and registered custom details
#
# 完整功能验证（面板连接 + PIE 驱动）另在 4.27 / 5.8 的代表工程上做。

param(
    [string]$Versions = "4.27,5.0,5.1,5.2,5.3,5.4,5.5,5.6,5.7,5.8,5.9",
    [int]$MaxWaitSeconds = 300,
    [string]$WorkRoot = "D:\rebocap\03 ue plugins\build_matrix"
)

$engines = @{
    "4.26" = "E:\Epic Games\UE_4.26"; "4.27" = "D:\Epic Games\UE_4.27"
    "5.0" = "E:\Epic Games\UE_5.0";   "5.1" = "E:\Epic Games\UE_5.1"; "5.2" = "E:\Epic Games\UE_5.2"
    "5.3" = "D:\Epic Games\UE_5.3";   "5.4" = "D:\Epic Games\UE_5.4"; "5.5" = "D:\Epic Games\UE_5.5"
    "5.6" = "D:\Epic Games\UE_5.6";   "5.7" = "D:\Epic Games\UE_5.7"; "5.8" = "D:\Epic Games\UE_5.8"
    "5.9" = "E:\Epic Games\UE_5.9"
}
$results = New-Object System.Collections.ArrayList

foreach ($v in ($Versions -split "\s*,\s*" | Where-Object { $_ })) {
    Write-Host ""
    Write-Host "######## $v ########"
    $engine = $engines[$v]
    $hostDir = Join-Path $WorkRoot "host_$v"
    $proj = Join-Path $hostDir "Host.uproject"
    if (-not (Test-Path -LiteralPath $proj)) { Write-Host "  无 host 工程，跳过"; continue }
    $exe = if ($v -like "4.*") { Join-Path $engine "Engine\Binaries\Win64\UE4Editor.exe" } else { Join-Path $engine "Engine\Binaries\Win64\UnrealEditor.exe" }
    if (-not (Test-Path -LiteralPath $exe)) { Write-Host "  编辑器不存在，跳过"; continue }

    Get-Process UE4Editor*, UnrealEditor* -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 2
    $log = Join-Path $hostDir "Saved\Logs\Host.log"
    if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log -Force }

    $proc = Start-Process -FilePath $exe -ArgumentList "`"$proj`"" -WorkingDirectory $hostDir -PassThru
    $deadline = (Get-Date).AddSeconds($MaxWaitSeconds)
    $mount = $false; $sdk = $false; $editor = $false
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 4
        if (Test-Path -LiteralPath $log) {
            $text = Get-Content -LiteralPath $log -Raw -ErrorAction SilentlyContinue
            if ($text) {
                $mount  = $text -match 'Mounting plugin rebocap'
                $sdk    = $text -match 'Rebocap SDK DLL loaded successfully'
                $editor = $text -match 'RebocapEditor module started'
                if ($mount -and $sdk -and $editor) { break }
            }
        }
        if ($proc.HasExited) { break }
    }
    Get-Process UE4Editor*, UnrealEditor* -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 2

    $ok = ($mount, $sdk, $editor | Where-Object { $_ }).Count
    $verdict = if ($ok -eq 3) { "PASS" } else { "CHECK($ok/3)" }
    Write-Host ("  结果: {0}  [mount={1} sdk={2} editormodule={3}]  exit={4}" -f $verdict, $mount, $sdk, $editor, $proc.HasExited)
    [void]$results.Add([pscustomobject]@{ Version = $v; Verdict = $verdict; Mount = $mount; SDK = $sdk; EditorModule = $editor })
}

Write-Host ""
Write-Host "== 冒烟汇总 =="
$results | Format-Table -AutoSize | Out-String | Write-Host
