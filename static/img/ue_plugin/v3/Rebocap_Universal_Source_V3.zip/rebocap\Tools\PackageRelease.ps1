﻿# 把各版本编译产物打成发布包（4.27~5.9）
#
# 依赖 BuildReleaseMatrix.ps1 先跑完，产物在 build_matrix\host_<ver>\Plugins\rebocap\Binaries\Win64
#
# 产出：
#   插件发布包_V3\UE_<ver>\rebocap\{rebocap.uplugin,Binaries,Config,Content,Resources,x64}
#   插件发布包_V3\rebocap_UE_<ver>_V3.zip
#   插件发布包_V3\Rebocap_UE4_Source_V3.zip / Rebocap_Universal_Source_V3.zip

param(
    [string[]]$Versions = @("4.26", "4.27", "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7", "5.8", "5.9"),
    [string]$UE5Tree = "D:\rebocap\03 ue plugins\插件迭代开发源码\rebocap",
    [string]$UE4Tree = "D:\rebocap\03 ue plugins\插件迭代开发源码_UE4",
    [string]$WorkRoot = "D:\rebocap\03 ue plugins\build_matrix",
    [string]$PackageRoot = "D:\rebocap\03 ue plugins\插件发布包_V3",
    [switch]$NoZip
)

$ErrorActionPreference = "Continue"
New-Item -ItemType Directory -Path $PackageRoot -Force | Out-Null

function Get-VersionFolder([string]$v) { "UE_$v" }

foreach ($v in $Versions) {
    Write-Host ""
    Write-Host "######## $v ########"
    $binSrc = Join-Path $WorkRoot "host_$v\Plugins\rebocap\Binaries\Win64"
    if (-not (Test-Path -LiteralPath $binSrc)) { Write-Host "  未找到编译产物，跳过"; continue }
    $tree = if ($v -like "4.*") { $UE4Tree } else { $UE5Tree }
    $dst = Join-Path $PackageRoot (Join-Path (Get-VersionFolder $v) "rebocap")
    if (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
    New-Item -ItemType Directory -Path $dst -Force | Out-Null

    # 预编译包：不要 Source / Intermediate，Docs/README 也不进包
    # 只排除顶层 Localization（po/manifest 工作文件）；Content\Localization 里的 locres 必须保留
    # 同时排除编译中间物、导入库导出文件与开发用点文件
    robocopy $tree $dst /E /NFL /NDL /NJH /NJS /NP `
        /XD (Join-Path $tree "Localization") (Join-Path $tree "Source") (Join-Path $tree "Intermediate") `
            (Join-Path $tree "Docs") (Join-Path $tree "Tools") (Join-Path $tree "Binaries\Win64") `
            (Join-Path $tree "Saved") `
        /XF "*.exp" "*.pdb" ".clang-format" ".gitignore" | Out-Null
    New-Item -ItemType Directory -Path "$dst\Binaries\Win64" -Force | Out-Null
    # 本地化工作文件（manifest / po / archive）与 beta 包保持同样的位置：Content\Localization\rebocap
    # 运行时只用 .locmeta + .locres，但这些文件是本地化目标的一部分（编辑器"本地化面板/重新采集"要用）
    $locWork = Join-Path $tree "Localization\rebocap"
    if (Test-Path -LiteralPath $locWork) {
        $locDst = Join-Path $dst "Content\Localization\rebocap"
        New-Item -ItemType Directory -Path $locDst -Force | Out-Null
        robocopy $locWork $locDst /E /NFL /NDL /NJH /NJS /NP | Out-Null
        Write-Host "  本地化工作文件已并入 Content\Localization\rebocap"
    }

    Copy-Item -Path "$binSrc\*Editor-rebocap*.dll" -Destination "$dst\Binaries\Win64" -Force -ErrorAction SilentlyContinue
    Copy-Item -Path "$binSrc\*.modules" -Destination "$dst\Binaries\Win64" -Force -ErrorAction SilentlyContinue
    # SDK DLL 必须同时出现在 Binaries\Win64（延迟加载搜索路径）与 ThirdParty（RuntimeDependencies）
    $sdkDll = Join-Path $binSrc "rebocap_ws_sdk.dll"
    if (-not (Test-Path -LiteralPath $sdkDll)) {
        $sdkDll = Join-Path $tree "Binaries\ThirdParty\RebocapWsSdk\Win64\rebocap_ws_sdk.dll"
    }
    if (Test-Path -LiteralPath $sdkDll) {
        Copy-Item -LiteralPath $sdkDll -Destination "$dst\Binaries\Win64\rebocap_ws_sdk.dll" -Force
    } else {
        Write-Host "  !! 找不到 rebocap_ws_sdk.dll"
    }


    # Epic BuildPlugin 会给已安装插件写两个标记：EngineVersion + Installed。
    # 缺了它们，编辑器会把它当"工程内源码插件"，部分流程会尝试重编（C++ 工程直接报
    # "Could not find definition for module"）。按目标引擎补上。
    $upluginPath = Join-Path $dst "rebocap.uplugin"
    if (Test-Path -LiteralPath $upluginPath) {
        $u = Get-Content -LiteralPath $upluginPath -Raw
        $engineVer = "$v.0"
        if ($u -notmatch '"EngineVersion"') {
            $u = [regex]::Replace($u, '("VersionName"\s*:\s*"[^"]+",)', ('$1' + "`r`n    `"EngineVersion`": `"$engineVer`","))
        }
        # 源码树里的 uplugin 带 "Installed": false（工程内插件），安装版必须置 true
        if ($u -match '"Installed"\s*:\s*(true|false)') {
            $u = [regex]::Replace($u, '"Installed"\s*:\s*(true|false)', '"Installed": true')
        } else {
            $u = [regex]::Replace($u, '("EngineVersion"\s*:\s*"[^"]+",)', ('$1' + "`r`n    `"Installed`": true,"))
        }
        [System.IO.File]::WriteAllText($upluginPath, $u, (New-Object System.Text.UTF8Encoding($false)))
        Write-Host "  uplugin 标记: EngineVersion=$engineVer Installed=true"
    }

    $dlls = @(Get-ChildItem -LiteralPath "$dst\Binaries\Win64" -Filter "*.dll" -ErrorAction SilentlyContinue)
    $mods = @(Get-ChildItem -LiteralPath "$dst\Binaries\Win64" -Filter "*.modules" -ErrorAction SilentlyContinue)
    Write-Host ("  Binaries: {0} dll, {1} modules" -f $dlls.Count, $mods.Count)
    $missing = @()
    if ($dlls.Count -lt 3) { $missing += "缺少模块 dll（应 3 个：rebocap/rebocap_editor/rebocap_runtime）" }
    if ($mods.Count -lt 1) { $missing += "缺少 .modules 描述文件" }
    if (-not (Test-Path -LiteralPath "$dst\Content\Localization\rebocap\zh-Hans\rebocap.locres")) { $missing += "缺少中文 locres" }
    if (-not (Test-Path -LiteralPath "$dst\rebocap.uplugin")) { $missing += "缺少 rebocap.uplugin" }
    if ($missing.Count -gt 0) { foreach ($m in $missing) { Write-Host "  !! $m" } }


    # UE 5.3+ 的 UBT 在批量构建时会把 .modules 的 BuildId 写成别的引擎的值（实测都写成了 5.5 的
    # 37670630），引擎启动时会判定 "out-of-date modules" 并跳过我们的 DLL。这里按目标引擎自身的
    # BuildId 校正——DLL 确实是用该引擎编译的，BuildId 只是兼容指纹。
    $modName = if ($v -like "4.*") { "UE4Editor.modules" } else { "UnrealEditor.modules" }
    $pkgMod = Join-Path $dst "Binaries\Win64\$modName"
    $engines = @{ "4.27" = "D:\Epic Games\UE_4.27"; "5.0" = "E:\Epic Games\UE_5.0"; "5.1" = "E:\Epic Games\UE_5.1";
                  "5.2" = "E:\Epic Games\UE_5.2"; "5.3" = "D:\Epic Games\UE_5.3"; "5.4" = "D:\Epic Games\UE_5.4";
                  "5.5" = "D:\Epic Games\UE_5.5"; "5.6" = "D:\Epic Games\UE_5.6"; "5.7" = "D:\Epic Games\UE_5.7";
                  "5.8" = "D:\Epic Games\UE_5.8"; "5.9" = "E:\Epic Games\UE_5.9" }
    $engMod = Join-Path $engines[$v] "Engine\Binaries\Win64\$modName"
    if ((Test-Path -LiteralPath $pkgMod) -and (Test-Path -LiteralPath $engMod)) {
        $engId = [regex]::Match((Get-Content -LiteralPath $engMod -Raw), '"BuildId"\s*:\s*"([^"]+)"').Groups[1].Value
        $pkgText = Get-Content -LiteralPath $pkgMod -Raw
        $newText = [regex]::Replace($pkgText, '("BuildId"\s*:\s*")[^"]+(")', '${1}' + $engId + '${2}')
        if ($newText -ne $pkgText) {
            [System.IO.File]::WriteAllText($pkgMod, $newText, (New-Object System.Text.UTF8Encoding($false)))
            Write-Host "  BuildId 校正为引擎值: $engId"
        }
    }

    if (-not $NoZip) {
        $zip = Join-Path $PackageRoot ("rebocap_UE_{0}_V3.zip" -f $v)
        if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
        Compress-Archive -Path $dst -DestinationPath $zip -CompressionLevel Optimal
        Write-Host ("  打包: {0}  {1} MB" -f (Split-Path $zip -Leaf), [math]::Round((Get-Item -LiteralPath $zip).Length / 1MB, 1))
    }
}

if (-not $NoZip) {
    Write-Host ""
    Write-Host "######## 源码包 ########"
    $srcZip4 = Join-Path $PackageRoot "Rebocap_UE4_Source_V3.zip"
    if (Test-Path -LiteralPath $srcZip4) { Remove-Item -LiteralPath $srcZip4 -Force }
    Compress-Archive -Path $UE4Tree -DestinationPath $srcZip4 -CompressionLevel Optimal
    Write-Host ("  {0}  {1} MB" -f (Split-Path $srcZip4 -Leaf), [math]::Round((Get-Item -LiteralPath $srcZip4).Length / 1MB, 1))

    $srcZip5 = Join-Path $PackageRoot "Rebocap_Universal_Source_V3.zip"
    if (Test-Path -LiteralPath $srcZip5) { Remove-Item -LiteralPath $srcZip5 -Force }
    Compress-Archive -Path $UE5Tree -DestinationPath $srcZip5 -CompressionLevel Optimal
    Write-Host ("  {0}  {1} MB" -f (Split-Path $srcZip5 -Leaf), [math]::Round((Get-Item -LiteralPath $srcZip5).Length / 1MB, 1))
}


    # 合并包：把 12 个版本包 + 2 个源码包 + 验收说明打成一个（对应 beta 包的 rebocap_UE426-58_*.zip）
    $combinedName = "rebocap_UE426-59_V3.zip"
    $combinedPath = Join-Path $PackageRoot $combinedName
    if (Test-Path -LiteralPath $combinedPath) { Remove-Item -LiteralPath $combinedPath -Force }
    $combinedItems = @()
    $combinedItems += Get-ChildItem -LiteralPath $PackageRoot -Filter "rebocap_UE_*_V3.zip" | Select-Object -ExpandProperty FullName
    $combinedItems += Get-ChildItem -LiteralPath $PackageRoot -Filter "*_Source_V3.zip" | Select-Object -ExpandProperty FullName
    $combinedItems += Get-ChildItem -LiteralPath $PackageRoot -Filter "验收说明.md" | Select-Object -ExpandProperty FullName
    if ($combinedItems.Count -gt 0) {
        Compress-Archive -Path $combinedItems -DestinationPath $combinedPath -CompressionLevel Optimal
        Write-Host ("  合并包: {0}  {1} MB  ({2} 个文件)" -f $combinedName, [math]::Round((Get-Item -LiteralPath $combinedPath).Length / 1MB, 1), $combinedItems.Count)
    }

Write-Host ""
Write-Host "== 发布包目录 =="
Get-ChildItem -LiteralPath $PackageRoot | ForEach-Object { "  " + $_.Name }
