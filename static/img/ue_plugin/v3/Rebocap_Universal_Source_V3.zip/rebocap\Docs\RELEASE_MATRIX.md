# 发布矩阵（4.27 ~ 5.9）

> 目标：一次交付 11 个引擎版本（4.27、5.0–5.9）的 V3 预编译包。
> 本文是"还需要准备什么"的核查结果与当前状态。

---

## 1. 环境核查

| 项目 | 结果 |
| --- | --- |
| 引擎安装 | **全部就位**：4.27、5.0–5.9（4.26 也在，供旧客户） |
| 编译器 | VS2022（5.x）+ VS2019 BuildTools（4.x） |
| 插件 Content | 只有本地化 `.locres`，**没有 `.uasset`** → 不需要逐版本重存资产 |
| `.locres` 格式 | 5.8 产出的与 4.27/5.9 引擎自带文件头一致（`0E 14 74 75 67 4A 03 FC`），跨版本通用 |
| `.uplugin` | 未写 `EngineVersion` → 不会被引擎判为版本不符 |

---

## 2. 跨版本 API 差异（本次修复，已进代码）

| 差异 | 影响版本 | 处理 |
| --- | --- | --- |
| `Animation/BoneReference.h` 5.3 才出现 | 4.27–5.2 编译失败 | 统一改用 `BoneContainer.h`（全版本都有，5.3+ 由它转发新头） |
| `ULiveLinkRemapAsset` 在 5.0 就属于 `LiveLinkAnimationCore` | 5.0 链接失败 | `rebocap_editor.Build.cs` 依赖条件 `>=5.1` → `>=5` |
| `FAppStyle` 5.1 才有 | 5.0 链接失败（`FEditorStyle::GetFontStyle`） | 依赖条件与 `RebocapEditorStyleCompat.h` 对齐 |
| `.modules` 里的 `BuildId` 写错 | **5.3 及以上全部**被引擎判定 `out-of-date modules` 并跳过 DLL | 实测 5.3/5.4/5.6–5.9 都被写成了 5.5 的值 `37670630`；打包脚本按目标引擎自身的 `BuildId` 校正（DLL 确实由该引擎编出，BuildId 只是兼容指纹） |

---

## 3. 构建与打包状态

全部 11 个版本 **0 error**，包已生成在 `插件发布包_V3\`。

| 版本 | 编译器 | 二进制前缀 | 构建 | 包内 BuildId 校正 | 加载冒烟 |
| --- | --- | --- | --- | --- |
| 4.27 | VS2019 | `UE4Editor-` | ✅ | 本来就对 | ✅ 模块挂载 + SDK 加载 + 编辑器模块启动（用发布包验证） |
| 5.0 | VS2022 | `UnrealEditor-` | ✅ | 本来就对 | ✅ 同上 |
| 5.1 | VS2022 | `UnrealEditor-` | ✅ | 本来就对 | ⏳ 首启慢，待补 |
| 5.2 | VS2022 | `UnrealEditor-` | ✅ | 本来就对 | ✅ |
| 5.3 | VS2022 | `UnrealEditor-` | ✅ | 已校正 27405482 | ⏳ |
| 5.4 | VS2022 | `UnrealEditor-` | ✅ | 已校正 33043543 | ⏳ |
| 5.5 | VS2022 | `UnrealEditor-` | ✅ | 本来就对 | ✅ |
| 5.6 | VS2022 | `UnrealEditor-` | ✅ | 已校正 43139311 | ⏳ |
| 5.7 | VS2022 | `UnrealEditor-` | ✅ | 已校正 47537391 | ⏳ |
| 5.8 | VS2022 | `UnrealEditor-` | ✅ | 已校正 55116800 | ✅ 真实工程验证（PIE/面板/本地化）；发布包另测 |
| 5.9 | VS2022 | `UnrealEditor-` | ✅ | 已校正 60351404 | ⏳ 引擎首启 >5 分钟，待补 |

> 冒烟超时不是插件问题：每个引擎**首次**启动要编译着色器（3–10 分钟），脚本等待窗口不够。
> 二次启动（DDC 已热）通常 1 分钟内即可用 `Tools/SmokeMatrix.ps1 -MaxWaitSeconds 300` 复测。

---

## 4. 发布包结构

```
插件发布包_V3/
├─ UE_4.27\rebocap\{rebocap.uplugin, Binaries\{ThirdParty\RebocapWsSdk\Win64, Win64}, Config, Content, Resources, x64, LICENSE, README.md}
├─ UE_5.0\rebocap\{...}
├─ ... UE_5.9
├─ rebocap_UE_<ver>_V3.zip          每版本一个（约 2.2–2.3 MB）
├─ Rebocap_UE4_Source_V3.zip        UE4 源码
└─ Rebocap_Universal_Source_V3.zip  UE5 源码（5.0–5.9 通用）
```

包内自检（`Tools/PackageRelease.ps1` 已内置）：3 个模块 dll + `rebocap_ws_sdk.dll` + `.modules` + 三语 locres + `.uplugin`。

---

## 5. 还需要准备的（按优先级）

1. **逐版本功能验证**：至少 4.27、5.4、5.9 各建一个最小工程，放一个含 Rebocap Body Pose 的 AnimBP，确认 PIE 里角色跟随动捕。
   （现有 `ue426_test` 只能验 4.26；跨版本打开会触发资产转换，不要混用。）
2. **Cook 验证**：4.27 与 5.8 各跑一次 `-run=Cook`，确认 `rebocap_ws_sdk.dll` 被 `RuntimeDependencies` 正确 stage 进包。
3. **`FilterPlugin.ini` 清理**：目前 `/x64/...` 会把 `x64/Release` 的 1.4 MB 重复 DLL 和 4 KB `.lib` 一起 stage 进 cooked 包。
   若确认运行时只用 `Binaries/ThirdParty`（代码里就是这条路径），可把该行改成 `/Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll`，每包省约 1.4 MB。
4. **补 4.26 包**（可选）：客户若还在 4.26，用 UE4 树再编一份即可（已验证）。
5. **发布说明**：README 版本徽标、CHANGELOG 增加 V3（A2T Retarget Asset、控制面板中文化、端口贯通、线程加固等）。
6. **回归**：5.x 包内二进制是本次矩阵构建产物，建议对 5.8 包做一次"装进干净工程 → 打开 → PIE"的端到端确认。

---

## 6. 风险与已知差异

| 项 | 说明 |
| --- | --- |
| 4.x 视口骨骼高亮 | UE4 只在骨骼控制节点编辑模式调用 `Draw`，普通预览不显示；UE5 选中即高亮（已与需求方确认以 UE5 为准） |
| 4.x 脊椎预设 | UE4 树映射 `spine_01/02/03`（UE4 Mannequin 只有 3 节）；5.x 保持 `spine_02/04/05` |
| 5.0/5.1 生命周期 | 5.0 已停更、5.1 也接近 EOL，仍保留在矩阵里（编译通过即可） |
| 打包重复 DLL | 见第 5 节第 3 条 |
