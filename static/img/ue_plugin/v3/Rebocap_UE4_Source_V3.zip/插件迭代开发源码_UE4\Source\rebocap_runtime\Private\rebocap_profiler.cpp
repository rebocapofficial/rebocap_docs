﻿#include "rebocap_profiler.h"
#include "rebocap_version.h"
#include "rebocap_source.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/DateTime.h"
#include "HAL/PlatformProcess.h"
#include "HAL/PlatformMemory.h"
#include "HAL/PlatformMisc.h"
#include "HAL/IConsoleManager.h"
#include "Scalability.h"
#include "Runtime/Launch/Resources/Version.h"

FRebocapProfiler& FRebocapProfiler::Get() {
    static FRebocapProfiler Instance;
    return Instance;
}

FRebocapProfiler::FRebocapProfiler() {
}

bool FRebocapProfiler::IsRecording() const {
    FScopeLock ScopeLock(&DataLock);
    return bIsRecording;
}

FString FRebocapProfiler::GetLastReportFilePath() const {
    FScopeLock ScopeLock(&DataLock);
    return LastReportFilePath;
}

FRebocapProfiler::~FRebocapProfiler() {
}

void FRebocapProfiler::StartRecording(float InDurationSeconds) {
    FScopeLock ScopeLock(&DataLock);
    TargetDuration = FMath::Max(1.0f, InDurationSeconds);
    RecordingStartTime = FPlatformTime::Seconds();
    LastSampleTime = RecordingStartTime;
    Samples.Empty();
    Samples.Reserve(static_cast<int32>(TargetDuration * 120.0f));
    PacketArrivalTimes.Empty();
    PacketArrivalTimes.Reserve(static_cast<int32>(TargetDuration * 120.0f));
    bIsRecording = true;
    UE_LOG(LogTemp, Display, TEXT("[Rebocap Profiler] Started deep diagnostic recording for %.1f seconds..."), TargetDuration);
}

void FRebocapProfiler::SampleFrame(float DeltaSeconds, float CurrentMocapHz, bool bIsConnected) {
    FScopeLock ScopeLock(&DataLock);
    if (!bIsRecording) return;

    double CurrentTime = FPlatformTime::Seconds();
    float Elapsed = static_cast<float>(CurrentTime - RecordingStartTime);

    if (Elapsed >= TargetDuration) {
        StopRecordingAndGenerateReport();
        return;
    }

    FRebocapSamplePoint Point;
    Point.ElapsedTime = Elapsed;
    Point.RenderDeltaMs = DeltaSeconds * 1000.0f;
    Point.RenderFPS = DeltaSeconds > 0.0f ? (1.0f / DeltaSeconds) : 0.0f;
    Point.MocapHz = CurrentMocapHz;
    Point.bConnected = bIsConnected;

    Samples.Add(Point);
}

void FRebocapProfiler::RecordPacketArrival(double Timestamp) {
    FScopeLock ScopeLock(&DataLock);
    if (bIsRecording) {
        PacketArrivalTimes.Add(Timestamp);
    }
}

void FRebocapProfiler::UpdateSkeletalContext(const FRebocapBoneMappingInfo& InInfo) {
    FScopeLock ScopeLock(&DataLock);
    CachedBoneInfo = InInfo;
    bHasBoneInfo = true;
}

void FRebocapProfiler::UpdateNodeConfig(const FRebocapNodeConfigSnapshot& InConfig) {
    FScopeLock ScopeLock(&DataLock);
    CachedNodeConfig = InConfig;
    bHasNodeConfig = true;
}

float FRebocapProfiler::GetRemainingTime() const {
    FScopeLock ScopeLock(&DataLock);
    if (!bIsRecording) return 0.0f;
    double CurrentTime = FPlatformTime::Seconds();
    float Elapsed = static_cast<float>(CurrentTime - RecordingStartTime);
    return FMath::Max(0.0f, TargetDuration - Elapsed);
}

float FRebocapProfiler::GetProgress() const {
    FScopeLock ScopeLock(&DataLock);
    if (!bIsRecording || TargetDuration <= 0.0f) return 0.0f;
    double CurrentTime = FPlatformTime::Seconds();
    float Elapsed = static_cast<float>(CurrentTime - RecordingStartTime);
    return FMath::Clamp(Elapsed / TargetDuration, 0.0f, 1.0f);
}

void FRebocapProfiler::StopRecordingAndGenerateReport() {
    FString ReportContent;
    FString ReportPath;
    {
        FScopeLock ScopeLock(&DataLock);
        if (!bIsRecording && Samples.Num() == 0) return;
        bIsRecording = false;

        ReportContent = GenerateReportString();

        const FString LogDir = FPaths::ProjectSavedDir() / TEXT("Logs");
        const FString TimeStamp = FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S"));
        ReportPath = LogDir / FString::Printf(TEXT("Rebocap_Diagnostic_Report_%s.txt"), *TimeStamp);
        LastReportFilePath = ReportPath;
    }

    // File IO and shell integration happen outside the lock: the worker thread keeps recording
    // packet arrivals while the report is written.
    const FString LogDir = FPaths::GetPath(ReportPath);
    IFileManager::Get().MakeDirectory(*LogDir, true);

    const bool bSaved = FFileHelper::SaveStringToFile(ReportContent, *ReportPath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    if (bSaved) {
        UE_LOG(LogTemp, Display, TEXT("[Rebocap Profiler] Deep diagnostic report successfully saved to: %s"), *ReportPath);
#if !UE_BUILD_SHIPPING
        // Never pop Explorer from a packaged game; it is an editor-side convenience.
        FPlatformProcess::ExploreFolder(*ReportPath);
#endif
    } else {
        UE_LOG(LogTemp, Error, TEXT("[Rebocap Profiler] Failed to save diagnostic report to: %s"), *ReportPath);
    }
}

static FString GetQualityName(int32 Level) {
    switch (Level) {
        case 0: return TEXT("Low");
        case 1: return TEXT("Medium");
        case 2: return TEXT("High");
        case 3: return TEXT("Epic");
        case 4: return TEXT("Cinematic");
        default: return FString::Printf(TEXT("Custom (%d)"), Level);
    }
}

FString FRebocapProfiler::GenerateReportString() {
    FString Report;
    Report += TEXT("================================================================================\n");
    Report += TEXT("        REBOCAP UE plugin in-depth runtime and performance diagnostics report (AI analysis edition)\n");
    Report += TEXT("================================================================================\n");
    Report += FString::Printf(TEXT("Generated at: %s\n"), *FDateTime::Now().ToString(TEXT("%Y-%m-%d %H:%M:%S")));
    Report += FString::Printf(TEXT("Plugin version: %s\n"), *RebocapVersion::GetFullVersion());
    Report += FString::Printf(TEXT("Unreal Engine version: %d.%d.%d\n"), ENGINE_MAJOR_VERSION, ENGINE_MINOR_VERSION, ENGINE_PATCH_VERSION);

#if WITH_EDITOR
    Report += TEXT("Run mode: Unreal Editor (editor)\n");
#else
    Report += TEXT("Run mode: Standalone / packaged game\n");
#endif

    // 1. Hardware and system environment
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[1. Hardware and system environment]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");
    Report += FString::Printf(TEXT("- OS: %s\n"), *FPlatformMisc::GetOSVersion());
    Report += FString::Printf(TEXT("- CPU: %s (physical cores: %d, logical threads: %d)\n"),
        *FPlatformMisc::GetCPUBrand(),
        FPlatformMisc::NumberOfCores(),
        FPlatformMisc::NumberOfCoresIncludingHyperthreads());

    FPlatformMemoryStats MemStats = FPlatformMemory::GetStats();
    Report += FString::Printf(TEXT("- RAM: %llu MB (available: %llu MB)\n"),
        MemStats.TotalPhysical / (1024 * 1024),
        MemStats.AvailablePhysical / (1024 * 1024));

    Report += FString::Printf(TEXT("- GPU: %s\n"), *FPlatformMisc::GetPrimaryGPUBrand());

    // 2. Engine viewport and render pipeline settings
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[2. Engine viewport and render quality settings]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");

    IConsoleVariable* CVarMaxFPS = IConsoleManager::Get().FindConsoleVariable(TEXT("t.MaxFPS"));
    float MaxFPS = CVarMaxFPS ? CVarMaxFPS->GetFloat() : 0.0f;
    Report += FString::Printf(TEXT("- Frame rate cap (t.MaxFPS): %.1f %s\n"), MaxFPS, MaxFPS <= 0.0f ? TEXT("(unlimited)") : TEXT(""));

    IConsoleVariable* CVarVSync = IConsoleManager::Get().FindConsoleVariable(TEXT("r.VSync"));
    int32 VSync = CVarVSync ? CVarVSync->GetInt() : 0;
    Report += FString::Printf(TEXT("- V-Sync (r.VSync): %s\n"), VSync > 0 ? TEXT("Enabled") : TEXT("Disabled"));

    IConsoleVariable* CVarScreenPercentage = IConsoleManager::Get().FindConsoleVariable(TEXT("r.ScreenPercentage"));
    float ScreenPercentage = CVarScreenPercentage ? CVarScreenPercentage->GetFloat() : 100.0f;
    Report += FString::Printf(TEXT("- Screen render percentage: %.1f%%\n"), ScreenPercentage);

    IConsoleVariable* CVarLumenGI = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Lumen.DiffuseIndirect.Allow"));
    int32 LumenGI = CVarLumenGI ? CVarLumenGI->GetInt() : 1;
    Report += FString::Printf(TEXT("- Lumen global illumination: %s\n"), LumenGI > 0 ? TEXT("Enabled") : TEXT("Disabled"));

    IConsoleVariable* CVarNanite = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Nanite"));
    int32 Nanite = CVarNanite ? CVarNanite->GetInt() : 1;
    Report += FString::Printf(TEXT("- Nanite virtualized geometry: %s\n"), Nanite > 0 ? TEXT("Enabled") : TEXT("Disabled"));

    Scalability::FQualityLevels QualityLevels = Scalability::GetQualityLevels();
    Report += FString::Printf(TEXT("- Global quality level:\n"));
    Report += FString::Printf(TEXT("  * View distance: %s | Anti-aliasing: %s | Shadows: %s | Post processing: %s\n"),
        *GetQualityName(QualityLevels.ViewDistanceQuality),
        *GetQualityName(QualityLevels.AntiAliasingQuality),
        *GetQualityName(QualityLevels.ShadowQuality),
        *GetQualityName(QualityLevels.PostProcessQuality));
#if ENGINE_MAJOR_VERSION >= 5
    Report += FString::Printf(TEXT("  * Textures: %s | Effects: %s | Global illumination: %s | Reflections: %s\n"),
        *GetQualityName(QualityLevels.TextureQuality),
        *GetQualityName(QualityLevels.EffectsQuality),
        *GetQualityName(QualityLevels.GlobalIlluminationQuality),
        *GetQualityName(QualityLevels.ReflectionQuality));
#else
    Report += FString::Printf(TEXT("  * Textures: %s | Effects: %s | Vegetation: %s\n"),
        *GetQualityName(QualityLevels.TextureQuality),
        *GetQualityName(QualityLevels.EffectsQuality),
        *GetQualityName(QualityLevels.FoliageQuality));
#endif

    // 3. Character mesh and 24-bone retarget mapping
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[3. Character model and 24-bone retarget mapping]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");
    if (bHasBoneInfo) {
        Report += FString::Printf(TEXT("- Skeletal Mesh: %s\n"), *CachedBoneInfo.MeshName);
        Report += FString::Printf(TEXT("- Skeleton: %s\n"), *CachedBoneInfo.SkeletonName);
        Report += FString::Printf(TEXT("- Total bones: %d | current LOD: %d\n"), CachedBoneInfo.BoneCount, CachedBoneInfo.LODLevel);
        Report += FString::Printf(TEXT("- Retarget Asset: %s\n"), *CachedBoneInfo.RetargetAssetName);
        Report += TEXT("- 24 core bone mappings:\n");

        int32 UnmappedCount = 0;
        for (const auto& Pair : CachedBoneInfo.BoneMap) {
            bool bIsNone = (Pair.Value.IsEmpty() || Pair.Value.Equals(TEXT("None"), ESearchCase::IgnoreCase));
            if (bIsNone) {
                UnmappedCount++;
                Report += FString::Printf(TEXT("  ❌ %-16s -> %-24s [warning: unmapped / None]\n"), *Pair.Key, *Pair.Value);
            } else {
                Report += FString::Printf(TEXT("  ✓  %-16s -> %-24s\n"), *Pair.Key, *Pair.Value);
            }
        }
        if (UnmappedCount > 0) {
            Report += FString::Printf(TEXT("⚠️ %d bones are unmapped! The matching body parts may not be driven by mocap.\n"), UnmappedCount);
        } else {
            Report += TEXT("✓ All 24 bones are mapped and bound successfully.\n");
        }
    } else {
        Report += TEXT("○ Rebocap Body Pose node is not active in the current viewport or anim blueprint, so no character bone bindings were captured.\n");
    }

    // 4. Current anim node runtime config snapshot
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[4. Current anim node runtime config snapshot]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");
    if (bHasNodeConfig) {
        Report += FString::Printf(TEXT("- Auto-connect mocap (Connect Rebocap): %s\n"), CachedNodeConfig.bAutoConnect ? TEXT("On") : TEXT("Off"));
        Report += FString::Printf(TEXT("- Auto submit skeleton data: %s\n"), CachedNodeConfig.bAutoSkeleton ? TEXT("On") : TEXT("Off"));
        Report += FString::Printf(TEXT("- Enable Frame Interpolation: %s (rate: %.1f)\n"),
            CachedNodeConfig.bEnableInterpolation ? TEXT("On") : TEXT("Off"),
            CachedNodeConfig.InterpolationSpeed);
        Report += FString::Printf(TEXT("- Hold Pose On Dropout: %s (timeout: %.1fs)\n"),
            CachedNodeConfig.bHoldPoseOnDropout ? TEXT("On") : TEXT("Off"),
            CachedNodeConfig.DropoutTimeout);
        Report += FString::Printf(TEXT("- Experimental switches: skeleton throttle=%s | zero allocation=%s | thread lock optimization=%s\n"),
            CachedNodeConfig.bThrottleSkeletonRegistration ? TEXT("On") : TEXT("Off"),
            CachedNodeConfig.bZeroAllocStaticSubject ? TEXT("On") : TEXT("Off"),
            CachedNodeConfig.bOptimizeFrameEvaluation ? TEXT("On") : TEXT("Off"));
    } else {
        Report += TEXT("○ Node config not ready.\n");
    }

    // 5. Mocap packet jitter and timing analysis
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[5. Mocap packet jitter and arrival timing analysis]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");
    auto Source = FRebocapSource::GetInstance();
    bool bConnected = Source.IsValid() && Source->IsPortOpen();
    Report += FString::Printf(TEXT("- WebSocket port: 7690 | link state: %s\n"), bConnected ? TEXT("● Streaming normally") : TEXT("○ Not connected"));

    int32 TotalPackets = PacketArrivalTimes.Num();
    Report += FString::Printf(TEXT("- Mocap packets received during the 10 s sample: %d\n"), TotalPackets);

    if (TotalPackets > 1) {
        int32 NormalIntervals = 0;   // 12ms ~ 20ms (around 60Hz)
        int32 DelayedIntervals = 0;  // 20ms ~ 50ms
        int32 DropoutIntervals = 0;  // > 50ms
        double MaxGapSeconds = 0.0;
        double SumInterval = 0.0;

        for (int32 i = 1; i < TotalPackets; ++i) {
            double Interval = PacketArrivalTimes[i] - PacketArrivalTimes[i - 1];
            double IntervalMs = Interval * 1000.0;
            SumInterval += Interval;
            MaxGapSeconds = FMath::Max(MaxGapSeconds, Interval);

            if (IntervalMs >= 12.0 && IntervalMs <= 20.0) {
                NormalIntervals++;
            } else if (IntervalMs > 50.0) {
                DropoutIntervals++;
            } else {
                DelayedIntervals++;
            }
        }

        int32 TotalIntervals = TotalPackets - 1;
        float NormalPct = (static_cast<float>(NormalIntervals) / TotalIntervals) * 100.0f;
        float AvgIntervalMs = static_cast<float>((SumInterval / TotalIntervals) * 1000.0);

        Report += FString::Printf(TEXT("- Average packet arrival interval: %.2f ms (60 Hz ideal: 16.67 ms)\n"), AvgIntervalMs);
        Report += FString::Printf(TEXT("- On-time 60 Hz arrival rate (12~20 ms): %.1f%% (%d/%d)\n"), NormalPct, NormalIntervals, TotalIntervals);
        Report += FString::Printf(TEXT("- Minor network delay (20~50 ms): %d times\n"), DelayedIntervals);
        Report += FString::Printf(TEXT("- Severe stutter / packet drop (>50 ms): %d times\n"), DropoutIntervals);
        Report += FString::Printf(TEXT("- Max gap without data: %.1f ms\n"), MaxGapSeconds * 1000.0);
    }

    // 6. Viewport framerate sampling stats
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[6. Viewport framerate sampling stats and waveform]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");

    if (Samples.Num() > 0) {
        float SumFPS = 0.0f;
        float MinFPS = 999999.0f;
        float MaxRenderFPS = 0.0f;
        float SumHz = 0.0f;
        float MinHz = 999999.0f;
        float MaxHz = 0.0f;
        int32 ConnectedSamples = 0;

        for (const auto& Pt : Samples) {
            SumFPS += Pt.RenderFPS;
            MinFPS = FMath::Min(MinFPS, Pt.RenderFPS);
            MaxRenderFPS = FMath::Max(MaxRenderFPS, Pt.RenderFPS);

            if (Pt.bConnected && Pt.MocapHz > 0.0f) {
                SumHz += Pt.MocapHz;
                MinHz = FMath::Min(MinHz, Pt.MocapHz);
                MaxHz = FMath::Max(MaxHz, Pt.MocapHz);
                ConnectedSamples++;
            }
        }

        float AvgFPS = SumFPS / static_cast<float>(Samples.Num());
        float AvgHz = ConnectedSamples > 0 ? (SumHz / static_cast<float>(ConnectedSamples)) : 0.0f;
        if (ConnectedSamples == 0) MinHz = 0.0f;

        Report += FString::Printf(TEXT("- Viewport framerate: avg %.1f FPS | min %.1f FPS | max %.1f FPS\n"), AvgFPS, MinFPS, MaxRenderFPS);
        Report += FString::Printf(TEXT("- Mocap receive rate: avg %.1f Hz  | min %.1f Hz  | max %.1f Hz\n"), AvgHz, MinHz, MaxHz);

        Report += TEXT("\n--- Sampling waveform (0.25 s buckets) ---\n");
        float BucketStart = 0.0f;
        float BucketFPS = 0.0f;
        float BucketHz = 0.0f;
        int32 BucketCount = 0;

        for (int32 i = 0; i < Samples.Num(); ++i) {
            const auto& Pt = Samples[i];
            BucketFPS += Pt.RenderFPS;
            BucketHz += Pt.MocapHz;
            BucketCount++;

            if (Pt.ElapsedTime - BucketStart >= 0.25f || i == Samples.Num() - 1) {
                float AvgBucketFPS = BucketCount > 0 ? (BucketFPS / BucketCount) : 0.0f;
                float AvgBucketHz = BucketCount > 0 ? (BucketHz / BucketCount) : 0.0f;
                Report += FString::Printf(TEXT("  [%5.2fs ~ %5.2fs] viewport: %5.1f FPS | mocap: %5.1f Hz %s\n"),
                    BucketStart, Pt.ElapsedTime, AvgBucketFPS, AvgBucketHz,
                    AvgBucketHz < 45.0f && bConnected ? TEXT("<< [host frame drop / jitter]") : TEXT(""));

                BucketStart = Pt.ElapsedTime;
                BucketFPS = 0.0f;
                BucketHz = 0.0f;
                BucketCount = 0;
            }
        }
    }

    // 7. Diagnostic findings and troubleshooting advice
    Report += TEXT("\n--------------------------------------------------------------------------------\n");
    Report += TEXT("[7. Diagnostic findings and troubleshooting advice]\n");
    Report += TEXT("--------------------------------------------------------------------------------\n");

    if (!bConnected) {
        Report += TEXT("❌ [Mocap not connected] Not connected to the Rebocap host app (port 7690). Make sure the Rebocap app is running and streaming.\n");
    } else {
        Report += TEXT("✓ Mocap link is connected and healthy.\n");
    }

    if (Samples.Num() > 0) {
        float SumFPS = 0.0f;
        for (const auto& Pt : Samples) SumFPS += Pt.RenderFPS;
        float AvgFPS = SumFPS / static_cast<float>(Samples.Num());

        if (AvgFPS < 25.0f) {
            Report += TEXT("⚠️ [Viewport framerate too low] Viewport framerate is below 25 FPS. Possible causes:\n");
            Report += TEXT("   1. The viewport is not in Realtime mode (press Ctrl+R to enable it).\n");
            Report += TEXT("   2. The editor lost focus, which triggered background throttling.\n");
        } else if (AvgFPS > 100.0f && (!bHasNodeConfig || !CachedNodeConfig.bEnableInterpolation)) {
            Report += TEXT("💡 [High-refresh smoothing tip] Viewport framerate is above 100 FPS. Enable [Enable Frame Interpolation] on the anim blueprint node to remove the micro-stutter caused by unsynchronized 60 Hz mocap sampling.\n");
        }
    }

    Report += TEXT("================================================================================\n");
    Report += TEXT("Report generation complete.\n");
    Report += TEXT("================================================================================\n");

    return Report;
}
