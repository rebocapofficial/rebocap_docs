#include "RebocapA2TEditorLibrary.h"

#include "AnimGraphNode_RebocapA2T.h"
#include "AnimGraphNode_RebocapPose.h"
#include "BoneContainer.h"   // FBoneReference (UE5.3+ moved it into Animation/BoneReference.h, re-exported here)
#include "Internationalization/Culture.h"
#include "Internationalization/Internationalization.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Misc/Paths.h"
#include "Engine/Blueprint.h"
#include "UObject/UObjectIterator.h"
#include "rebocap_body_remap_asset.h"
#include "rebocap_pose_node.h"
#include "rebocap_source.h"

namespace RebocapA2TEditor
{
	static UClass* ResolveMapDataClass(const FString& InPath)
	{
		if (InPath.IsEmpty())
		{
			return nullptr;
		}

		// 1) Full object path: /Game/Dir/Asset.Asset_C
		if (UClass* Loaded = LoadClass<URebocapMapData>(nullptr, *InPath))
		{
			return Loaded;
		}

		// 2) Asset path only, /Game/Dir/Asset 闂?append the class object name
		const FString BaseName = FPaths::GetBaseFilename(InPath);
		if (UClass* Loaded = LoadClass<URebocapMapData>(nullptr, *FString::Printf(TEXT("%s.%s_C"), *InPath, *BaseName)))
		{
			return Loaded;
		}

		// 3) Asset name only 闂?look up a class with that name under /Game
		return LoadClass<URebocapMapData>(nullptr, *FString::Printf(TEXT("/Game/%s.%s_C"), *InPath, *InPath));
	}

	static void CollectNodes(TArray<UAnimGraphNode_RebocapA2T*>& Out)
	{
		for (TObjectIterator<UAnimGraphNode_RebocapA2T> It; It; ++It)
		{
			UAnimGraphNode_RebocapA2T* Node = *It;
			if (!IsValid(Node) || Node->HasAnyFlags(RF_ClassDefaultObject | RF_ArchetypeObject))
			{
				continue;
			}
			Out.Add(Node);
		}
	}
}

int32 URebocapA2TEditorLibrary::ApplyRetargetAssetToAllA2TNodes(const FString& RetargetAssetPath)
{
	UClass* AssetClass = RebocapA2TEditor::ResolveMapDataClass(RetargetAssetPath);
	if (!AssetClass)
	{
		UE_LOG(LogTemp, Warning, TEXT("[Rebocap A2T] Retarget Asset not found: %s"), *RetargetAssetPath);
		return -1;
	}

	TArray<UAnimGraphNode_RebocapA2T*> Nodes;
	RebocapA2TEditor::CollectNodes(Nodes);

	for (UAnimGraphNode_RebocapA2T* Node : Nodes)
	{
		Node->Modify();
		Node->Node.retarget_asset_ = AssetClass;
		Node->Node.bUseRetargetAssetBones = true;
		UE_LOG(LogTemp, Display, TEXT("[Rebocap A2T][diag] %s read-back after assignment: asset=%s"),
			*Node->GetName(),
			Node->Node.retarget_asset_ ? *Node->Node.retarget_asset_->GetName() : TEXT("None"));

		Node->Node.ApplyRetargetAssetBones();
		UE_LOG(LogTemp, Display, TEXT("[Rebocap A2T][diag] %s read-back after ApplyRetargetAssetBones: asset=%s"),
			*Node->GetName(),
			Node->Node.retarget_asset_ ? *Node->Node.retarget_asset_->GetName() : TEXT("None"));

		Node->ReconstructNode();
		UE_LOG(LogTemp, Display, TEXT("[Rebocap A2T][diag] %s read-back after ReconstructNode: asset=%s"),
			*Node->GetName(),
			Node->Node.retarget_asset_ ? *Node->Node.retarget_asset_->GetName() : TEXT("None"));

		Node->MarkPackageDirty();
	}

	UE_LOG(LogTemp, Display, TEXT("[Rebocap A2T] Assigned Retarget Asset to %d node(s): %s"), Nodes.Num(), *AssetClass->GetName());
	return Nodes.Num();
}

TArray<FString> URebocapA2TEditorLibrary::GetLocalizedTextProbe()
{
	// Same LOCTEXT entries as the node and panel titles, so they reveal whether localization really took effect.
	TArray<FString> Lines;

	const FText PanelTitle = NSLOCTEXT("FrebocapModule", "FrebocapTabTitle", "Rebocap Control Panel");
	const FText PoseTitle = NSLOCTEXT("RebocapAnimGraphNode", "RebocapPoseNodeTitle", "Rebocap Body Pose");
	const FText A2TTitle = NSLOCTEXT("RebocapA2TAnimGraphNode", "RebocapA2TNodeTitle", "Rebocap A-Pose to T-Pose");
	const FText HzFormat = NSLOCTEXT("RebocapAnimGraphNode", "RebocapPoseNodeTitleHzFormat", "Rebocap Body Pose [{0} Hz]");
	const FText DisplayNameProbe = NSLOCTEXT("UObjectDisplayNames", "AnimNode_RebocapA2T:Alpha", "Alpha");

	Lines.Add(FString::Printf(TEXT("culture=%s"), *FInternationalization::Get().GetCurrentCulture()->GetName()));
	Lines.Add(FString::Printf(TEXT("panel_title=[%s]"), *PanelTitle.ToString()));
	Lines.Add(FString::Printf(TEXT("pose_title=[%s]"), *PoseTitle.ToString()));
	Lines.Add(FString::Printf(TEXT("a2t_title=[%s]"), *A2TTitle.ToString()));
	Lines.Add(FString::Printf(TEXT("hz_format=[%s]"), *HzFormat.ToString()));
	Lines.Add(FString::Printf(TEXT("hz_formatted=[%s]"), *FText::Format(HzFormat, FText::AsNumber(60)).ToString()));
	Lines.Add(FString::Printf(TEXT("display_name=[%s]"), *DisplayNameProbe.ToString()));

	// The property's own tooltip, which feeds both the Details panel and the pin hover text
	if (FProperty* PoseProp = FindFProperty<FProperty>(FRebocapPoseNode::StaticStruct(), TEXT("bEnableInterpolation")))
	{
		Lines.Add(FString::Printf(TEXT("pose_prop_tooltip=[%s]"), *PoseProp->GetToolTipText().ToString()));
	}
	if (FProperty* A2TProp = FindFProperty<FProperty>(FAnimNode_RebocapA2T::StaticStruct(), TEXT("bUseRetargetAssetBones")))
	{
		Lines.Add(FString::Printf(TEXT("a2t_prop_tooltip=[%s]"), *A2TProp->GetToolTipText().ToString()));
	}
	return Lines;
}

int32 URebocapA2TEditorLibrary::RebuildRebocapPinData()
{
	TSet<UBlueprint*> Blueprints;

	auto Collect = [&Blueprints](auto* Node) { if (Node) { if (UBlueprint* BP = Node->GetBlueprint()) { Blueprints.Add(BP); } } };
	for (TObjectIterator<UAnimGraphNode_RebocapA2T> It; It; ++It)
	{
		if (IsValid(*It) && !It->HasAnyFlags(RF_ClassDefaultObject)) { Collect(*It); }
	}
	for (TObjectIterator<UAnimGraphNode_RebocapPose> It; It; ++It)
	{
		if (IsValid(*It) && !It->HasAnyFlags(RF_ClassDefaultObject)) { Collect(*It); }
	}

	int32 Count = 0;
	for (UBlueprint* BP : Blueprints)
	{
		FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(BP);
		FKismetEditorUtilities::CompileBlueprint(BP);
		++Count;
		UE_LOG(LogTemp, Display, TEXT("[Rebocap] Recompiled Anim Blueprint '%s' to rebuild pin data"), *BP->GetName());
	}
	return Count;
}

TArray<FString> URebocapA2TEditorLibrary::DumpRebocapPinTooltips()
{
	TArray<FString> Lines;

	auto DumpNode = [&Lines](UEdGraphNode* Node)
	{
		Lines.Add(FString::Printf(TEXT("--- %s (%d pins) ---"), *Node->GetName(), Node->Pins.Num()));
		for (UEdGraphPin* Pin : Node->Pins)
		{
			if (!Pin)
			{
				continue;
			}
			// GetPinHoverText is what an SGraphPin hover tooltip actually reads from
			FString HoverText;
			Node->GetPinHoverText(*Pin, HoverText);
			Lines.Add(FString::Printf(TEXT("  %s | hover=[%s] | pinToolTip=[%s]"),
				*Pin->PinName.ToString(),
				*HoverText.Replace(TEXT("\n"), TEXT(" / ")),
				*Pin->PinToolTip.Replace(TEXT("\n"), TEXT(" / "))));
		}
	};

	for (TObjectIterator<UAnimGraphNode_RebocapA2T> It; It; ++It)
	{
		if (IsValid(*It) && !It->HasAnyFlags(RF_ClassDefaultObject)) { DumpNode(*It); }
	}
	for (TObjectIterator<UAnimGraphNode_RebocapPose> It; It; ++It)
	{
		if (IsValid(*It) && !It->HasAnyFlags(RF_ClassDefaultObject)) { DumpNode(*It); }
	}

	if (Lines.Num() == 0)
	{
		Lines.Add(TEXT("(no Rebocap anim graph nodes loaded)"));
	}
	return Lines;
}


TArray<FString> URebocapA2TEditorLibrary::DumpRebocapNodeTooltips()
{
	TArray<FString> Lines;

	for (TObjectIterator<UAnimGraphNode_RebocapA2T> It; It; ++It)
	{
		if (IsValid(*It) && !It->HasAnyFlags(RF_ClassDefaultObject))
		{
			Lines.Add(FString::Printf(TEXT("=== %s ===\n%s"), *It->GetName(), *It->GetTooltipText().ToString()));
		}
	}
	for (TObjectIterator<UAnimGraphNode_RebocapPose> It; It; ++It)
	{
		if (IsValid(*It) && !It->HasAnyFlags(RF_ClassDefaultObject))
		{
			Lines.Add(FString::Printf(TEXT("=== %s ===\n%s"), *It->GetName(), *It->GetTooltipText().ToString()));
		}
	}

	if (Lines.Num() == 0)
	{
		Lines.Add(TEXT("(no Rebocap anim graph nodes loaded)"));
	}
	return Lines;
}

TArray<FString> URebocapA2TEditorLibrary::DumpRebocapPoseNodes()
{
	TArray<FString> Lines;

	for (TObjectIterator<UAnimGraphNode_RebocapPose> It; It; ++It)
	{
		if (!IsValid(*It) || It->HasAnyFlags(RF_ClassDefaultObject))
		{
			continue;
		}

		const FRebocapPoseNode& N = It->Node;
		Lines.Add(FString::Printf(
			TEXT("%s | subject=%s autoConnect=%d autoSkeleton=%d interp=%d dropoutHold=%d optimizeEval=%d"),
			*It->GetName(),
			*N.LiveLinkSubjectName.Name.ToString(),
			N.bAutoConnect ? 1 : 0,
			N.bAutoSkeleton ? 1 : 0,
			N.bEnableInterpolation ? 1 : 0,
			N.bHoldPoseOnDropout ? 1 : 0,
			N.bOptimizeFrameEvaluation ? 1 : 0));

		// Walk the bone map through reflection so the report always matches the struct layout.
		int32 Mapped = 0;
		FString BoneList;
		for (TFieldIterator<FStructProperty> Prop(FRebocapBodyMap::StaticStruct()); Prop; ++Prop)
		{
			if (Prop->Struct != FBoneReference::StaticStruct())
			{
				continue;
			}
			const FBoneReference* Ref = Prop->ContainerPtrToValuePtr<FBoneReference>(&N.bone_map_);
			const FName BoneName = Ref ? Ref->BoneName : NAME_None;
			if (BoneName != NAME_None)
			{
				++Mapped;
			}
			BoneList += FString::Printf(TEXT("%s=%s "), *Prop->GetName(), *BoneName.ToString());
		}
		Lines.Add(FString::Printf(TEXT("  mapped bones: %d"), Mapped));

		// Port / subject plumbing: shows what the node is actually using after the control panel set a port.
		if (TSharedPtr<FRebocapSource> Source = FRebocapSource::GetInstance())
		{
			Lines.Add(FString::Printf(TEXT("  source: port=%d configuredPort=%d subject=%s open=%d"),
				Source->GetPort(),
				FRebocapSource::GetConfiguredPort(),
				*Source->GetSubjectName().ToString(),
				Source->IsPortOpen() ? 1 : 0));
		}
		else
		{
			Lines.Add(FString::Printf(TEXT("  source: (none) configuredPort=%d"), FRebocapSource::GetConfiguredPort()));
		}
		Lines.Add(FString::Printf(TEXT("  bone map: %s"), *BoneList));
	}

	if (Lines.Num() == 0)
	{
		Lines.Add(TEXT("(no Rebocap Pose nodes loaded)"));
	}
	return Lines;
}

void URebocapA2TEditorLibrary::SetMocapSourcePort(int32 Port)
{
	FRebocapSource::SetConfiguredPort(static_cast<uint16_t>(FMath::Clamp(Port, 1, 65535)));
	UE_LOG(LogTemp, Display, TEXT("[Rebocap] Mocap source port set to %d"), FRebocapSource::GetConfiguredPort());
}

int32 URebocapA2TEditorLibrary::ApplyRetargetAssetToAllPoseNodes(const FString& RetargetAssetPath)
{
	UClass* AssetClass = RebocapA2TEditor::ResolveMapDataClass(RetargetAssetPath);
	if (!AssetClass)
	{
		UE_LOG(LogTemp, Error, TEXT("[Rebocap] Retarget Asset not found: %s"), *RetargetAssetPath);
		return -1;
	}

	int32 Count = 0;
	for (TObjectIterator<UAnimGraphNode_RebocapPose> It; It; ++It)
	{
		if (!IsValid(*It) || It->HasAnyFlags(RF_ClassDefaultObject))
		{
			continue;
		}

		It->Modify();
		It->Node.retarget_asset_ = AssetClass;
		// Resolve the 24 bone references right away so the details panel and Dump show the result
		// without having to enter PIE first.
		It->Node.InitBoneMap();
		It->ReconstructNode();
		It->MarkPackageDirty();
		++Count;
	}

	UE_LOG(LogTemp, Display, TEXT("[Rebocap] Assigned Retarget Asset to %d Body Pose node(s): %s"), Count, *AssetClass->GetName());
	return Count;
}

TArray<FString> URebocapA2TEditorLibrary::DescribeA2TNodes()
{
	TArray<FString> Lines;
	TArray<UAnimGraphNode_RebocapA2T*> Nodes;
	RebocapA2TEditor::CollectNodes(Nodes);

	for (const UAnimGraphNode_RebocapA2T* Node : Nodes)
	{
		const FAnimNode_RebocapA2T& N = Node->Node;
		Lines.Add(FString::Printf(
			TEXT("%s | asset=%s | override=%s | effective=%s | useAsset=%s | pelvis=%s thighL=%s calfL=%s footL=%s upperArmL=%s lowerArmL=%s handL=%s spine=%s chest=%s upChest=%s neck=%s head=%s"),
			*Node->GetName(),
			N.retarget_asset_ ? *N.retarget_asset_->GetName() : TEXT("None"),
			N.retarget_asset_override_ ? *N.retarget_asset_override_->GetName() : TEXT("None"),
			N.GetEffectiveRetargetAsset() ? *N.GetEffectiveRetargetAsset()->GetName() : TEXT("None"),
			N.bUseRetargetAssetBones ? TEXT("true") : TEXT("false"),
			*N.Pelvis.BoneName.ToString(),
			*N.LeftThigh.BoneName.ToString(),
			*N.LeftCalf.BoneName.ToString(),
			*N.LeftFoot.BoneName.ToString(),
			*N.LeftUpperArm.BoneName.ToString(),
			*N.LeftLowerArm.BoneName.ToString(),
			*N.LeftHand.BoneName.ToString(),
			*N.Spine.BoneName.ToString(),
			*N.Chest.BoneName.ToString(),
			*N.UpChest.BoneName.ToString(),
			*N.Neck.BoneName.ToString(),
			*N.Head.BoneName.ToString()));
	}

	if (Lines.Num() == 0)
	{
		Lines.Add(TEXT("(no Rebocap A2T nodes currently loaded)"));
	}
	return Lines;
}
