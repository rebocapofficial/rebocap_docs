#pragma once

#include "CoreMinimal.h"
#include "AnimGraphNode_SkeletalControlBase.h"
#include "rebocap_pose_node.h"
#include "LiveLinkTypes.h"
#include "LiveLinkRefSkeleton.h"
#include "AnimGraphNode_RebocapPose.generated.h"

UCLASS()
class REBOCAP_EDITOR_API UAnimGraphNode_RebocapPose : public UAnimGraphNode_SkeletalControlBase
{
    GENERATED_BODY()

public:
    // Runtime logic node
    UPROPERTY(EditAnywhere, Category = Settings)
    FRebocapPoseNode Node;

    // --- Viewport bone highlight settings ---
    /** Highlights the bones and joints driven by Rebocap mocap in the animation preview viewport. */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Show Controlled Bones"))
    bool bShowControlledBones = true;

    /** Highlight color for controlled joints (default: bright neon blue). */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Joint Color"))
    FLinearColor JointColor = FLinearColor(0.0f, 0.75f, 1.0f, 1.0f);

    /** Highlight color for bone link lines (default: bright magenta). */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Link Color"))
    FLinearColor LinkColor = FLinearColor(1.0f, 0.2f, 0.6f, 1.0f);

    /** Joint sphere radius. */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Joint Radius", ClampMin = "0.5", ClampMax = "10.0"))
    float JointRadius = 2.2f;

    /** Bone link line thickness. */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Link Thickness", ClampMin = "0.5", ClampMax = "8.0"))
    float LinkThickness = 1.6f;

    // Draw controlled bone highlights in the viewport
    virtual void Draw(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* PreviewSkelMeshComp) const override;

    // Required virtual function (must be const on UE5.1+)
    virtual const FAnimNode_SkeletalControlBase* GetNode() const override { return &Node; }

    // Node title
    virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;

    // Pin hover text (UE 5.8's default path returns an empty string for this node)
    virtual void GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const override;

    // Hover tooltip
    virtual FText GetTooltipText() const override;

    // Node menu category
    virtual FText GetMenuCategory() const override;

    // Search keywords
    virtual FText GetKeywords() const override;
};