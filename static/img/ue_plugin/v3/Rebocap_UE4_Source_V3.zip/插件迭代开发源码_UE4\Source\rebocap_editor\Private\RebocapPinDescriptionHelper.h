// Copyright Rebocap. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraphPin.h"
#include "UObject/UnrealType.h"

/**
 * Builds the "pins" section that is appended to a Rebocap anim graph node's tooltip.
 *
 * UE 5.8 invalidates the Slate pin widget of optional pins whenever the node's optional
 * pins are rebuilt, and an invalidated pin widget returns an empty hover text without ever
 * asking the node (see SGraphPin::GetTooltipText -> bGraphDataInvalid). The node tooltip
 * itself keeps working, so the pin descriptions are surfaced there instead.
 *
 * Only pins that are actually visible on the graph node and backed by a struct property are
 * listed, in pin order. The pin name uses the raw (untranslated) metadata so it matches the
 * English label drawn on the node; the description is the localized tooltip.
 */
inline FString RebocapBuildPinDescriptionSection(const UEdGraphNode& GraphNode, const UScriptStruct* InStruct)
{
	if (!InStruct)
	{
		return FString();
	}

	// "Plumbing" properties shared by every anim node (pose input, Alpha blending, LOD) are present
	// on all of them and say nothing useful, so listing them would only drown out the pins that matter.
	auto IsPlumbingPin = [](const FName& PinName)
	{
		static const FName PlumbingNames[] = {
			FName(TEXT("BasePose")),
			FName(TEXT("ComponentPose")),
			FName(TEXT("Alpha")),
			FName(TEXT("AlphaCurveName")),
			FName(TEXT("bAlphaBoolEnabled")),
			FName(TEXT("LODThreshold"))
		};
		for (const FName& Name : PlumbingNames)
		{
			if (PinName == Name)
			{
				return true;
			}
		}
		return false;
	};

	TArray<FString> Lines;
	for (const UEdGraphPin* Pin : GraphNode.Pins)
	{
		if (!Pin || Pin->bHidden || IsPlumbingPin(Pin->PinName))
		{
			continue;
		}

		const FProperty* Prop = InStruct->FindPropertyByName(Pin->PinName);
		if (!Prop)
		{
			// Not a property pin (standard pins such as Component Pose / Alpha / Pose)
			continue;
		}

		// List only properties this plugin declares: inherited engine pins such as Component Pose /
		// Alpha / Pose carry nothing extra for the user and would only make the tooltip longer.
		if (Prop->GetOwnerStruct() != InStruct)
		{
			continue;
		}

		FString ToolTip = Prop->GetToolTipText().ToString();
		ToolTip.ReplaceInline(TEXT("\n"), TEXT(" "));
		ToolTip.TrimStartAndEndInline();

		// The pin label drawn on the graph is always the raw English text (GetPinMetaData returns an
		// untranslated FString), so the untranslated DisplayName metadata must be used here too to
		// match the pin names on the node. Properties without that metadata are drawn with an
		// auto-prettified name, so fall back to GetDisplayNameText() for those (also untranslated).
		FString PinName = Prop->GetMetaData(TEXT("DisplayName"));
		if (PinName.IsEmpty())
		{
			PinName = Prop->GetName();
		}

		Lines.Add(ToolTip.IsEmpty()
			? FString::Printf(TEXT("  \u2022 %s"), *PinName)
			: FString::Printf(TEXT("  \u2022 %s \u2014 %s"), *PinName, *ToolTip));
	}

	if (Lines.Num() == 0)
	{
		return FString();
	}

	FString Out = FString::Printf(TEXT("\n\n%s"), *NSLOCTEXT("RebocapNodeTooltip", "PinLegendHeader", "Pins:").ToString());
	for (const FString& Line : Lines)
	{
		Out += TEXT("\n") + Line;
	}
	return Out;
}
