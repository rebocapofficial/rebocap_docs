#pragma once

#include <optional>

#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimNodeBase.h"
#include "BoneControllers/AnimNode_SkeletalControlBase.h"
#include "LiveLinkTypes.h"
#include "ILiveLinkClient.h"
#include "Runtime/Launch/Resources/Version.h"

class ULiveLinkRemapAsset;
class ILiveLinkClient;

#if ENGINE_MAJOR_VERSION < 5
typedef FVector FVector3f;
typedef FVector4 FVector4f;
typedef FQuat FQuat4f;
typedef FMatrix FMatrix44f;
#endif

#include "rebocap_body_remap_asset.h"
#include "rebocap_pose_node.generated.h"

// 1. Bone definitions
USTRUCT()
struct REBOCAP_RUNTIME_API FRebocapBodyMap {
  GENERATED_USTRUCT_BODY()

  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference Pelvis;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Hip;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Hip;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference Spine1;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Knee;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Knee;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference Spine2;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Ankle;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Ankle;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference Spine3;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Foot;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Foot;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference Neck;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Collar;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Collar;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference Head;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Shoulder;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Shoulder;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Elbow;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Elbow;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Wrist;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Wrist;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference L_Hand;
  UPROPERTY(EditAnywhere, Category = SkeletalControl) FBoneReference R_Hand;
};

// 2. TPose
struct TPose {
  std::optional<FTransform> pelvis;
  std::optional<FTransform> l_hip;
  std::optional<FTransform> r_hip;
  std::optional<FTransform> spine1;
  std::optional<FTransform> l_knee;
  std::optional<FTransform> r_knee;
  std::optional<FTransform> spine2;
  std::optional<FTransform> l_ankle;
  std::optional<FTransform> r_ankle;
  std::optional<FTransform> spine3;
  std::optional<FTransform> l_foot;
  std::optional<FTransform> r_foot;
  std::optional<FTransform> neck;
  std::optional<FTransform> l_collar;
  std::optional<FTransform> r_collar;
  std::optional<FTransform> head;
  std::optional<FTransform> l_shoulder;
  std::optional<FTransform> r_shoulder;
  std::optional<FTransform> l_elbow;
  std::optional<FTransform> r_elbow;
  std::optional<FTransform> l_wrist;
  std::optional<FTransform> r_wrist;
  std::optional<FTransform> l_hand;
  std::optional<FTransform> r_hand;
};

// 3. Anim node
USTRUCT()
struct REBOCAP_RUNTIME_API FRebocapPoseNode : public FAnimNode_SkeletalControlBase {
  GENERATED_USTRUCT_BODY()
  typedef FAnimNode_SkeletalControlBase Super;

  FRebocapPoseNode();

  UPROPERTY()
  FRebocapBodyMap bone_map_;

  /** Live Link subject name (defaults to rebocap). */
  UPROPERTY(EditAnywhere, Category = SourceData, meta = (PinHiddenByDefault, DisplayName = "LiveLink Subject Name", ToolTip = "Live Link subject name (defaults to rebocap)."))
  FLiveLinkSubjectName LiveLinkSubjectName;

  // --- Switches fully delegated to Blueprint ---
  
  // 1. Whether to submit the T-Pose automatically
  /** 
   * Whether to send the current character's T-Pose skeleton data back to Rebocap automatically.
   * Disable this once a fixed skeleton file exists, or if the repeated data is unwanted;
   * exposing it as a pin for manual control is recommended. (Default: ON)
   */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinShownByDefault, DisplayName = "Auto Submit Skeleton Data", ToolTip = "Automatically submit character T-Pose skeleton data back to Rebocap."))
  bool bAutoSkeleton = true;

  // 2. Whether to connect automatically (default ON)
  /** Controls whether Rebocap is connected. (Default: ON) */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinShownByDefault, DisplayName = "Connect Rebocap", ToolTip = "Controls whether to automatically connect to Rebocap mocap service."))
  bool bAutoConnect = true;

  // 3. Mocap frame smoothing interpolation (default OFF)
  /** 
   * Enables high-precision time-based quaternion interpolation (SLERP frame interpolation):
   * removes the visual micro-stutter caused by 60Hz mocap data not lining up with high-refresh rendering
   * (e.g. 120 FPS / 144 FPS). (Default: OFF)
   */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinShownByDefault, DisplayName = "Enable Frame Interpolation", ToolTip = "Smoothly interpolates mocap data across high-framerate rendering to eliminate stuttering and judder."))
  bool bEnableInterpolation = false;

  /** Interpolation smoothing rate (default 45.0; higher follows the raw input closer, recommended 25.0 ~ 60.0). 0 disables smoothing. */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinShownByDefault, DisplayName = "Interpolation Speed", ClampMin = "1.0", ClampMax = "120.0", UIMin = "1.0", UIMax = "120.0", ToolTip = "Interpolation smoothing speed"))
  float InterpolationSpeed = 45.0f;

  // 4. Dropout protection (default ON)
  /** When enabled, holds the last valid pose through packet loss or lag spikes so the character never snaps back to T-Pose (default ON). */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinShownByDefault, DisplayName = "Hold Pose On Dropout", ToolTip = "When enabled, automatically holds the last valid pose during packet drops or lag spikes to prevent flickering into T-Pose."))
  bool bHoldPoseOnDropout = true;

  /** Dropout timeout in seconds (default 2.0): no new data for this long is treated as a full disconnect. */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (EditCondition = "bHoldPoseOnDropout", PinHiddenByDefault, DisplayName = "Dropout Timeout (s)", ClampMin = "0.1", ClampMax = "10.0", ToolTip = "Timeout in seconds before dropping out of pose hold protection."))
  float DropoutTimeout = 2.0f;

  /** A frame older than this (seconds) counts as a dropped frame. LiveLink keeps returning the last
   *  buffered frame, so without this a disconnect froze the character indefinitely. */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinHiddenByDefault, DisplayName = "Stale Frame Timeout (s)", ClampMin = "0.05", ClampMax = "2.0", ToolTip = "Frames older than this are treated as dropped. / 超过该时间的帧视为掉帧。"))
  float StaleFrameTimeout = 0.25f;

  /** Blend window applied when the stream resumes after a dropout (seconds). */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinHiddenByDefault, DisplayName = "Resume Blend (s)", ClampMin = "0.0", ClampMax = "1.0", ToolTip = "Smoothing window applied when the stream resumes after a dropout. / 掉线恢复时的过渡时间。"))
  float ResumeBlendSeconds = 0.15f;

  // 5. Viewport real-time diagnostics HUD (default OFF)
  /** 
   * Whether to display live mocap stream diagnostics in the top-left of the game or editor viewport
   * (mocap receive rate in Hz, rendering FPS and connection state). (Default: OFF)
   */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Rebocap Settings", meta = (PinShownByDefault, DisplayName = "Show Viewport Debug HUD", ToolTip = "Displays real-time mocap input rate (Hz), viewport rendering FPS, and stream diagnostics on screen."))
  bool bShowDebugHUD = false;

  // --- Experimental low-level performance tuning (all OFF by default, original logic preserved) ---

  /** 
   * [Experimental] Throttles skeleton and vertex submission:
   * T-Pose and foot-sole vertex data are sent back to the host at most once every 2.0 seconds
   * and fall completely silent after a successful handshake, avoiding per-frame mesh traversal
   * and network traffic while not yet connected or not ready. (Default: OFF)
   */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Experimental / Performance (Default OFF)", meta = (PinHiddenByDefault, DisplayName = "Throttle Skeleton Registration", ToolTip = "[Experimental] Throttles skeleton and vertex registration to at most once per 2 seconds to eliminate per-frame CPU hitches."))
  bool bThrottleSkeletonRegistration = false;

  /** 
   * [Experimental] Zero-allocation LiveLink data build:
   * skips the temporary static struct allocations otherwise performed 60 times per second
   * on the mocap receive thread. (Default: OFF)
   */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Experimental / Performance (Default OFF)", meta = (PinHiddenByDefault, DisplayName = "Zero-Alloc Static Subject", ToolTip = "[Experimental] Skips redundant 60Hz LiveLink static skeleton allocations when subject is already registered."))
  bool bZeroAllocStaticSubject = false;

  /** 
   * [Experimental] Animation evaluation lock and cache optimization:
   * caches the LiveLink subject role so frequent per-frame evaluation no longer re-requests
   * the role lock from LiveLinkClient. (Default: OFF)
   */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Experimental / Performance (Default OFF)", meta = (PinHiddenByDefault, DisplayName = "Optimize Frame Evaluation", ToolTip = "[Experimental] Caches LiveLink subject role to reduce per-frame lock contention on animation evaluation thread."))
  bool bOptimizeFrameEvaluation = false;

  // -----------------------------

  UPROPERTY(transient)
  ULiveLinkRemapAsset* current_retarget_asset_ = nullptr;

  // One-shot guard so the empty bone-map warning is logged only once per node instance.
  bool bWarnedAboutEmptyBoneMap_ = false;


  /** Bone mapping / retargeting name mapping table. */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, NoClear, Category = Retarget, meta = (PinShownByDefault, DisplayName = "Retarget Asset", ToolTip = "Bone mapping and retarget asset for character skeletal binding."))
  TSubclassOf<URebocapMapData> retarget_asset_;

  virtual void OnInitializeAnimInstance(const FAnimInstanceProxy* InProxy, const UAnimInstance* InAnimInstance) override;
  virtual void GatherDebugData(FNodeDebugData& DebugData) override;

  void Init_Foot_Vertices_And_SkeletalData(USkeletalMeshComponent* MeshComp);
  virtual void EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms) override;

  virtual bool HasPreUpdate() const override final { return true; }
  virtual void PreUpdate(const UAnimInstance* InAnimInstance) override final;

  void InitBoneMap();

  virtual bool IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones) override { return true; }
  virtual void UpdateComponentPose_AnyThread(const FAnimationUpdateContext& Context) override;
  virtual void UpdateInternal(const FAnimationUpdateContext& Context) override;
  virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;

 private:
  ILiveLinkClient* live_link_client_ = nullptr;
  virtual void InitializeBoneReferences(const FBoneContainer& RequiredBones) override;
  
  void UpdateConnectionState();

  TPose t_pose_;
  bool init_vertices_ = false;

  struct FPoseData {
    FQuat pelvis_quat = FQuat::Identity;
    FVector pelvis_position = FVector::ZeroVector;
    FQuat l_hip = FQuat::Identity;
    FQuat r_hip = FQuat::Identity;
    FQuat spine1 = FQuat::Identity;
    FQuat l_knee = FQuat::Identity;
    FQuat r_knee = FQuat::Identity;
    FQuat spine2 = FQuat::Identity;
    FQuat l_ankle = FQuat::Identity;
    FQuat r_ankle = FQuat::Identity;
    FQuat spine3 = FQuat::Identity;
    FQuat l_foot = FQuat::Identity;
    FQuat r_foot = FQuat::Identity;
    FQuat neck = FQuat::Identity;
    FQuat l_collar = FQuat::Identity;
    FQuat r_collar = FQuat::Identity;
    FQuat head = FQuat::Identity;
    FQuat l_shoulder = FQuat::Identity;
    FQuat r_shoulder = FQuat::Identity;
    FQuat l_elbow = FQuat::Identity;
    FQuat r_elbow = FQuat::Identity;
    FQuat l_wrist = FQuat::Identity;
    FQuat r_wrist = FQuat::Identity;
    FQuat l_hand = FQuat::Identity;
    FQuat r_hand = FQuat::Identity;
  };

  FPoseData cached_pose_data_;
  FPoseData interpolated_pose_data_;
  double last_valid_frame_time_ = 0.0;
  bool bHasValidFrameCached_ = false;
  bool bHasInterpolatedPoseCached_ = false;
  double last_skeleton_submit_time_ = 0.0;
  TSubclassOf<ULiveLinkRole> cached_subject_role_ = nullptr;

  TArray<FVector3f> LeftVertices_, LeftNormals_, RightVertices_, RightNormals_, SkeletonPosition_;
};