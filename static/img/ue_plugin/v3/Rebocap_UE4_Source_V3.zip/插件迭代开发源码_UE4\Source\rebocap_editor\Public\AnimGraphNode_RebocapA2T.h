#pragma once

#include "CoreMinimal.h"
#include "AnimGraphNode_Base.h"
#include "rebocap_a2t_node.h"
#include "AnimGraphNode_RebocapA2T.generated.h"

/**
 * Rebocap A2T pose calibration anim graph node (Editor - Local Space)
 * Expands an A-Pose character's limbs into a standard T-Pose with local-space rotation offsets, ready for mocap.
 */
UCLASS()
class REBOCAP_EDITOR_API UAnimGraphNode_RebocapA2T : public UAnimGraphNode_Base
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, Category = Settings)
    FAnimNode_RebocapA2T Node;

    // --- Viewport bone highlight settings ---
    /** Highlights the bones and joints controlled by the A2T node in the animation preview viewport. */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Show Controlled Bones"))
    bool bShowControlledBones = true;

    /** Highlight color for controlled joints (default: bright cyan-green). */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Joint Color"))
    FLinearColor JointColor = FLinearColor(0.0f, 1.0f, 0.5f, 1.0f);

    /** Highlight color for bone link lines (default: bright gold). */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Link Color"))
    FLinearColor LinkColor = FLinearColor(1.0f, 0.85f, 0.1f, 1.0f);

    /** Joint sphere radius. */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Joint Radius", ClampMin = "0.5", ClampMax = "10.0"))
    float JointRadius = 2.2f;

    /** Bone link line thickness. */
    UPROPERTY(EditAnywhere, Category = "Visual Debug / Viewport Bone Highlight", meta = (DisplayName = "Link Thickness", ClampMin = "0.5", ClampMax = "8.0"))
    float LinkThickness = 1.6f;

    virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
    virtual FText GetTooltipText() const override;
    virtual FText GetMenuCategory() const override;
    virtual FText GetKeywords() const override;

    // Pin hover text (UE 5.8's default path returns an empty string for this node)
    virtual void GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const override;

    // Draw controlled bone highlights in the viewport
    virtual void Draw(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* PreviewSkelMeshComp) const override;

    // Sync node data to the preview viewport live (WYSIWYG preview without recompiling)
    virtual void CopyNodeDataToPreviewNode(FAnimNode_Base* InPreviewNode) override;

    // Property change callback: handles one-click preset fill and mirrored symmetry edits
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

    // Pin related: sync rules for the Retarget Asset pin defaults (see the .cpp for details)
    virtual void AllocateDefaultPins() override;
    virtual void CopyPinDefaultsToNodeData(UEdGraphPin* InPin) override;

    // JSON export and import
    void ExportToJson();
    void ImportFromJson();
};
