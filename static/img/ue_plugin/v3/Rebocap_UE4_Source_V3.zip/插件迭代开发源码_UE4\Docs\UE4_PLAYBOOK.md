# Rebocap 插件 UE4 版本制作经验书

> 适用对象：接手 UE4 版本维护的同学。
> 核心原则：**UE5 是唯一事实来源（source of truth），UE4 是跟随者**。
> 本文替代早期的 `UE4_PORTING.md`（那份是首次移植的记录，内容已并入本文）。

---

## 1. 定位与原则

| 角色 | 说明 |
| --- | --- |
| UE5 树 `插件迭代开发源码\rebocap` | 唯一事实来源。所有功能、修复、本地化都在这里改。 |
| UE4 树 `插件迭代开发源码_UE4` | 由 UE5 同步而来，**只允许存在"引擎差异"改动**，不写业务逻辑。 |
| 老树 `插件迭代开发源码_UE4.27` | **不要沿用**。其中的中文字符串是乱码（`銈汇兂銈裤兗` 这类），且缺失 A2T、多语言、端口贯通等全部 V2.x 改动。 |

判断标准：如果某个改动在 UE5 里也需要，就必须改 UE5 再同步；只有"UE4 引擎 API 不同"才允许留在 UE4 树里。

---

## 2. 目录结构

```
插件迭代开发源码_UE4\
├─ Source\             ← 同步自 UE5，除 6 处引擎差异外逐行一致
├─ Config\             ← 同步（含 Localization\rebocap.ini）
├─ Content\            ← 同步（含三类语言的 .locres）
├─ Localization\       ← 同步（po/manifest 工作文件）
├─ Resources\          ← 同步（图标）
├─ x64\Release\        ← 同步（SDK 的 .lib/.dll）
├─ Binaries\
│  ├─ ThirdParty\RebocapWsSdk\Win64\rebocap_ws_sdk.dll   ← 运行时依赖，必须存在
│  └─ Win64\UE4Editor-*.dll                              ← 4.26 预编译产物（入库）
├─ Docs\               ← 不同步！UE4 专属文档
└─ Tools\
   ├─ SyncFromUE5.ps1           ← 一键同步（幂等）
   └─ UE4Overrides\*.Build.cs   ← UE4 版本模板（3 个）
```

> `Docs` 故意不参与镜像：镜像会删掉 UE4 专属文档。

---

## 3. 标准流程（UE5 发版后照做）

### 3.1 同步

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File Tools\SyncFromUE5.ps1
```

脚本做 5 件事：
1. 镜像 `Source/Config/Content/Localization/Resources/x64` + `rebocap.uplugin/README/LICENSE`
2. 用 `Tools\UE4Overrides\*.Build.cs` 覆盖 3 个构建脚本
3. `RebocapA2TEditorLibrary.cpp` 的 `BoneReference.h` 换成版本判断
4. `rebocap_body_remap_asset.cpp` 脊椎预设改成 UE4 命名
5. 缺失时补 `Binaries\ThirdParty\...\rebocap_ws_sdk.dll`

**验收脚本本身**：跑完后 `git status` 只应看到 `Tools/`，源码零差异。若出现源码差异，说明手改过 UE4 树，先还原再同步。

### 3.2 切换编译器（每次编译 UE4 前）

UE4 的 UBT **不认识** `VisualStudio2022` 这个枚举值，全局配置里写了它，UE4 的 UBT 会直接崩在解析阶段。改 `%APPDATA%\Unreal Engine\UnrealBuildTool\BuildConfiguration.xml`：

```xml
<?xml version="1.0" encoding="utf-8" ?>
<Configuration xmlns="https://www.unrealengine.com/BuildConfiguration">
  <WindowsPlatform>
    <Compiler>VisualStudio2019</Compiler>
  </WindowsPlatform>
</Configuration>
```

编译完**立刻改回** `VisualStudio2022`，否则 UE5 编译会挂。建议先备份 `.bak-vs2022`，用两条命令来回切：

```powershell
$cfg = "$env:APPDATA\Unreal Engine\UnrealBuildTool\BuildConfiguration.xml"
Copy-Item "$cfg.bak-vs2022" $cfg -Force   # 恢复 UE5
```

### 3.3 编译

插件不能单独编译，需要一个带 C++ target 的 host 工程（`build_temp_ue426\HostProject` 已备好；纯蓝图工程会报 `Couldn't find target rules file`）：

```powershell
& "E:\Epic Games\UE_4.26\Engine\Build\BatchFiles\Build.bat" `
    HostProjectEditor Win64 Development `
    "-Project=D:\rebocap\03 ue plugins\build_temp_ue426\HostProject\HostProject.uproject" `
    -WaitMutex -FromMsBuild
```

产物在 `HostProject\Plugins\rebocap\Binaries\Win64\`：`UE4Editor-rebocap*.dll` + `UE4Editor.modules`。

> 编译前先关掉 4.26 编辑器。开着编辑器会触发 Live Coding，产出 `-0002.dll` 这类带序号的文件名，无法直接发布。

### 3.4 部署到测试工程

```powershell
robocopy "插件迭代开发源码_UE4" "test project\ue426_test\Plugins\rebocap" /MIR /XD Binaries\Win64
Copy-Item "build_temp_ue426\HostProject\Plugins\rebocap\Binaries\Win64\*.dll" "…\Plugins\rebocap\Binaries\Win64" -Force
Copy-Item "…\*.modules" "…\Binaries\Win64" -Force
```

`/XD Binaries\Win64` 很关键：镜像会用源树里可能更旧的二进制覆盖刚编好的。

### 3.5 更新预编译包

把 `HostProject\Plugins\rebocap\Binaries\Win64\*.dll` 与 `.modules` 拷回 `插件迭代开发源码_UE4\Binaries\Win64\`，再连同 `Source/Content/Config/Resources/x64/Binaries` 打成发布包。

---

## 4. UE4 与 UE5 的 6 处引擎差异

只有这 6 处允许不一致；表格里的"现象"就是不改会看到的东西。

| # | 位置 | 现象（不改会怎样） | 改法 |
| --- | --- | --- | --- |
| 1 | `*.Build.cs` | UBT 编译规则程序集失败：`CppStandardVersion 并不包含 Cpp20 的定义`（写在 `if` 分支里也会失败，C# 是整体编译） | 固定 `CppStandard = CppStandardVersion.Cpp17;` |
| 2 | `rebocap_runtime.Build.cs` | `fatal error C1083: 无法打开包括文件 "LiveLinkRemapAsset.h"` | `LiveLink` 放 **Public** 依赖（公开头引用它，私有依赖的 include 路径不对外） |
| 3 | `rebocap.Build.cs` | 链接错误：`ULiveLinkRemapAsset::GetPrivateStaticClass` / `FEditorStyle::Get` 未解析 | 补 `LiveLink` + `EditorStyle` 依赖 |
| 4 | `RebocapA2TEditorLibrary.cpp` | `fatal error C1083: 无法打开包括文件 "Animation/BoneReference.h"` | UE5 用 `Animation/BoneReference.h`，UE4 用 `BoneContainer.h` |
| 5 | `rebocap_body_remap_asset.cpp` | 预览/运行刷 `FBoneReference::Initialize ... 'spine_04' does not exist`，胸部不动 | 预设脊椎改 `spine_01/02/03`（UE4 Mannequin 只有 3 节脊椎） |
| 6 | `Binaries/ThirdParty/.../rebocap_ws_sdk.dll` | UBT 报 `Source file '...rebocap_ws_sdk.dll' does not exist`（RuntimeDependencies 校验） | 把 SDK DLL 放进该目录 |

其余 `#if ENGINE_MAJOR_VERSION` 分支（`GetSubjectRole` vs `GetSubjectRole_AnyThread`、`SkeletalMesh` vs `GetSkeletalMeshAsset`、`FEditorStyle` vs `FAppStyle`、`FVector3f` 别名）UE5 源码里本来就有，不需要额外处理。

---

## 5. 验收清单

启动 4.26 编辑器后，日志（`<工程>\Saved\Logs\ue426_test.log`）应依次出现：

```
LogPluginManager: Mounting plugin rebocap
LogTextLocalizationResource: LocRes '.../Content/Localization/rebocap/zh-Hans/rebocap.locres'
LogTemp: [Rebocap] Rebocap SDK DLL loaded successfully from .../Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll
LogTemp: Display: RebocapEditor module started and registered custom details
LogTemp: Display: New Rebocap Source created on port: 7690
LogTemp: Display: Rebocap SDK Connected on localhost:7690!
LogTemp: Display: Regist rebocap SUCCESS!
```

界面检查：编辑器全中文、工具栏有 Rebocap 蝴蝶图标、面板显示 `V2.1`、端口 7690 已连接、动捕帧率 ≈60 Hz。

> `LocRes .../zh/rebocap.locres could not be opened` 是 UE4 对旧文化名的退化尝试，**无害**；真正的 `zh-Hans` 已加载。

---

## 6. 已知引擎行为差异（不是 bug，不要"修"）

| 行为 | UE5 | UE4 |
| --- | --- | --- |
| 节点视口骨骼高亮 | 选中动画节点即显示（`Draw(PDI, Mesh, bIsSelected, bIsPoseWatchEnabled)` 由预览对每个节点调用） | **只在骨骼控制节点的编辑模式里调用** `Draw`（`AnimNodeEditMode.cpp:147`），普通预览不会调用；A2T 这类非骨骼控制节点在 4.26 里没有这条路径 |
| 结论 | 产品默认体验以 UE5 为准 | UE4 保持引擎原生行为，不做额外 overlay（已与需求方确认：选中即高亮是 UE5 的效果） |

排查手法（值得记住）：怀疑 `Draw` 没被调用时，在函数体首行塞一句 `UE_LOG` 计数，编一次看日志是否命中——比反复截图快得多。本次就是靠探针确认 UE4 预览下两个节点的 `Draw` 均为 0 次调用。

另外，`Draw` 解析骨骼名时若未指定 Retarget Asset，会回落到 `URebocapMapData` 默认类（内置预设），否则预览里什么都画不出来——这段逻辑两棵树共用，改动请改 UE5。

---

## 7. 常见故障速查

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| `System.ArgumentException: 未找到请求的值"VisualStudio2022"` | 全局 UBT 配置是 VS2022 | 见 3.2 |
| `Couldn't find target rules file for target 'XXXEditor'` | host 工程是纯蓝图工程 | 加 `Source\XXX.Target.cs` / `XXXEditor.Target.cs` + 最小模块 |
| `error CS0101: 命名空间已包含 "rebocap" 的定义` | `Plugins` 下有两个同名插件（例如备份目录没移走） | 备份移到 `Plugins` 之外 |
| `Source file '...rebocap_ws_sdk.dll' does not exist` | 缺 SDK DLL | 见差异 6 |
| 产物是 `UE4Editor-rebocap-0002.dll` | 编辑器开着，Live Coding 占用原文件 | 关编辑器后删掉 Binaries/Win64 里的 dll 重新编译 |
| 只有中文失效、界面是英文 | 少了 `zh-Hans` 目录或 `.locres` 未打包 | 检查 `Content\Localization\rebocap\zh-Hans\rebocap.locres` |
| 编译报 `error C1083` 找不到引擎头 | 该头在 UE4 换了位置/模块 | 查 4.26 引擎源码确认，按差异 2/4 的方式处理 |

---

## 8. 版本与发布

- 版本号只在 `rebocap.uplugin` 的 `Version` / `VersionName`，运行时由 `RebocapVersion` 读取；UE4 树同步时会一并带过来，**不要在 UE4 树里单独改版本号**。
- UE4 发布包结构：`rebocap.uplugin` + `Binaries`（含 `ThirdParty`）+ `Content` + `Config` + `Resources` + `x64`（可选 `Source`）。
- 目标引擎：4.26（当前验证）、4.27（同一套源码，换个引擎路径编一遍即可）。

---

## 9. UE5 发版后的 checklist

1. [ ] `git -C 插件迭代开发源码\rebocap pull` / 确认 UE5 树是最新
2. [ ] 跑 `Tools\SyncFromUE5.ps1`，确认 `git status` 只剩 `Tools/`
3. [ ] 切 VS2019 → 编 4.26（必要时再编 4.27）→ 切回 VS2022
4. [ ] 部署到 `ue426_test`，按第 5 节验收
5. [ ] 更新 `Binaries\Win64` 预编译产物，提交 UE4 树
6. [ ] 若新增了本地化条目，确认 `Content\Localization\rebocap\{en,zh-Hans,ja}` 三个 `.locres` 都是最新的
7. [ ] 打发布包

---

## 10. 历史教训

- **不要沿用老 UE4 树**：4.27 老树里中文是乱码（PowerShell 用 `Get-Content -Raw` + `WriteAllText` 读写 UTF-8 会二次编码），且缺 V2.x 全部功能。重建比修复便宜。
- **不要用正则大改 `*.Build.cs`**：第一次尝试用正则插依赖，引号转义出错直接把构建脚本写坏，报 `error CS1002` 一片。改成"模板覆盖"后稳定。
- **不要用非贪婪正则批量删代码块**：清理调试探针时误删了函数里的花括号，导致 `error C2059`。批量删除要么精确锚点，要么改完立刻编译一遍。
- **改完必编译**：UE4 的 `Live Coding` 会把新 DLL 写成 `-0002` 后缀，看着"编过了"其实发布包拿到的是旧文件；关编辑器重编才是干净产物。
