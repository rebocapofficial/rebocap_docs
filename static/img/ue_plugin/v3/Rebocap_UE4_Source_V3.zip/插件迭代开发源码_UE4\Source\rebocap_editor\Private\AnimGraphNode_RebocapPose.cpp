#include "AnimGraphNode_RebocapPose.h"
#include "RebocapPinDescriptionHelper.h"
#include "Internationalization/Culture.h"
#include "Internationalization/Internationalization.h"
#include "SceneManagement.h"
#include "rebocap_body_remap_asset.h"
#include "rebocap_skeleton_data.h"
#include "rebocap_source.h"

#define LOCTEXT_NAMESPACE "RebocapAnimGraphNode"

void UAnimGraphNode_RebocapPose::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
    Super::GetPinHoverText(Pin, HoverTextOut);
    if (!HoverTextOut.IsEmpty())
    {
        return;
    }

    // UE5.8's default hover path often produced no text for this node, which surfaced as an
    // empty tooltip box. Fall back to the pin's cached PinToolTip, then to property metadata.
    // Then fall back to the DisplayName/ToolTip metadata on the node struct property itself.
    if (!Pin.PinToolTip.IsEmpty())
    {
        HoverTextOut = Pin.PinToolTip;
        return;
    }

    if (const FProperty* Prop = FRebocapPoseNode::StaticStruct()->FindPropertyByName(Pin.PinName))
    {
        const FString DisplayName = Prop->GetDisplayNameText().ToString();
        const FString ToolTip = Prop->GetToolTipText().ToString();
        HoverTextOut = ToolTip.IsEmpty() ? DisplayName : FString::Printf(TEXT("%s\n\n%s"), *DisplayName, *ToolTip);
    }
}

FText UAnimGraphNode_RebocapPose::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
    // Node names stay in English on purpose: tutorials ask users to type English keywords into
    // the node palette and the Details search, so a translated name would not match.
    // Returning FText::FromString also keeps the graph title widget from caching a stale
    // localized string (SNodeTitle only rebuilds when its title cache is marked dirty).
    if (TitleType == ENodeTitleType::ListView)
    {
        return FText::FromString(TEXT("Rebocap Body Pose"));
    }

    auto Source = FRebocapSource::GetInstance();
    if (Source.IsValid() && Source->IsPortOpen())
    {
        const float Hz = Source->GetMocapHz();
        if (Hz > 0.0f)
        {
            return FText::FromString(FString::Printf(TEXT("Rebocap Body Pose [%d Hz]"), FMath::RoundToInt(Hz)));
        }
        return FText::FromString(TEXT("Rebocap Body Pose [Connected]"));
    }
    return FText::FromString(TEXT("Rebocap Body Pose"));
}


FText UAnimGraphNode_RebocapPose::GetTooltipText() const
{
    // The engine can flag a pin widget invalid, and in that state GetPinHoverText is never
    // called -- so the pin descriptions are folded into the node tooltip instead.
    const FString PinSection = RebocapBuildPinDescriptionSection(*this, FRebocapPoseNode::StaticStruct());

    auto Source = FRebocapSource::GetInstance();
    if (Source.IsValid() && Source->IsPortOpen())
    {
        const FText StateOn = LOCTEXT("RebocapOptionOn", "On");
        const FText StateOff = LOCTEXT("RebocapOptionOff", "Off");
        const FString Body = FText::Format(
            LOCTEXT("RebocapPoseNodeTooltipActiveFormat",
                    "Rebocap mocap driver node\n\u25cf Current state: connected (Active)\n\u25cf Mocap receive rate: {0} Hz\n\u25cf Auto skeleton submit: {1}\n\u25cf Frame interpolation: {2}"),
            FText::AsNumber(FMath::RoundToInt(Source->GetMocapHz())),
            Node.bAutoSkeleton ? StateOn : StateOff,
            Node.bEnableInterpolation ? StateOn : StateOff).ToString();
        return FText::FromString(Body + PinSection);
    }

    const FString Body = LOCTEXT("RebocapPoseNodeTooltip", "Rebocap mocap driver node\n\u25cb Status: Disconnected\nDrives the character from LiveLink motion capture data through a bone retarget asset.").ToString();
    return FText::FromString(Body + PinSection);
}

FText UAnimGraphNode_RebocapPose::GetMenuCategory() const
{
    return LOCTEXT("RebocapPoseCategory", "Rebocap");
}

FText UAnimGraphNode_RebocapPose::GetKeywords() const
{
    return LOCTEXT("RebocapPoseKeywords", "rebocap, mocap, live link, pose, skeleton, motion capture");
}

static void DrawPoseBoneChain(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* SkelMeshComp, const TArray<FName>& BoneNames, const FLinearColor& JointColor, const FLinearColor& LinkColor, float JointRadius, float LinkThickness)
{
    if (!PDI || !SkelMeshComp) return;
    
    FVector PrevLoc = FVector::ZeroVector;
    bool bHasPrev = false;

    for (const FName& BoneName : BoneNames)
    {
        if (BoneName == NAME_None)
        {
            bHasPrev = false;
            continue;
        }

        int32 BoneIndex = SkelMeshComp->GetBoneIndex(BoneName);
        if (BoneIndex == INDEX_NONE)
        {
            bHasPrev = false;
            continue;
        }

        FVector BoneLoc = SkelMeshComp->GetBoneLocation(BoneName, EBoneSpaces::WorldSpace);
        
        // Draw a glowing sphere at each controlled joint
        DrawWireSphere(PDI, BoneLoc, JointColor, JointRadius, 12, SDPG_Foreground, 1.0f);

        // Draw the parent-child link between bones
        if (bHasPrev)
        {
            PDI->DrawLine(PrevLoc, BoneLoc, LinkColor, SDPG_Foreground, LinkThickness);
        }

        PrevLoc = BoneLoc;
        bHasPrev = true;
    }
}

static void DrawPoseLink(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* SkelMeshComp, const FName& BoneA, const FName& BoneB, const FLinearColor& LinkColor, float LinkThickness)
{
    if (!PDI || !SkelMeshComp || BoneA == NAME_None || BoneB == NAME_None) return;
    if (SkelMeshComp->GetBoneIndex(BoneA) == INDEX_NONE || SkelMeshComp->GetBoneIndex(BoneB) == INDEX_NONE) return;

    FVector PosA = SkelMeshComp->GetBoneLocation(BoneA, EBoneSpaces::WorldSpace);
    FVector PosB = SkelMeshComp->GetBoneLocation(BoneB, EBoneSpaces::WorldSpace);
    PDI->DrawLine(PosA, PosB, LinkColor, SDPG_Foreground, LinkThickness);
}

void UAnimGraphNode_RebocapPose::Draw(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* PreviewSkelMeshComp) const
{
    Super::Draw(PDI, PreviewSkelMeshComp);

    if (!bShowControlledBones || !PDI || !PreviewSkelMeshComp) return;

    // Resolve the bone mapping table that is currently in effect
    FName PelvisName = Node.bone_map_.Pelvis.BoneName;
    FName Spine1Name = Node.bone_map_.Spine1.BoneName;
    FName Spine2Name = Node.bone_map_.Spine2.BoneName;
    FName Spine3Name = Node.bone_map_.Spine3.BoneName;
    FName NeckName = Node.bone_map_.Neck.BoneName;
    FName HeadName = Node.bone_map_.Head.BoneName;

    FName L_CollarName = Node.bone_map_.L_Collar.BoneName;
    FName L_ShoulderName = Node.bone_map_.L_Shoulder.BoneName;
    FName L_ElbowName = Node.bone_map_.L_Elbow.BoneName;
    FName L_WristName = Node.bone_map_.L_Wrist.BoneName;
    FName L_HandName = Node.bone_map_.L_Hand.BoneName;

    FName R_CollarName = Node.bone_map_.R_Collar.BoneName;
    FName R_ShoulderName = Node.bone_map_.R_Shoulder.BoneName;
    FName R_ElbowName = Node.bone_map_.R_Elbow.BoneName;
    FName R_WristName = Node.bone_map_.R_Wrist.BoneName;
    FName R_HandName = Node.bone_map_.R_Hand.BoneName;

    FName L_HipName = Node.bone_map_.L_Hip.BoneName;
    FName L_KneeName = Node.bone_map_.L_Knee.BoneName;
    FName L_AnkleName = Node.bone_map_.L_Ankle.BoneName;
    FName L_FootName = Node.bone_map_.L_Foot.BoneName;

    FName R_HipName = Node.bone_map_.R_Hip.BoneName;
    FName R_KneeName = Node.bone_map_.R_Knee.BoneName;
    FName R_AnkleName = Node.bone_map_.R_Ankle.BoneName;
    FName R_FootName = Node.bone_map_.R_Foot.BoneName;

    // Use the assigned retarget asset, or the stock map data class when none is assigned: the
    // stock class carries the built-in bone preset. Without this fallback a Pose node with no
    // asset draws nothing in the animation preview, while the A2T node next to it highlights fine.
    UClass* EffectiveAssetClass = Node.retarget_asset_ ? Node.retarget_asset_.Get() : URebocapMapData::StaticClass();
    if (URebocapMapData* MapData = EffectiveAssetClass ? Cast<URebocapMapData>(EffectiveAssetClass->GetDefaultObject()) : nullptr)
    {
        PelvisName = MapData->GetRemappedBoneName(rebocap_bones::pelvis);
        Spine1Name = MapData->GetRemappedBoneName(rebocap_bones::spine1);
        Spine2Name = MapData->GetRemappedBoneName(rebocap_bones::spine2);
        Spine3Name = MapData->GetRemappedBoneName(rebocap_bones::spine3);
        NeckName = MapData->GetRemappedBoneName(rebocap_bones::neck);
        HeadName = MapData->GetRemappedBoneName(rebocap_bones::head);

        L_CollarName = MapData->GetRemappedBoneName(rebocap_bones::l_collar);
        L_ShoulderName = MapData->GetRemappedBoneName(rebocap_bones::l_shoulder);
        L_ElbowName = MapData->GetRemappedBoneName(rebocap_bones::l_elbow);
        L_WristName = MapData->GetRemappedBoneName(rebocap_bones::l_wrist);
        L_HandName = MapData->GetRemappedBoneName(rebocap_bones::l_hand);

        R_CollarName = MapData->GetRemappedBoneName(rebocap_bones::r_collar);
        R_ShoulderName = MapData->GetRemappedBoneName(rebocap_bones::r_shoulder);
        R_ElbowName = MapData->GetRemappedBoneName(rebocap_bones::r_elbow);
        R_WristName = MapData->GetRemappedBoneName(rebocap_bones::r_wrist);
        R_HandName = MapData->GetRemappedBoneName(rebocap_bones::r_hand);

        L_HipName = MapData->GetRemappedBoneName(rebocap_bones::l_hip);
        L_KneeName = MapData->GetRemappedBoneName(rebocap_bones::l_knee);
        L_AnkleName = MapData->GetRemappedBoneName(rebocap_bones::l_ankle);
        L_FootName = MapData->GetRemappedBoneName(rebocap_bones::l_foot);

        R_HipName = MapData->GetRemappedBoneName(rebocap_bones::r_hip);
        R_KneeName = MapData->GetRemappedBoneName(rebocap_bones::r_knee);
        R_AnkleName = MapData->GetRemappedBoneName(rebocap_bones::r_ankle);
    R_FootName = MapData->GetRemappedBoneName(rebocap_bones::r_foot);
    }

    // 1. Left arm chain (Left Arm)
    TArray<FName> LeftArmChain;
    LeftArmChain.Add(L_CollarName);
    LeftArmChain.Add(L_ShoulderName);
    LeftArmChain.Add(L_ElbowName);
    LeftArmChain.Add(L_WristName);
    LeftArmChain.Add(L_HandName);
    DrawPoseBoneChain(PDI, PreviewSkelMeshComp, LeftArmChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 2. Right arm chain (Right Arm)
    TArray<FName> RightArmChain;
    RightArmChain.Add(R_CollarName);
    RightArmChain.Add(R_ShoulderName);
    RightArmChain.Add(R_ElbowName);
    RightArmChain.Add(R_WristName);
    RightArmChain.Add(R_HandName);
    DrawPoseBoneChain(PDI, PreviewSkelMeshComp, RightArmChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 3. Left leg chain (Left Leg)
    TArray<FName> LeftLegChain;
    LeftLegChain.Add(L_HipName);
    LeftLegChain.Add(L_KneeName);
    LeftLegChain.Add(L_AnkleName);
    LeftLegChain.Add(L_FootName);
    DrawPoseBoneChain(PDI, PreviewSkelMeshComp, LeftLegChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 4. Right leg chain (Right Leg)
    TArray<FName> RightLegChain;
    RightLegChain.Add(R_HipName);
    RightLegChain.Add(R_KneeName);
    RightLegChain.Add(R_AnkleName);
    RightLegChain.Add(R_FootName);
    DrawPoseBoneChain(PDI, PreviewSkelMeshComp, RightLegChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 5. Torso and head chain (Spine & Head)
    TArray<FName> TorsoChain;
    TorsoChain.Add(PelvisName);
    TorsoChain.Add(Spine1Name);
    TorsoChain.Add(Spine2Name);
    TorsoChain.Add(Spine3Name);
    TorsoChain.Add(NeckName);
    TorsoChain.Add(HeadName);
    DrawPoseBoneChain(PDI, PreviewSkelMeshComp, TorsoChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 6. Shoulder and hip cross links (Cross Links)
    FName UpperTorsoBone = (Spine3Name != NAME_None && PreviewSkelMeshComp->GetBoneIndex(Spine3Name) != INDEX_NONE) ? Spine3Name : ((Spine2Name != NAME_None && PreviewSkelMeshComp->GetBoneIndex(Spine2Name) != INDEX_NONE) ? Spine2Name : Spine1Name);
    DrawPoseLink(PDI, PreviewSkelMeshComp, UpperTorsoBone, L_CollarName, LinkColor, LinkThickness);
    DrawPoseLink(PDI, PreviewSkelMeshComp, UpperTorsoBone, R_CollarName, LinkColor, LinkThickness);
    DrawPoseLink(PDI, PreviewSkelMeshComp, PelvisName, L_HipName, LinkColor, LinkThickness);
    DrawPoseLink(PDI, PreviewSkelMeshComp, PelvisName, R_HipName, LinkColor, LinkThickness);
}

#undef LOCTEXT_NAMESPACE
