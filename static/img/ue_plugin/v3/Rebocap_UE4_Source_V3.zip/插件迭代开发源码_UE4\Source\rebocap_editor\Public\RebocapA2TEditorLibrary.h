#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "RebocapA2TEditorLibrary.generated.h"

/**
 * Editor helper for attaching / inspecting the Retarget Asset on Rebocap A2T anim nodes in bulk.
 * Lives in the editor module so it can be called from editor Python and Blueprints, and makes it easy
 * to check what the bone names actually map to.
 */
UCLASS()
class REBOCAP_EDITOR_API URebocapA2TEditorLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * Assigns the same Retarget Asset to every Rebocap A-To-T node in the currently loaded Blueprints
	 * and immediately refreshes the 20 bone names from its mapping table.
	 * Returns the number of nodes processed (-1 if the asset could not be found).
	 * @param RetargetAssetPath Asset path, e.g. /Game/Rebocap/RebocapMapData_UE; a bare asset name is also accepted.
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Apply Retarget Asset To All A2T Nodes"))
	static int32 ApplyRetargetAssetToAllA2TNodes(const FString& RetargetAssetPath);

	/**
	 * Lists the bone mapping state of the currently loaded A2T nodes (one line per node) to verify the mapping matches expectations.
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Describe A2T Nodes"))
	static TArray<FString> DescribeA2TNodes();

	/**
	 * Diagnostic helper: resolves the plugin's localized strings for the current culture and returns them,
	 * so localization problems can be checked without eyeballing the UI.
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Localized Text Probe"))
	static TArray<FString> GetLocalizedTextProbe();

	/**
	 * Forces every loaded Anim Blueprint that contains Rebocap nodes to be marked structurally
	 * modified and recompiled, so the anim-graph pin data (including pin tooltips) is rebuilt
	 * from the current property metadata. Returns the number of blueprints recompiled.
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Rebuild Rebocap Pin Data"))
	static int32 RebuildRebocapPinData();

	/**
	 * Dumps the cached PinToolTip string of every pin on loaded Rebocap anim-graph nodes, so
	 * blank pin tooltips can be diagnosed without hovering the graph by hand.
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Dump Rebocap Pin Tooltips"))
	static TArray<FString> DumpRebocapPinTooltips();

	/** Dumps the node tooltip (including the pin description section) of loaded Rebocap anim graph nodes. */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Dump Rebocap Node Tooltips"))
	static TArray<FString> DumpRebocapNodeTooltips();

	/** Dumps the runtime configuration of loaded Rebocap Body Pose nodes (bone map, subject, flags). */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Dump Rebocap Pose Nodes"))
	static TArray<FString> DumpRebocapPoseNodes();

	/**
	 * Assigns a Retarget Asset to every loaded Rebocap Body Pose node and re-resolves its 24 bone
	 * names immediately. Returns the number of nodes updated (-1 when the asset cannot be found).
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Apply Retarget Asset To All Pose Nodes"))
	static int32 ApplyRetargetAssetToAllPoseNodes(const FString& RetargetAssetPath);

	/**
	 * Sets the port used when the plugin creates a mocap source on its own (anim node auto-connect).
	 * The control panel writes the same value when the user connects on a custom port.
	 */
	UFUNCTION(BlueprintCallable, Category = "Rebocap|Editor", meta = (DisplayName = "Set Mocap Source Port"))
	static void SetMocapSourcePort(int32 Port);
};
