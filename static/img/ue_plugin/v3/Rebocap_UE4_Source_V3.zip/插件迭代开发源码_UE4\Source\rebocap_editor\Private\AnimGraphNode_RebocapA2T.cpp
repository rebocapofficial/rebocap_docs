#include "AnimGraphNode_RebocapA2T.h"
#include "RebocapPinDescriptionHelper.h"
#include "Internationalization/Culture.h"
#include "Internationalization/Internationalization.h"
#include "SceneManagement.h"

#if WITH_EDITOR
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "Framework/Application/SlateApplication.h"
#include "Misc/MessageDialog.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#endif

#define LOCTEXT_NAMESPACE "RebocapA2TAnimGraphNode"

void UAnimGraphNode_RebocapA2T::GetPinHoverText(const UEdGraphPin& Pin, FString& HoverTextOut) const
{
    Super::GetPinHoverText(Pin, HoverTextOut);
    if (!HoverTextOut.IsEmpty())
    {
        return;
    }

    // Same fallback as the Pose node: pin tooltip cache first, then the property metadata.
    if (!Pin.PinToolTip.IsEmpty())
    {
        HoverTextOut = Pin.PinToolTip;
        return;
    }

    if (const FProperty* Prop = FAnimNode_RebocapA2T::StaticStruct()->FindPropertyByName(Pin.PinName))
    {
        const FString DisplayName = Prop->GetDisplayNameText().ToString();
        const FString ToolTip = Prop->GetToolTipText().ToString();
        HoverTextOut = ToolTip.IsEmpty() ? DisplayName : FString::Printf(TEXT("%s\n\n%s"), *DisplayName, *ToolTip);
    }
}

FText UAnimGraphNode_RebocapA2T::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
    // English only, same reason as the Pose node title (see AnimGraphNode_RebocapPose.cpp).
    return FText::FromString(TEXT("Rebocap A-Pose to T-Pose"));
}


FText UAnimGraphNode_RebocapA2T::GetTooltipText() const
{
    // The engine can flag a pin widget invalid, and in that state GetPinHoverText is never
    // called -- so the pin descriptions are folded into the node tooltip instead.
    const FString Body = LOCTEXT("RebocapA2TNodeTooltip", "Calibrates A-Pose characters into standard T-Pose for Rebocap motion capture.").ToString();
    return FText::FromString(Body + RebocapBuildPinDescriptionSection(*this, FAnimNode_RebocapA2T::StaticStruct()));
}

FText UAnimGraphNode_RebocapA2T::GetMenuCategory() const
{
    return LOCTEXT("RebocapA2TCategory", "Rebocap");
}

FText UAnimGraphNode_RebocapA2T::GetKeywords() const
{
    return LOCTEXT("RebocapA2TKeywords", "rebocap, a2t, tpose, a-pose, t-pose, calibrate, limb, mocap, live link");
}

void UAnimGraphNode_RebocapA2T::CopyNodeDataToPreviewNode(FAnimNode_Base* InPreviewNode)
{
    FAnimNode_RebocapA2T* PreviewNode = static_cast<FAnimNode_RebocapA2T*>(InPreviewNode);

    // With mirroring enabled, sync the left-side live offsets to the right side first.
    if (Node.bMirrorEdit)
    {
        Node.SyncMirrorLimbOffsets();
    }

    // 1. Copy every rotation offset so dragging a slider updates the preview live
    PreviewNode->LeftClavicleOffset = Node.LeftClavicleOffset;
    PreviewNode->LeftUpperArmOffset = Node.LeftUpperArmOffset;
    PreviewNode->LeftLowerArmOffset = Node.LeftLowerArmOffset;
    PreviewNode->LeftHandOffset = Node.LeftHandOffset;

    PreviewNode->RightClavicleOffset = Node.RightClavicleOffset;
    PreviewNode->RightUpperArmOffset = Node.RightUpperArmOffset;
    PreviewNode->RightLowerArmOffset = Node.RightLowerArmOffset;
    PreviewNode->RightHandOffset = Node.RightHandOffset;

    PreviewNode->LeftThighOffset = Node.LeftThighOffset;
    PreviewNode->LeftCalfOffset = Node.LeftCalfOffset;
    PreviewNode->LeftFootOffset = Node.LeftFootOffset;

    PreviewNode->RightThighOffset = Node.RightThighOffset;
    PreviewNode->RightCalfOffset = Node.RightCalfOffset;
    PreviewNode->RightFootOffset = Node.RightFootOffset;

    PreviewNode->PelvisOffset = Node.PelvisOffset;
    PreviewNode->SpineOffset = Node.SpineOffset;
    PreviewNode->ChestOffset = Node.ChestOffset;
    PreviewNode->UpChestOffset = Node.UpChestOffset;
    PreviewNode->NeckOffset = Node.NeckOffset;
    PreviewNode->HeadOffset = Node.HeadOffset;

    PreviewNode->Alpha = Node.Alpha;
    PreviewNode->bMirrorEdit = Node.bMirrorEdit;
    PreviewNode->bMirrorInvertRoll = Node.bMirrorInvertRoll;
    PreviewNode->bMirrorInvertPitch = Node.bMirrorInvertPitch;
    PreviewNode->bMirrorInvertYaw = Node.bMirrorInvertYaw;

    // 2. Refresh a name only when it really changed; copying outright would overwrite the resolved BoneIndex
    auto CopyBoneNameIfChanged = [](FBoneReference& Dst, const FBoneReference& Src)
    {
        if (Dst.BoneName != Src.BoneName)
        {
            Dst.BoneName = Src.BoneName;
            Dst.BoneIndex = INDEX_NONE;
        }
    };

    CopyBoneNameIfChanged(PreviewNode->LeftClavicle, Node.LeftClavicle);
    CopyBoneNameIfChanged(PreviewNode->LeftUpperArm, Node.LeftUpperArm);
    CopyBoneNameIfChanged(PreviewNode->LeftLowerArm, Node.LeftLowerArm);
    CopyBoneNameIfChanged(PreviewNode->LeftHand, Node.LeftHand);

    CopyBoneNameIfChanged(PreviewNode->RightClavicle, Node.RightClavicle);
    CopyBoneNameIfChanged(PreviewNode->RightUpperArm, Node.RightUpperArm);
    CopyBoneNameIfChanged(PreviewNode->RightLowerArm, Node.RightLowerArm);
    CopyBoneNameIfChanged(PreviewNode->RightHand, Node.RightHand);

    CopyBoneNameIfChanged(PreviewNode->LeftThigh, Node.LeftThigh);
    CopyBoneNameIfChanged(PreviewNode->LeftCalf, Node.LeftCalf);
    CopyBoneNameIfChanged(PreviewNode->LeftFoot, Node.LeftFoot);

    CopyBoneNameIfChanged(PreviewNode->RightThigh, Node.RightThigh);
    CopyBoneNameIfChanged(PreviewNode->RightCalf, Node.RightCalf);
    CopyBoneNameIfChanged(PreviewNode->RightFoot, Node.RightFoot);

    CopyBoneNameIfChanged(PreviewNode->Pelvis, Node.Pelvis);
    CopyBoneNameIfChanged(PreviewNode->Spine, Node.Spine);
    CopyBoneNameIfChanged(PreviewNode->Chest, Node.Chest);
    CopyBoneNameIfChanged(PreviewNode->UpChest, Node.UpChest);
    CopyBoneNameIfChanged(PreviewNode->Neck, Node.Neck);
    CopyBoneNameIfChanged(PreviewNode->Head, Node.Head);

    // 3. Retarget Asset: sync the mapping into the preview node.
    // Must run after the bone-name copy above, otherwise the fresh mapping gets overwritten.
    PreviewNode->retarget_asset_ = Node.retarget_asset_;
    PreviewNode->retarget_asset_override_ = Node.retarget_asset_override_;
    PreviewNode->bUseRetargetAssetBones = Node.bUseRetargetAssetBones;
    if (Node.bUseRetargetAssetBones && Node.HasRetargetAsset())
    {
        PreviewNode->ApplyRetargetAssetBones();
    }
}

void UAnimGraphNode_RebocapA2T::AllocateDefaultPins()
{
    Super::AllocateDefaultPins();
    // The override pin value is owned by the pin itself; the main retarget_asset_ is not
    // pin-driven, so rebuilding the pins never clears it.
}

void UAnimGraphNode_RebocapA2T::CopyPinDefaultsToNodeData(UEdGraphPin* InPin)
{
    // Only the override property is pin-driven: copy the pin value back into the node data.
    if (InPin && InPin->PinName == GET_MEMBER_NAME_CHECKED(FAnimNode_RebocapA2T, retarget_asset_override_))
    {
        Node.retarget_asset_override_ = Cast<UClass>(InPin->DefaultObject);
    }
}

void UAnimGraphNode_RebocapA2T::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);

    const FName PropertyName = PropertyChangedEvent.Property ? PropertyChangedEvent.Property->GetFName() : NAME_None;
    const FName MemberName = PropertyChangedEvent.MemberProperty ? PropertyChangedEvent.MemberProperty->GetFName() : NAME_None;

    if (PropertyName == GET_MEMBER_NAME_CHECKED(FAnimNode_RebocapA2T, PresetTemplate))
    {
        Node.ApplyPreset(Node.PresetTemplate);
    }
    else if (PropertyName == GET_MEMBER_NAME_CHECKED(FAnimNode_RebocapA2T, retarget_asset_) ||
             PropertyName == GET_MEMBER_NAME_CHECKED(FAnimNode_RebocapA2T, retarget_asset_override_) ||
             PropertyName == GET_MEMBER_NAME_CHECKED(FAnimNode_RebocapA2T, bUseRetargetAssetBones))
    {
    // When the asset or the toggle changes, refresh bone names immediately so Details reflects it.
        if (Node.bUseRetargetAssetBones && Node.HasRetargetAsset())
        {
            Node.ApplyRetargetAssetBones();
        }
    }
    else if (Node.bMirrorEdit)
    {
        Node.SyncMirrorLimbOffsets();
    }
}

void UAnimGraphNode_RebocapA2T::ExportToJson()
{
#if WITH_EDITOR
    IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
    if (!DesktopPlatform) return;

    const void* ParentWindowHandle = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
    const FString DefaultPath = FPaths::ProjectSavedDir();
    const FString DefaultFile = TEXT("Rebocap_A2T_Config.json");
    TArray<FString> OutFilenames;

    const bool bSaved = DesktopPlatform->SaveFileDialog(
        ParentWindowHandle,
        TEXT("Export Rebocap A2T config file"),
        DefaultPath,
        DefaultFile,
        TEXT("JSON files (*.json)|*.json"),
        EFileDialogFlags::None,
        OutFilenames);

    if (bSaved && OutFilenames.Num() > 0)
    {
        const FString SaveFilePath = OutFilenames[0];
        const FString JsonString = Node.ToJsonString();
        if (FFileHelper::SaveStringToFile(JsonString, *SaveFilePath))
        {
            UE_LOG(LogTemp, Display, TEXT("Exported A2T config to: %s"), *SaveFilePath);
            FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("A2TExportJsonSuccess", "Exported A2T config to:\n{0}"), FText::FromString(SaveFilePath)));
        }
    }
#endif
}

void UAnimGraphNode_RebocapA2T::ImportFromJson()
{
#if WITH_EDITOR
    IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
    if (!DesktopPlatform) return;

    const void* ParentWindowHandle = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
    const FString DefaultPath = FPaths::ProjectSavedDir();
    TArray<FString> OutFilenames;

    const bool bOpened = DesktopPlatform->OpenFileDialog(
        ParentWindowHandle,
        TEXT("Select the Rebocap A2T config file to import"),
        DefaultPath,
        TEXT(""),
        TEXT("JSON files (*.json)|*.json"),
        EFileDialogFlags::None,
        OutFilenames);

    if (bOpened && OutFilenames.Num() > 0)
    {
        const FString OpenFilePath = OutFilenames[0];
        FString JsonString;
        if (FFileHelper::LoadFileToString(JsonString, *OpenFilePath))
        {
            if (Node.FromJsonString(JsonString))
            {
                MarkPackageDirty();
                UE_LOG(LogTemp, Display, TEXT("Imported A2T config: %s"), *OpenFilePath);
                FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("A2TImportJsonSuccess", "A2T config imported successfully!\nAll limb rotations and bone bindings restored."));
            }
            else
            {
                FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("A2TImportJsonFailed", "Import failed: JSON format does not match the A2T spec!"));
            }
        }
    }
#endif
}

// Helper that draws a bone chain
static void DrawA2TBoneChain(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* SkelMeshComp, const TArray<FName>& BoneNames, const FLinearColor& JointColor, const FLinearColor& LinkColor, float JointRadius, float LinkThickness)
{
    if (!PDI || !SkelMeshComp) return;
    
    FVector PrevLoc = FVector::ZeroVector;
    bool bHasPrev = false;

    for (const FName& BoneName : BoneNames)
    {
        if (BoneName == NAME_None)
        {
            bHasPrev = false;
            continue;
        }

        int32 BoneIndex = SkelMeshComp->GetBoneIndex(BoneName);
        if (BoneIndex == INDEX_NONE)
        {
            bHasPrev = false;
            continue;
        }

        FVector BoneLoc = SkelMeshComp->GetBoneLocation(BoneName, EBoneSpaces::WorldSpace);
        
        // Draw a glowing sphere at each controlled joint
        DrawWireSphere(PDI, BoneLoc, JointColor, JointRadius, 12, SDPG_Foreground, 1.0f);

        // Draw the parent-child link between bones
        if (bHasPrev)
        {
            PDI->DrawLine(PrevLoc, BoneLoc, LinkColor, SDPG_Foreground, LinkThickness);
        }

        PrevLoc = BoneLoc;
        bHasPrev = true;
    }
}

// Helper that draws a link between two bones
static void DrawA2TLink(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* SkelMeshComp, const FName& BoneA, const FName& BoneB, const FLinearColor& LinkColor, float LinkThickness)
{
    if (!PDI || !SkelMeshComp || BoneA == NAME_None || BoneB == NAME_None) return;
    if (SkelMeshComp->GetBoneIndex(BoneA) == INDEX_NONE || SkelMeshComp->GetBoneIndex(BoneB) == INDEX_NONE) return;

    FVector PosA = SkelMeshComp->GetBoneLocation(BoneA, EBoneSpaces::WorldSpace);
    FVector PosB = SkelMeshComp->GetBoneLocation(BoneB, EBoneSpaces::WorldSpace);
    PDI->DrawLine(PosA, PosB, LinkColor, SDPG_Foreground, LinkThickness);
}

void UAnimGraphNode_RebocapA2T::Draw(FPrimitiveDrawInterface* PDI, USkeletalMeshComponent* PreviewSkelMeshComp) const
{
    Super::Draw(PDI, PreviewSkelMeshComp);

    if (!bShowControlledBones || !PDI || !PreviewSkelMeshComp) return;

    // 1. Left arm chain (Left Arm)
    TArray<FName> LeftArmChain;
    LeftArmChain.Add(Node.LeftClavicle.BoneName);
    LeftArmChain.Add(Node.LeftUpperArm.BoneName);
    LeftArmChain.Add(Node.LeftLowerArm.BoneName);
    LeftArmChain.Add(Node.LeftHand.BoneName);
    DrawA2TBoneChain(PDI, PreviewSkelMeshComp, LeftArmChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 2. Right arm chain (Right Arm)
    TArray<FName> RightArmChain;
    RightArmChain.Add(Node.RightClavicle.BoneName);
    RightArmChain.Add(Node.RightUpperArm.BoneName);
    RightArmChain.Add(Node.RightLowerArm.BoneName);
    RightArmChain.Add(Node.RightHand.BoneName);
    DrawA2TBoneChain(PDI, PreviewSkelMeshComp, RightArmChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 3. Left leg chain (Left Leg)
    TArray<FName> LeftLegChain;
    LeftLegChain.Add(Node.LeftThigh.BoneName);
    LeftLegChain.Add(Node.LeftCalf.BoneName);
    LeftLegChain.Add(Node.LeftFoot.BoneName);
    DrawA2TBoneChain(PDI, PreviewSkelMeshComp, LeftLegChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 4. Right leg chain (Right Leg)
    TArray<FName> RightLegChain;
    RightLegChain.Add(Node.RightThigh.BoneName);
    RightLegChain.Add(Node.RightCalf.BoneName);
    RightLegChain.Add(Node.RightFoot.BoneName);
    DrawA2TBoneChain(PDI, PreviewSkelMeshComp, RightLegChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 5. Torso and head chain (Spine & Head)
    TArray<FName> TorsoChain;
    TorsoChain.Add(Node.Pelvis.BoneName);
    TorsoChain.Add(Node.Spine.BoneName);
    TorsoChain.Add(Node.Chest.BoneName);
    TorsoChain.Add(Node.UpChest.BoneName);
    TorsoChain.Add(Node.Neck.BoneName);
    TorsoChain.Add(Node.Head.BoneName);
    DrawA2TBoneChain(PDI, PreviewSkelMeshComp, TorsoChain, JointColor, LinkColor, JointRadius, LinkThickness);

    // 6. Shoulder and hip cross links (Cross Links)
    FName UpperTorsoBone = (Node.UpChest.BoneName != NAME_None && PreviewSkelMeshComp->GetBoneIndex(Node.UpChest.BoneName) != INDEX_NONE) ? Node.UpChest.BoneName : Node.Chest.BoneName;
    DrawA2TLink(PDI, PreviewSkelMeshComp, UpperTorsoBone, Node.LeftClavicle.BoneName, LinkColor, LinkThickness);
    DrawA2TLink(PDI, PreviewSkelMeshComp, UpperTorsoBone, Node.RightClavicle.BoneName, LinkColor, LinkThickness);
    DrawA2TLink(PDI, PreviewSkelMeshComp, Node.Pelvis.BoneName, Node.LeftThigh.BoneName, LinkColor, LinkThickness);
    DrawA2TLink(PDI, PreviewSkelMeshComp, Node.Pelvis.BoneName, Node.RightThigh.BoneName, LinkColor, LinkThickness);
}

#undef LOCTEXT_NAMESPACE
