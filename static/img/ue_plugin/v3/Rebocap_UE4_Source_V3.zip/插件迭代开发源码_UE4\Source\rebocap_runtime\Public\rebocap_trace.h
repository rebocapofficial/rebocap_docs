#pragma once

#include "CoreMinimal.h"
#include "HAL/IConsoleManager.h"
#include "Misc/CommandLine.h"
#include "HAL/PlatformTime.h"

// Lightweight diagnostics used while investigating connect flicker / pose jitter.
// Enabled only when the process is started with -RebocapTrace, so it costs nothing in shipping.
namespace RebocapTrace
{
    inline bool Enabled()
    {
        static int32 Cached = -1;
        if (Cached < 0)
        {
            Cached = FParse::Param(FCommandLine::Get(), TEXT("RebocapTrace")) ? 1 : 0;
        }
        return Cached == 1;
    }

    inline double Now()
    {
        return FPlatformTime::Seconds();
    }

    inline void Log(const FString& InMessage)
    {
        if (Enabled())
        {
            UE_LOG(LogTemp, Warning, TEXT("[RTrace] %s"), *InMessage);
        }
    }

    inline void Logf(const TCHAR* Format, ...)
    {
        if (!Enabled())
        {
            return;
        }
        TCHAR Buffer[1024];
        va_list Args;
        va_start(Args, Format);
        FCString::GetVarArgs(Buffer, UE_ARRAY_COUNT(Buffer), Format, Args);
        va_end(Args);
        UE_LOG(LogTemp, Warning, TEXT("[RTrace] %s"), Buffer);
    }
}

// Test driver: -RebocapTest exercises disconnect / reconnect / bad-port fallback on a timer.
namespace RebocapTest
{
    inline bool Enabled()
    {
        static int32 Cached = -1;
        if (Cached < 0)
        {
            Cached = FParse::Param(FCommandLine::Get(), TEXT("RebocapTest")) ? 1 : 0;
        }
        return Cached == 1;
    }
}
