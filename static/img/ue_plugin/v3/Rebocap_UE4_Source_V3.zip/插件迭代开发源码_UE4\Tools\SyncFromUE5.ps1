﻿# 把 V2.x 的 UE5 源码同步成 UE4 插件（幂等）
#
# 用法：
#   powershell -NoProfile -ExecutionPolicy Bypass -File Tools\SyncFromUE5.ps1
#   powershell ... -File Tools\SyncFromUE5.ps1 -UE5Root "D:\...\rebocap" -UE4Root "D:\...\插件迭代开发源码_UE4"
#
# 策略：UE5 是唯一事实来源。
#   1) 把 UE5 树的资源/源码镜像过来（会覆盖 UE4 侧的旧改动）
#   2) 用 Tools\UE4Overrides 里的 3 个 Build.cs 模板覆盖（模板即"UE4 正确版本"）
#   3) 对 2 个源文件做定点替换（BoneReference 头、脊椎预设）
#   4) 确保 SDK DLL 存在
# 脚本可反复执行；执行完 git 差异应只剩 Tools/ 本身。

param(
    [string]$UE5Root = "D:\rebocap\03 ue plugins\插件迭代开发源码\rebocap",
    [string]$UE4Root = "D:\rebocap\03 ue plugins\插件迭代开发源码_UE4"
)

$ErrorActionPreference = "Stop"
$changes = New-Object System.Collections.ArrayList
function Note($msg) { [void]$changes.Add($msg); Write-Host "  $msg" }

# 读取时记录 BOM，写回时保持一致（UE5 的部分 .cpp 带 BOM，去掉会导致整文件 diff）
function Read-SourceFile($path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = [System.Text.Encoding]::UTF8.GetString($bytes)
    if ($hasBom) { $text = $text.TrimStart([char]0xFEFF) }
    return @{ Text = $text; Bom = $hasBom; Crlf = $text.Contains("`r`n") }
}
function Write-SourceFile($path, $info, $text) {
    if ($info.Crlf) { $text = $text -replace "`r?`n", "`r`n" }
    [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($info.Bom)))
}


Write-Host "== 1. 镜像 UE5 资源与源码 =="
# 注意：Docs 不同步——UE4 的文档是 UE4 专属的，镜像会把它删掉
foreach ($dir in @("Source", "Config", "Content", "Localization", "Resources", "x64")) {
    $src = Join-Path $UE5Root $dir
    if (Test-Path -LiteralPath $src) {
        robocopy $src (Join-Path $UE4Root $dir) /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
    }
}
foreach ($f in @("rebocap.uplugin", "README.md", "LICENSE", ".clang-format", ".gitignore")) {
    $src = Join-Path $UE5Root $f
    if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $UE4Root $f) -Force }
}
Note "已镜像 Source/Config/Content/Localization/Resources/x64/Docs"

Write-Host "== 2. 覆盖 3 个 Build.cs（UE4 版本模板）=="
$overrideDir = Join-Path $UE4Root "Tools\UE4Overrides"
foreach ($m in @("rebocap", "rebocap_editor", "rebocap_runtime")) {
    $tpl = Join-Path $overrideDir "$m.Build.cs"
    $dst = Join-Path $UE4Root "Source\$m\$m.Build.cs"
    if ((Test-Path -LiteralPath $tpl) -and (Test-Path -LiteralPath (Split-Path $dst))) {
        Copy-Item -LiteralPath $tpl -Destination $dst -Force
        Note "$m.Build.cs <- 模板"
    }
}

Write-Host "== 3. FBoneReference 头文件统一为 BoneContainer.h =="
$p = Join-Path $UE4Root "Source\rebocap_editor\Private\RebocapA2TEditorLibrary.cpp"
$info = Read-SourceFile $p
$t = $info.Text
if ($t -match '#include "Animation/BoneReference\.h"') {
    $t = [regex]::Replace($t, '#include "Animation/BoneReference\.h"[^\r\n]*',
        '#include "BoneContainer.h"   // FBoneReference (UE5.3+ moved it into Animation/BoneReference.h, re-exported here)')
    Write-SourceFile $p $info $t
    Note "RebocapA2TEditorLibrary.cpp: BoneReference.h -> BoneContainer.h（4.27~5.9 通用）"
}

Write-Host "== 4. 脊椎骨骼预设改为 UE4 Mannequin 命名 =="
$p = Join-Path $UE4Root "Source\rebocap_runtime\Private\rebocap_body_remap_asset.cpp"
$info = Read-SourceFile $p
$t = $info.Text
$patched = $false
if ($t -match 'spine1_ = TEXT\("spine_02"\)') {
    $t = [regex]::Replace($t, 'spine1_ = TEXT\("spine_02"\);[^\r\n]*', 'spine1_ = TEXT("spine_01"); // UE4 Mannequin: lower spine')
    $patched = $true
}
if ($t -match 'spine2_ = TEXT\("spine_04"\)') {
    $t = [regex]::Replace($t, 'spine2_ = TEXT\("spine_04"\);[^\r\n]*', 'spine2_ = TEXT("spine_02"); // UE4 Mannequin: mid spine')
    $patched = $true
}
if ($t -match 'spine3_ = TEXT\("spine_05"\)') {
    $t = [regex]::Replace($t, 'spine3_ = TEXT\("spine_05"\);[^\r\n]*', 'spine3_ = TEXT("spine_03"); // UE4 Mannequin: upper spine (UE4 has no spine_04/05)')
    $patched = $true
}
if ($patched) {
    Write-SourceFile $p $info $t
    Note "rebocap_body_remap_asset.cpp: spine_02/04/05 -> spine_01/02/03"
}

Write-Host "== 5. 确保 SDK DLL 存在 =="
$dllDst = Join-Path $UE4Root "Binaries\ThirdParty\RebocapWsSdk\Win64\rebocap_ws_sdk.dll"
if (-not (Test-Path -LiteralPath $dllDst)) {
    $dllSrc = Join-Path $UE5Root "Binaries\ThirdParty\RebocapWsSdk\Win64\rebocap_ws_sdk.dll"
    if (Test-Path -LiteralPath $dllSrc) {
        New-Item -ItemType Directory -Path (Split-Path $dllDst) -Force | Out-Null
        Copy-Item -LiteralPath $dllSrc -Destination $dllDst -Force
        Note "Binaries/ThirdParty: 补 rebocap_ws_sdk.dll"
    }
}

Write-Host ""
Write-Host "== 完成，共 $($changes.Count) 项 =="
foreach ($c in $changes) { Write-Host "  - $c" }
Write-Host ""
Write-Host "下一步："
Write-Host "  1) 切换 UBT 编译器为 VS2019（见 Docs\UE4_PLAYBOOK.md 第 4 节）"
Write-Host "  2) 编译 4.26 / 4.27 host 工程"
Write-Host "  3) 按第 6 节清单验收，再把二进制拷到发布包 / 测试工程"
