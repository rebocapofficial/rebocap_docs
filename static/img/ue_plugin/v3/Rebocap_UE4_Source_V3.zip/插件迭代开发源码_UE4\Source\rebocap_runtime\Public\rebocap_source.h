#pragma once

#include <string>
#include <atomic>
#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "ILiveLinkClient.h"
#include "ILiveLinkSource.h"
#include "rebocap_source_settings.h"
#include "rebocap_ws_sdk_cpp.h"

class REBOCAP_RUNTIME_API FRebocapSource final : public ILiveLinkSource, public FRunnable
{
public:
    FRebocapSource(uint16_t port, const FString& InHost = FString());
    FRebocapSource(const FString& IPAddress, uint16_t port);
    virtual ~FRebocapSource() override;

    // --- LiveLink interface ---
    virtual void ReceiveClient(ILiveLinkClient* InClient, FGuid InSourceGuid) override;
    virtual void InitializeSettings(ULiveLinkSourceSettings* Settings) override;
    virtual bool IsSourceStillValid() const override;
    virtual bool RequestSourceShutdown() override;
    virtual FText GetSourceType() const override;
    virtual FText GetSourceMachineName() const override;
    virtual FText GetSourceStatus() const override;

    // --- Feature interface ---
    int CalculateAndRegisterToRebocap(
        TArray<FVector3f>& left_vertex,
        TArray<FVector3f>& left_normals,
        TArray<FVector3f>& right_vertex,
        TArray<FVector3f>& right_normals,
        TArray<FVector3f>& skeletons,
        const std::string& coordinate,
        TArray<FVector3f>& foot_vertices);

    bool IsPortOpen() const { return status_; }
    // bUserInitiated: the control panel / blueprint helper asked for the disconnect, so the anim
  // node must not silently reconnect on its next tick (that produced a ~0.3 s base-pose flash).
  void ManualStop(bool bUserInitiated = false);

  bool IsUserStopped() const { return bUserStopped_.load(); }
    bool ManualStart(uint16_t port);

    /** Port this source currently points at. */
    uint16_t GetPort() const { return port_; }

    /**
     * Port used when a source is created implicitly (anim node auto-connect, blueprint helper).
     * Defaults to 7690; the control panel writes it when the user connects on a custom port so the
     * node does not silently fall back to 7690 on the next reconnect.
     */
    static uint16_t GetConfiguredPort();
    static void SetConfiguredPort(uint16_t Port);

    /** LiveLink subject name this source publishes (default "rebocap"). */
    void SetSubjectName(FName InName) { subject_name_ = InName.IsNone() ? FName(TEXT("rebocap")) : InName; }
    FName GetSubjectName() const { return subject_name_; }

    // --- Live mocap stream rate statistics (Hz) ---
    float GetMocapHz() const;

  // Seconds since the last pose packet arrived. Used by the anim node to tell a live stream
  // from LiveLink handing back the same stale frame after the mocap app went away.
  double SecondsSinceLastPacket() const;

    // --- Thread priority control ---
    void SetThreadPriority(EThreadPriority NewPriority);
    EThreadPriority GetThreadPriority() const { return thread_priority_; }

    // --- Singleton management ---
    static TSharedPtr<FRebocapSource> GetInstance();
    static void SetInstance(TSharedPtr<FRebocapSource> instance);

    // --- Global static switches ---
    static bool bAutoSkeleton;          
    static bool bUserOverrideDisconnect; // Kept defined to avoid link errors
    static bool bZeroAllocStaticSubject; // [Experimental] Zero-allocation LiveLink data build switch (default OFF)

private:
    // --- FRunnable thread interface ---
    virtual bool Init() override;
    virtual uint32 Run() override;
    virtual void Stop() override;

    // Internal functions
    void clear_all_subjects();
    bool open();
    void pose_msg_callback(const QuatMsg* msg);

private:
    ILiveLinkClient* client_ = nullptr;
    FGuid source_guid_;
    URebocapSourceSettings* saved_source_settings_ = nullptr;

    /** Subject names published by this source; written on the LiveLink worker thread, read on the game thread. */
    TArray<FName> subject_names_;
    mutable FCriticalSection subject_names_lock_;

    /** LiveLink subject name published by the SDK callback (default "rebocap"). */
    FName subject_name_{TEXT("rebocap")};
    
    uint16_t port_;

    // Fallback state for a custom port that never opens: retried on the worker thread so it does not
    // depend on the anim graph ticking.
    int32 consecutive_open_failures_{0};
    bool bPortFallbackDone_{false};
    double first_open_failure_time_{0.0};
    double last_open_failure_log_time_{0.0};
    FString host_;      // Remote host; empty means local machine (localhost)
    bool status_{false}; // Connection state

    // Live mocap frame rate statistics
    std::atomic<float> current_mocap_hz_{0.0f};
    std::atomic<double> last_packet_time_{0.0}; // Time the last packet arrived (used to detect a stopped stream)
  std::atomic<bool> bUserStopped_{false};     // Set by an explicit disconnect, cleared by an explicit connect
    double last_fps_calc_time_{0.0};
    uint32_t frames_in_period_{0};

    // Thread related
    FRunnableThread* thread_{nullptr};
    EThreadPriority thread_priority_{TPri_Highest};
    bool running_{true};     
    bool bIsShuttingDown{false}; 

    // SDK pointer
    TSharedPtr<rebocap::RebocapWsSdk> rebocap_sdk_;

    // Singleton static pointer
    static TSharedPtr<FRebocapSource> instance_;

    /** Port used when the plugin has to create a source on its own (see GetConfiguredPort). */
    static std::atomic<uint16_t> configured_port_;
};