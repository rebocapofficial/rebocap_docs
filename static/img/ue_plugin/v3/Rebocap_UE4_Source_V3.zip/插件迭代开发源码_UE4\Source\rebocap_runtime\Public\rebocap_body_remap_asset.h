#pragma once

#include "LiveLinkCustomVersion.h"
#include "LiveLinkRemapAsset.h"
#include "rebocap_body_remap_asset.generated.h"

/** Bone Naming Preset Standards */
UENUM(BlueprintType)
enum class ERebocapBonePreset : uint8 {
  Unreal_Engine UMETA(DisplayName = "Unreal Engine (UE4 / UE5 / MetaHuman Standard)"),
  Mixamo UMETA(DisplayName = "Adobe Mixamo (No Prefix: Hips, Spine...)"),
  Mixamo_Prefix UMETA(DisplayName = "Adobe Mixamo (With Prefix: mixamorig:Hips...)"),
  MMD_Japanese UMETA(DisplayName = "MMD Standard Japanese Bones (センター, 上半身, 左腕...)"),
  VRM_Humanoid UMETA(DisplayName = "VRM / VRoid / Unity Humanoid Standard"),
  Rebocap_Standard UMETA(DisplayName = "Rebocap 24 Bones Standard (Default)"),
  Custom UMETA(DisplayName = "Custom")
};

/** 
 * Rebocap Bone Remapping Asset
 * Maps standard Rebocap 24-bone motion capture nodes to the character's skeletal joint names.
 */
UCLASS(BlueprintType, Blueprintable, meta = (ToolTip = "Rebocap bone mapping asset for retargeting mocap bones to character skeleton joint names."))
class REBOCAP_RUNTIME_API URebocapMapData : public ULiveLinkRemapAsset {
  GENERATED_BODY()

 public:
  URebocapMapData();

  FName GetRemappedBoneName_Implementation(FName CurveName) const final;

  void Initialize() final { InitializeTMap(); }

  UFUNCTION(BlueprintCallable, Category = "BoneRemapping")
  void InitializeTMap();

  // One-shot guard: GetRemappedBoneName runs per bone per frame, so a missing mapping must not spam the log.
  mutable bool bWarnedMissingMapping_ = false;

  /** Preset Template */
  UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "0. Presets & Actions", meta = (DisplayName = "Select Bone Preset", ToolTip = "Select a bone preset to automatically populate all joint names below."))
  ERebocapBonePreset PresetTemplate = ERebocapBonePreset::Unreal_Engine;

  /** Apply Bone Preset */
  UFUNCTION(BlueprintCallable, Category = "BoneRemapping")
  void ApplyPreset(ERebocapBonePreset InPreset);

  /** Export to JSON */
  UFUNCTION(BlueprintCallable, Category = "BoneRemapping")
  void ExportToJson();

  /** Import from JSON */
  UFUNCTION(BlueprintCallable, Category = "BoneRemapping")
  void ImportFromJson();

#if WITH_EDITOR
  virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

  UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "0. Mapping Preview", meta = (DisplayName = "Name Mapping"))
  TMap<FName, FName> name_mapping_;

  // --- 1. Root & Spine & Head ---

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "1. Root & Spine & Head", meta = (DisplayName = "Pelvis / Hips", ToolTip = "Root mocap bone, receives root motion translation."))
  FName rebocap_pelvis_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "1. Root & Spine & Head", meta = (DisplayName = "Spine1 / Waist", ToolTip = "Waist / Lower spine joint."))
  FName spine1_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "1. Root & Spine & Head", meta = (DisplayName = "Spine2 / Chest", ToolTip = "Chest joint for mid-torso bend."))
  FName spine2_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "1. Root & Spine & Head", meta = (DisplayName = "Spine3 / Up Chest", ToolTip = "Upper chest joint (leave empty if skeleton has no spine3)."))
  FName spine3_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "1. Root & Spine & Head", meta = (DisplayName = "Neck", ToolTip = "Neck joint."))
  FName neck_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "1. Root & Spine & Head", meta = (DisplayName = "Head", ToolTip = "Head joint."))
  FName head_;

  // --- 2. Left Arm ---

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "2. Left Arm", meta = (DisplayName = "Left Collar / Clavicle", ToolTip = "Left shoulder / clavicle joint."))
  FName l_collar_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "2. Left Arm", meta = (DisplayName = "Left Shoulder / UpperArm", ToolTip = "Left upper arm joint."))
  FName l_shoulder_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "2. Left Arm", meta = (DisplayName = "Left Elbow / LowerArm", ToolTip = "Left forearm / lower arm joint."))
  FName l_elbow_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "2. Left Arm", meta = (DisplayName = "Left Wrist / Hand", ToolTip = "Left wrist / hand joint."))
  FName l_wrist_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "2. Left Arm", meta = (DisplayName = "Left Hand End / Fingers", ToolTip = "Left hand end / fingers joint (optional)."))
  FName l_hand_;

  // --- 3. Right Arm ---

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "3. Right Arm", meta = (DisplayName = "Right Collar / Clavicle", ToolTip = "Right shoulder / clavicle joint."))
  FName r_collar_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "3. Right Arm", meta = (DisplayName = "Right Shoulder / UpperArm", ToolTip = "Right upper arm joint."))
  FName r_shoulder_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "3. Right Arm", meta = (DisplayName = "Right Elbow / LowerArm", ToolTip = "Right forearm / lower arm joint."))
  FName r_elbow_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "3. Right Arm", meta = (DisplayName = "Right Wrist / Hand", ToolTip = "Right wrist / hand joint."))
  FName r_wrist_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "3. Right Arm", meta = (DisplayName = "Right Hand End / Fingers", ToolTip = "Right hand end / fingers joint (optional)."))
  FName r_hand_;

  // --- 4. Left Leg ---

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "4. Left Leg", meta = (DisplayName = "Left Hip / Thigh", ToolTip = "Left thigh / upper leg joint."))
  FName l_hip_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "4. Left Leg", meta = (DisplayName = "Left Knee / Calf", ToolTip = "Left knee / lower leg joint."))
  FName l_knee_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "4. Left Leg", meta = (DisplayName = "Left Ankle / Foot", ToolTip = "Left ankle / foot joint."))
  FName l_ankle_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "4. Left Leg", meta = (DisplayName = "Left Foot End / Toe", ToolTip = "Left toe joint (optional)."))
  FName l_foot_;

  // --- 5. Right Leg ---

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "5. Right Leg", meta = (DisplayName = "Right Hip / Thigh", ToolTip = "Right thigh / upper leg joint."))
  FName r_hip_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "5. Right Leg", meta = (DisplayName = "Right Knee / Calf", ToolTip = "Right knee / lower leg joint."))
  FName r_knee_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "5. Right Leg", meta = (DisplayName = "Right Ankle / Foot", ToolTip = "Right ankle / foot joint."))
  FName r_ankle_;

  UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "5. Right Leg", meta = (DisplayName = "Right Foot End / Toe", ToolTip = "Right toe joint (optional)."))
  FName r_foot_;

  // --- 6. Foot Sole Collision Indices ---
  UPROPERTY()
  TArray<int32> FootIndices;
};