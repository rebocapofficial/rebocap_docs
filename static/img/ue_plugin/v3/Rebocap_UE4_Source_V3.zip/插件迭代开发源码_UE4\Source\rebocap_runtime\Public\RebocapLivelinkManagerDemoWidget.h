﻿#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

// Empty shell UI class, kept only to avoid unrelated link errors caused by deleting the file
// It no longer contains any functionality
class SRebocapLivelinkManagerDemoWidget : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SRebocapLivelinkManagerDemoWidget)
    {}
    SLATE_END_ARGS()

    void Construct(const FArguments& InArgs);
};