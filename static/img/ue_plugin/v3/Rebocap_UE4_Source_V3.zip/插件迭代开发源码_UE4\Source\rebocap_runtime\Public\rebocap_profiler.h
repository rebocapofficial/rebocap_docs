#pragma once

#include "CoreMinimal.h"
#include "HAL/CriticalSection.h"
#include "HAL/PlatformTime.h"

struct FRebocapSamplePoint {
    float ElapsedTime = 0.0f;
    float RenderFPS = 0.0f;
    float RenderDeltaMs = 0.0f;
    float MocapHz = 0.0f;
    bool bConnected = false;
};

struct FRebocapBoneMappingInfo {
    FString MeshName;
    FString SkeletonName;
    int32 BoneCount = 0;
    int32 LODLevel = 0;
    FString RetargetAssetName;
    TMap<FString, FString> BoneMap; // e.g. "Pelvis" -> "pelvis"
};

struct FRebocapNodeConfigSnapshot {
    bool bAutoSkeleton = true;
    bool bAutoConnect = true;
    bool bEnableInterpolation = false;
    float InterpolationSpeed = 45.0f;
    bool bHoldPoseOnDropout = true;
    float DropoutTimeout = 2.0f;
    bool bThrottleSkeletonRegistration = false;
    bool bZeroAllocStaticSubject = false;
    bool bOptimizeFrameEvaluation = false;
};

class REBOCAP_RUNTIME_API FRebocapProfiler {
public:
    static FRebocapProfiler& Get();

    /** Starts diagnostic recording (default 10.0 seconds) */
    void StartRecording(float InDurationSeconds = 10.0f);

    /** Stops recording and generates the report */
    void StopRecordingAndGenerateReport();

    /** Checks whether recording is in progress */
    bool IsRecording() const;

    /** Gets the remaining recording time (seconds) */
    float GetRemainingTime() const;

    /** Gets the recording progress percentage, 0.0 ~ 1.0 */
    float GetProgress() const;

    /** Samples the current frame (called from the animation or game thread tick) */
    void SampleFrame(float DeltaSeconds, float CurrentMocapHz, bool bIsConnected);

    /** Records the arrival time of a mocap packet (used for network jitter analysis) */
    void RecordPacketArrival(double Timestamp);

    /** Updates the character skeleton and retarget mapping context */
    void UpdateSkeletalContext(const FRebocapBoneMappingInfo& InInfo);

    /** Updates the anim node configuration snapshot */
    void UpdateNodeConfig(const FRebocapNodeConfigSnapshot& InConfig);

    /** Gets the absolute path of the most recently generated diagnostic report */
    FString GetLastReportFilePath() const;

private:
    FRebocapProfiler();
    ~FRebocapProfiler();

    FString GenerateReportString();

    /** Guards every member below: packet arrivals come from the LiveLink worker thread, the rest from the game thread. */
    mutable FCriticalSection DataLock;

    bool bIsRecording = false;
    float TargetDuration = 10.0f;
    double RecordingStartTime = 0.0;
    double LastSampleTime = 0.0;

    TArray<FRebocapSamplePoint> Samples;
    TArray<double> PacketArrivalTimes;

    FRebocapBoneMappingInfo CachedBoneInfo;
    bool bHasBoneInfo = false;

    FRebocapNodeConfigSnapshot CachedNodeConfig;
    bool bHasNodeConfig = false;

    FString LastReportFilePath;
};
