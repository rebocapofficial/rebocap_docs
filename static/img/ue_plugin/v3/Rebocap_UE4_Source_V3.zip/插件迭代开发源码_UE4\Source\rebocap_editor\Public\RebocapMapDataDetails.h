#pragma once

#include "CoreMinimal.h"
#include "IDetailCustomization.h"

class IDetailLayoutBuilder;

/**
 * Details panel customization for RebocapMapData (adds one-click apply plus JSON import/export buttons to the class defaults panel)
 */
class FRebocapMapDataDetails : public IDetailCustomization
{
public:
    static TSharedRef<IDetailCustomization> MakeInstance()
    {
        return MakeShareable(new FRebocapMapDataDetails);
    }

    virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
};
