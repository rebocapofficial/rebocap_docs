#include "rebocap_source.h"
#include "rebocap_trace.h"
#include "rebocap_runtime.h"
#include "rebocap_ws_sdk_cpp.h"
#include "rebocap_skeleton_data.h"
#include "Roles/LiveLinkAnimationRole.h"
#include "ILiveLinkClient.h" 
#include "Async/Async.h"
#include "Containers/StringConv.h"
#include "Misc/QualifiedFrameTime.h"
#include "rebocap_profiler.h"

// Static variable initialization
TSharedPtr<FRebocapSource> FRebocapSource::instance_ = nullptr;
bool FRebocapSource::bAutoSkeleton = true; 
bool FRebocapSource::bZeroAllocStaticSubject = false; 
// Port used whenever the plugin has to create a source on its own (node auto-connect / BP helper).
std::atomic<uint16_t> FRebocapSource::configured_port_{7690};

FRebocapSource::FRebocapSource(uint16_t port, const FString& InHost)
    : port_(port)
    , host_(InHost)
{
    client_ = nullptr;
    
    // [Hardening]: never call the underlying SDK when the DLL failed to load, eliminating 0xc06d007e delay-load crashes.
    bool bSdkLoaded = false;
    if (FModuleManager::Get().IsModuleLoaded("rebocap_runtime"))
    {
        bSdkLoaded = Frebocap_runtimeModule::Get().IsSdkLoaded();
    }

    if (!bSdkLoaded)
    {
        UE_LOG(LogTemp, Warning,
               TEXT("[Rebocap] Mocap runtime library not loaded (Microsoft vc_redist.x64 is the usual cause). ")
               TEXT("Unreal Editor started normally; install it to enable mocap: https://aka.ms/vs/17/release/vc_redist.x64.exe"));
        return;
    }

    // Initialize the SDK object
    rebocap_sdk_ = MakeShared<rebocap::RebocapWsSdk>(CoordinateSpaceType::UECoordinate, true);
    
    // Bind callbacks
    rebocap_sdk_->SetPoseMsgCallback([this](const QuatMsg* msg, rebocap::RebocapWsSdk* h) { 
        this->pose_msg_callback(msg); 
    });
    
    // Register the exception-close callback
    rebocap_sdk_->SetExceptionCloseCallback([this](rebocap::RebocapWsSdk* h) { 
        status_ = false; 
    });

    // ================== [Fix start] ==================
    // Critical fix: detect whether a commandlet is running (e.g. the packaging / Cook step)
    // If so, never start the connection thread, to avoid the SECURE CRT crash.
    if (IsRunningCommandlet())
    {
        UE_LOG(LogTemp, Warning, TEXT("Rebocap: Skipped connection thread during Commandlet/Cooking mode."));
        // Return without creating the thread
        return;
    }
    // ================== [Fix end] ==================

    FString ThreadName(FString::Printf(TEXT("FRebocapSource_%d_%lld"), port, FDateTime::UtcNow().ToUnixTimestamp()));
    thread_ = FRunnableThread::Create(this, *ThreadName, 512 * 1024, thread_priority_);

    UE_LOG(LogTemp, Display, TEXT("New Rebocap Source created on port: %d"), port);
}

FRebocapSource::FRebocapSource(const FString& IPAddress, uint16_t port)
    : FRebocapSource(port, IPAddress) 
{
}

FRebocapSource::~FRebocapSource() {
    UE_LOG(LogTemp, Display, TEXT("Destroying Rebocap Source..."));

    // 1. Stop flag: block any further data processing
    bIsShuttingDown = true;
    running_ = false; 

    // 2. Thread sync: wait for Run() to fully exit
    if (thread_ != nullptr) {
        thread_->WaitForCompletion(); 
        delete thread_;
        thread_ = nullptr;
    }

    // 3. Clean up LiveLink
    clear_all_subjects();

    // 4. Destroy the SDK: the thread has stopped safely, so the memory can be released
    if (rebocap_sdk_.IsValid()) {
        rebocap_sdk_->UnregisterCallbacks();
        rebocap_sdk_->Close();
        rebocap_sdk_.Reset();
    }
}

void FRebocapSource::ReceiveClient(ILiveLinkClient* InClient, FGuid InSourceGuid) {
    client_ = InClient;
    source_guid_ = InSourceGuid;
}

void FRebocapSource::InitializeSettings(ULiveLinkSourceSettings* Settings) {
    saved_source_settings_ = Cast<URebocapSourceSettings>(Settings);
}

bool FRebocapSource::IsSourceStillValid() const { 
    return client_ != nullptr; 
}

bool FRebocapSource::RequestSourceShutdown() {
    clear_all_subjects();
    return true;
}

FText FRebocapSource::GetSourceType() const { return FText::FromString("Rebocap"); }
FText FRebocapSource::GetSourceMachineName() const {
    const FString Endpoint = host_.IsEmpty() ? FString(TEXT("localhost")) : host_;
    return FText::FromString(FString::Printf(TEXT("WS:%s:%d"), *Endpoint, port_));
}
FText FRebocapSource::GetSourceStatus() const { return status_ ? FText::FromString("Active") : FText::FromString("Connecting"); }

TSharedPtr<FRebocapSource> FRebocapSource::GetInstance() { return instance_; }
void FRebocapSource::SetInstance(TSharedPtr<FRebocapSource> instance) { instance_ = instance; }

void FRebocapSource::clear_all_subjects() {
    if (client_ == nullptr) return;
    
    FScopeLock Lock(&subject_names_lock_);
    const int32 RemovedCount = subject_names_.Num();
    for (const auto& subject_name : subject_names_) {
        client_->RemoveSubject_AnyThread(FLiveLinkSubjectKey(source_guid_, subject_name));
    }
    subject_names_.Empty();
    RebocapTrace::Logf(TEXT("t=%.3f subject_remove n=%d"), RebocapTrace::Now(), RemovedCount);
}

bool FRebocapSource::open() {
    if (status_) return true;
    
    if (!rebocap_sdk_.IsValid()) return false;

    // Remote host connection (rebocap_ws_sdk_open_with_host is available since SDK 2026-11);
    // localhost / 127.0.0.1 / 0.0.0.0 / empty are treated as the local machine and use the original Open path.
    const bool bRemoteHost = !host_.IsEmpty()
        && !host_.Equals(TEXT("localhost"), ESearchCase::IgnoreCase)
        && !host_.Equals(TEXT("127.0.0.1"))
        && !host_.Equals(TEXT("0.0.0.0"));

    // A previous attempt may have left the SDK with a pending/failed socket; reset it before retrying,
    // otherwise the next Open() can block forever and the worker thread stops producing any log.
    if (consecutive_open_failures_ > 0) {
        rebocap_sdk_->Close();
    }

    int ret = bRemoteHost
        ? rebocap_sdk_->OpenRemote(std::string(TCHAR_TO_UTF8(*host_)), port_, "reborn_app", 114514)
        : rebocap_sdk_->Open(port_, "reborn_app", 114514);
    status_ = (ret == 0);

    const FString Endpoint = host_.IsEmpty() ? FString(TEXT("localhost")) : host_;
    if (status_) {
        consecutive_open_failures_ = 0;
        first_open_failure_time_ = 0.0;
        last_open_failure_log_time_ = 0.0;
        UE_LOG(LogTemp, Display, TEXT("Rebocap SDK Connected on %s:%d!"), *Endpoint, port_);
        RebocapTrace::Logf(TEXT("t=%.3f open_ok port=%d"), RebocapTrace::Now(), port_);
    } else {
        ++consecutive_open_failures_;
        const double NowSeconds = FPlatformTime::Seconds();
        if (first_open_failure_time_ <= 0.0) {
            first_open_failure_time_ = NowSeconds;
        }

        // A custom port that never opens would leave the user with a silently dead source.
        // open() blocks for ~5 s on an unreachable port, so waiting for several attempts costs the
        // user 13+ seconds of a frozen character (measured). One failed attempt is enough to fall
        // back; the panel can still point the source at the custom port again.
        if (port_ != 7690 && !bPortFallbackDone_ && consecutive_open_failures_ >= 1) {
            bPortFallbackDone_ = true;
            consecutive_open_failures_ = 0;
            UE_LOG(LogTemp, Warning,
                   TEXT("[Rebocap] No mocap data on custom port %d after several attempts; falling back to 7690. ")
                   TEXT("If your Rebocap app listens on %d, reconnect from the control panel."),
                   port_, port_);
            if (rebocap_sdk_.IsValid()) {
                rebocap_sdk_->Close();
            }
            port_ = 7690;
            first_open_failure_time_ = 0.0;
            consecutive_open_failures_ = 0;
            return false;
        }

        // Retries happen every few seconds while the Rebocap app is closed; log the first failure and
        // then at most once a minute so a long session does not fill the log with identical lines.
        if (last_open_failure_log_time_ <= 0.0 || (NowSeconds - last_open_failure_log_time_) > 60.0) {
            last_open_failure_log_time_ = NowSeconds;
            UE_LOG(LogTemp, Warning, TEXT("Rebocap SDK Open failed on %s:%d (ret: %d)"), *Endpoint, port_, ret);
            RebocapTrace::Logf(TEXT("t=%.3f open_fail port=%d ret=%d"), RebocapTrace::Now(), port_, ret);
        }
    }
    return status_;
}

bool FRebocapSource::Init() { return true; }

uint32 FRebocapSource::Run() {
    uint16_t tick = 0;
    while (running_) {
        if (tick++ % 10 == 0) {
            open();
        }
        FPlatformProcess::Sleep(0.033f);
    }
    return 0;
}

void FRebocapSource::Stop() {
    running_ = false;
    if (thread_) {
        thread_->WaitForCompletion();
    }
}

void FRebocapSource::ManualStop(bool bUserInitiated) {
    status_ = false;
    running_ = false;
    if (bUserInitiated)
    {
        bUserStopped_.store(true);
    }
    // Drop the LiveLink subject as well: otherwise the node keeps re-evaluating the last frame and
    // the character stays frozen instead of following the documented dropout behaviour.
    clear_all_subjects();
    if (rebocap_sdk_.IsValid()) {
        rebocap_sdk_->Close();
    }
    // Do not join here: the worker may be blocked inside open(), and ManualStop is called on the
    // game thread. ManualStart() reaps a finished thread before creating a new one.
}

void FRebocapSource::SetThreadPriority(EThreadPriority NewPriority) {
    thread_priority_ = NewPriority;
    if (thread_) {
        thread_->SetThreadPriority(NewPriority);
    }
}

bool FRebocapSource::ManualStart(uint16_t port) {
    bUserStopped_.store(false);
    // [Fix] Prevent manual start while cooking
    if (IsRunningCommandlet()) return false;

    if (port != port_) {
        // Port changed while a socket may still be open: open() short-circuits on status_, so the
        // connection has to be dropped explicitly or the source would keep streaming from the old port
        // while reporting the new one.
        status_ = false;
        if (rebocap_sdk_.IsValid()) {
            rebocap_sdk_->Close();
        }

        // A user-requested port gets a fresh chance (and a fresh fallback budget).
        bPortFallbackDone_ = false;
        consecutive_open_failures_ = 0;
        first_open_failure_time_ = 0.0;
    }
    port_ = port;

    if (running_) {
        // Already running: the new port is picked up by the next open() attempt.
        return true;
    }

    // Reap a finished thread before creating a new one, so repeated start/stop cycles do not leak
    // thread objects (the old code overwrote thread_ while the previous runnable was still alive).
    if (thread_ != nullptr) {
        // running_ is false here, so the loop exits within one sleep tick; Kill(true) reaps it
        // instead of leaking the runnable and spawning a second thread on top of it.
        thread_->Kill(true);
        delete thread_;
        thread_ = nullptr;
    }

    running_ = true;
    FString ThreadName(FString::Printf(TEXT("FRebocapSource_%d_Restart"), port));
    thread_ = FRunnableThread::Create(this, *ThreadName, 512 * 1024, thread_priority_);
    return thread_ != nullptr;
}

uint16_t FRebocapSource::GetConfiguredPort() {
    return configured_port_.load();
}

void FRebocapSource::SetConfiguredPort(uint16_t Port) {
    configured_port_.store(Port == 0 ? 7690 : Port);
}

double FRebocapSource::SecondsSinceLastPacket() const
{
    const double Last = last_packet_time_.load();
    if (Last <= 0.0)
    {
        return 1.0e9; // never received anything
    }
    return FPlatformTime::Seconds() - Last;
}

float FRebocapSource::GetMocapHz() const {
    if (!status_) {
        return 0.0f;
    }
    // Treat the stream as stopped after 0.5 s without a new packet and return 0;
    // otherwise a stalled or fake connection keeps reporting the last rate and makes a frozen character look like a healthy link.
    const double Now = FPlatformTime::Seconds();
    const double LastPacket = last_packet_time_.load();
    if (LastPacket <= 0.0 || (Now - LastPacket) > 0.5) {
        return 0.0f;
    }
    return current_mocap_hz_.load();
}

int FRebocapSource::CalculateAndRegisterToRebocap(
    TArray<FVector3f>& left_vertex, TArray<FVector3f>& left_normals,
    TArray<FVector3f>& right_vertex, TArray<FVector3f>& right_normals,
    TArray<FVector3f>& skeletons, const std::string& coordinate,
    TArray<FVector3f>& foot_vertices) 
{
    if (rebocap_sdk_.IsValid()) {
        return rebocap_sdk_->CalculateAndRegisterToRebocap(
            left_vertex, left_normals, right_vertex, right_normals, skeletons, coordinate, foot_vertices);
    }
    return -1;
}

void FRebocapSource::pose_msg_callback(const QuatMsg* msg) {
    // Double-check to avoid running during destruction
    if (bIsShuttingDown || !client_ || !running_ || IsEngineExitRequested()) {
        return;
    }

    if (!msg) return;

    // Live mocap stream receive rate (Hz)
    const double CurrentTime = FPlatformTime::Seconds();
    last_packet_time_.store(CurrentTime);
    FRebocapProfiler::Get().RecordPacketArrival(CurrentTime);
    frames_in_period_++;
    const double ElapsedTime = CurrentTime - last_fps_calc_time_;
    if (ElapsedTime >= 0.5) {
        current_mocap_hz_.store(static_cast<float>(frames_in_period_ / ElapsedTime));
        frames_in_period_ = 0;
        last_fps_calc_time_ = CurrentTime;
    }

    // --- trace: packet gap ---
    {
        static double LastPacketTime = 0.0;
        if (LastPacketTime > 0.0)
        {
            const double Gap = CurrentTime - LastPacketTime;
            if (Gap > 0.12)
            {
                RebocapTrace::Logf(TEXT("t=%.3f packet_gap=%.3f"), CurrentTime, Gap);
            }
        }
        LastPacketTime = CurrentTime;
    }

    const FName subject = GetSubjectName();
    
    // 1. Push static data (declare a 60 FPS sample rate)
    if (bZeroAllocStaticSubject) {
        bool bAlreadyPublished = false;
          {
              FScopeLock Lock(&subject_names_lock_);
              bAlreadyPublished = subject_names_.Contains(subject);
          }
          if (!bAlreadyPublished) {
            FLiveLinkStaticDataStruct static_data_struct = FLiveLinkStaticDataStruct(FLiveLinkSkeletonStaticData::StaticStruct());
            FLiveLinkSkeletonStaticData& static_data = *static_data_struct.Cast<FLiveLinkSkeletonStaticData>();

            static const TArray<FName> bone_names = {
                rebocap_bones::pelvis,  rebocap_bones::l_hip,      rebocap_bones::r_hip,      rebocap_bones::spine1,   rebocap_bones::l_knee,
                rebocap_bones::r_knee,  rebocap_bones::spine2,     rebocap_bones::l_ankle,    rebocap_bones::r_ankle,  rebocap_bones::spine3,
                rebocap_bones::l_foot,  rebocap_bones::r_foot,     rebocap_bones::neck,       rebocap_bones::l_collar, rebocap_bones::r_collar,
                rebocap_bones::head,    rebocap_bones::l_shoulder, rebocap_bones::r_shoulder, rebocap_bones::l_elbow,  rebocap_bones::r_elbow,
                rebocap_bones::l_wrist, rebocap_bones::r_wrist,    rebocap_bones::l_hand,     rebocap_bones::r_hand,
            };

            static const TArray<int32> bone_parents = {
                -1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 12, 13, 14, 16, 17, 18, 19, 20, 21,
            };

            static_data.SetBoneNames(bone_names);
            static_data.SetBoneParents(bone_parents);

            client_->PushSubjectStaticData_AnyThread({source_guid_, subject}, ULiveLinkAnimationRole::StaticClass(), MoveTemp(static_data_struct));
        RebocapTrace::Logf(TEXT("t=%.3f subject_add %s"), RebocapTrace::Now(), *subject.ToString());
            RebocapTrace::Logf(TEXT("t=%.3f subject_add %s"), RebocapTrace::Now(), *subject.ToString());
            {
                  FScopeLock Lock(&subject_names_lock_);
                  subject_names_.Add(subject);
              }
        }
    } else {
        FLiveLinkStaticDataStruct static_data_struct = FLiveLinkStaticDataStruct(FLiveLinkSkeletonStaticData::StaticStruct());
        FLiveLinkSkeletonStaticData& static_data = *static_data_struct.Cast<FLiveLinkSkeletonStaticData>();

        static TArray<FName> bone_names = {
            rebocap_bones::pelvis,  rebocap_bones::l_hip,      rebocap_bones::r_hip,      rebocap_bones::spine1,   rebocap_bones::l_knee,
            rebocap_bones::r_knee,  rebocap_bones::spine2,     rebocap_bones::l_ankle,    rebocap_bones::r_ankle,  rebocap_bones::spine3,
            rebocap_bones::l_foot,  rebocap_bones::r_foot,     rebocap_bones::neck,       rebocap_bones::l_collar, rebocap_bones::r_collar,
            rebocap_bones::head,    rebocap_bones::l_shoulder, rebocap_bones::r_shoulder, rebocap_bones::l_elbow,  rebocap_bones::r_elbow,
            rebocap_bones::l_wrist, rebocap_bones::r_wrist,    rebocap_bones::l_hand,     rebocap_bones::r_hand,
        };

        static TArray<int32> bone_parents = {
            -1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 12, 13, 14, 16, 17, 18, 19, 20, 21,
        };

        static_data.SetBoneNames(bone_names);
        static_data.SetBoneParents(bone_parents);

        bool bAlreadyPublishedDefault = false;
        {
            FScopeLock Lock(&subject_names_lock_);
            bAlreadyPublishedDefault = subject_names_.Contains(subject);
        }
        if (!bAlreadyPublishedDefault) {
            client_->PushSubjectStaticData_AnyThread({source_guid_, subject}, ULiveLinkAnimationRole::StaticClass(), MoveTemp(static_data_struct));
            FScopeLock Lock(&subject_names_lock_);
            subject_names_.Add(subject);
        }
    }

    // 2. Push frame data
    FLiveLinkFrameDataStruct frame = FLiveLinkFrameDataStruct(FLiveLinkAnimationFrameData::StaticStruct());
    FLiveLinkBaseFrameData* base_data = frame.GetBaseData();
    base_data->WorldTime = FLiveLinkWorldTime(CurrentTime);
    base_data->MetaData.SceneTime = FQualifiedFrameTime(FFrameTime(FFrameNumber((int32)(CurrentTime * 60.0))), FFrameRate(60, 1));
    
    FLiveLinkAnimationFrameData& frame_data = *frame.Cast<FLiveLinkAnimationFrameData>();
    frame_data.Transforms.Reserve(24);

    static int32 BadQuatCount = 0;
    for (int i = 0; i < 96; i += 4) {
        FTransform transform;
        if (i == 0) {
            transform.SetTranslation(FVector(msg->trans[0], msg->trans[1], msg->trans[2]));
        } else {
            transform.SetTranslation(FVector::ZeroVector);
        }
        
        // [Critical fix: prevent flicker]
        // Read the raw quaternion
        FQuat RawRot(msg->quat[i], msg->quat[i + 1], msg->quat[i + 2], msg->quat[i + 3]);
        
        // Detect dirty data (all zeros or not normalized)
        if (RawRot.IsIdentity() || RawRot.SizeSquared() < 1.e-4f) {
            // Bad data: keep the default rotation to avoid collapsing the mesh
            transform.SetRotation(FQuat::Identity);
            ++BadQuatCount;
            if (BadQuatCount <= 5 || (BadQuatCount % 60) == 0)
            {
                RebocapTrace::Logf(TEXT("t=%.3f badquat bone=%d total=%d"), CurrentTime, i / 4, BadQuatCount);
            }
        } else {
            // Valid data: force normalization to avoid jitter
            RawRot.Normalize();
            transform.SetRotation(RawRot);
        }
        
        transform.SetScale3D(FVector::OneVector);
        
        frame_data.Transforms.Add(MoveTemp(transform));
    }

    client_->PushSubjectFrameData_AnyThread({source_guid_, subject}, MoveTemp(frame));
}