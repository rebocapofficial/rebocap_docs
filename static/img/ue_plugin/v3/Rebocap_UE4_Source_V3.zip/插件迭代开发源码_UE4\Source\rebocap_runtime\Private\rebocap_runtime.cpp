#include "rebocap_runtime.h"
#include "rebocap_source.h"
#include "Interfaces/IPluginManager.h"
#include "CoreMinimal.h"
#include "Misc/Paths.h"
#include "HAL/PlatformProcess.h"
#include "Containers/Ticker.h"
#include "rebocap_trace.h"
#include "RebocapLivelinkBluePrintManager.h"

void Frebocap_runtimeModule::StartupModule()
{
    FString BaseDir;
    TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("rebocap"));
    if (Plugin.IsValid())
    {
        BaseDir = Plugin->GetBaseDir();
    }
    else
    {
        BaseDir = FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("rebocap"));
    }

    FString LibraryPath;
#if PLATFORM_WINDOWS
    TArray<FString> CandidatePaths;

    // 1. Standalone game binary directory (supports Development and Shipping packages)
    FString AppBaseDir = FPlatformProcess::BaseDir();
    if (!AppBaseDir.IsEmpty())
    {
        CandidatePaths.Add(FPaths::Combine(*AppBaseDir, TEXT("rebocap_ws_sdk.dll")));
        CandidatePaths.Add(FPaths::Combine(*AppBaseDir, TEXT("rebocap/Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll")));
        CandidatePaths.Add(FPaths::Combine(*AppBaseDir, TEXT("../Plugins/rebocap/Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll")));
        CandidatePaths.Add(FPaths::Combine(*AppBaseDir, TEXT("../../Plugins/rebocap/Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll")));
    }

    // 2. Plugin install base directory (editor and development projects)
    if (!BaseDir.IsEmpty())
    {
        CandidatePaths.Add(FPaths::Combine(*BaseDir, TEXT("Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll")));
        CandidatePaths.Add(FPaths::Combine(*BaseDir, TEXT("x64/Release/rebocap_ws_sdk.dll")));
        CandidatePaths.Add(FPaths::Combine(*BaseDir, TEXT("Binaries/Win64/rebocap_ws_sdk.dll")));
        CandidatePaths.Add(FPaths::Combine(*BaseDir, TEXT("rebocap_ws_sdk.dll")));
    }

    // 3. Standard project and engine plugin directories
    CandidatePaths.Add(FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("rebocap/Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll")));
    CandidatePaths.Add(FPaths::Combine(FPaths::ProjectPluginsDir(), TEXT("rebocap/x64/Release/rebocap_ws_sdk.dll")));
    CandidatePaths.Add(FPaths::Combine(FPaths::ProjectDir(), TEXT("Binaries/Win64/rebocap_ws_sdk.dll")));
    CandidatePaths.Add(FPaths::Combine(FPaths::EnginePluginsDir(), TEXT("Marketplace/rebocap/Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll")));

    for (const FString& Path : CandidatePaths)
    {
        if (FPaths::FileExists(Path))
        {
            LibraryPath = Path;
            FPlatformProcess::AddDllDirectory(*FPaths::GetPath(Path));
            break;
        }
    }
#elif PLATFORM_MAC
    LibraryPath = FPaths::Combine(*BaseDir, TEXT("Source/ThirdParty/testPulginLibrary/Mac/Release/libExampleLibrary.dylib"));
#elif PLATFORM_LINUX
    LibraryPath = FPaths::Combine(*BaseDir, TEXT("Binaries/ThirdParty/testPulginLibrary/Linux/x86_64-unknown-linux-gnu/libExampleLibrary.so"));
#endif 

    rebocap_ws_sdk_handle_ = !LibraryPath.IsEmpty() ? FPlatformProcess::GetDllHandle(*LibraryPath) : nullptr;
    
    if (!rebocap_ws_sdk_handle_)
    {
        // One warning instead of an Error banner: the editor still works without the SDK, and a red
        // error block on startup made healthy installs look broken.
        UE_LOG(LogTemp, Warning,
               TEXT("[Rebocap] Mocap SDK not loaded (rebocap_ws_sdk.dll). Missing Microsoft Visual C++ runtime (vc_redist.x64) is the usual cause; ")
               TEXT("install it to enable mocap: https://aka.ms/vs/17/release/vc_redist.x64.exe"));
    }
    else
    {
        UE_LOG(LogTemp, Log, TEXT("[Rebocap] Rebocap SDK DLL loaded successfully from %s"), *LibraryPath);
    }
}

void Frebocap_runtimeModule::ShutdownModule()
{
    // Critical order: destroy all SDK instances before freeing the DLL handle, so no unloaded DLL code is called on exit
    if (FRebocapSource::GetInstance().IsValid())
    {
        FRebocapSource::GetInstance()->ManualStop();
        FRebocapSource::SetInstance(nullptr);
    }

    if (rebocap_ws_sdk_handle_)
    {
        FPlatformProcess::FreeDllHandle(rebocap_ws_sdk_handle_);
        rebocap_ws_sdk_handle_ = nullptr;
    }
}

IMPLEMENT_MODULE(Frebocap_runtimeModule, rebocap_runtime)