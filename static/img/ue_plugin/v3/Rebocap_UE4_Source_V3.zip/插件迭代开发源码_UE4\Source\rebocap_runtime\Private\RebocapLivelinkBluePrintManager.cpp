#include "RebocapLivelinkBluePrintManager.h"

#include "rebocap_source.h"
#include "rebocap_profiler.h"
#include "Features/IModularFeatures.h"
#include "LiveLinkClient.h"  
#include "ILiveLinkClient.h" 

bool URebocapLivelinkBluePrintManager::bIsConnected = false;

void URebocapLivelinkBluePrintManager::ConnectToRebocapLivelinkSource(int Port) {
  bIsConnected = true;
  if (!FRebocapSource::GetInstance().IsValid()) {
    UE_LOG(LogTemp, Display, TEXT("[Rebocap] Starting and creating Rebocap LiveLink source on port: %d"), Port);
    // Create a new LiveLink source
    TSharedPtr<FRebocapSource> NewSource = MakeShared<FRebocapSource>(static_cast<uint16_t>(Port));

    // Get the LiveLink client
    IModularFeatures& ModularFeatures = IModularFeatures::Get();
    if (ModularFeatures.IsModularFeatureAvailable(ILiveLinkClient::ModularFeatureName)) {
      ILiveLinkClient* LiveLinkClient = &ModularFeatures.GetModularFeature<ILiveLinkClient>(ILiveLinkClient::ModularFeatureName);

      if (LiveLinkClient) {
        // Add the source to the LiveLink client
        FRebocapSource::SetInstance(NewSource);
        LiveLinkClient->AddSource(NewSource);
      }
    }
  } else {
    FRebocapSource::SetConfiguredPort(static_cast<uint16_t>(Port));
    FRebocapSource::GetInstance()->ManualStart(static_cast<uint16_t>(Port));
  }
}

void URebocapLivelinkBluePrintManager::DisconnectToRebocapLivelinkSource() {
  bIsConnected = false;
  UE_LOG(LogTemp, Display, TEXT("[Rebocap] Disconnecting Rebocap LiveLink source..."));
  if (FRebocapSource::GetInstance().IsValid()) {
    FRebocapSource::GetInstance()->ManualStop(/*bUserInitiated=*/true);
  }
}

bool URebocapLivelinkBluePrintManager::IsConnectedToRebocap() {
  auto Source = FRebocapSource::GetInstance();
  if (Source.IsValid()) {
    return Source->IsPortOpen();
  }
  return false;
}

float URebocapLivelinkBluePrintManager::GetMocapFrameRate() {
  auto Source = FRebocapSource::GetInstance();
  if (Source.IsValid()) {
    return Source->GetMocapHz();
  }
  return 0.0f;
}

void URebocapLivelinkBluePrintManager::StartDiagnosticRecording(float DurationSeconds) {
  FRebocapProfiler::Get().StartRecording(DurationSeconds);
}

bool URebocapLivelinkBluePrintManager::IsDiagnosticRecording() {
  return FRebocapProfiler::Get().IsRecording();
}
