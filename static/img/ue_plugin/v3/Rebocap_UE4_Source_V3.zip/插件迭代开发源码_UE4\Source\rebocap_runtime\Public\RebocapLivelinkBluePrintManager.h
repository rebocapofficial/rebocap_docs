#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Features/IModularFeatures.h"
#include "RebocapLivelinkBluePrintManager.generated.h"

UCLASS()
class REBOCAP_RUNTIME_API URebocapLivelinkBluePrintManager : public UBlueprintFunctionLibrary {
  GENERATED_BODY()
public:
  /** 
   * Manually starts the Rebocap Live Link connection (useful in packaged games or for custom in-game UI control).
   * @param Port Local websocket port the Rebocap service listens on (default 7690).
   */
  UFUNCTION(BlueprintCallable, Category = "Rebocap|LiveLink", meta = (DisplayName = "Connect Rebocap LiveLink", ToolTip = "Manually start the Rebocap Live Link mocap connection."))
  static void ConnectToRebocapLivelinkSource(int Port = 7690);

  /** 
   * Manually disconnects the current Rebocap Live Link connection and releases its resources.
   */
  UFUNCTION(BlueprintCallable, Category = "Rebocap|LiveLink", meta = (DisplayName = "Disconnect Rebocap LiveLink", ToolTip = "Manually disconnect the Rebocap Live Link connection and release resources."))
  static void DisconnectToRebocapLivelinkSource();

  /** 
   * Queries whether the Rebocap Live Link connection is actively receiving data.
   */
  UFUNCTION(BlueprintPure, Category = "Rebocap|LiveLink", meta = (DisplayName = "Is Rebocap Connected", ToolTip = "Returns true while the Rebocap Live Link connection is actively receiving."))
  static bool IsConnectedToRebocap();

  /** 
   * Gets the actual receive rate (Hz) of the current Rebocap mocap stream.
   */
  UFUNCTION(BlueprintPure, Category = "Rebocap|Diagnostics", meta = (DisplayName = "Get Rebocap Mocap Frame Rate (Hz)", ToolTip = "Gets the actual receive rate (Hz) of the current Rebocap mocap stream."))
  static float GetMocapFrameRate();

  /** 
   * Starts a 10 second (or custom length) performance and diagnostics black-box recording.
   * A report is written under Saved/Logs when it finishes and its folder is opened automatically.
   * @param DurationSeconds Recording length in seconds (default 10.0).
   */
  UFUNCTION(BlueprintCallable, Category = "Rebocap|Diagnostics", meta = (DisplayName = "Start Rebocap Diagnostic Recording", ToolTip = "Start a diagnostic recording; a report is exported and opened automatically when it finishes."))
  static void StartDiagnosticRecording(float DurationSeconds = 10.0f);

  /** 
   * Queries whether a diagnostic recording is currently running.
   */
  UFUNCTION(BlueprintPure, Category = "Rebocap|Diagnostics", meta = (DisplayName = "Is Rebocap Diagnostic Recording", ToolTip = "Returns true while a diagnostic recording is running."))
  static bool IsDiagnosticRecording();

private:
  static bool bIsConnected;
};
