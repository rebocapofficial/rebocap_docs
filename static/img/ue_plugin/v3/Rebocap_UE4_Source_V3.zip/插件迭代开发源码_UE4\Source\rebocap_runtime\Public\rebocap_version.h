// Copyright Rebocap. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Interfaces/IPluginManager.h"

/**
 * Single source of truth for the plugin version.
 *
 * The version lives in `rebocap.uplugin` (`VersionName` / `Version`) and is read from the plugin
 * descriptor at runtime, so bumping the plugin only requires editing that one file. Everything that
 * displays a version (control panel badge, diagnostic report, tools) goes through this helper
 * instead of hardcoding a string.
 */
namespace RebocapVersion
{
	/** Shown when the plugin descriptor cannot be resolved (should not happen in normal builds). */
	inline const TCHAR* GetFallbackVersionName()
	{
		return TEXT("V3");
	}

	inline TSharedPtr<IPlugin> GetSelfPlugin()
	{
		return IPluginManager::Get().FindPlugin(TEXT("rebocap"));
	}

	/** Marketing version, e.g. "V3". */
	inline FString GetVersionName()
	{
		if (const TSharedPtr<IPlugin> Plugin = GetSelfPlugin())
		{
			const FString& Name = Plugin->GetDescriptor().VersionName;
			if (!Name.IsEmpty())
			{
				return Name;
			}
		}
		return GetFallbackVersionName();
	}

	/** Integer build number from the descriptor (0 when unavailable). */
	inline int32 GetBuildNumber()
	{
		if (const TSharedPtr<IPlugin> Plugin = GetSelfPlugin())
		{
			return Plugin->GetDescriptor().Version;
		}
		return 0;
	}

	/** "V3 (Build 32)" — for reports and logs. */
	inline FString GetFullVersion()
	{
		const int32 Build = GetBuildNumber();
		return Build > 0
			? FString::Printf(TEXT("%s (Build %d)"), *GetVersionName(), Build)
			: GetVersionName();
	}
}
