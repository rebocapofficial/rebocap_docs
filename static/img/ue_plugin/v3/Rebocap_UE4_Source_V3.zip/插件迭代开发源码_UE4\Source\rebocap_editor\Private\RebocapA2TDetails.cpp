#include "RebocapA2TDetails.h"
#include "RebocapEditorStyleCompat.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"
#include "DetailWidgetRow.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "AnimGraphNode_RebocapA2T.h"

#define LOCTEXT_NAMESPACE "RebocapA2TDetails"

void FRebocapA2TDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
    TArray<TWeakObjectPtr<UObject>> ObjectsBeingCustomized;
    DetailBuilder.GetObjectsBeingCustomized(ObjectsBeingCustomized);

    IDetailCategoryBuilder& PresetCategory = DetailBuilder.EditCategory(
        "0. Presets & Control",
        LOCTEXT("A2TPresetCategoryName", "0. Presets & Control"),
        ECategoryPriority::Important
    );

    // Add the action button row: Export JSON, Import JSON
    PresetCategory.AddCustomRow(LOCTEXT("A2TPresetActionsFilter", "Preset Actions Export Import JSON A2T"))
    .WholeRowContent()
    [
        SNew(SHorizontalBox)
        + SHorizontalBox::Slot()
        .AutoWidth()
        .Padding(0.0f, 4.0f, 4.0f, 4.0f)
        [
            SNew(SButton)
            .ButtonStyle(REBOCAP_STYLE::Get(), "Button")
            .ContentPadding(FMargin(10.0f, 4.0f))
            .ToolTipText(LOCTEXT("ExportA2TJsonTooltip", "Export current A2T calibration angles and bone mappings to JSON."))
            .OnClicked_Lambda([ObjectsBeingCustomized]() -> FReply {
                for (auto& WeakObj : ObjectsBeingCustomized)
                {
                    if (UAnimGraphNode_RebocapA2T* A2TNode = Cast<UAnimGraphNode_RebocapA2T>(WeakObj.Get()))
                    {
                        A2TNode->ExportToJson();
                        break;
                    }
                }
                return FReply::Handled();
            })
            [
                SNew(STextBlock)
                .Text(LOCTEXT("ExportA2TJsonButton", "📤 Export to JSON"))
                .Font(REBOCAP_STYLE::GetFontStyle(TEXT("NormalFontBold")))
            ]
        ]
        + SHorizontalBox::Slot()
        .AutoWidth()
        .Padding(4.0f, 4.0f, 0.0f, 4.0f)
        [
            SNew(SButton)
            .ButtonStyle(REBOCAP_STYLE::Get(), "Button")
            .ContentPadding(FMargin(10.0f, 4.0f))
            .ToolTipText(LOCTEXT("ImportA2TJsonTooltip", "Import an A2T calibration JSON to auto-fill limb angles and bone mappings."))
            .OnClicked_Lambda([ObjectsBeingCustomized, &DetailBuilder]() -> FReply {
                for (auto& WeakObj : ObjectsBeingCustomized)
                {
                    if (UAnimGraphNode_RebocapA2T* A2TNode = Cast<UAnimGraphNode_RebocapA2T>(WeakObj.Get()))
                    {
                        A2TNode->ImportFromJson();
                    }
                }
                DetailBuilder.ForceRefreshDetails();
                return FReply::Handled();
            })
            [
                SNew(STextBlock)
                .Text(LOCTEXT("ImportA2TJsonButton", "📥 Import from JSON"))
                .Font(REBOCAP_STYLE::GetFontStyle(TEXT("NormalFontBold")))
            ]
        ]
        + SHorizontalBox::Slot()
        .AutoWidth()
        .Padding(4.0f, 4.0f, 0.0f, 4.0f)
        [
            SNew(SButton)
            .ButtonStyle(REBOCAP_STYLE::Get(), "Button")
            .ContentPadding(FMargin(10.0f, 4.0f))
            .ToolTipText(LOCTEXT("ApplyRetargetTooltip", "Resolve the 20 bone names through the selected Retarget Asset."))
            .IsEnabled_Lambda([ObjectsBeingCustomized]() -> bool {
                for (auto& WeakObj : ObjectsBeingCustomized)
                {
                    if (UAnimGraphNode_RebocapA2T* A2TNode = Cast<UAnimGraphNode_RebocapA2T>(WeakObj.Get()))
                    {
                        return A2TNode->Node.HasRetargetAsset();
                    }
                }
                return false;
            })
            .OnClicked_Lambda([ObjectsBeingCustomized, &DetailBuilder]() -> FReply {
                for (auto& WeakObj : ObjectsBeingCustomized)
                {
                    if (UAnimGraphNode_RebocapA2T* A2TNode = Cast<UAnimGraphNode_RebocapA2T>(WeakObj.Get()))
                    {
                        A2TNode->Node.ApplyRetargetAssetBones();
                    }
                }
                DetailBuilder.ForceRefreshDetails();
                return FReply::Handled();
            })
            [
                SNew(STextBlock)
                .Text(LOCTEXT("ApplyRetargetButton", "🗺 Fill Bone Names"))
                .Font(REBOCAP_STYLE::GetFontStyle(TEXT("NormalFontBold")))
            ]
        ]
    ];
}

#undef LOCTEXT_NAMESPACE
