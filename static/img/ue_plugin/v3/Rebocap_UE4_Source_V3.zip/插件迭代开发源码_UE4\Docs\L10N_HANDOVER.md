# Localization & Handover Notes

This document describes how text works in the Rebocap Unreal Engine plugin. It is the
reference for anyone picking the codebase up: **English is the product language; every other
culture is a text skin on top of it.**

---

## 1. The model

* Every user-facing string in the source code is **English** (`LOCTEXT` / `NSLOCTEXT` source
  argument, `meta = (DisplayName = "...", ToolTip = "...")`).
* Simplified Chinese and Japanese ship as **translation data only**. No `#if` branches, no
  per-language assets, no duplicate graphs.
* One package contains **all** cultures. The engine picks the skin from the editor/game
  culture; a missing entry silently falls back to the English source string.
* Adding a language therefore means adding one folder under
  `Content/Localization/rebocap/<culture>/` — not shipping a second build.

---

## 2. What is localized, what stays English

| Surface | Language | Reason |
| --- | --- | --- |
| **Pin labels** on anim graph nodes | English only | `UEdGraphPin` labels come from `GetPinMetaData`, which returns a raw `FString` and never consults the localization tables. Not fixable from plugin code. |
| **Node titles** (`Rebocap Body Pose`, `Rebocap A-Pose to T-Pose`) | English only | Tutorials tell users to type English keywords; titles are returned as `FText::FromString` so the graph title widget can never cache a translated variant. |
| **Type display names** (structs, classes, anim graph nodes, enums) in the variable type picker | English only | Same reason: searchable names must match the tutorials. Their `UObjectDisplayNames` translations are deliberately left empty. |
| **Details panel property labels** | English first line + localized second line | See §5. Pin labels still use the raw English metadata, so pins stay single-line. |
| **Property and node tooltips**, pin description block | Localized | Explanations, not searchable identifiers. |
| **Control panel, dialogs, logs** | Localized | |
| **Source code, comments, identifiers, commit messages** | English | Handover. |
| **MMD bone name literals** (e.g. `センター`, `上半身`) | Japanese, verbatim | They must match the MMD preset byte-for-byte. Translating them breaks MMD retargeting. |

Rule of thumb: **things users type to find something stay English; things users read are
localized.**

---

## 3. Files and cultures

```
Config/Localization/rebocap.ini                      gather/compile pipeline (8 steps)
Localization/rebocap/rebocap.manifest                source manifest (regenerated)
Localization/rebocap/en/rebocap.po                   source culture (msgstr == msgid)
Localization/rebocap/zh-Hans/rebocap.po              translation skin
Localization/rebocap/zh-Hans/rebocap.archive         intermediate, merge target for imports
Content/Localization/rebocap/rebocap.locmeta         target metadata (kept in Content)
Content/Localization/rebocap/zh-Hans/rebocap.locres  compiled resource loaded at runtime
```

Only `.locres` / `.locmeta` live under `Content`; everything the pipeline needs but the game does
not ship with (`.manifest`, `.po`, `.archive`) is kept in `Localization/rebocap` so it never ends up
inside the packaged plugin content. `GatherTextStep7` writes the compiled `.locres` back into
`Content/Localization/rebocap`.

Supported cultures: `en`, `zh-Hans`, `ja`. The engine maps `zh-CN` / `zh-Hant` onto
`zh-Hans` and `ja-JP` onto `ja`; anything else falls back to English.

---

## 4. Adding or changing a string

1. **Write the source in English**, e.g.

   ```cpp
   LOCTEXT("RebocapPoseNodeTitle", "Rebocap Body Pose")
   NSLOCTEXT("RebocapNodeTooltip", "PinLegendHeader", "Pins:")
   UPROPERTY(meta = (DisplayName = "Enable Frame Interpolation",
                     ToolTip = "Smoothly interpolates mocap data ..."))
   ```

2. **Regenerate the manifest and `.po` files** (editor must be closed; relative paths in
   `rebocap.ini` resolve against the *project* directory). Manifest/`.po`/`.archive` are written to
   `Localization/rebocap`, the compiled `.locres` to `Content/Localization/rebocap`:

   ```
   UnrealEditor-Cmd.exe <Project>.uproject -run=GatherText -config="Config/Localization/rebocap.ini" -unattended -nosplash -nop4
   ```

3. **Fill `msgstr`** in `zh-Hans/rebocap.po` and `ja/rebocap.po`. Leave a `msgstr` empty to
   keep the English fallback.

4. **Run the same command again.** Its later steps import the `.po` files into the
   `.archive`, export back, and compile `*.locres`.

> Ordering matters: the import step only runs after the archive step. If you delete the
> `.archive` files *and* leave the `.po` empty, the translations are gone — fill the `.po`
> first, then gather.

Useful checks:

```powershell
# translations present?
Select-String -Path Localization\rebocap\zh-Hans\rebocap.po -Pattern '^msgstr "..+'
# all three cultures compiled and different?
Get-ChildItem -Recurse Content\Localization\rebocap -Filter *.locres | Select Name, Length
```

---

## 5. Bilingual Details labels

Details panel labels are the one place where English and the translation are shown together,
because tutorials reference the English name while users read the localized one.

The rule is applied **in the translation value only** — no code changes:

```po
msgid "Enable Frame Interpolation"
msgstr "Enable Frame Interpolation\n启用帧插值"
```

Constraints:

* Only applies to `UObjectDisplayNames` entries **with a field part**
  (`UObjectDisplayNames,<Type>:<Property>`).
* Type entries (`UObjectDisplayNames,<Type>` — no colon) stay **empty** so the type picker
  shows the English name.
* Pin labels read the raw metadata, so they remain single-line English.
* Long Chinese lines can wrap inside a narrow Details column; drag the column divider to widen
  it, or shorten the translation.

---

## 6. Known engine quirks (and what the plugin does about them)

1. **Pin hover tooltips can be blank.** `SGraphPin::GetTooltipText()` returns an empty `FText`
   while `bGraphDataInvalid` is set, and in that state `GetPinHoverText()` is never called
   (verified with in-function logging across 85 hover positions). Since the flag is private,
   the plugin appends a generated **pin description block** to the *node* tooltip instead
   (`RebocapBuildPinDescriptionSection`). The block only lists visible pins that belong to the
   plugin's own struct and skips anim-node plumbing (`BasePose`, `Component Pose`, `Alpha`,
   `LODThreshold`, ...).
2. **Node titles do not re-localize.** `SNodeTitle` caches its text and only rebuilds when the
   node's title cache is marked dirty, so a translated `FText` can keep rendering the old
   string. Titles are returned as `FText::FromString` of an English literal, which also
   removes the problem for good.
3. **Pin data is compiled, not live.** Pin labels/tooltips are baked into the pin when the Anim
   Blueprint is compiled. After changing `DisplayName` / `ToolTip` metadata, recompile the
   Blueprint — `URebocapA2TEditorLibrary.RebuildRebocapPinData()` does it in bulk, and
   `DumpRebocapPinTooltips()` / `DumpRebocapNodeTooltips()` report what is actually stored.

---

## 7. Pre-release checklist

- [ ] No CJK left in source comments or user-facing strings (MMD literals excepted).
- [ ] `gather` → fill `.po` → `gather` completed with exit code 0.
- [ ] `en` / `zh-Hans` / `ja` `.locres` differ in size (i.e. translations actually landed).
- [ ] Spot check in the editor: node titles and pin labels English, Details labels bilingual,
      tooltips and control panel localized.
- [ ] `URebocapA2TEditorLibrary.GetLocalizedTextProbe()` resolves the expected strings.
