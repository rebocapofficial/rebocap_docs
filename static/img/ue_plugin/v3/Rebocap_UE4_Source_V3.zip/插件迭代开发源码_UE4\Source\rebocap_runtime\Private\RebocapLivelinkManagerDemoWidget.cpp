﻿#include "RebocapLivelinkManagerDemoWidget.h"
#include "SlateOptMacros.h"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SRebocapLivelinkManagerDemoWidget::Construct(const FArguments& InArgs)
{
    // [Source V2 - blueprint-only control]
    // All UI logic has been removed; left empty to keep the build error-free.
    // The animation blueprint now drives all functionality.
    
    ChildSlot
    [
        SNullWidget::NullWidget
    ];
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION