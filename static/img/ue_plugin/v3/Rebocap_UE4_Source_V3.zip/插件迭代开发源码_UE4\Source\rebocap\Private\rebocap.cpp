// Copyright Epic Games, Inc. All Rights Reserved.

#include "rebocap.h"
#include "rebocap_version.h"
#include "LevelEditor.h"
#include "ToolMenus.h"
#include "rebocapCommands.h"
#include "rebocapStyle.h"
#include "rebocap_source.h"
#include "rebocap_runtime.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "Widgets/Input/SButton.h"
#include "Containers/Ticker.h"
#include "Editor.h"
#include "PlayInEditorDataTypes.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "Animation/SkeletalMeshActor.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "rebocap_trace.h"
#include "RebocapLivelinkBluePrintManager.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Text/STextBlock.h"
#include "Interfaces/IPluginManager.h"
#include "Features/IModularFeatures.h"
#include "ILiveLinkClient.h"
#include "Framework/Application/SlateApplication.h"
#include "HAL/PlatformProcess.h"
#include "Misc/Paths.h"
#include "rebocap_profiler.h"
#include "Styling/CoreStyle.h"
#include "Runtime/Launch/Resources/Version.h"

#if ENGINE_MAJOR_VERSION >= 5
#include "Styling/AppStyle.h"
#define REBOCAP_STYLE_GET() FAppStyle::Get()
#else
#include "EditorStyleSet.h"
#define REBOCAP_STYLE_GET() FEditorStyle::Get()
#endif

static const FName rebocapTabName("rebocap");

#define LOCTEXT_NAMESPACE "FrebocapModule"


// --- temporary self-test driver (editor only): opens the test AnimBP, then exercises the
// connect / disconnect / bad-port paths on a fixed timeline so the trace log can be diffed. ---
namespace RebocapSelfTest
{
    // Timeline (seconds after startup):
    //   8  load level + spawn a mannequin driven by the Rebocap AnimBP
    //   15 start PIE   (continuous evaluation, unlike the idle Persona preview)
    //   35 disconnect
    //   50 connect 7690
    //   65 connect 7777 (unreachable -> fallback path)
    //   85 connect 7690 (restore)
    static void Start()
    {
        static double StartTime = FPlatformTime::Seconds();
        static int32 Stage = 0;
        UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f ui_driver_start"), RebocapTrace::Now());

        FTickerDelegate Delegate = FTickerDelegate::CreateLambda([](float) -> bool
        {
            const double Elapsed = FPlatformTime::Seconds() - StartTime;

            if (Stage == 0 && Elapsed > 8.0)
            {
                Stage = 1;
                if (!GEditor) { return true; }

                // No map load here: Exec("OPEN ...") inside a core ticker trips an engine assert.
                // PIE duplicates whatever level is already open, so spawning into it is enough.
                UWorld* World = GEditor->GetEditorWorldContext().World();
                USkeletalMesh* Mesh = LoadObject<USkeletalMesh>(nullptr, TEXT("/Game/Characters/Mannequins/Meshes/SKM_Manny_Simple.SKM_Manny_Simple"));
                UClass* AnimClass = LoadObject<UClass>(nullptr, TEXT("/Game/新建文件夹/SK_Mannequin_AnimBlueprint.SK_Mannequin_AnimBlueprint_C"));
                ASkeletalMeshActor* Actor = nullptr;
                if (World && Mesh && AnimClass)
                {
                    FActorSpawnParameters SpawnParams;
                    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
                    Actor = World->SpawnActor<ASkeletalMeshActor>(FVector(0.0f, 0.0f, 120.0f), FRotator::ZeroRotator, SpawnParams);
                    if (Actor && Actor->GetSkeletalMeshComponent())
                    {
                        Actor->GetSkeletalMeshComponent()->SetSkeletalMesh(Mesh);
                        Actor->GetSkeletalMeshComponent()->SetAnimInstanceClass(AnimClass);
                    }
                }
                UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f action=spawn_actor world=%d mesh=%d anim=%d actor=%d"),
                       RebocapTrace::Now(), World ? 1 : 0, Mesh ? 1 : 0, AnimClass ? 1 : 0, Actor ? 1 : 0);
            }
            else if (Stage == 1 && Elapsed > 15.0)
            {
                Stage = 2;
                if (GEditor)
                {
#if ENGINE_MAJOR_VERSION >= 5
                    FRequestPlaySessionParams Params;
                    GEditor->RequestPlaySession(Params);
#else
                    GEditor->RequestPlaySession(false, nullptr, false);
#endif
                    GEditor->StartQueuedPlaySessionRequest();
                    UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f action=start_pie"), RebocapTrace::Now());
                }
            }
            else if (Stage == 2 && Elapsed > 35.0)
            {
                Stage = 3;
                UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f action=disconnect"), RebocapTrace::Now());
                URebocapLivelinkBluePrintManager::DisconnectToRebocapLivelinkSource();
            }
            else if (Stage == 3 && Elapsed > 50.0)
            {
                Stage = 4;
                UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f action=connect_7690"), RebocapTrace::Now());
                URebocapLivelinkBluePrintManager::ConnectToRebocapLivelinkSource(7690);
            }
            else if (Stage == 4 && Elapsed > 65.0)
            {
                Stage = 5;
                UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f action=connect_7777_badport"), RebocapTrace::Now());
                URebocapLivelinkBluePrintManager::ConnectToRebocapLivelinkSource(7777);
            }
            else if (Stage == 5 && Elapsed > 85.0)
            {
                Stage = 6;
                UE_LOG(LogTemp, Warning, TEXT("[RTrace] t=%.3f action=connect_7690_restore"), RebocapTrace::Now());
                URebocapLivelinkBluePrintManager::ConnectToRebocapLivelinkSource(7690);
            }
            return true;
        });

#if ENGINE_MAJOR_VERSION >= 5
        FTSTicker::GetCoreTicker().AddTicker(Delegate, 0.5f);
#else
        FTicker::GetCoreTicker().AddTicker(Delegate, 0.5f);
#endif
    }
}

void FrebocapModule::StartupModule()
{
	FrebocapStyle::Initialize();
	FrebocapStyle::ReloadTextures();

	FrebocapCommands::Register();
	
	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FrebocapCommands::Get().OpenPluginWindow,
		FExecuteAction::CreateRaw(this, &FrebocapModule::PluginButtonClicked),
		FCanExecuteAction());

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FrebocapModule::RegisterMenus));
	
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(rebocapTabName, FOnSpawnTab::CreateRaw(this, &FrebocapModule::OnSpawnPluginTab))
		.SetDisplayName(LOCTEXT("FrebocapTabTitle", "Rebocap Control Panel"))
		.SetMenuType(ETabSpawnerMenuType::Hidden);

	TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("rebocap"));
	if (Plugin.IsValid())
	{
		FString BaseDir = Plugin->GetBaseDir();
		FString LibraryPath = FPaths::Combine(*BaseDir, TEXT("Binaries/ThirdParty/RebocapWsSdk/Win64/rebocap_ws_sdk.dll"));
		if (FPaths::FileExists(LibraryPath))
		{
			rebocap_ws_sdk_handle_ = FPlatformProcess::GetDllHandle(*LibraryPath);
		}
	}

    if (RebocapTest::Enabled())
    {
        RebocapSelfTest::Start();
    }
}

void FrebocapModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);
	FrebocapStyle::Shutdown();
	FrebocapCommands::Unregister();
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(rebocapTabName);

	if (rebocap_ws_sdk_handle_)
	{
		FPlatformProcess::FreeDllHandle(rebocap_ws_sdk_handle_);
		rebocap_ws_sdk_handle_ = nullptr;
	}
}

TSharedRef<SDockTab> FrebocapModule::OnSpawnPluginTab(const FSpawnTabArgs& SpawnTabArgs)
{
	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SBorder)
			.BorderImage(REBOCAP_STYLE_GET().GetBrush("ToolPanel.GroupBorder"))
			.Padding(12.0f)
			[
				SNew(SVerticalBox)

				// 1. Top header (title and version)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 0.0f, 0.0f, 10.0f)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("RebocapTitle", "Rebocap Mocap Control Center"))
						.Font(FCoreStyle::GetDefaultFontStyle("Bold", 14))
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.Padding(8.0f, 0.0f, 0.0f, 0.0f)
					.VAlign(VAlign_Center)
					[
						SNew(SBorder)
						.BorderImage(REBOCAP_STYLE_GET().GetBrush("ToolPanel.DarkGroupBorder"))
						.BorderBackgroundColor(FLinearColor(0.08f, 0.25f, 0.45f, 1.0f))
						.Padding(FMargin(6.0f, 2.0f))
						[
							SNew(STextBlock)
							.Text_Lambda([]() {
								// Version comes from rebocap.uplugin via the shared helper (no hardcoded string).
								return FText::FromString(RebocapVersion::GetVersionName());
							})
							.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9))
							.ColorAndOpacity(FLinearColor(0.35f, 0.9f, 1.0f))
						]
					]
				]

				// If the SDK fails to load, show a prominent one-click fix banner
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 0.0f, 0.0f, 8.0f)
				[
					SNew(SBorder)
					.Visibility_Lambda([]() {
						bool bLoaded = false;
						if (FModuleManager::Get().IsModuleLoaded("rebocap_runtime"))
						{
							bLoaded = Frebocap_runtimeModule::Get().IsSdkLoaded();
						}
						return bLoaded ? EVisibility::Collapsed : EVisibility::Visible;
					})
					.BorderBackgroundColor(FLinearColor(0.8f, 0.2f, 0.2f, 1.0f))
					.Padding(8.0f)
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Center)
						.Padding(0.0f, 0.0f, 8.0f, 0.0f)
						[
							SNew(STextBlock)
							.Text(LOCTEXT("MissingVcRedist", "⚠️ Microsoft VC++ Runtime is missing - the mocap backend cannot be loaded!"))
							.ColorAndOpacity(FLinearColor::Yellow)
						]
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Center)
						[
							SNew(SButton)
							.Text(LOCTEXT("DownloadVcRedist", "Download Microsoft VC++ Runtime (vc_redist.x64)"))
							.OnClicked_Lambda([]() {
								FPlatformProcess::LaunchURL(TEXT("https://aka.ms/vs/17/release/vc_redist.x64.exe"), nullptr, nullptr);
								return FReply::Handled();
							})
						]
					]
				]

				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 0.0f, 0.0f, 8.0f)
				[
					SNew(SSeparator)
				]

				// 2. Connection and port settings
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 4.0f)
				[
					SNew(SHorizontalBox)
					// Port
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 6.0f, 0.0f)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("PortLabel", "Port:"))
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 12.0f, 0.0f)
					[
						SNew(SNumericEntryBox<uint16>)
						.IsEnabled(true)
						.AllowSpin(true)
						.MinSliderValue(1000)
						.MaxSliderValue(65535)
						.MinDesiredValueWidth(70)
						.Value_Raw(this, &FrebocapModule::GetPortValue)
						.OnValueChanged_Raw(this, &FrebocapModule::OnPortChanged)
					]
					// Connect button
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 8.0f, 0.0f)
					[
						SNew(SButton)
						.OnClicked_Raw(this, &FrebocapModule::OnConnectButtonClicked)
						.ContentPadding(FMargin(12.0f, 4.0f))
						[
							SNew(STextBlock)
							.Text_Raw(this, &FrebocapModule::GetConnectButtonText)
						]
					]
					// Status indicator
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(8.0f, 0.0f, 0.0f, 0.0f)
					[
						SNew(STextBlock)
						.Text_Raw(this, &FrebocapModule::GetStatusText)
						.ColorAndOpacity_Raw(this, &FrebocapModule::GetStatusColor)
					]
				]

				// 3. 📊 Realtime stream and frame rate monitoring (Performance & Stream Monitor)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 6.0f, 0.0f, 6.0f)
				[
					SNew(SBorder)
					.BorderImage(REBOCAP_STYLE_GET().GetBrush("ToolPanel.DarkGroupBorder"))
					.Padding(FMargin(10.0f, 6.0f))
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot()
						.AutoHeight()
						[
							SNew(SHorizontalBox)
							// Mocap stream rate
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.VAlign(VAlign_Center)
							[
								SNew(STextBlock)
								.Text(LOCTEXT("MocapHzLabel", "Mocap rate: "))
								.ColorAndOpacity(FSlateColor(FLinearColor(0.8f, 0.8f, 0.8f)))
							]
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.VAlign(VAlign_Center)
							.Padding(0.0f, 0.0f, 16.0f, 0.0f)
							[
								SNew(STextBlock)
								.Text_Raw(this, &FrebocapModule::GetMocapHzText)
								.ColorAndOpacity_Raw(this, &FrebocapModule::GetMocapHzColor)
							]
							// Viewport render frame rate
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.VAlign(VAlign_Center)
							[
								SNew(STextBlock)
								.Text(LOCTEXT("RenderFPSLabel", "Viewport FPS: "))
								.ColorAndOpacity(FSlateColor(FLinearColor(0.8f, 0.8f, 0.8f)))
							]
							+ SHorizontalBox::Slot()
							.AutoWidth()
							.VAlign(VAlign_Center)
							[
								SNew(STextBlock)
								.Text_Raw(this, &FrebocapModule::GetViewportFPSText)
								.ColorAndOpacity(FSlateColor(FLinearColor(0.4f, 0.85f, 1.0f)))
							]
						]
						// Quick stutter troubleshooting tip
						+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0.0f, 4.0f, 0.0f, 0.0f)
						[
							SNew(STextBlock)
							.Text(LOCTEXT("StutterTip", "Tip: if the viewport stutters, make sure Realtime mode is enabled (Ctrl+R). If the motion looks slightly choppy on a high-refresh display, enable Frame Interpolation on the anim graph node."))
							.ColorAndOpacity(FSlateColor(FLinearColor(0.65f, 0.65f, 0.65f)))
							.Font(REBOCAP_STYLE_GET().GetFontStyle("NormalFont"))
						]
					]
				]

				// 4. ⚡ Thread scheduling priority
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 4.0f, 0.0f, 4.0f)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 8.0f, 0.0f)
					[
						SNew(STextBlock)
						.Text(LOCTEXT("ThreadPriorityLabel", "Thread priority:"))
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 4.0f, 0.0f)
					[
						SNew(SCheckBox)
						.Style(&REBOCAP_STYLE_GET().GetWidgetStyle<FCheckBoxStyle>("RadioButton"))
						.IsChecked_Lambda([this]() { return IsThreadPriority(TPri_Normal) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
						.OnCheckStateChanged_Lambda([this](ECheckBoxState State) { if (State == ECheckBoxState::Checked) SetThreadPriority(TPri_Normal); })
						[
							SNew(STextBlock).Text(LOCTEXT("PriNormal", "Normal"))
						]
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					.Padding(0.0f, 0.0f, 4.0f, 0.0f)
					[
						SNew(SCheckBox)
						.Style(&REBOCAP_STYLE_GET().GetWidgetStyle<FCheckBoxStyle>("RadioButton"))
						.IsChecked_Lambda([this]() { return IsThreadPriority(TPri_AboveNormal) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
						.OnCheckStateChanged_Lambda([this](ECheckBoxState State) { if (State == ECheckBoxState::Checked) SetThreadPriority(TPri_AboveNormal); })
						[
							SNew(STextBlock).Text(LOCTEXT("PriAboveNormal", "Above Normal"))
						]
					]
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.VAlign(VAlign_Center)
					[
						SNew(SCheckBox)
						.Style(&REBOCAP_STYLE_GET().GetWidgetStyle<FCheckBoxStyle>("RadioButton"))
						.IsChecked_Lambda([this]() { return IsThreadPriority(TPri_Highest) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
						.OnCheckStateChanged_Lambda([this](ECheckBoxState State) { if (State == ECheckBoxState::Checked) SetThreadPriority(TPri_Highest); })
						[
							SNew(STextBlock).Text(LOCTEXT("PriHighest", "Highest"))
						]
					]
				]

				// 5. 🛠️ Performance and runtime diagnostic capture (10s Diagnostic Blackbox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 6.0f, 0.0f, 4.0f)
				[
					SNew(SBorder)
					.BorderImage(REBOCAP_STYLE_GET().GetBrush("ToolPanel.GroupBorder"))
					.Padding(FMargin(10.0f, 6.0f))
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Center)
						.Padding(0.0f, 0.0f, 8.0f, 0.0f)
						[
							SNew(SButton)
							.OnClicked_Raw(this, &FrebocapModule::OnStartProfilerClicked)
							.ContentPadding(FMargin(12.0f, 4.0f))
							.ButtonColorAndOpacity_Raw(this, &FrebocapModule::GetProfilerButtonColor)
							[
								SNew(STextBlock)
								.Text_Raw(this, &FrebocapModule::GetProfilerButtonText)
								.Font(REBOCAP_STYLE_GET().GetFontStyle("NormalFontBold"))
							]
						]
						+ SHorizontalBox::Slot()
						.AutoWidth()
						.VAlign(VAlign_Center)
						[
							SNew(SButton)
							.OnClicked_Raw(this, &FrebocapModule::OnOpenLogsFolderClicked)
							.ContentPadding(FMargin(8.0f, 4.0f))
							[
								SNew(STextBlock)
								.Text(LOCTEXT("OpenLogDirBtn", "Open Logs Folder"))
							]
						]
					]
				]

				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 8.0f)
				[
					SNew(SSeparator)
				]

				// 4. Quick actions and entry points
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 4.0f)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.AutoWidth()
					.Padding(0.0f, 0.0f, 0.0f, 0.0f)
					[
						SNew(SButton)
						.OnClicked_Raw(this, &FrebocapModule::OnOpenLiveLinkWindowClicked)
						.ContentPadding(FMargin(8.0f, 4.0f))
						[
							SNew(STextBlock)
							.Text(LOCTEXT("OpenLiveLinkBtn", "📡 Open Live Link Window"))
						]
					]
				]

				// 5. Usage tips at the bottom
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 10.0f, 0.0f, 0.0f)
				[
					SNew(SBorder)
					.BorderImage(REBOCAP_STYLE_GET().GetBrush("ToolPanel.DarkGroupBorder"))
					.Padding(8.0f)
					[
						SNew(SVerticalBox)
						+ SVerticalBox::Slot()
						.AutoHeight()
						[
							SNew(STextBlock)
							.Text(LOCTEXT("Tip1", "💡 Quick start: add a [Rebocap Pose Node] and a [Rebocap A2T Node] to your Anim Blueprint to drive full-body mocap."))
							.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
						]
						+ SVerticalBox::Slot()
						.AutoHeight()
						.Padding(0.0f, 4.0f, 0.0f, 0.0f)
						[
							SNew(STextBlock)
							.Text(LOCTEXT("Tip2", "💡 Smoothing: if the motion looks slightly choppy on a high-refresh display, enable [Enable Frame Interpolation] on the Pose node."))
							.ColorAndOpacity(FLinearColor(0.7f, 0.7f, 0.7f))
						]
					]
				]
			]
		];
}

FReply FrebocapModule::OnConnectButtonClicked()
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid() && Source->IsPortOpen())
	{
		Source->ManualStop(/*bUserInitiated=*/true);
	}
	else
	{
		IModularFeatures& ModularFeatures = IModularFeatures::Get();
		if (ModularFeatures.IsModularFeatureAvailable(ILiveLinkClient::ModularFeatureName))
		{
			ILiveLinkClient* LiveLinkClient = &ModularFeatures.GetModularFeature<ILiveLinkClient>(ILiveLinkClient::ModularFeatureName);
			if (LiveLinkClient)
			{
				if (!Source.IsValid())
				{
					Source = MakeShared<FRebocapSource>(ConnectPort);
					FRebocapSource::SetInstance(Source);
					LiveLinkClient->AddSource(Source);
				}
				else
				{
					// Remember the port so the anim node keeps using it on reconnect instead of forcing 7690.
            FRebocapSource::SetConfiguredPort(ConnectPort);
            Source->ManualStart(ConnectPort);
				}
			}
		}
	}
	return FReply::Handled();
}

FReply FrebocapModule::OnOpenLiveLinkWindowClicked()
{
	FGlobalTabmanager::Get()->TryInvokeTab(FTabId("LiveLinkClient"));
	return FReply::Handled();
}

FText FrebocapModule::GetConnectButtonText() const
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid() && Source->IsPortOpen())
	{
		return LOCTEXT("DisconnectBtn", "Disconnect");
	}
	return LOCTEXT("ConnectBtn", "Connect");
}

FSlateColor FrebocapModule::GetStatusColor() const
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid() && Source->IsPortOpen())
	{
		return FSlateColor(FLinearColor(0.1f, 0.9f, 0.2f)); // Green
	}
	return FSlateColor(FLinearColor(0.8f, 0.4f, 0.1f)); // Orange/Gray
}

FText FrebocapModule::GetStatusText() const
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid() && Source->IsPortOpen())
	{
		return LOCTEXT("StatusConnected", "● Connected");
	}
	return LOCTEXT("StatusDisconnected", "○ Disconnected");
}

FText FrebocapModule::GetMocapHzText() const
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid() && Source->IsPortOpen())
	{
		float Hz = Source->GetMocapHz();
		return FText::FromString(FString::Printf(TEXT("%.1f Hz"), Hz));
	}
	return LOCTEXT("HzDisconnected", "0.0 Hz (disconnected)");
}

FSlateColor FrebocapModule::GetMocapHzColor() const
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid() && Source->IsPortOpen())
	{
		float Hz = Source->GetMocapHz();
		if (Hz >= 50.0f)
		{
			return FSlateColor(FLinearColor(0.1f, 0.95f, 0.2f)); // Green
		}
		else if (Hz > 0.0f)
		{
			return FSlateColor(FLinearColor(1.0f, 0.85f, 0.1f)); // Yellow
		}
		else
		{
			return FSlateColor(FLinearColor(1.0f, 0.5f, 0.1f)); // Orange
		}
	}
	return FSlateColor(FLinearColor(0.6f, 0.6f, 0.6f)); // Gray
}

FText FrebocapModule::GetViewportFPSText() const
{
	float DeltaTime = FApp::GetDeltaTime();
	float FPS = DeltaTime > 0.0f ? (1.0f / DeltaTime) : 0.0f;
	return FText::FromString(FString::Printf(TEXT("%.1f FPS"), FPS));
}

FReply FrebocapModule::OnStartProfilerClicked()
{
	if (FRebocapProfiler::Get().IsRecording())
	{
		FRebocapProfiler::Get().StopRecordingAndGenerateReport();
	}
	else
	{
		FRebocapProfiler::Get().StartRecording(10.0f);
	}
	return FReply::Handled();
}

FReply FrebocapModule::OnOpenLogsFolderClicked()
{
	FString LogDir = FPaths::ProjectSavedDir() / TEXT("Logs");
	IFileManager::Get().MakeDirectory(*LogDir, true);
	FPlatformProcess::ExploreFolder(*LogDir);
	return FReply::Handled();
}

FText FrebocapModule::GetProfilerButtonText() const
{
	if (FRebocapProfiler::Get().IsRecording())
	{
		return FText::Format(LOCTEXT("StopProfilerBtnFormat", "■ Stop and generate report ({0} s remaining)"),
			FText::AsNumber(FMath::RoundToInt(FRebocapProfiler::Get().GetRemainingTime())));
	}
	return LOCTEXT("StartProfilerBtn", "● Start 10s Diagnostic Capture");
}

FSlateColor FrebocapModule::GetProfilerButtonColor() const
{
	if (FRebocapProfiler::Get().IsRecording())
	{
		return FSlateColor(FLinearColor(0.85f, 0.15f, 0.15f));
	}
	return FSlateColor(FLinearColor(0.15f, 0.55f, 0.95f));
}

TOptional<uint16> FrebocapModule::GetPortValue() const
{
	return ConnectPort;
}

void FrebocapModule::OnPortChanged(uint16 value)
{
	ConnectPort = value;
}

void FrebocapModule::SetThreadPriority(EThreadPriority NewPriority)
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid())
	{
		Source->SetThreadPriority(NewPriority);
	}
}

bool FrebocapModule::IsThreadPriority(EThreadPriority CheckPriority) const
{
	auto Source = FRebocapSource::GetInstance();
	if (Source.IsValid())
	{
		return Source->GetThreadPriority() == CheckPriority;
	}
	return CheckPriority == TPri_Highest;
}

void FrebocapModule::PluginButtonClicked()
{
	FGlobalTabmanager::Get()->TryInvokeTab(rebocapTabName);
}

void FrebocapModule::RegisterMenus()
{
	FToolMenuOwnerScoped OwnerScoped(this);

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
		{
			FToolMenuSection& Section = Menu->FindOrAddSection("WindowLayout");
			Section.AddMenuEntryWithCommandList(FrebocapCommands::Get().OpenPluginWindow, PluginCommands);
		}
	}

	{
		UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar");
		{
			FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("Settings");
			{
				FToolMenuEntry& Entry = Section.AddEntry(FToolMenuEntry::InitToolBarButton(FrebocapCommands::Get().OpenPluginWindow));
				Entry.SetCommandList(PluginCommands);
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FrebocapModule, rebocap)