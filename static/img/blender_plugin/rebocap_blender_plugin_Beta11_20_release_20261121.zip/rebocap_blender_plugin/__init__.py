import ctypes
import importlib
import sys
import time
import traceback

# 解决 Windows 控制台默认 GBK 导致的中文乱码（将控制台代码页无缝切换为 UTF-8）
if sys.platform.startswith('win'):
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)
    except Exception:
        pass
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

import bpy
import atexit
from . import core
from . import ops
from . import ui
from .ops import history
from .ops import library_recovery
from .ui import history_panel
from .ui import puppet_canvas_hud
from .core import timer, save_context
from .core.version import VERSION, VERSION_STR

bl_info = {
    "name": "REBOCAP BLENDER PLUGIN",
    "author": "Rebocap",
    "description": "",
    "blender": (3, 6, 0),
    "version": (11, 20, 0),
    "location": "",
    "warning": "",
    "doc_url": "https://doc.rebocap.com/zh_cn/plugins/blender.html",
    "tracker_url": "https://forum.rebocap.site/latest",
    "category": "Rebocap"
}

class_list = [
    ops.RebocapConnect,
    ops.RebocapDisconnect,
    ops.RebocapStartRecord,
    ops.RebocapStopRecord,
    ops.RebocapRestorePose,
    ops.AutoMapBone,
    ops.SaveBone,
    ops.REBOCAP_OT_select_foot_contact_point,
    ops.REBOCAP_OT_place_all_foot_contact_points,
    ops.puppet_mapper.REBOCAP_OT_puppet_mapper,
    ops.puppet_mapper.REBOCAP_OT_clear_all_bone_map,
    ops.ik_tracking.REBOCAP_OT_auto_detect_config,
    ops.ik_tracking.REBOCAP_OT_read_config_data,
    ops.a2t_ops.REBOCAP_OT_export_a2t_json,
    ops.a2t_ops.REBOCAP_OT_import_a2t_json,
    ops.a2t_ops.REBOCAP_OT_reset_a2t_offsets,
    ops.ik_tracking.REBOCAP_OT_create_tracking_nodes,
    core.RebocapBones,
    ui.REBOCAP_OT_change_scene_fps,
    ui.ConnectionPanel,
    history_panel.REBOCAP_UL_history_takes,
    history_panel.REBOCAP_PT_history_panel,
    ui.fk_panel.REBOCAP_PT_fk_panel,
    puppet_canvas_hud.REBOCAP_OT_toggle_puppet_hud,
    ui.a2t_panel.REBOCAP_PT_a2t_panel,
    ui.CreateSkeletonPanel,
    ui.ik_panel.REBOCAP_PT_ik_tracking_panel,
    ui.PickBoneOperator,
    ui.REBOCAP_OT_import_bone_map,
    ui.REBOCAP_OT_export_bone_map,
    ui.REBOCAP_OT_language_changed_msg,
    history.REBOCAP_OT_apply_take,
    history.REBOCAP_OT_bake_take,
    history.REBOCAP_OT_stop_playback,
    history.REBOCAP_OT_resolve_duplicate_bone_binding,
    history.REBOCAP_OT_delete_take,
    history.REBOCAP_OT_export_take,
    history.REBOCAP_OT_import_take,
    ops.demo_character.REBOCAP_OT_toggle_demo_character,
    ops.demo_character.REBOCAP_OT_offset_demo_character,
    ui.demo_character_panel.REBOCAP_PT_demo_character_panel,
]

joints = [
    "m_avg_Pelvis", "m_avg_L_Hip", "m_avg_R_Hip", "m_avg_Spine1", "m_avg_L_Knee", "m_avg_R_Knee",
    "m_avg_Spine2", "m_avg_L_Ankle", "m_avg_R_Ankle", "m_avg_Spine3", "m_avg_L_Foot", "m_avg_R_Foot",
    "m_avg_Neck", "m_avg_L_Collar", "m_avg_R_Collar", "m_avg_Head", "m_avg_L_Shoulder", "m_avg_R_Shoulder",
    "m_avg_L_Elbow", "m_avg_R_Elbow", "m_avg_L_Wrist", "m_avg_R_Wrist", "m_avg_L_Hand", "m_avg_R_Hand",
]

pyd_module = None
done_module_release = None
register_ts = time.time()
_sdk_warning_callback = None


@bpy.app.handlers.persistent
def before_file_load(_):
    # Preserve outgoing frames before Blender can discard their scene. Keep
    # preview, live connection and recovery intent until the load succeeds.
    from .ops.rebocap_connection import stop_record, has_pending_recording
    attempted = False
    for scene in bpy.data.scenes:
        if getattr(scene, 'recording', False):
            stop_record(bpy.context, scene=scene, for_file_load=True)
            attempted = True
    if not attempted and has_pending_recording() and bpy.context.scene:
        stop_record(bpy.context, scene=bpy.context.scene, for_file_load=True)


@bpy.app.handlers.persistent
def reset_property_values(_):
    from .ops import playback_control
    playback_control.reset()
    library_recovery.reset_runtime()
    timer.reset_cache()
    from .core.control import clear_runtime_owners
    clear_runtime_owners()
    from .core.a2t_types import _preview_sessions, _preview_history, cancel_preview_warning_timers
    cancel_preview_warning_timers()
    _preview_sessions.clear()
    _preview_history.clear()
    from .ops.ik_tracking import clear_imported_cache
    clear_imported_cache()
    try:
        from .ops.rebocap_connection import force_disconnect
        force_disconnect()
    except Exception as e:
        print("Rebocap auto disconnect error: " + str(e))
        
    history.clear_runtime_cache()
    ops.rebocap_connection.restore_saved_recording_control()
    history.reset_project_recovery_epoch()
    history.preserve_project_for_linked_library_conflict()
    for scene in bpy.data.scenes:
        if hasattr(scene, 'rebocap_a2t') and scene.rebocap_a2t.preview_mode:
            scene.rebocap_a2t.preview_mode = False
        if getattr(scene, 'rebocap_tracking_refresh_pending', False):
            from .ops.ik_tracking import flush_pending_tracking_refresh
            try:
                if flush_pending_tracking_refresh(scene):
                    library_recovery.request_checkpoint(scene)
            except Exception as error:
                print(f"[Rebocap] Deferred tracking refresh failed after opening file: {error}")
        if getattr(scene, 'rebocap_playback_active', False):
            try:
                scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
            except Exception as error:
                print(f"[Rebocap] Playback could not be restored after opening file: {error}")
    try:
        bpy.context.scene.open = False
        bpy.context.scene.recording = False
    except:
        pass
    from .ops.rebocap_connection import notify_recording_after_file_load
    notify_recording_after_file_load()
    library_recovery.restore_runtime_pose_if_copy()


def _cleanup_old_pycache():
    """Auto-clean stale __pycache__ and orphan files on overwrite installation."""
    try:
        import os
        import shutil
        current_dir = os.path.dirname(os.path.abspath(__file__))
        for root, dirs, files in os.walk(current_dir, topdown=False):
            for d in dirs:
                if d == '__pycache__':
                    pycache_path = os.path.join(root, d)
                    try:
                        shutil.rmtree(pycache_path, ignore_errors=True)
                    except Exception:
                        pass
    except Exception:
        pass


@bpy.app.handlers.persistent
def auto_detect_config_on_start(_=None):
    try:
        import os
        scene = bpy.context.scene
        if hasattr(scene, 'rebocap_bone_map'):
            from .ops.ik_tracking import may_auto_detect_config, find_rebocap_config_path, read_and_sync_config
            if may_auto_detect_config(scene):
                cfg_path = find_rebocap_config_path()
                if cfg_path and os.path.exists(cfg_path):
                    if read_and_sync_config(scene, cfg_path) != 'OK':
                        print('[Rebocap] Automatic tracking-node update failed; retry with auto refresh enabled.')
    except Exception:
        pass
    return None



def register():
    global done_module_release, pyd_module, register_ts
    global _sdk_warning_callback
    print(f"start register rebocap {VERSION_STR}!")

    # 1. Clean stale pycache
    _cleanup_old_pycache()

    # 2. Check SDK loading status
    from .rebocap_api.rebocap_ws_sdk import REBOCAP_JOINT_NAMES, my_pyd_module, pyd_load_error

    if pyd_load_error:
        print("[REBOCAP WARNING] SDK load issue: " + str(pyd_load_error))
        def show_overwrite_warning():
            from .ops.utils import show_message_box
            msg = (
                "【Rebocap 插件提醒】\n"
                "检测到可能存在覆盖安装或动态库占用。\n"
                "为了确保所有新功能正常运行，请直接【重启 Blender】！"
            )
            show_message_box(msg, title="Rebocap Notice", icon='ERROR')
        _sdk_warning_callback = show_overwrite_warning
        bpy.app.timers.register(_sdk_warning_callback, first_interval=1.0)

    pyd_module = my_pyd_module
    if before_file_load not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(before_file_load)
    if reset_property_values not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(reset_property_values)
    from .ops.rebocap_connection import notify_recording_after_file_load
    if notify_recording_after_file_load not in bpy.app.handlers.load_post_fail:
        bpy.app.handlers.load_post_fail.append(notify_recording_after_file_load)
        
    try:
        ops.init_rebocap_api()
    except Exception as e:
        print(f"init_rebocap_api notice: {e}")

    for item in class_list:
        try:
            bpy.utils.register_class(item)
        except ValueError:
            # Already registered in memory, unregister and re-register
            try:
                bpy.utils.unregister_class(item)
                bpy.utils.register_class(item)
            except Exception:
                pass
        except Exception as e:
            print(f"Error registering class {item}: {e}")

    core.register_types()
    library_recovery.register()
    if hasattr(bpy.data, 'scenes'):
        history.preserve_project_for_linked_library_conflict()
    else:
        bpy.app.timers.register(history.preserve_project_for_linked_library_conflict, first_interval=0.0)
    from .core import a2t_types
    a2t_types.register_preview_runtime()
    from .core.control import register_control_runtime
    register_control_runtime()
    timer.register()
    
    if auto_detect_config_on_start not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(auto_detect_config_on_start)
    bpy.app.timers.register(auto_detect_config_on_start, first_interval=0.5)

    if history.rebocap_timeline_playback_handler not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(history.rebocap_timeline_playback_handler)

    from .core import a2t_types
    if a2t_types.maintain_preview_on_frame_change not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(a2t_types.maintain_preview_on_frame_change)
    for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        from .core.control import clear_runtime_owners
        if clear_runtime_owners not in handlers:
            handlers.append(clear_runtime_owners)
        if history.clear_runtime_cache not in handlers:
            handlers.append(history.clear_runtime_cache)
        if a2t_types.restore_preview_after_undo not in handlers:
            handlers.append(a2t_types.restore_preview_after_undo)
        if ops.rebocap_connection.clear_retarget_after_undo not in handlers:
            handlers.append(ops.rebocap_connection.clear_retarget_after_undo)
    from .ops import playback_control
    from .ops import baked_drivers
    baked_drivers.register()
    for handlers in (bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if playback_control.before_undo not in handlers:
            handlers.append(playback_control.before_undo)
        if history.synchronize_anchor_names_before_lifecycle not in handlers:
            handlers.append(history.synchronize_anchor_names_before_lifecycle)
        if ops.rebocap_connection.stop_recording_before_undo not in handlers:
            handlers.append(ops.rebocap_connection.stop_recording_before_undo)
    for handlers, callback in (
        (bpy.app.handlers.frame_change_pre, ops.rebocap_connection.synchronize_recording_before_frame),
        (bpy.app.handlers.frame_change_pre, playback_control.before_frame),
        (bpy.app.handlers.save_pre, playback_control.before_save),
        (bpy.app.handlers.save_post, playback_control.after_save),
        (bpy.app.handlers.save_post_fail, playback_control.after_save),
        (bpy.app.handlers.depsgraph_update_post, ops.rebocap_connection.restore_duplicated_recording_state),
        (bpy.app.handlers.save_pre, ops.rebocap_connection.suspend_recording_channels_for_save),
        (bpy.app.handlers.save_pre, history.synchronize_anchor_names_before_lifecycle),
        (bpy.app.handlers.save_pre, history.preserve_project_for_linked_library_conflict),
        (bpy.app.handlers.save_pre, a2t_types.prepare_preview_for_save),
        (bpy.app.handlers.save_pre, library_recovery.linked_pose.capture_for_save),
        (bpy.app.handlers.save_post, save_context.capture_recovery_save),
        (bpy.app.handlers.save_post, a2t_types.restore_preview_after_save),
        (bpy.app.handlers.save_post, history.finish_project_recovery_epoch_after_save),
        (bpy.app.handlers.save_post, ops.rebocap_connection.commit_recording_checkpoints_after_save),
        (bpy.app.handlers.save_post, ops.rebocap_connection.resume_recording_channels_after_save),
        (bpy.app.handlers.save_post_fail, a2t_types.restore_preview_after_save),
        (bpy.app.handlers.save_post_fail, ops.rebocap_connection.resume_recording_channels_after_save),
    ):
        if callback not in handlers:
            handlers.append(callback)

    done_module_release = None
    register_ts = time.time()


def cleanup():
    # Close SDK connections normally; never FreeLibrary a Python extension.
    ops.uninit_rebocap_api()


def unregister():
    from .ops import baked_drivers
    baked_drivers.unregister()
    global _sdk_warning_callback
    print("unregister rebocap!", flush=True)
    from .core.a2t_types import preview_active
    for scene in bpy.data.scenes:
        if preview_active(scene):
            scene.rebocap_a2t.preview_mode = False
    from .ops import playback_control
    playback_control.close_all()
    for scene in bpy.data.scenes:
        history.restore_playback_rotation_modes(scene)
        for obj in bpy.data.objects:
            history._release_playback_action(scene, obj)
    from .core.a2t_types import _preview_sessions, _preview_history
    _preview_sessions.clear()
    _preview_history.clear()
    timer.unregister()
    if _sdk_warning_callback and bpy.app.timers.is_registered(_sdk_warning_callback):
        bpy.app.timers.unregister(_sdk_warning_callback)
    _sdk_warning_callback = None
    if before_file_load in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(before_file_load)
    from .ops.rebocap_connection import notify_recording_after_file_load
    if notify_recording_after_file_load in bpy.app.handlers.load_post_fail:
        bpy.app.handlers.load_post_fail.remove(notify_recording_after_file_load)
    if bpy.app.timers.is_registered(auto_detect_config_on_start):
        bpy.app.timers.unregister(auto_detect_config_on_start)
    for handler in (reset_property_values, auto_detect_config_on_start):
        if handler in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(handler)
    if history.rebocap_timeline_playback_handler in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(history.rebocap_timeline_playback_handler)
    from .core import a2t_types
    if a2t_types.maintain_preview_on_frame_change in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(a2t_types.maintain_preview_on_frame_change)
    puppet_canvas_hud.REBOCAP_OT_toggle_puppet_hud.stop_hud(None, bpy.context)
    for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        from .core.control import clear_runtime_owners
        if clear_runtime_owners in handlers:
            handlers.remove(clear_runtime_owners)
        if history.clear_runtime_cache in handlers:
            handlers.remove(history.clear_runtime_cache)
        if a2t_types.restore_preview_after_undo in handlers:
            handlers.remove(a2t_types.restore_preview_after_undo)
        if ops.rebocap_connection.clear_retarget_after_undo in handlers:
            handlers.remove(ops.rebocap_connection.clear_retarget_after_undo)
    for handlers in (bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if playback_control.before_undo in handlers:
            handlers.remove(playback_control.before_undo)
        if history.synchronize_anchor_names_before_lifecycle in handlers:
            handlers.remove(history.synchronize_anchor_names_before_lifecycle)
        if ops.rebocap_connection.stop_recording_before_undo in handlers:
            handlers.remove(ops.rebocap_connection.stop_recording_before_undo)
    from .core import a2t_types
    for handlers, callback in (
        (bpy.app.handlers.frame_change_pre, ops.rebocap_connection.synchronize_recording_before_frame),
        (bpy.app.handlers.frame_change_pre, playback_control.before_frame),
        (bpy.app.handlers.save_pre, playback_control.before_save),
        (bpy.app.handlers.save_post, playback_control.after_save),
        (bpy.app.handlers.save_post_fail, playback_control.after_save),
        (bpy.app.handlers.depsgraph_update_post, ops.rebocap_connection.restore_duplicated_recording_state),
        (bpy.app.handlers.save_pre, ops.rebocap_connection.suspend_recording_channels_for_save),
        (bpy.app.handlers.save_pre, history.synchronize_anchor_names_before_lifecycle),
        (bpy.app.handlers.save_pre, history.preserve_project_for_linked_library_conflict),
        (bpy.app.handlers.save_pre, a2t_types.prepare_preview_for_save),
        (bpy.app.handlers.save_pre, library_recovery.linked_pose.capture_for_save),
        (bpy.app.handlers.save_post, save_context.capture_recovery_save),
        (bpy.app.handlers.save_post, a2t_types.restore_preview_after_save),
        (bpy.app.handlers.save_post, history.finish_project_recovery_epoch_after_save),
        (bpy.app.handlers.save_post, ops.rebocap_connection.commit_recording_checkpoints_after_save),
        (bpy.app.handlers.save_post, ops.rebocap_connection.resume_recording_channels_after_save),
        (bpy.app.handlers.save_post_fail, a2t_types.restore_preview_after_save),
        (bpy.app.handlers.save_post_fail, ops.rebocap_connection.resume_recording_channels_after_save),
    ):
        if callback in handlers:
            handlers.remove(callback)
    cleanup()
    from .core.control import unregister_control_runtime
    unregister_control_runtime()
    history.clear_runtime_cache()
    history.reset_project_recovery_epoch()
    a2t_types.unregister_preview_runtime()
    library_recovery.unregister()
    core.unregister_types()
    for item in reversed(class_list):
        if getattr(item, 'is_registered', False):
            bpy.utils.unregister_class(item)
