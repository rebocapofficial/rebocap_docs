"""Open a restored copy in its own UI process with the owning add-on version."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import rebocap_blender_plugin as addon
addon.register()
addon.reset_property_values(None)
from rebocap_blender_plugin.ops import library_recovery
library_recovery._finish_restore()
