"""Verified, immutable library checkpoints; runtime jobs never confer rig ownership."""
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import time
import uuid
import bpy
from ..core.save_context import recovery_copy, is_recovery_copy
from ..core.translation import T
from . import library_checkpoint_native as native, linked_pose

_jobs = []
_scheduled = None
_attempted = set()
_creating = False
_time_cache = {}
_verified_cache = {}
_project_epoch = 0
_deferred_restore = None
_legacy_owner_cache = None
_PROJECT_MARKER = '.ReboCap Recovery Project'


def directory():
    return Path(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'))/'Rebocap'/'LibraryCheckpoints'


def project_identity():
    marker = bpy.data.texts.get(_PROJECT_MARKER)
    if marker and not marker.library:
        value = marker.as_string().strip()
        try:
            if uuid.UUID(hex=value).hex == value:
                return value
        except ValueError:
            pass
    return ''


def _ensure_project_identity():
    value = project_identity()
    if not value:
        marker = bpy.data.texts.get(_PROJECT_MARKER)
        if marker:
            raise ValueError('Invalid recovery project identity')
        value = _owner_key() or uuid.uuid4().hex
        marker = bpy.data.texts.new(_PROJECT_MARKER)
        marker.use_fake_user = True
        marker.write(value)
    return value


def _owner_key():
    """Bind a pre-identity saved file only by proof of its exact bytes."""
    global _legacy_owner_cache
    value, path = project_identity(), bpy.data.filepath
    if value or not path or not bpy.data.libraries:
        return value
    try:
        info = os.stat(path)
        key = (path, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        if _legacy_owner_cache and _legacy_owner_cache[0] == key:
            return _legacy_owner_cache[1]
        digest = native.digest_file(path)
        after = os.stat(path)
        if (info.st_size, info.st_mtime_ns, info.st_ctime_ns) != (
                after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            return ''
        value = uuid.uuid5(uuid.NAMESPACE_URL, 'rebocap-recovery:' + digest).hex
        _legacy_owner_cache = key, value
        return value
    except OSError:
        return ''


@bpy.app.handlers.persistent
def before_user_save(_):
    if not is_recovery_copy() and bpy.data.libraries:
        _ensure_project_identity()


def index_path(project, owner=None):
    import hashlib
    owner = _owner_key() if owner is None else owner
    path = os.path.normcase(os.path.abspath(project))
    key = hashlib.sha256((owner + '\0' + path).encode('utf-8')).hexdigest()
    return directory()/(key + '.json')


def _indexed_points(project, owner):
    if not project or not owner:
        return []
    try:
        record = json.loads(index_path(project, owner).read_text(encoding='utf-8'))
        if (_same_project(record['project'], project) and record['project_id'] == owner
                and isinstance(record['points'], list)):
            return record['points']
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return []


def discover(scene, *, fresh=False):
    """Prefer this path's history, with an explicit inherited point on Save As."""
    inherited = scene.rebocap_health_checkpoint
    project, owner = bpy.data.filepath, _owner_key()

    def verified(path):
        return verify_checkpoint(path)[1] if fresh else _verified_record(path)

    # Only the newest usable entry from this ordered history needs a full check.
    local = None
    for item in _indexed_points(project, owner):
        try:
            path = item['checkpoint']
            record = verified(path)
            if record.get('project_id') == owner and _same_project(record['project'], project):
                local = (record['created'], record['checkpoint_id'], path)
                break
        except (OSError, ValueError, KeyError, TypeError):
            continue
    if inherited:
        try:
            record = verified(inherited)
            if record.get('project_id') in (None, owner):
                if _same_project(record['project'], project):
                    candidate = (record['created'], record['checkpoint_id'], inherited)
                    local = max(candidate, local) if local else candidate
                elif not local:
                    return inherited
        except (OSError, ValueError, KeyError, TypeError):
            pass
    return local[2] if local else ''


def _same_project(left, right):
    return bool(left and right and os.path.normcase(os.path.abspath(left)) ==
                os.path.normcase(os.path.abspath(right)))


def _verified_record(path):
    manifest = Path(path)
    source = manifest.parent/'recovery.blend'
    signature = tuple((p.stat().st_mtime_ns, p.stat().st_size) for p in (manifest, source))
    key = (str(manifest), signature, tuple(bpy.app.version))
    if key not in _verified_cache:
        _, record = verify_checkpoint(path)
        if len(_verified_cache) >= 16:
            _verified_cache.clear()
        _verified_cache[key] = record
    return _verified_cache[key]


def verify_checkpoint(path):
    if not path:
        raise ValueError('No valid recovery point available')
    manifest = Path(path)
    record = json.loads(manifest.read_text(encoding='utf-8'))
    if (not isinstance(record, dict) or record.get('format') != 'rebocap_library_checkpoint'
            or record.get('version') != 1):
        raise ValueError('Invalid recovery point format')
    if tuple(record['blender']) != tuple(bpy.app.version):
        raise ValueError('Use the original Blender version to restore this recovery point')
    created = record.get('created')
    if (type(created) not in (int, float) or not math.isfinite(created) or created <= 0
            or not isinstance(record.get('project'), str)
            or not isinstance(record.get('checkpoint_id'), str)):
        raise ValueError('Invalid recovery point metadata')
    source = manifest.parent/'recovery.blend'
    if native.digest_file(source) != record['blend_hash']:
        raise ValueError('Recovery point integrity check failed')
    return source, record


def checkpoint_time(scene):
    path = discover(scene)
    if not path:
        return ''
    try:
        info = os.stat(path)
        key = (path, info.st_mtime_ns, info.st_size)
        if key not in _time_cache:
            record = json.loads(Path(path).read_text(encoding='utf-8'))
            value = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(record['created']))
            if len(_time_cache) >= 16:
                _time_cache.clear()
            _time_cache[key] = value
        return _time_cache[key]
    except (OSError, ValueError, KeyError, TypeError, OverflowError):
        return ''


def _status(message):
    for scene in bpy.data.scenes:
        if not scene.library:
            scene.rebocap_health_status = message


def create_checkpoint(scene):
    global _creating, _scheduled
    if not bpy.data.libraries:
        raise ValueError('No linked libraries to protect')
    if any(s.rebocap_tracking_refresh_pending for s in bpy.data.scenes):
        if not request_checkpoint(scene):
            raise RuntimeError('Recovery point verification is already running')
        _status('Recovery point queued until skeleton refresh completes')
        return None
    if _creating or _jobs:
        raise RuntimeError('Recovery point verification is already running')
    from . import history
    from ..core.a2t_types import preview_save_warning
    if any(history._scene_linked_library_conflict(s) for s in bpy.data.scenes):
        raise ValueError('Restore the original library before creating a healthy recovery point')
    owner = _ensure_project_identity()
    _scheduled = None
    if bpy.app.timers.is_registered(_run_scheduled):
        bpy.app.timers.unregister(_run_scheduled)
    root = directory()/uuid.uuid4().hex
    root.mkdir(parents=True)
    captured = {}
    project = bpy.data.filepath
    scenes = list(bpy.data.scenes)

    def capture():
        try:
            if linked_pose.last_error:
                raise ValueError(linked_pose.last_error)
            if any(preview_save_warning(s) for s in bpy.data.scenes):
                raise ValueError('Preview cleanup failed; recovery point was not created')
            captured.update({'libraries': native.libraries(), 'state': native.state()})
        except Exception as error:
            captured['error'] = str(error)

    _creating = True
    try:
        from ..core.a2t_types import preview_active
        if scene.rebocap_playback_active and not preview_active(scene):
            # An authoring operation may have invalidated animation after the
            # last frame handler. Snapshot the current controlling take's pose.
            scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
        with recovery_copy(on_saved=capture):
            result = bpy.ops.wm.save_as_mainfile(filepath=str(root/'working.blend'), copy=True,
                                               relative_remap=True)
        if result != {'FINISHED'} or not captured or captured.get('error'):
            raise ValueError(captured.get('error', 'Recovery snapshot was not saved'))
        job = {**captured, 'blender': list(bpy.app.version), 'created': time.time(),
               'project': project, 'project_id': owner, 'checkpoint_id': root.name}
        native.write_json(root/'job.json', job)
        log = (root/'worker.log').open('w', encoding='utf-8')
        try:
            process = subprocess.Popen([bpy.app.binary_path, '--factory-startup', '-b', '-noaudio',
                                        '--disable-autoexec', '--python-exit-code', '2', '--python',
                                        str(Path(native.__file__)), '--', str(root/'job.json')],
                                       stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        finally:
            log.close()
        _jobs.append({'process': process, 'root': root, 'scenes': scenes, 'project': project,
                      'project_id': owner, 'epoch': _project_epoch, 'started': time.monotonic()})
        _status('Recovery point verification started')
        if not bpy.app.timers.is_registered(poll_jobs):
            bpy.app.timers.register(poll_jobs, first_interval=0.25, persistent=True)
        return str(root)
    except Exception:
        _status('Recovery point failed; previous point retained')
        raise
    finally:
        _creating = False


def poll_jobs():
    for job in list(_jobs):
        process, root = job['process'], job['root']
        code = process.poll()
        if code is None and time.monotonic()-job['started'] < 120:
            continue
        if code is None:
            process.terminate()
            code = -1
        _jobs.remove(job)
        try:
            result = json.loads((root/'result.json').read_text(encoding='utf-8'))
            if code != 0 or not result.get('success'):
                raise ValueError(result.get('error', 'Recovery worker failed'))
            manifest = str(root/'checkpoint.json')
            _, verified = verify_checkpoint(manifest)
            project, owner = job['project'], job['project_id']
            if project:
                points = [entry for entry in _indexed_points(project, owner)
                          if isinstance(entry, dict) and isinstance(entry.get('checkpoint'), str)
                          and type(entry.get('created')) in (int, float)
                          and math.isfinite(entry['created']) and entry['checkpoint'] != manifest]
                points.append({'checkpoint': manifest, 'created': verified['created']})
                points.sort(key=lambda item: (item['created'], item['checkpoint']), reverse=True)
                native.write_json(index_path(project, owner), {'project': project, 'project_id': owner,
                                  'checkpoint': points[0]['checkpoint'], 'points': points})
            # File loading and undo may have invalidated these RNA objects.
            if bpy.data.filepath == job['project'] and job['epoch'] == _project_epoch:
                for scene in job['scenes']:
                    try:
                        if bpy.data.scenes.get(scene.name) == scene:
                            scene.rebocap_health_checkpoint = discover(scene) or manifest
                            scene.rebocap_health_status = 'Recovery point verified'
                    except ReferenceError:
                        continue
            # Staging is expendable only after the immutable checkpoint verifies.
            (root/'working.blend').unlink(missing_ok=True)
        except (OSError, ValueError, TypeError, KeyError, ReferenceError) as error:
            print('[Rebocap] Recovery point failed:', error)
            if bpy.data.filepath == job['project'] and job['epoch'] == _project_epoch:
                _status('Recovery point failed; previous point retained')
    return 0.25 if _jobs else None


def prepare_recovery(scene):
    checkpoint = discover(scene, fresh=True)
    source, record = verify_checkpoint(checkpoint)
    destination = source.parent/('restored_' + uuid.uuid4().hex + '.blend')
    try:
        with source.open('rb') as reader, destination.open('xb') as writer:
            shutil.copyfileobj(reader, writer)
            writer.flush()
            os.fsync(writer.fileno())
        if native.digest_file(destination) != record['blend_hash']:
            raise ValueError('Restored copy integrity check failed')
        native.write_json(destination.with_suffix('.json'), {'checkpoint': checkpoint,
                                                           'blend_hash': record['blend_hash']})
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return str(destination)


def _finish_restore():
    global _deferred_restore
    expected = _deferred_restore
    _deferred_restore = None
    if expected is not None and expected == _restore_context():
        restore_runtime_pose_if_copy(defer=False)
    return None


def _restore_context():
    scene = bpy.context.scene
    if not scene:
        return None
    # A late correction is permitted only while the initial load still owns
    # these channels. Compare the original RNA values, not evaluated copies.
    return (_project_epoch, bpy.data.filepath, scene, scene.frame_current, scene.frame_subframe,
            scene.rebocap_playback_active, scene.rebocap_playback_take_uuid, scene.rebocap_playback_mode,
            scene.rebocap_source_armature, scene.rebocap_a2t.preview_mode,
            scene.rebocap_a2t.enable_a2t,
            tuple(getattr(scene.rebocap_bone_map, f'node_{i}') for i in range(22)),
            scene.rebocap_pause_control, scene.open, scene.recording,
            {obj: (obj.data, linked_pose.channels(obj)) for obj in bpy.data.objects if obj.pose})


def _queue_restore_finish():
    global _deferred_restore
    _deferred_restore = _restore_context()
    if not bpy.app.timers.is_registered(_finish_restore):
        bpy.app.timers.register(_finish_restore, first_interval=0.0)


def restore_runtime_pose_if_copy(*, defer=True):
    """Bind the actual source point and load the project's supplemental channels."""
    if not bpy.data.filepath:
        return
    record = _bind_restored_point()
    if linked_pose.has_saved_pose():
        if linked_pose.restore():
            # Saved channels supply the baseline; the current controller owns
            # mapped channels. Never apply this carrier on every frame change.
            scene = bpy.context.scene
            scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
            if defer:
                _queue_restore_finish()
        return
    if record is None:
        return
    try:
        # Legacy sidecar-only snapshots need the archived runtime channels.
        scene = bpy.context.scene
        scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
        native.apply_runtime_pose(record)
        linked_pose.capture_for_save()
        if defer:
            _queue_restore_finish()
        else:
            native.compare(record['state'], native.state())
            _status('Recovery point verified')
    except (OSError, ValueError, KeyError, TypeError, ReferenceError) as error:
        print('[Rebocap] Restored runtime pose could not be applied:', error)
        _status('Recovery point failed; previous point retained')


def _bind_restored_point():
    """Use provenance only while this file is the exact restored snapshot."""
    sidecar = Path(bpy.data.filepath).with_suffix('.json')
    if not sidecar.is_file():
        return
    try:
        link = json.loads(sidecar.read_text(encoding='utf-8'))
        if not isinstance(link, dict) or not {'checkpoint', 'blend_hash'} <= link.keys():
            return
        if native.digest_file(bpy.data.filepath) != link['blend_hash']:
            return  # A subsequently edited/saved project is no longer this copy.
        _, record = verify_checkpoint(link['checkpoint'])
        if record['blend_hash'] != link['blend_hash'] or record.get('project_id') not in (None, project_identity()):
            raise ValueError('Restored project identity does not match its recovery point')
        if native.libraries(True) != record['libraries']:
            raise ValueError('Restored runtime library versions differ')
        for scene in bpy.data.scenes:
            if not scene.library:
                scene.rebocap_health_checkpoint = link['checkpoint']
        return record
    except (OSError, ValueError, KeyError, TypeError, ReferenceError) as error:
        print('[Rebocap] Could not identify the restored project source:', error)


def _run_scheduled():
    global _scheduled
    if _scheduled is None:
        return None
    if _scheduled != (_project_epoch, bpy.data.filepath):
        _scheduled = None
        return None
    if not bpy.data.libraries:
        _scheduled = None
        _status('No linked libraries to protect')
        return None
    if _jobs or _creating:
        return 0.5  # Coalesce successful saves/bindings during verification.
    if _scheduled is not None and any(s.rebocap_tracking_refresh_pending for s in bpy.data.scenes):
        return 0.5
    _scheduled = None
    try:
        if bpy.context.scene:
            create_checkpoint(bpy.context.scene)
    except (OSError, ValueError, RuntimeError, ReferenceError) as error:
        print('[Rebocap] Automatic recovery point deferred:', error)
        _status('Recovery point failed; previous point retained')
    return None


def request_checkpoint(scene, binding=None):
    global _scheduled
    if _creating or is_recovery_copy() or not bpy.data.libraries:
        return False
    if binding is not None:
        if binding in _attempted:
            return False
        _attempted.add(binding)
    # The copy protects the whole project. Resolve the current scene at
    # execution, because Undo/Redo can replace every Scene RNA wrapper.
    _scheduled = (_project_epoch, bpy.data.filepath)
    if not bpy.app.timers.is_registered(_run_scheduled):
        bpy.app.timers.register(_run_scheduled, first_interval=0.5)
    return True


@bpy.app.handlers.persistent
def after_user_save(_):
    if not is_recovery_copy() and bpy.context.scene:
        request_checkpoint(bpy.context.scene)


@bpy.app.handlers.persistent
def reset_runtime(_=None):
    global _scheduled, _project_epoch, _deferred_restore, _legacy_owner_cache
    _project_epoch += 1
    _scheduled = None
    _deferred_restore = None
    _legacy_owner_cache = None
    _attempted.clear()
    _verified_cache.clear()
    if bpy.app.timers.is_registered(_run_scheduled):
        bpy.app.timers.unregister(_run_scheduled)
    if bpy.app.timers.is_registered(_finish_restore):
        bpy.app.timers.unregister(_finish_restore)


class REBOCAP_OT_create_library_checkpoint(bpy.types.Operator):
    bl_idname = 'rebocap.create_library_checkpoint'
    bl_label = 'Create verified recovery point'

    def execute(self, context):
        try:
            point = create_checkpoint(context.scene)
        except (OSError, ValueError, RuntimeError) as error:
            self.report({'WARNING'}, T(str(error)))
            return {'CANCELLED'}
        self.report({'INFO'}, T('Recovery point verification started' if point else
                               'Recovery point queued until skeleton refresh completes'))
        return {'FINISHED'}


class REBOCAP_OT_restore_library_checkpoint(bpy.types.Operator):
    bl_idname = 'rebocap.restore_library_checkpoint'
    bl_label = 'Restore into a new project'
    launch: bpy.props.BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        try:
            destination = prepare_recovery(context.scene)
            if self.launch:
                subprocess.Popen([bpy.app.binary_path, '--factory-startup', '--disable-autoexec', destination,
                                  '--python', str(Path(__file__).with_name('library_checkpoint_open.py'))],
                                 creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            self.report({'INFO'}, T('Restored project copy created') + ': ' + destination)
        except (OSError, ValueError, RuntimeError, KeyError, TypeError) as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    linked_pose.register()
    bpy.types.Scene.rebocap_health_checkpoint = bpy.props.StringProperty()
    bpy.types.Scene.rebocap_health_status = bpy.props.StringProperty(options={'SKIP_SAVE'})
    for cls in (REBOCAP_OT_create_library_checkpoint, REBOCAP_OT_restore_library_checkpoint):
        bpy.utils.register_class(cls)
    bpy.app.handlers.save_post.append(after_user_save)
    bpy.app.handlers.save_pre.append(before_user_save)


def unregister():
    reset_runtime()
    for job in _jobs:
        if job['process'].poll() is None:
            job['process'].terminate()
    _jobs.clear()
    if bpy.app.timers.is_registered(poll_jobs):
        bpy.app.timers.unregister(poll_jobs)
    if after_user_save in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.remove(after_user_save)
    if before_user_save in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(before_user_save)
    for cls in (REBOCAP_OT_restore_library_checkpoint, REBOCAP_OT_create_library_checkpoint):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.rebocap_health_status
    del bpy.types.Scene.rebocap_health_checkpoint
    linked_pose.unregister()
