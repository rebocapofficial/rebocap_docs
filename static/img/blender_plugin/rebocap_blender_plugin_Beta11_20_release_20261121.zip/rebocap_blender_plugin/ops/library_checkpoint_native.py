"""Native recovery-file verification, also runnable in an isolated Blender.

The JSON describes invariants for verification. Restoration uses the .blend.
The worker registers the owning solver to reconstruct saved native takes;
it never connects to the SDK.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import bpy


def digest_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def library_path(library):
    return os.path.normcase(os.path.normpath(bpy.path.abspath(library.filepath, library=library.parent)))


def libraries(packed_only=False):
    result = {}
    for library in bpy.data.libraries:
        if library.is_missing:
            raise ValueError('Missing linked library: ' + library.filepath)
        if library.packed_file:
            digest = hashlib.sha256(bytes(library.packed_file.data)).hexdigest()
        else:
            if packed_only:
                raise ValueError('Recovery file still requires an external library')
            path = library_path(library)
            before = os.stat(path)
            digest = digest_file(path)
            after = os.stat(path)
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError('Library changed while reading')
        # A packed library keeps its locator as a hint; Save Copy can relocate
        # that hint without changing its bytes or any native ID references.
        # The native Library ID name is unique inside this immutable snapshot.
        result[library.name_full] = {'hash': digest, 'parent': library.parent.name_full if library.parent else ''}
    return result


def reference(value):
    return [value.name_full, value.library.name_full if value.library else ''] if value else None


def properties(value):
    result = {}
    for prop in value.bl_rna.properties:
        name = prop.identifier
        if name == 'rna_type' or (prop.is_readonly and name != 'type'):
            continue
        item = getattr(value, name)
        if prop.type in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
            if getattr(prop, 'is_array', False):
                item = list(item)
            if isinstance(item, set):
                item = sorted(item)
            result[name] = item
        elif prop.type == 'POINTER' and isinstance(item, bpy.types.ID):
            result[name] = reference(item)
        elif prop.type == 'COLLECTION':
            result[name] = [properties(part) for part in item]
    return result


def curve(fc):
    return {'path': fc.data_path, 'index': fc.array_index, 'mute': fc.mute,
            'keys': [[list(k.co), list(k.handle_left), list(k.handle_right), k.interpolation,
                      k.handle_left_type, k.handle_right_type] for k in fc.keyframe_points],
            'samples': [list(k.co) for k in fc.sampled_points],
            'modifiers': [properties(m) for m in fc.modifiers]}


def animation(obj):
    ad = obj.animation_data
    if not ad:
        return None
    actions = set()
    if ad.action:
        actions.add(ad.action)
    tracks = []
    for track in ad.nla_tracks:
        strips = []
        for strip in track.strips:
            if strip.action:
                actions.add(strip.action)
            strips.append({'settings': properties(strip),
                           'slot': getattr(getattr(strip, 'action_slot', None), 'identifier', ''),
                           'curves': [curve(c) for c in strip.fcurves]})
        tracks.append({'name': track.name, 'mute': track.mute, 'solo': track.is_solo, 'strips': strips})
    clips = []
    for action in sorted(actions, key=lambda a: (a.name_full, str(reference(a)))):
        bags = []
        if hasattr(action, 'slots'):
            for layer in action.layers:
                for strip in layer.strips:
                    for bag in strip.channelbags:
                        bags.append([bag.slot.identifier, [curve(c) for c in bag.fcurves]])
        else:
            bags.append(['', [curve(c) for c in action.fcurves]])
        clips.append([reference(action), bags])
    drivers = []
    for fc in ad.drivers:
        drivers.append([fc.data_path, fc.array_index, fc.driver.type, fc.driver.expression,
                        [[v.name, v.type, [properties(t) for t in v.targets]] for v in fc.driver.variables]])
    return {'action': reference(ad.action),
            'slot': getattr(getattr(ad, 'action_slot', None), 'identifier', ''),
            'use_nla': ad.use_nla, 'blend': ad.action_blend_type,
            'influence': ad.action_influence, 'tracks': tracks, 'actions': clips, 'drivers': drivers}


def state():
    bpy.context.view_layer.update()
    objects = []
    for obj in sorted(bpy.data.objects, key=lambda o: (o.name_full, str(reference(o)))):
        if not obj.users and not obj.use_fake_user:
            continue
        if obj.is_missing or (obj.data and obj.data.is_missing):
            raise ValueError('Missing object data: ' + obj.name)
        entry = {'id': reference(obj), 'type': obj.type, 'parent': reference(obj.parent),
                 'parent_bone': obj.parent_bone, 'matrix_basis': [list(r) for r in obj.matrix_basis],
                 'constraints': [properties(c) for c in obj.constraints], 'animation': animation(obj),
                 'data': reference(obj.data), 'override': reference(obj.override_library.reference)
                 if obj.override_library else None}
        if obj.type == 'ARMATURE':
            entry['rest'] = [[b.name, b.parent.name if b.parent else '', [list(r) for r in b.matrix_local],
                              b.length, b.use_deform] for b in obj.data.bones]
            entry['pose'] = [[b.name, b.rotation_mode, list(b.location), list(b.rotation_quaternion),
                              list(b.rotation_euler), list(b.rotation_axis_angle), list(b.scale),
                              [properties(c) for c in b.constraints]] for b in obj.pose.bones]
            if obj.name in bpy.context.scene.objects:
                evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                entry['evaluated'] = [[b.name, [list(r) for r in b.matrix]] for b in evaluated.pose.bones]
        objects.append(entry)
    return {'active_scene': bpy.context.scene.name,
            'texts': [[t.name_full, t.as_string()] for t in bpy.data.texts if t.users or t.use_fake_user],
            'scenes': [[s.name, s.frame_current, s.frame_subframe, sorted(reference(o) for o in s.objects)]
                       for s in bpy.data.scenes], 'objects': objects}


def compare(expected, actual, path='state'):
    if isinstance(expected, (int, float)) and not isinstance(expected, bool):
        if not isinstance(actual, (int, float)) or not math.isfinite(actual) or abs(expected-actual) > 1e-5:
            raise ValueError('Recovery mismatch: ' + path)
    elif isinstance(expected, dict):
        if not isinstance(actual, dict) or expected.keys() != actual.keys():
            raise ValueError('Recovery fields differ: ' + path + ' expected=' + str(sorted(expected)) +
                             ' actual=' + str(sorted(actual) if isinstance(actual, dict) else actual))
        for key in expected:
            compare(expected[key], actual[key], path + '.' + key)
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(expected) != len(actual):
            raise ValueError('Recovery count differs: ' + path)
        for i, (left, right) in enumerate(zip(expected, actual)):
            compare(left, right, path + '[' + str(i) + ']')
    elif expected != actual:
        raise ValueError('Recovery identity differs: ' + path)


def write_json(path, data):
    temporary = Path(str(path) + '.tmp')
    with temporary.open('w', encoding='utf-8') as destination:
        json.dump(data, destination, ensure_ascii=False, allow_nan=False)
        destination.flush()
        os.fsync(destination.fileno())
    os.replace(temporary, path)


def select_scene(expected):
    bpy.context.window.scene = bpy.data.scenes[expected['active_scene']]


def apply_runtime_pose(job):
    """Blender does not serialize runtime Pose channels on a fully linked Object.

    Supplement only those channels, against the exact archived library bytes.
    Animation, constraints and their references remain native .blend data.
    """
    for entry in job['state']['objects']:
        if entry['type'] != 'ARMATURE' or not entry['id'][1]:
            continue
        matches = [o for o in bpy.data.objects if reference(o) == entry['id']]
        if len(matches) != 1 or not matches[0].data:
            raise ValueError('Cannot identify the linked runtime pose')
        obj = matches[0]
        if [b.name for b in obj.data.bones] != [b[0] for b in entry['rest']]:
            raise ValueError('Runtime pose bones differ from the archived version')
        obj.matrix_basis = entry['matrix_basis']
        for name, mode, location, quaternion, euler, axis_angle, scale, _ in entry['pose']:
            bone = obj.pose.bones[name]
            bone.rotation_mode = mode
            bone.location, bone.rotation_quaternion = location, quaternion
            bone.rotation_euler, bone.rotation_axis_angle, bone.scale = euler, axis_angle, scale


def verify_scene(job, packed_only):
    from rebocap_blender_plugin.ops import library_recovery

    select_scene(job['state'])
    library_recovery._finish_restore()
    scene = bpy.context.scene
    scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
    if libraries(packed_only) != job['libraries']:
        raise ValueError('Linked library version differs from the captured state')
    compare(job['state'], state())


def worker(job_path):
    directory = Path(job_path).parent
    job = json.loads(Path(job_path).read_text(encoding='utf-8'))
    try:
        if tuple(job['blender']) != tuple(bpy.app.version):
            raise ValueError('Recovery must use the same Blender version')
        # Native clips and raw takes are both saved inputs. Reconstruct takes
        # with the owning solver, without connecting an SDK or creating copies.
        sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
        import rebocap_blender_plugin as addon
        addon.register()
        from rebocap_blender_plugin.ops import library_recovery
        library_recovery._creating = True
        if addon.auto_detect_config_on_start in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(addon.auto_detect_config_on_start)
        if bpy.app.timers.is_registered(addon.auto_detect_config_on_start):
            bpy.app.timers.unregister(addon.auto_detect_config_on_start)
        bpy.ops.wm.open_mainfile(filepath=str(directory/'working.blend'), load_ui=False, use_scripts=False)
        verify_scene(job, False)
        # Blender's native packer refuses absolute library locators. Change
        # locators only in this disposable worker, retaining nested resolution.
        paths = {library: library_path(library) for library in bpy.data.libraries}
        for library, path in paths.items():
            start = os.path.dirname(paths[library.parent]) if library.parent else str(directory)
            library.filepath = bpy.path.relpath(path, start=start)
        if libraries() != job['libraries']:
            raise ValueError('Relative library locators changed the resource versions')
        bpy.ops.file.pack_libraries()
        if libraries(True) != job['libraries']:
            raise ValueError('Packed library bytes do not match the original versions')
        output = directory/'recovery.blend'
        bpy.ops.wm.save_as_mainfile(filepath=str(output), relative_remap=False, compress=True)
        bpy.ops.wm.open_mainfile(filepath=str(output), load_ui=False, use_scripts=False)
        verify_scene(job, True)
        job['blend_hash'] = digest_file(output)
        job['format'] = 'rebocap_library_checkpoint'
        job['version'] = 1
        write_json(directory/'checkpoint.json', job)
        write_json(directory/'result.json', {'success': True})
        print('REBOCAP_CHECKPOINT_VERIFIED', flush=True)
    except Exception as error:
        write_json(directory/'result.json', {'success': False, 'error': str(error)})
        print('REBOCAP_CHECKPOINT_REJECTED', str(error), flush=True)
        raise


if __name__ == '__main__':
    worker(sys.argv[sys.argv.index('--')+1])
