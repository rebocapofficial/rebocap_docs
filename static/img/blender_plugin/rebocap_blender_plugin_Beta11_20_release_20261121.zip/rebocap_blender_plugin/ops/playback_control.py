"""Coordinate animation isolation for the current playback writer."""

import bpy

from .recording_control import RecordingChannels

_sessions = {}
_saving = set()
_syncing = set()


def _key(scene):
    return scene.as_pointer()


def _channels(scene, take):
    from ..core.control import drive_objects
    from .history import get_drive_type
    from .rebocap_connection import _recording_binding, _recording_channels

    binding, mapping = _recording_binding(scene)
    mode = scene.rebocap_playback_mode if scene.rebocap_playback_active else get_drive_type(scene, take)
    source, data, hip, root = binding
    if mode in ('FK', 'DUAL') and (source is None or data is None or hip is None or root is None):
        raise ValueError('Please bind a source armature and its pelvis first')
    channels, bones = _recording_channels(scene, binding, mapping)
    objects = set(drive_objects(scene, mode))
    return ({obj: paths for obj, paths in channels.items() if obj in objects},
            {bone for bone in bones if bone.id_data in objects})


def synchronize(scene, take):
    from ..core.a2t_types import preview_saving
    key = _key(scene)
    # A2T can evaluate the reserved frame while writing the project. That
    # evaluation must not create a new playback helper after save_pre released it.
    if key in _saving or key in _syncing or preview_saving(scene):
        return
    _syncing.add(key)
    try:
        channels, bones = _channels(scene, take)
        session = _sessions.get(key)
        if session is None:
            session = RecordingChannels(scene, channels, bones)
            try:
                session.start()
            except Exception:
                session.close()
                raise
            _sessions[key] = session
        elif session.channels != channels or set(session.rotation_modes) != bones:
            session.rebind(channels, bones)
        else:
            session.refresh()
    finally:
        _syncing.discard(key)


def pose_layer_for(scene):
    session = _sessions.get(_key(scene))
    return session.pose if session is not None and not session.suspended else None


def has_active_sessions():
    return bool(_sessions)


def release(scene):
    session = _sessions.pop(_key(scene), None)
    if session is not None:
        session.close()


def reset():
    _sessions.clear()
    _saving.clear()
    _syncing.clear()


@bpy.app.handlers.persistent
def before_frame(scene, depsgraph=None):
    if not getattr(scene, 'rebocap_playback_active', False) or getattr(scene, 'recording', False):
        return
    from ..core.a2t_types import preview_active, preview_frame_suspended
    if preview_frame_suspended(scene) or preview_active(scene):
        return
    take = next((take for take in scene.rebocap_takes
                 if take.uuid == scene.rebocap_playback_take_uuid), None)
    if take is not None:
        try:
            synchronize(scene, take)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as error:
            print('[Rebocap] Playback isolation failed:', error)


@bpy.app.handlers.persistent
def before_save(_):
    for key, session in tuple(_sessions.items()):
        if not session.suspended:
            session.suspend_for_save()
            _saving.add(key)


@bpy.app.handlers.persistent
def after_save(_):
    for key in tuple(_saving):
        session = _sessions.get(key)
        if session is not None:
            session.resume_after_save()
        _saving.discard(key)


@bpy.app.handlers.persistent
def before_undo(_):
    for session in tuple(_sessions.values()):
        session.close()
    reset()


@bpy.app.handlers.persistent
def after_undo(_):
    reset()


def close_all():
    for session in tuple(_sessions.values()):
        session.close()
    reset()
