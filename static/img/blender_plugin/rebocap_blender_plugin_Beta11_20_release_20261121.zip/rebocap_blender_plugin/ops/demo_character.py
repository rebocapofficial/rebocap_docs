import os
import bpy
from mathutils import Vector, Quaternion, Euler
from ..core.translation import T, T_static
from ..core.a2t_types import preview_active
from .ik_tracking import parse_and_update_ik_config, find_rebocap_config_path
from .utils import adjust_baked_action, _is_rebocap_baked

_ADAPTER_HELPER = 'rebocap_demo_adapter_helper'
_ADAPTER_VERSION = 'rebocap_demo_adapter_version'
_SCALE_CONSTRAINT = 'Rebocap static scale'
_LOCATION_CONSTRAINT = 'Rebocap static location'


def _adapter_snapshot(arm):
    helper = arm.get(_ADAPTER_HELPER)
    constraints = {}
    for pb in arm.pose.bones:
        for con in pb.constraints:
            if (con.type == 'TRANSFORM' and con.target == helper and helper is not None
                    and con.name.startswith((_SCALE_CONSTRAINT, _LOCATION_CONSTRAINT))):
                attrs = ('to_min_x', 'to_min_y', 'to_min_z', 'to_max_x', 'to_max_y', 'to_max_z',
                         'to_min_x_scale', 'to_min_y_scale', 'to_min_z_scale',
                         'to_max_x_scale', 'to_max_y_scale', 'to_max_z_scale')
                constraints[(pb.name, con.name)] = {name: getattr(con, name) for name in attrs}
    return helper, arm.get(_ADAPTER_VERSION), constraints


def _restore_adapter_snapshot(arm, state):
    old_helper, version, saved = state
    helper = arm.get(_ADAPTER_HELPER)
    for pb in arm.pose.bones:
        for con in list(pb.constraints):
            if (con.type != 'TRANSFORM' or con.target not in (helper, old_helper)
                    or not con.name.startswith((_SCALE_CONSTRAINT, _LOCATION_CONSTRAINT))):
                continue
            values = saved.get((pb.name, con.name))
            if values is None:
                pb.constraints.remove(con)
            else:
                for name, value in values.items():
                    setattr(con, name, value)
    if helper and helper != old_helper:
        bpy.data.objects.remove(helper, do_unlink=True)
    if old_helper:
        arm[_ADAPTER_HELPER] = old_helper
    elif _ADAPTER_HELPER in arm:
        del arm[_ADAPTER_HELPER]
    if version is None:
        if _ADAPTER_VERSION in arm:
            del arm[_ADAPTER_VERSION]
    else:
        arm[_ADAPTER_VERSION] = version


def _adapter_helper(arm):
    helper = arm.get(_ADAPTER_HELPER)
    if helper and helper.type == 'EMPTY':
        return helper
    helper = bpy.data.objects.new('Rebocap_Demo_Adapter', None)
    helper['rebocap_demo_character'] = True
    helper.hide_render = True
    for scene in bpy.data.scenes:
        if scene.objects.get(arm.name) == arm:
            scene.collection.objects.link(helper)
    arm[_ADAPTER_HELPER] = helper
    try:
        helper.hide_set(True)
    except RuntimeError:
        pass
    return helper


def _adapter_constraint(pb, helper, name, mode, values):
    con = next((item for item in pb.constraints if item.type == 'TRANSFORM'
                and item.target == helper and item.name.startswith(name)), None)
    if con is None:
        con = pb.constraints.new('TRANSFORM')
        con.name = name
        con.target = helper
    con.owner_space = 'LOCAL'
    con.target_space = 'LOCAL'
    con.map_from = 'LOCATION'
    con.map_to = mode
    if mode == 'SCALE':
        con.mix_mode_scale = 'MULTIPLY'
        suffix = '_scale'
    else:
        con.mix_mode = 'ADD'
        suffix = ''
    for axis, value in zip('xyz', values):
        setattr(con, 'to_min_' + axis + suffix, value)
        setattr(con, 'to_max_' + axis + suffix, value)
    return con


def get_demo_character_armature(scene=None):
    scene = scene or bpy.context.scene
    for obj in scene.objects:
        if obj.get("rebocap_demo_character") and obj.type == 'ARMATURE':
            return obj
    return None


def get_demo_character_meshes(scene=None):
    scene = scene or bpy.context.scene
    return [obj for obj in scene.objects if obj.get("rebocap_demo_character") and obj.type == 'MESH']


def is_demo_character_present(scene=None):
    scene = scene or bpy.context.scene
    return any(obj.get("rebocap_demo_character") for obj in scene.objects)


def _remove_demo_objects(objects):
    for obj in objects:
        mesh_data = obj.data if obj.type == 'MESH' else None
        arm_data = obj.data if obj.type == 'ARMATURE' else None
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh_data and mesh_data.users == 0:
            bpy.data.meshes.remove(mesh_data, do_unlink=True)
        if arm_data and arm_data.users == 0:
            bpy.data.armatures.remove(arm_data, do_unlink=True)


def demo_shared_with_another_scene(scene, objects):
    return any(other != scene and other.objects.get(obj.name) == obj
               for other in bpy.data.scenes for obj in objects)


def remove_demo_character(scene=None):
    scene = scene or bpy.context.scene
    objects = [obj for obj in scene.objects if obj.get("rebocap_demo_character")]
    if demo_shared_with_another_scene(scene, objects):
        return False
    _remove_demo_objects(objects)
    return True


def adapt_demo_character_scale_isolated(arm_obj, rest_positions=None):
    """Restore the previous pose and baseline if adapting the demo fails."""
    if not arm_obj or arm_obj.type != 'ARMATURE':
        return
    pose = {pb.name: (pb.matrix_basis.copy(), pb.bone.inherit_scale) for pb in arm_obj.pose.bones}
    adapter = _adapter_snapshot(arm_obj)
    properties = {}
    for name in ('rebocap_adapted_hip_location', 'rebocap_rest_pelvis_z', 'rebocap_demo_static_thigh_center'):
        value = arm_obj.get(name)
        properties[name] = (name in arm_obj, list(value) if name in ('rebocap_adapted_hip_location', 'rebocap_demo_static_thigh_center') and value is not None else value)
    display_type, show_in_front = arm_obj.data.display_type, arm_obj.show_in_front
    try:
        return _adapt_demo_character_scale(arm_obj, rest_positions)
    except Exception:
        _restore_adapter_snapshot(arm_obj, adapter)
        for pb in arm_obj.pose.bones:
            if pb.name in pose:
                basis, inherit_scale = pose[pb.name]
                pb.bone.inherit_scale = inherit_scale
                pb.matrix_basis = basis
        for name, (existed, value) in properties.items():
            if existed:
                arm_obj[name] = value
            elif name in arm_obj:
                del arm_obj[name]
        arm_obj.data.display_type = display_type
        arm_obj.show_in_front = show_in_front
        bpy.context.view_layer.update()
        raise


def _adapt_demo_character_scale(arm_obj, rest_positions=None):
    """根据静态骨架调整示范角色比例，保留当前动作和约束。"""
    if not arm_obj or arm_obj.type != 'ARMATURE':
        return

    # The reference comes from the configuration, never the currently driven nodes.
    if rest_positions is None:
        root = bpy.context.scene.objects.get('Rebocap_Root')
        values = root.get('rebocap_rest_positions') if root else None
        if values is None or len(values) != 72:
            raise ValueError("Static tracking skeleton data is unavailable; regenerate tracking nodes")
        rest_positions = {i: values[i * 3:i * 3 + 3] for i in range(24)}
    positions = {i: Vector(rest_positions[i]) for i in range(24)}
    previous_base = arm_obj.get('rebocap_adapted_hip_location')
    previous_height = arm_obj.get('rebocap_rest_pelvis_z')
    had_adapter = bool(arm_obj.get(_ADAPTER_VERSION))
    old_scales = {pb.name: tuple(pb.scale) for pb in arm_obj.pose.bones}
    adapted_hip_location = None
    scales = {}
    if previous_base is None:
        for pb in arm_obj.pose.bones:
            if pb.parent:
                pb.bone.inherit_scale = 'NONE'

    # 2. 脚部骨骼长宽独立精准自适应（X轴横向加宽15%增强饱满度与包裹感，Y/Z轴等比保持脚掌水平贴地）
    for side, prefix in [('Left', 'L'), ('Right', 'R')]:
        sole_obj = bpy.context.scene.objects.get(f'Rebocap_{prefix}_Sole')
        s_len, s_width = 1.0, 1.0
        if sole_obj and sole_obj.type == 'MESH':
            pts = [v.co.copy() for v in sole_obj.data.vertices]
            if len(pts) >= 7:
                w_target = max(v.x for v in pts) - min(v.x for v in pts)
                l_target = (pts[1] - pts[4]).length
                s_width = max(min((w_target / 0.1438) * 1.15, 3.0), 0.1)
                s_len = max(min(l_target / 0.2961, 3.0), 0.1)
        foot_pb = arm_obj.pose.bones.get(f'mixamorig:{side}Foot')
        toe_pb = arm_obj.pose.bones.get(f'mixamorig:{side}ToeBase')
        if foot_pb:
            scales[foot_pb.name] = (s_width, s_len, s_len)
        if toe_pb:
            scales[toe_pb.name] = (s_width, s_len, s_len)

    # 3. 大腿与小腿三维等比适配（消除脚底悬空与膝盖错位）
    for side, thigh_index, knee_index, ankle_index in [('Left', 1, 4, 7), ('Right', 2, 5, 8)]:
        node_knee = positions.get(knee_index)
        node_thigh = positions.get(thigh_index)
        if node_knee is None or node_thigh is None or positions.get(ankle_index) is None:
            continue
        # Imported skeletons may have non-vertical lower legs; use the actual
        # static knee-to-ankle distance instead of a vertical projection.
        target_calf_len = max(0.05, (node_knee - positions[ankle_index]).length)
        target_thigh_len = (node_knee - node_thigh).length
        
        up_leg_pb = arm_obj.pose.bones.get(f'mixamorig:{side}UpLeg')
        leg_pb = arm_obj.pose.bones.get(f'mixamorig:{side}Leg')
        if up_leg_pb and up_leg_pb.bone.length > 0.001:
            ratio_thigh = target_thigh_len / up_leg_pb.bone.length
            scales[up_leg_pb.name] = (ratio_thigh, ratio_thigh, ratio_thigh)
        if leg_pb and leg_pb.bone.length > 0.001:
            ratio_calf = target_calf_len / leg_pb.bone.length
            scales[leg_pb.name] = (ratio_calf, ratio_calf, ratio_calf)

    # 4. 骨盆（Hips）大腿根关节中心精准对位与胯宽对齐
    node_l_thigh = positions.get(1)
    node_r_thigh = positions.get(2)
    hip_pb = arm_obj.pose.bones.get('mixamorig:Hips')
    hip_db = arm_obj.data.bones.get('mixamorig:Hips')
    l_thigh_db = arm_obj.data.bones.get('mixamorig:LeftUpLeg')
    r_thigh_db = arm_obj.data.bones.get('mixamorig:RightUpLeg')

    if node_l_thigh is not None and node_r_thigh is not None and hip_pb and hip_db and l_thigh_db and r_thigh_db:
        target_thigh_center = (node_l_thigh + node_r_thigh) * 0.5
        base_thigh_center = (l_thigh_db.head_local + r_thigh_db.head_local) * 0.5
        diff_world = target_thigh_center - base_thigh_center
        adapted_hip_location = hip_db.matrix_local.to_3x3().inverted() @ diff_world
        if previous_base is not None:
            previous_center = arm_obj.get('rebocap_demo_static_thigh_center')
            if previous_center is None:
                previous_center = base_thigh_center + hip_db.matrix_local.to_3x3() @ Vector(previous_base)
            from .rebocap_connection import evaluated_world_matrix
            world_inverse = evaluated_world_matrix(bpy.context.scene, arm_obj).to_3x3().inverted()
            delta = target_thigh_center - Vector(previous_center)
            adapted_hip_location = (Vector(previous_base) +
                                    hip_db.matrix_local.to_3x3().inverted() @ world_inverse @ delta)
        arm_obj['rebocap_demo_static_thigh_center'] = list(target_thigh_center)

        target_hip_w = (node_l_thigh - node_r_thigh).length
        base_hip_w = (l_thigh_db.head - r_thigh_db.head).length
        if base_hip_w > 0.001:
            scales[hip_pb.name] = (target_hip_w / base_hip_w, 1.0, 1.0)

    # 5. 脊椎段与肩膀高度精准对齐（消除手臂下垂偏矮问题）
    node_shoulder = positions.get(16)
    if node_shoulder is not None and node_l_thigh is not None and node_r_thigh is not None:
        target_thigh_center = (node_l_thigh + node_r_thigh) * 0.5
        t_torso_h = node_shoulder.z - target_thigh_center.z
        spine_ratio = max(min(t_torso_h / 0.4215, 3.0), 0.1)
        
        spine_bones = ['mixamorig:Spine', 'mixamorig:Spine1', 'mixamorig:Spine2']
        for s in spine_bones:
            pb = arm_obj.pose.bones.get(s)
            if pb:
                scales[pb.name] = (spine_ratio, spine_ratio, spine_ratio)
        neck_pb = arm_obj.pose.bones.get('mixamorig:Neck')
        head_pb = arm_obj.pose.bones.get('mixamorig:Head')
        if neck_pb:
            scales[neck_pb.name] = (spine_ratio, spine_ratio, spine_ratio)
        if head_pb:
            scales[head_pb.name] = (spine_ratio, spine_ratio, spine_ratio)

    # 6. 上肢各段骨骼等比拉伸（锁骨、大臂、小臂）
    for sh_name, arm_name, fa_name, side in [
        ('mixamorig:LeftShoulder', 'mixamorig:LeftArm', 'mixamorig:LeftForeArm', 'L'),
        ('mixamorig:RightShoulder', 'mixamorig:RightArm', 'mixamorig:RightForeArm', 'R')]:
        sh_pb = arm_obj.pose.bones.get(sh_name)
        arm_pb = arm_obj.pose.bones.get(arm_name)
        fa_pb = arm_obj.pose.bones.get(fa_name)
        node_sh = positions.get(13 if side == 'L' else 14)
        node_ua = positions.get(16 if side == 'L' else 17)
        node_la = positions.get(18 if side == 'L' else 19)
        node_hd = positions.get(20 if side == 'L' else 21)
        
        if sh_pb and node_sh is not None and node_ua is not None and sh_pb.bone.length > 0.001:
            sh_len = (node_ua - node_sh).length
            scales[sh_pb.name] = (sh_len / sh_pb.bone.length,) * 3
        if arm_pb and node_ua is not None and node_la is not None and arm_pb.bone.length > 0.001:
            ua_len = (node_la - node_ua).length
            scales[arm_pb.name] = (ua_len / arm_pb.bone.length,) * 3
        if fa_pb and node_la is not None and node_hd is not None and fa_pb.bone.length > 0.001:
            la_len = (node_hd - node_la).length
            scales[fa_pb.name] = (la_len / fa_pb.bone.length,) * 3

    # 7. 隐藏骨骼线框显示，保持角色表面光洁，并记录基准贴地坐标与静止骨盆高供实时驱动增量使用
    arm_obj.data.display_type = 'WIRE'
    arm_obj.show_in_front = False
    ad = arm_obj.animation_data
    action_owners = ([ad] if ad and ad.action else [])
    if ad:
        action_owners += [strip for track in ad.nla_tracks for strip in track.strips if strip.action]
    has_animation = bool(action_owners)
    has_baked = any(_is_rebocap_baked(owner.action) for owner in action_owners)
    legacy_baked = not had_adapter and has_baked
    height_offset = Vector((0.0, 0.0, 0.0))
    if hip_pb and previous_base is not None and previous_height is not None:
        height_delta = float(previous_height) - positions[0].z
        from .rebocap_connection import evaluated_world_matrix
        world_to_local = (evaluated_world_matrix(bpy.context.scene, arm_obj).to_3x3() @ hip_db.matrix_local.to_3x3()).inverted()
        height_offset = world_to_local @ Vector((0, 0, height_delta))
    if legacy_baked:
        # Older plugin-baked actions contain the old body proportions. Convert
        # copies to dynamic channels before installing the independent layer.
        changes = {}
        for name in scales:
            pb = arm_obj.pose.bones[name]
            for axis, old_value in enumerate(old_scales[name]):
                if abs(old_value) > 1e-8:
                    changes[(pb.path_from_id('scale'), axis)] = ('multiply', 1.0 / old_value)
        if hip_pb and previous_base is not None:
            for axis in range(3):
                changes[(hip_pb.path_from_id('location'), axis)] = ('add', -float(previous_base[axis]))
        adjust_baked_action(arm_obj, changes)
    elif had_adapter and has_baked and hip_pb and height_offset.length > 1e-8:
        # Baked native playback contains dynamic pelvis offsets. Preserve its
        # world position when the static pelvis height changes.
        changes = {(hip_pb.path_from_id('location'), axis): ('add', height_offset[axis])
                   for axis in range(3)}
        adjust_baked_action(arm_obj, changes)

    if not had_adapter and previous_base is not None and (legacy_baked or not has_animation):
        for name in scales:
            pb = arm_obj.pose.bones[name]
            pb.scale = tuple((pb.scale[i] / old_scales[name][i]) if abs(old_scales[name][i]) > 1e-8 else 1.0
                             for i in range(3))
        if hip_pb:
            hip_pb.location -= Vector(previous_base)

    if hip_pb and adapted_hip_location is not None:
        arm_obj['rebocap_adapted_hip_location'] = list(adapted_hip_location)
    arm_obj['rebocap_rest_pelvis_z'] = float(positions[0].z)

    helper = _adapter_helper(arm_obj)
    for name, value in scales.items():
        _adapter_constraint(arm_obj.pose.bones[name], helper, _SCALE_CONSTRAINT, 'SCALE', value)
    if hip_pb and adapted_hip_location is not None:
        _adapter_constraint(hip_pb, helper, _LOCATION_CONSTRAINT, 'LOCATION', adapted_hip_location)
    arm_obj[_ADAPTER_VERSION] = 1
    bpy.context.view_layer.update()


class REBOCAP_OT_offset_demo_character(bpy.types.Operator):
    bl_idname = "rebocap.offset_demo_character"
    bl_label = T_static("偏移示范角色")
    bl_description = T_static("左右移动示范角色水平位置")
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.StringProperty(default='SET')
    offset_x: bpy.props.FloatProperty(default=0.0)

    def execute(self, context):
        arm = get_demo_character_armature(context.scene)
        if not arm:
            self.report({'WARNING'}, "未找到示范角色")
            return {'CANCELLED'}
        if demo_shared_with_another_scene(context.scene, [arm]):
            self.report({'WARNING'}, T("Tracking nodes are used by another scene"))
            return {'CANCELLED'}
        if self.mode == 'SET':
            arm.location.x = self.offset_x
        elif self.mode == 'ADD':
            arm.location.x += self.offset_x
        context.view_layer.update()
        return {'FINISHED'}


class REBOCAP_OT_toggle_demo_character(bpy.types.Operator):
    bl_idname = "rebocap.toggle_demo_character"
    bl_label = T_static("导入示范角色")
    bl_description = T_static("一键导入/移除示范角色")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if is_demo_character_present(context.scene):
            if not remove_demo_character(context.scene):
                self.report({'WARNING'}, T("Tracking nodes are used by another scene"))
                return {'CANCELLED'}
            self.report({'INFO'}, "已移除示范角色")
            return {'FINISHED'}

        addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        fbx_path = os.path.join(addon_dir, 'assets', 'rebo_robot.fbx')
        
        if not os.path.exists(fbx_path):
            self.report({'ERROR'}, f"未找到示范角色模型文件: {fbx_path}")
            return {'CANCELLED'}

        # 确保场景中已有追踪节点数据
        tracking_root = context.scene.objects.get('Rebocap_Root')
        rest = tracking_root.get('rebocap_rest_positions') if tracking_root else None
        if not context.scene.objects.get('Rebocap_Pelvis') or rest is None or len(rest) != 72:
            if preview_active(context.scene):
                self.report({'WARNING'}, T("Exit A2T preview before importing the demo character"))
                return {'CANCELLED'}
            try:
                rebocap = context.scene.rebocap_bone_map
                if rebocap.sk_upper_leg <= 0.001:
                    cfg_path = rebocap.ik_config_path or find_rebocap_config_path()
                    if cfg_path and os.path.exists(cfg_path):
                        parse_and_update_ik_config(cfg_path, rebocap, None)
                if bpy.ops.rebocap.create_tracking_nodes() != {'FINISHED'}:
                    return {'CANCELLED'}
                tracking_root = context.scene.objects.get('Rebocap_Root')
                rest = tracking_root.get('rebocap_rest_positions') if tracking_root else None
                if not context.scene.objects.get('Rebocap_Pelvis') or rest is None or len(rest) != 72:
                    self.report({'WARNING'}, T("Please load valid skeleton dimensions"))
                    return {'CANCELLED'}
                bpy.context.view_layer.update()
            except Exception as e:
                print(f"[Rebocap] auto generate tracking nodes notice: {e}")
                self.report({'ERROR'}, str(e))
                return {'CANCELLED'}

        # 确保处于物体模式，防止在姿态/编辑模式下导入报错
        if context.object and context.object.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        # 取消选择场景已有物体
        for obj in list(context.selected_objects):
            obj.select_set(False)

        objects_before = set(bpy.data.objects)
        try:
            bpy.ops.import_scene.fbx(filepath=fbx_path)
        except Exception as e:
            _remove_demo_objects([obj for obj in bpy.data.objects if obj not in objects_before])
            self.report({'ERROR'}, f"导入示范角色失败: {e}")
            return {'CANCELLED'}

        imported_objs = [obj for obj in bpy.data.objects if obj not in objects_before]
        armature_obj = None
        mesh_objs = []

        for obj in imported_objs:
            obj["rebocap_demo_character"] = True
            if obj.type == 'ARMATURE':
                armature_obj = obj
                obj.name = "Rebo_Official_Demo_Character"
            elif obj.type == 'MESH':
                mesh_objs.append(obj)
                obj.name = "Rebo_Official_Demo_Mesh"

        if armature_obj:
            # 1. 统一应用旋转与缩放变换，保证模型以标准 1.0 比例直立在世界空间
            bpy.ops.object.select_all(action='DESELECT')
            armature_obj.select_set(True)
            for m in mesh_objs:
                m.select_set(True)
            context.view_layer.objects.active = armature_obj
            
            try:
                area = None
                window = None
                for w in context.window_manager.windows:
                    for a in w.screen.areas:
                        if a.type == 'VIEW_3D':
                            area = a
                            window = w
                            break
                    if area: break
                    
                if hasattr(context, "temp_override") and area:
                    with context.temp_override(window=window, area=area):
                        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
                else:
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            except Exception as e:
                print(f"[Rebocap] transform_apply notice: {e}")
                
            bpy.context.view_layer.update()

            # 2. 执行改版方案一（独立缩放隔离法自适应）
            try:
                adapt_demo_character_scale_isolated(armature_obj)
            except Exception as e:
                _remove_demo_objects(imported_objs)
                self.report({'ERROR'}, f"{T('Could not adapt demo character')}: {e}")
                return {'CANCELLED'}

            # 3. 默认偏开右侧 2m，避免遮挡中心的主模型或追踪节点
            armature_obj.location.x = 2.0
            bpy.context.view_layer.update()

            self.report({'INFO'}, "示范角色已成功载入（默认偏开右侧 2m）")
            return {'FINISHED'}
        else:
            _remove_demo_objects(imported_objs)
            self.report({'WARNING'}, "未能在导入的模型中找到骨架")
            return {'CANCELLED'}
