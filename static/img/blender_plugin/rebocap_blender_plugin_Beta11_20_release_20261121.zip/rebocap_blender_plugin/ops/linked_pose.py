"""Persist fully linked runtime channels in the owning user project.

Native ID pointers identify the object/data; immutable library bytes and rest
structure qualify bone names. This supplements Pose channels, never animation
or constraints, and is applied only during loading, before current-frame solve.
"""
import json
import math
import bpy

last_error = ''
_POSE_ERRORS = (ValueError, TypeError, KeyError, IndexError, AttributeError, ReferenceError, RuntimeError)


class REBOCAP_PG_linked_pose(bpy.types.PropertyGroup):
    target: bpy.props.PointerProperty(type=bpy.types.Object)
    armature: bpy.props.PointerProperty(type=bpy.types.Armature)
    object_hash: bpy.props.StringProperty()
    data_hash: bpy.props.StringProperty()
    structure: bpy.props.StringProperty()
    channels: bpy.props.StringProperty()


def channels(obj):
    return {'matrix': [list(r) for r in obj.matrix_basis],
            'bones': [[b.name, b.rotation_mode, list(b.location), list(b.rotation_quaternion),
                       list(b.rotation_euler), list(b.rotation_axis_angle), list(b.scale)]
                      for b in obj.pose.bones]}


def _validate(obj, data):
    def vector(value, length):
        if (not isinstance(value, list) or len(value) != length or
                any(type(v) not in (int, float) or not math.isfinite(v) for v in value)):
            raise ValueError('Invalid linked pose channels')
    matrix, bones = data['matrix'], data['bones']
    if len(matrix) != 4:
        raise ValueError('Invalid linked pose matrix')
    for row in matrix:
        vector(row, 4)
    if [b[0] for b in bones] != [b.name for b in obj.pose.bones]:
        raise ValueError('Linked pose bones cannot be identified')
    modes = {item.identifier for item in bpy.types.PoseBone.bl_rna.properties['rotation_mode'].enum_items}
    for bone in bones:
        if len(bone) != 7 or bone[1] not in modes:
            raise ValueError('Invalid linked pose channels')
        for value, size in zip(bone[2:], (3, 4, 3, 4, 3)):
            vector(value, size)


def _apply(obj, data):
    obj.matrix_basis = data['matrix']
    for name, mode, location, quaternion, euler, axis, scale in data['bones']:
        bone = obj.pose.bones[name]
        bone.rotation_mode = mode
        bone.location, bone.rotation_quaternion = location, quaternion
        bone.rotation_euler, bone.rotation_axis_angle, bone.scale = euler, axis, scale


def _report_failures(errors):
    global last_error
    last_error = '; '.join(errors)
    if not errors:
        return
    from .library_recovery import _status
    _status('Linked pose preservation failed')
    print('[Rebocap] Linked pose preservation failed:', last_error)


def _identity(obj, hashes):
    from . import history

    def fingerprint(id_data):
        library = history.linked_library(id_data)
        if library not in hashes:
            hashes[library] = history._linked_library_hash(id_data, refresh=True)
        return hashes[library]

    if (obj.is_missing or obj.type != 'ARMATURE' or not obj.library or obj.override_library
            or not obj.data or obj.data.is_missing):
        raise ValueError('Linked pose library is unavailable')
    object_hash, data_hash = fingerprint(obj), fingerprint(obj.data)
    if not object_hash or not data_hash:
        raise ValueError('Linked pose library is unavailable')
    return object_hash, data_hash, history.linked_structure_signature(obj.data)


def _matches(item, obj, identity):
    return (item.armature == obj.data and
            (item.object_hash, item.data_hash, item.structure) == identity)


@bpy.app.handlers.persistent
def capture_for_save(_=None):
    """Update healthy objects while retaining the last carrier of a failed one."""
    errors, hashes, snapshots = [], {}, {}
    for scene in bpy.data.scenes:
        if scene.library:
            continue
        poses = scene.rebocap_linked_poses
        members = set(scene.objects)
        for index in reversed(range(len(poses))):
            target = poses[index].target
            if target not in members:
                poses.remove(index)
        previous = {item.target: item for item in poses}
        for obj in scene.objects:
            old = previous.get(obj)
            if not old and (obj.type != 'ARMATURE' or not obj.library or obj.override_library):
                continue
            try:
                if obj not in snapshots:
                    identity = _identity(obj, hashes)
                    value = channels(obj)
                    _validate(obj, value)
                    snapshots[obj] = identity, json.dumps(value, allow_nan=False, separators=(',', ':'))
                identity, payload = snapshots[obj]
                if old and not _matches(old, obj, identity):
                    raise ValueError('Linked pose library changed; retain its previous identity')
                if old:
                    old.channels = payload
                else:
                    item = poses.add()
                    item.target, item.armature = obj, obj.data
                    item.object_hash, item.data_hash, item.structure = identity
                    item.channels = payload
            except _POSE_ERRORS as error:
                errors.append(f'{obj.name}: {error}')
    _report_failures(errors)


def has_saved_pose():
    return any(len(s.rebocap_linked_poses) for s in bpy.data.scenes if not s.library)


def restore():
    """Validate and apply once per object across all of its scenes."""
    targets, hashes, errors = {}, {}, []
    for scene in bpy.data.scenes:
        if scene.library:
            continue
        members = set(scene.objects)
        for item in scene.rebocap_linked_poses:
            obj = item.target
            if obj in members:
                targets.setdefault(obj, []).append(item)
            else:
                errors.append(f'{scene.name}: Saved linked pose target is unavailable')
    applied = False
    for obj, items in targets.items():
        try:
            identity = _identity(obj, hashes)
            if not all(_matches(item, obj, identity) for item in items):
                raise ValueError('Saved linked pose identity cannot be confirmed')
            data = None
            for item in items:
                value = json.loads(item.channels)
                _validate(obj, value)
                if data is not None and data != value:
                    raise ValueError('Shared linked pose has conflicting saved channels')
                data = value
            before = channels(obj)
            try:
                _apply(obj, data)
            except _POSE_ERRORS:
                _apply(obj, before)
                raise
            applied = True
        except _POSE_ERRORS as error:
            errors.append(f'{obj.name}: {error}')
    _report_failures(errors)
    return applied


def register():
    bpy.utils.register_class(REBOCAP_PG_linked_pose)
    bpy.types.Scene.rebocap_linked_poses = bpy.props.CollectionProperty(type=REBOCAP_PG_linked_pose)


def unregister():
    del bpy.types.Scene.rebocap_linked_poses
    bpy.utils.unregister_class(REBOCAP_PG_linked_pose)
