"""Apply controlled transforms ahead of the rig's authored constraints."""

import bpy


_OWNER = '_rebocap_channel_pose_owner'
_NAME = '_ReboCap_Channel_Pose'


def _targets(obj):
    yield obj
    if obj.pose is not None:
        yield from obj.pose.bones


def _remove_constraints(obj, helpers=None, *, foreign=False):
    if not getattr(obj, 'is_editable', obj.library is None):
        return
    for target in _targets(obj):
        for constraint in tuple(target.constraints):
            if (not constraint.name.startswith(_NAME) or
                    constraint.type not in {'COPY_ROTATION', 'COPY_LOCATION'}):
                continue
            source = constraint.target
            if helpers is not None:
                remove = source in helpers
            else:
                remove = source is None or (_OWNER in source and
                                             (not foreign or source[_OWNER] != obj))
            if remove:
                target.constraints.remove(constraint)


def release_copied_constraints(obj):
    _remove_constraints(obj, foreign=True)


def restore_saved_pose_layers():
    # Blender's undo and auto-save snapshots can bypass the normal save hooks.
    for obj in tuple(bpy.data.objects):
        _remove_constraints(obj)
    for helper in tuple(bpy.data.objects):
        if _OWNER in helper:
            bpy.data.objects.remove(helper, do_unlink=True)


class ChannelPose:
    def __init__(self, scene):
        self.scene = scene
        self.paths = {}
        self.helpers = {}
        self.constraints = {}
        self.values = {}

    def _helper(self, obj):
        helper = self.helpers.get(obj)
        if helper is not None:
            return helper
        # A newly linked armature has no Pose until Blender updates relations.
        # Copy the object to obtain a Pose even inside a frame-change callback.
        helper = obj.copy() if obj.type == 'ARMATURE' else bpy.data.objects.new(_NAME, None)
        try:
            helper.name = _NAME
            helper.animation_data_clear()
            helper.parent = None
            helper.modifiers.clear()
            for target in _targets(helper):
                for constraint in tuple(target.constraints):
                    target.constraints.remove(constraint)
            for key in tuple(helper.keys()):
                del helper[key]
            helper[_OWNER] = obj
            helper.hide_render = True
            helper.hide_select = True
            helper.hide_viewport = True
            self.scene.collection.objects.link(helper)
            self.helpers[obj] = helper
            return helper
        except Exception:
            bpy.data.objects.remove(helper, do_unlink=True)
            raise

    def write(self, target, prop, value):
        obj = target.id_data
        paths = self.paths.get(obj)
        if not paths:
            return False
        if prop == 'rotation_quaternion' and isinstance(target, bpy.types.PoseBone):
            # Euler, axis-angle and mode animation can affect the same rotation.
            claims = ('rotation_quaternion', 'rotation_euler', 'rotation_axis_angle', 'rotation_mode')
        else:
            claims = (prop,)
        if not any(target.path_from_id(claim) in paths for claim in claims):
            return False

        helper = self._helper(obj)
        is_bone = isinstance(target, bpy.types.PoseBone)
        source = helper.pose.bones[target.name] if is_bone else helper
        key = (target, prop)
        if prop == 'rotation_quaternion':
            source.rotation_mode = 'QUATERNION'
        setattr(source, prop, value)

        name = self.constraints.get(key)
        constraint = target.constraints.get(name) if name else None
        if constraint is None or constraint.target != helper:
            kind = 'COPY_ROTATION' if prop == 'rotation_quaternion' else 'COPY_LOCATION'
            constraint = target.constraints.new(kind)
            try:
                constraint.name = _NAME
                constraint.target = helper
                if is_bone:
                    constraint.subtarget = target.name
                constraint.owner_space = 'LOCAL'
                constraint.target_space = 'LOCAL'
                target.constraints.move(len(target.constraints) - 1, 0)
                self.constraints[key] = constraint.name
            except Exception:
                target.constraints.remove(constraint)
                raise
        self.values[key] = value.copy()
        return True

    def set_paths(self, paths):
        # Once a property has moved to the layer, keep it there until release.
        # Removing/recreating constraints mid-session would expose the base pose
        # between changes to a curve's binding or path.
        self.paths = paths
        for target, prop in self.values:
            try:
                self.paths.setdefault(target.id_data, set()).add(target.path_from_id(prop))
            except ReferenceError:
                continue

    def sample(self, target, prop):
        value = self.values.get((target, prop))
        return tuple(value if value is not None else getattr(target, prop))

    def clear(self):
        helpers = set(self.helpers.values())
        if helpers:
            for obj in tuple(bpy.data.objects):
                _remove_constraints(obj, helpers)
            for helper in helpers:
                try:
                    bpy.data.objects.remove(helper, do_unlink=True)
                except ReferenceError:
                    continue
        self.helpers.clear()
        self.constraints.clear()

    def resume(self):
        values = self.values
        self.values = {}
        for (target, prop), value in values.items():
            try:
                self.write(target, prop, value)
            except ReferenceError:
                continue
