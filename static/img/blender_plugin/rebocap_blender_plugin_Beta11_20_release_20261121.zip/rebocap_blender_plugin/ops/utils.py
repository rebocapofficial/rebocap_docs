import bpy


def _is_rebocap_baked(action):
    return bool(action and (action.get('rebocap_baked') or action.name.startswith('rebocap_baked_')))


def _action_curves_for_slots(action, slot_ids):
    """Do not alter other objects' channel bags in a shared slotted Action."""
    if not hasattr(action, 'slots'):
        yield from action.fcurves
        return
    for layer in action.layers:
        for strip in layer.strips:
            bags = getattr(strip, 'channelbags', ())
            for bag in bags:
                slot = getattr(bag, 'slot', None)
                if slot is not None and slot.identifier in slot_ids:
                    yield from bag.fcurves


def nla_adaptation_issue(obj):
    """Reject NLA compositions for which changing clip keys is not equivalent."""
    ad = obj.animation_data
    if not ad:
        return None
    strips = [strip for track in ad.nla_tracks for strip in track.strips]
    def contains_baked(strip):
        return (_is_rebocap_baked(getattr(strip, 'action', None)) or
                any(contains_baked(child) for child in getattr(strip, 'strips', ())))
    if not strips or not (_is_rebocap_baked(ad.action) or any(contains_baked(strip) for strip in strips)):
        return None
    if getattr(ad, 'use_tweak_mode', False):
        return 'NLA tweak mode'
    if ad.action and (not _is_rebocap_baked(ad.action) or
                      getattr(ad, 'action_blend_type', 'REPLACE') != 'REPLACE' or
                      abs(getattr(ad, 'action_influence', 1.0) - 1.0) > 1e-6):
        return 'mixed active action'
    if any(driver.data_path == 'location' or driver.data_path.endswith('.location') or
           driver.data_path == 'scale' or driver.data_path.endswith('.scale') for driver in ad.drivers):
        return 'driven transform channels'
    for strip in strips:
        if (strip.type != 'CLIP' or not _is_rebocap_baked(strip.action) or
                strip.blend_type != 'REPLACE' or
                getattr(strip, 'use_animated_influence', False) or
                getattr(strip, 'use_auto_blend', False) or
                strip.blend_in > 1e-6 or strip.blend_out > 1e-6):
            return 'mixed, blended, or non-clip NLA strip'
        if hasattr(strip.action, 'slots') and getattr(strip, 'action_slot', None) is None:
            return 'unbound action slot'
    from .rebocap_connection import _action_iter_fcurves
    owners = list(strips)
    if ad.action:
        owners.append(ad)
    for owner in owners:
        action = owner.action
        slot = getattr(owner, 'action_slot', None)
        if hasattr(action, 'slots') and len(action.slots):
            if slot is None:
                return 'unbound action slot'
            curves = _action_curves_for_slots(action, {slot.identifier})
        else:
            curves = _action_iter_fcurves(action)
        for curve in curves:
            if (curve.data_path == 'location' or curve.data_path.endswith('.location') or
                    curve.data_path == 'scale' or curve.data_path.endswith('.scale')):
                if len(curve.modifiers) or len(curve.sampled_points):
                    return 'modified or sampled animation curves'
    return None


def adjust_baked_action(obj, changes):
    """Adjust copies of the active action and supported plugin-baked NLA clips."""
    ad = obj.animation_data
    if not ad:
        return False
    changes = {key: change for key, change in changes.items()
               if abs(change[1] - (1.0 if change[0] == 'multiply' else 0.0)) > 1e-7}
    if not changes:
        return False
    issue = nla_adaptation_issue(obj)
    if issue:
        raise ValueError('Unsupported NLA on %s: %s' % (obj.name, issue))
    owners = []
    if _is_rebocap_baked(ad.action):
        owners.append(ad)
    for track in ad.nla_tracks:
        for strip in track.strips:
            if _is_rebocap_baked(getattr(strip, 'action', None)):
                owners.append(strip)
    slots_by_action = {}
    for owner in owners:
        action = owner.action
        slot = getattr(owner, 'action_slot', None)
        if hasattr(action, 'slots') and slot is None:
            raise ValueError('Unbound action slot on %s' % obj.name)
        slots_by_action.setdefault(action, set()).add(slot.identifier if slot else None)
    copies, previous = {}, []
    try:
        for owner in owners:
            action = owner.action
            if action not in copies:
                if not any((curve.data_path, curve.array_index) in changes
                           for curve in _action_curves_for_slots(action, slots_by_action[action])):
                    copies[action] = None
                    continue
                updated = action.copy()
                updated.use_fake_user = True
                updated['rebocap_baked'] = True
                copies[action] = updated
                for curve in _action_curves_for_slots(updated, slots_by_action[action]):
                    change = changes.get((curve.data_path, curve.array_index))
                    if not change:
                        continue
                    op, value = change
                    for point in curve.keyframe_points:
                        for coordinate in (point.co, point.handle_left, point.handle_right):
                            coordinate.y = coordinate.y * value if op == 'multiply' else coordinate.y + value
                    curve.update()
                if action.library is None:
                    action.use_fake_user = True
            updated = copies[action]
            if updated is None:
                continue
            slot = getattr(owner, 'action_slot', None)
            slot_id = slot.identifier if slot else None
            previous.append((owner, action, slot))
            owner.action = updated
            if slot_id and hasattr(owner, 'action_slot'):
                new_slot = next((item for item in updated.slots if item.identifier == slot_id), None)
                if new_slot is not None:
                    owner.action_slot = new_slot
        return bool(previous)
    except Exception:
        for owner, action, slot in reversed(previous):
            owner.action = action
            if slot is not None and hasattr(owner, 'action_slot'):
                owner.action_slot = slot
        for updated in copies.values():
            if updated is not None:
                bpy.data.actions.remove(updated)
        raise


def show_message_box(message="", title="Message Box", icon='INFO'):
    # Blender's popup API can crash natively when there is no UI, so do not
    # call it from background scripts or file-load handlers in that mode.
    if bpy.app.background:
        print(f'[{title}] {message}')
        return
    def draw(self, context):
        for line in str(message).split('\n'):
            if line:
                self.layout.label(text=line)
            else:
                self.layout.separator()

    try:
        wm = getattr(bpy.context, 'window_manager', None)
        if wm:
            wm.popup_menu(draw, title=title, icon=icon)
    except Exception:
        pass


def restore_rotation_mode(bone, mode):
    if bone.rotation_mode == mode:
        return
    prop = {'QUATERNION': 'rotation_quaternion', 'AXIS_ANGLE': 'rotation_axis_angle'}.get(
        mode, 'rotation_euler')
    # Blender converts the displayed rotation when changing mode. Restore
    # the destination channel afterward so unkeyed components stay authored.
    rotation = tuple(getattr(bone, prop))
    bone.rotation_mode = mode
    setattr(bone, prop, rotation)
