"""Keep conflicting drivers available while a baked action owns their output."""

import json
import bpy
from bpy.app.handlers import persistent

_MARKER = '_rebocap_baked_driver_controls'
_OWNED = '_rebocap_baked_driver_owned'
_updating = False


def _uses_action(obj, action, handle, scene):
    animation = obj.animation_data
    if not animation:
        return False
    current = animation.action
    if current is not None:
        original = current.get('_rebocap_recording_original')
        slot = getattr(animation, 'action_slot', None)
        if (current == action or original == action) and (not handle or (slot and slot.handle == handle)):
            return True
    for track in animation.nla_tracks:
        if track.mute:
            continue
        for strip in track.strips:
            slot = getattr(strip, 'action_slot', None)
            frame = scene.frame_current + scene.frame_subframe if scene else None
            if frame is not None:
                extrapolation = getattr(strip, 'extrapolation', 'HOLD')
                if extrapolation in {'NOTHING', 'HOLD_FORWARD'} and frame < strip.frame_start:
                    continue
                if extrapolation == 'NOTHING' and frame > strip.frame_end:
                    continue
            if (not strip.mute and strip.action == action and
                    (not handle or (slot and slot.handle == handle))):
                return True
    return False


def synchronize(scene=None):
    global _updating
    if _updating or not hasattr(bpy.data, 'objects'):
        return
    scene = scene or getattr(bpy.context, 'scene', None)
    _updating = True
    try:
        for obj in bpy.data.objects:
            if _MARKER not in obj or not obj.animation_data:
                continue
            owned = {}
            for record in obj[_MARKER]:
                action = record.get('action')
                active = action is not None and _uses_action(obj, action, record.get('slot', 0), scene)
                for entry in record['drivers']:
                    key = (entry['path'], entry['index'])
                    owned[key] = owned.get(key, False) or active
            owned_before = {tuple(entry) for entry in json.loads(obj.get(_OWNED, '[]'))}
            owned_after = set(owned_before)
            present = {(item.data_path, item.array_index) for item in obj.animation_data.drivers}
            owned_after.intersection_update(present)
            for driver in obj.animation_data.drivers:
                key = (driver.data_path, driver.array_index)
                active = owned.get((driver.data_path, driver.array_index))
                if active:
                    if driver.is_valid:
                        driver.is_valid = False
                        obj.update_tag()
                        owned_after.add(key)
                elif key in owned_before:
                    if not driver.is_valid:
                        driver.is_valid = True
                        obj.update_tag()
                    owned_after.discard(key)
            if owned_after != owned_before:
                if owned_after:
                    obj[_OWNED] = json.dumps(sorted(owned_after))
                elif _OWNED in obj:
                    del obj[_OWNED]
    finally:
        _updating = False


def remember(obj, action, paths):
    if not obj.animation_data:
        return
    previously_owned = {(entry['path'], entry['index']) for record in obj.get(_MARKER, ())
                        for entry in record['drivers']}
    drivers = [{'path': curve.data_path, 'index': curve.array_index}
               for curve in obj.animation_data.drivers
               if curve.data_path in paths and
               (curve.is_valid or (curve.data_path, curve.array_index) in previously_owned)]
    if not drivers:
        return
    old = list(obj.get(_MARKER, ()))
    records = [entry.to_dict() if hasattr(entry, 'to_dict') else entry for entry in old]
    slot = getattr(obj.animation_data, 'action_slot', None)
    records.append({'action': action, 'slot': slot.handle if slot else 0, 'drivers': drivers})
    obj[_MARKER] = records


@persistent
def on_update(*args):
    scene = args[0] if args and isinstance(args[0], bpy.types.Scene) else getattr(bpy.context, 'scene', None)
    synchronize(scene)


def register():
    for handlers in (bpy.app.handlers.frame_change_pre, bpy.app.handlers.depsgraph_update_pre,
                     bpy.app.handlers.load_post, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if on_update not in handlers:
            handlers.append(on_update)
    synchronize()


def unregister():
    for handlers in (bpy.app.handlers.frame_change_pre, bpy.app.handlers.depsgraph_update_pre,
                     bpy.app.handlers.load_post, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if on_update in handlers:
            handlers.remove(on_update)
    for obj in bpy.data.objects:
        if _OWNED in obj and obj.animation_data:
            keys = {tuple(entry) for entry in json.loads(obj[_OWNED])}
            for driver in obj.animation_data.drivers:
                if (driver.data_path, driver.array_index) in keys and not driver.is_valid:
                    driver.is_valid = True
                    obj.update_tag()
            del obj[_OWNED]
