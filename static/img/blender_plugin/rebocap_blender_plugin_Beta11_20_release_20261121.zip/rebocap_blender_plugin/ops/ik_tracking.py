import bpy
import os
import pickle
import subprocess
from mathutils import Vector
from .utils import show_message_box, adjust_baked_action, nla_adaptation_issue
from ..core.translation import T
from ..core.a2t_types import preview_active

def _find_running_rebocap_dir():
    """Ultra-fast native Windows process detection (0.001s, 0 subprocesses, 0 lag)."""
    try:
        import ctypes, ctypes.wintypes
        kernel32 = ctypes.windll.kernel32
        hSnap = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
        if hSnap == -1: return ""

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [
                ('dwSize', ctypes.wintypes.DWORD),
                ('cntUsage', ctypes.wintypes.DWORD),
                ('th32ProcessID', ctypes.wintypes.DWORD),
                ('th32DefaultHeapID', ctypes.c_void_p),
                ('th32ModuleID', ctypes.wintypes.DWORD),
                ('cntThreads', ctypes.wintypes.DWORD),
                ('th32ParentProcessID', ctypes.wintypes.DWORD),
                ('pcPriClassBase', ctypes.c_long),
                ('dwFlags', ctypes.wintypes.DWORD),
                ('szExeFile', ctypes.c_wchar * 260)
            ]

        pe = PROCESSENTRY32W()
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        exe_dir = ""
        if kernel32.Process32FirstW(hSnap, ctypes.byref(pe)):
            while True:
                if pe.szExeFile.lower() == 'rebocap.exe':
                    hProc = kernel32.OpenProcess(0x1000, False, pe.th32ProcessID)
                    if hProc:
                        buf = ctypes.create_unicode_buffer(1024)
                        size = ctypes.wintypes.DWORD(1024)
                        if kernel32.QueryFullProcessImageNameW(hProc, 0, buf, ctypes.byref(size)):
                            exe_dir = os.path.dirname(buf.value)
                        kernel32.CloseHandle(hProc)
                    break
                if not kernel32.Process32NextW(hSnap, ctypes.byref(pe)):
                    break
        kernel32.CloseHandle(hSnap)
        return exe_dir
    except Exception:
        return ""


def find_rebocap_config_path():
    """Tries zero-latency candidate paths and native process detection to find rebocap config.data."""
    # 1. Standard candidate installation & AppData paths (instant <0.1ms)
    candidates = [
        # User AppData / LocalLow
        os.path.join(os.environ.get('APPDATA', ''), '..', 'LocalLow', 'RebornTechnology', 'Rebocap', 'config.data'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'Rebocap', 'data', 'config.data'),
        os.path.join(os.environ.get('PROGRAMFILES', ''), 'Rebocap', 'data', 'config.data'),
        os.path.join(os.environ.get('ProgramFiles(x86)', ''), 'Rebocap', 'data', 'config.data'),
        # Common local installation drives
        r"D:\rebocap\Rebocap test\Rebocap\data\config.data",
        r"D:\rebocap\Rebocap\data\config.data",
        r"D:\Rebocap\data\config.data",
        r"C:\Rebocap\data\config.data",
        r"E:\Rebocap\data\config.data",
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return os.path.abspath(c)

    # 2. If not in default paths, check running rebocap.exe directory via native Windows API (0 subprocesses)
    running_dir = _find_running_rebocap_dir()
    if running_dir:
        p = os.path.join(running_dir, "data", "config.data")
        if os.path.exists(p):
            return os.path.abspath(p)

    return ""

get_rebocap_config_path = find_rebocap_config_path

_SKELETON_CONFIG_FIELDS = (
    'sk_upper_arm', 'sk_lower_arm', 'sk_upper_leg', 'sk_lower_leg',
    'sk_spine', 'sk_chest', 'sk_shoulder_width', 'sk_hip_width',
    'sk_hip_height', 'sk_neck_head', 'sk_foot', 'sk_ankle',
    'sk_final_height', 'sk_skeleton_ratio', 'sk_use_imported',
)


def may_auto_detect_config(scene):
    """Only discover another host's configuration for an empty scene."""
    props = scene.rebocap_bone_map
    if props.ik_config_path or scene.objects.get('Rebocap_Root'):
        return False
    return not any(getattr(props, name) != props.bl_rna.properties[name].default
                   for name in _SKELETON_CONFIG_FIELDS)


def _snapshot_configuration(scene):
    from copy import deepcopy
    props = scene.rebocap_bone_map
    fields = ('ik_config_path',) + _SKELETON_CONFIG_FIELDS
    pending_keys = ('rebocap_pending_import_positions', 'rebocap_pending_import_feet',
                    'rebocap_pending_import_source')
    pending = {key: (list(scene[key]) if hasattr(scene[key], 'to_list') else scene[key])
               for key in pending_keys if key in scene}
    return ({name: (props.is_property_set(name), getattr(props, name)) for name in fields},
            deepcopy(cached_imported_positions), deepcopy(cached_imported_foot_vertices),
            _cached_imported_owner, scene.rebocap_tracking_refresh_pending, pending)


def _restore_configuration(scene, snapshot):
    global cached_imported_positions, cached_imported_foot_vertices, _cached_imported_owner
    fields, cached_imported_positions, cached_imported_foot_vertices, _cached_imported_owner, pending, values = snapshot
    props = scene.rebocap_bone_map
    for name, (was_set, value) in fields.items():
        if was_set:
            setattr(props, name, value)
        elif props.is_property_set(name):
            props.property_unset(name)
    scene.rebocap_tracking_refresh_pending = pending
    for key in ('rebocap_pending_import_positions', 'rebocap_pending_import_feet',
                'rebocap_pending_import_source'):
        if key in values:
            scene[key] = values[key]
        elif key in scene:
            del scene[key]


def read_and_sync_config(scene, path, *, read=None, sync=None):
    """Commit a configuration only when both parsing and refresh succeed."""
    read = read or parse_and_update_ik_config
    sync = sync or sync_tracking_nodes
    snapshot = _snapshot_configuration(scene)
    committed = False
    try:
        if not read(path, scene.rebocap_bone_map, None):
            return 'READ_ERROR'
        scene.rebocap_bone_map.ik_config_path = path
        if not sync(scene):
            return 'SYNC_ERROR'
        committed = True
        return 'OK'
    finally:
        if not committed:
            _restore_configuration(scene, snapshot)


class REBOCAP_OT_auto_detect_config(bpy.types.Operator):
    bl_idname = "rebocap.auto_detect_config"
    bl_label = "Auto Detect Config Path"
    bl_description = "Automatically detect rebocap configuration path and load skeleton data"

    def execute(self, context):
        config_path = find_rebocap_config_path()
        if config_path and os.path.exists(config_path):
            try:
                status = read_and_sync_config(context.scene, config_path)
                if status != 'OK':
                    message = ('Unable to read skeleton configuration' if status == 'READ_ERROR'
                               else 'Unable to update tracking nodes')
                    self.report({'WARNING'}, T(message))
                    return {'CANCELLED'}
            except Exception as error:
                self.report({'ERROR'}, str(error))
                return {'CANCELLED'}
            self.report({'INFO'}, f"Auto-detected and loaded config: {config_path}")
            return {'FINISHED'}
        else:
            show_message_box("Could not automatically locate rebocap config.data. Please select manually.", icon='ERROR')
            return {'CANCELLED'}


# Global cache for imported skeleton positions
cached_imported_positions = None
cached_imported_foot_vertices = None
_cached_imported_owner = None


def _imported_cache_key(scene, path):
    return (scene.as_pointer(), os.path.normcase(os.path.abspath(path)) if path else '')


def clear_imported_cache():
    global cached_imported_positions, cached_imported_foot_vertices, _cached_imported_owner
    cached_imported_positions = None
    cached_imported_foot_vertices = None
    _cached_imported_owner = None

class REBOCAP_OT_read_config_data(bpy.types.Operator):
    bl_idname = "rebocap.read_config_data"
    bl_label = "Read Bone Lengths"
    bl_description = "Read IK skeleton scale settings from config.data"
    
    def execute(self, context):
        rebocap = context.scene.rebocap_bone_map
        path = rebocap.ik_config_path
        if not path:
            path = find_rebocap_config_path()
        try:
            status = read_and_sync_config(context.scene, path)
            if status == 'OK':
                self.report({'INFO'}, "Config updated from Rebocap")
                return {'FINISHED'}
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        message = ('Unable to read skeleton configuration' if status == 'READ_ERROR'
                   else 'Unable to update tracking nodes')
        self.report({'WARNING'}, T(message))
        return {'CANCELLED'}

def parse_and_update_ik_config(path, rebocap_props, operator=None):
    global cached_imported_positions, cached_imported_foot_vertices, _cached_imported_owner
    if not path or not os.path.exists(path):
        if operator:
            show_message_box("Config path is invalid or file does not exist!", icon='ERROR')
        return False
        
    try:
        with open(path, 'rb') as f:
            data = f.read()

        # Validate the complete outer pickle without executing it. Some host
        # versions leave bytes from an older write after the STOP opcode.
        import pickletools
        stop = None
        for opcode, _value, position in pickletools.genops(data):
            if opcode.name == 'STOP':
                stop = position
        if stop is None:
            raise ValueError("Incomplete skeleton configuration")
        data = data[:stop + 1]

        import struct
        sk = {}
        
        # 1. Check if switch_use_skeleton_data is True
        use_imported = False
        idx_switch = data.find(b'switch_use_skeleton_data')
        if idx_switch != -1:
            switch_bytes = data[idx_switch+24:idx_switch+30]
            # \x88 is True, K\x01 is int 1, \x89 is False, K\x00 is int 0
            if b'\x88' in switch_bytes or b'K\x01' in switch_bytes:
                use_imported = True
                
        positions = None
        foot_vertices = None
        
        if use_imported:
            import base64
            import pickle
            import sys
            import types
            import math
            
            # Mock the SkeletonData class
            if 'common' not in sys.modules:
                class MockSkeletonData: pass
                m = types.ModuleType('common')
                m.config = types.ModuleType('config')
                m.config.SkeletonData = MockSkeletonData
                sys.modules['common'] = m
                sys.modules['common.config'] = m.config
                
            idx_import = data.find(b'import_skeleton_data')
            if idx_import != -1:
                s = data[idx_import+20:]
                x = s.find(b'X')
                if x != -1:
                    length = struct.unpack('<I', s[x+1:x+5])[0]
                    b64_str = s[x+5:x+5+length]
                    dec = base64.b64decode(b64_str)
                    obj = pickle.loads(dec)
                    positions = getattr(obj, 'skeleton_positions', None)
                    foot_vertices = getattr(obj, 'foot_vertex_positions', None)
                    
                    if positions and len(positions) >= 24:
                        def dist(i, j):
                            p1, p2 = positions[i], positions[j]
                            return math.sqrt(sum((a-b)**2 for a,b in zip(p1, p2))) * 100
                            
                        sk[b'skeleton_upper_arm'] = dist(16, 18)
                        sk[b'skeleton_lower_arm'] = dist(18, 20)
                        sk[b'skeleton_upper_leg_len'] = dist(1, 4)
                        sk[b'skeleton_lower_leg_len'] = dist(4, 7)
                        sk[b'skeleton_spine_len'] = dist(0, 9)
                        sk[b'skeleton_chest_len'] = dist(9, 12)
                        sk[b'skeleton_shoulder_width'] = dist(16, 17)
                        sk[b'skeleton_hip_width'] = dist(1, 2)
                        sk[b'skeleton_hip_height'] = dist(0, 1)
                        sk[b'skeleton_neck_and_head_len'] = dist(12, 15)
                        sk[b'skeleton_foot_len'] = dist(7, 10)
                        sk[b'skeleton_ankle_len'] = positions[7][1] * 100 if len(positions) > 7 else 9.0
        else:
            # Manual Mode: Strictly clear imported cache and read 12 manual parameters
            keys = [
                b'skeleton_upper_arm', b'skeleton_lower_arm', b'skeleton_upper_leg_len',
                b'skeleton_lower_leg_len', b'skeleton_spine_len', b'skeleton_chest_len',
                b'skeleton_shoulder_width', b'skeleton_hip_width', b'skeleton_hip_height',
                b'skeleton_neck_and_head_len', b'skeleton_foot_len', b'skeleton_ankle_len'
            ]
            for k in keys:
                idx = data.find(k)
                if idx != -1:
                    s = data[idx+len(k):idx+len(k)+15]
                    g = s.find(b'G')
                    if g != -1:
                        val = struct.unpack('>d', data[idx+len(k)+g+1 : idx+len(k)+g+9])[0]
                        sk[k] = val

        if not sk or (not use_imported and not all(key in sk for key in keys)):
            if operator:
                show_message_box("No skeleton data found in the config file!", icon='ERROR')
                operator.report({'ERROR'}, "No skeleton data found in the config file!")
            return False
            
        # Read final_height and skeleton_ratio
        for k in [b'final_height', b'skeleton_ratio']:
            idx = data.find(k)
            if idx != -1:
                s = data[idx+len(k):idx+len(k)+15]
                g = s.find(b'G')
                if g != -1:
                    sk[k] = struct.unpack('>d', data[idx+len(k)+g+1 : idx+len(k)+g+9])[0]

        import math
        if not all(math.isfinite(float(value)) for value in sk.values()):
            raise ValueError("Non-finite skeleton data")
        if sk[b'skeleton_upper_leg_len'] <= 0 or sk[b'skeleton_lower_leg_len'] <= 0:
            raise ValueError("Invalid skeleton leg lengths")
        if use_imported:
            if any(len(p) != 3 or not all(math.isfinite(float(v)) for v in p)
                   for p in positions[:24]):
                raise ValueError("Invalid imported skeleton positions")
            if foot_vertices is not None and any(
                    len(p) != 3 or not all(math.isfinite(float(v)) for v in p)
                    for p in foot_vertices):
                raise ValueError("Invalid imported foot positions")

        rebocap_props.sk_use_imported = use_imported
        rebocap_props.sk_upper_arm = float(sk.get(b'skeleton_upper_arm', 28.0))
        rebocap_props.sk_lower_arm = float(sk.get(b'skeleton_lower_arm', 28.0))
        rebocap_props.sk_upper_leg = float(sk.get(b'skeleton_upper_leg_len', 45.0))
        rebocap_props.sk_lower_leg = float(sk.get(b'skeleton_lower_leg_len', 45.0))
        rebocap_props.sk_spine = float(sk.get(b'skeleton_spine_len', 22.5))
        rebocap_props.sk_chest = float(sk.get(b'skeleton_chest_len', 19.0))
        rebocap_props.sk_shoulder_width = float(sk.get(b'skeleton_shoulder_width', 28.0))
        rebocap_props.sk_hip_width = float(sk.get(b'skeleton_hip_width', 20.0))
        rebocap_props.sk_hip_height = float(sk.get(b'skeleton_hip_height', 11.0))
        rebocap_props.sk_neck_head = float(sk.get(b'skeleton_neck_and_head_len', 17.0))
        rebocap_props.sk_foot = float(sk.get(b'skeleton_foot_len', 27.0))
        rebocap_props.sk_ankle = float(sk.get(b'skeleton_ankle_len', 9.0))
        rebocap_props.sk_final_height = float(sk.get(b'final_height', 180.0))
        rebocap_props.sk_skeleton_ratio = float(sk.get(b'skeleton_ratio', 1.0))
        
        if operator:
            operator.report({'INFO'}, f"Config updated from Rebocap")
            
        cached_imported_positions = positions if use_imported else None
        cached_imported_foot_vertices = foot_vertices if use_imported else None
        _cached_imported_owner = _imported_cache_key(rebocap_props.id_data, path) if use_imported else None
        return True
    except Exception as e:
        if operator:
            show_message_box(f"Failed to parse config: {str(e)}", icon='ERROR')
            operator.report({'ERROR'}, f"Failed to parse config: {str(e)}")
        return False

def skeleton_signature(props):
    """Compare static skeleton inputs, including imported joint and foot geometry."""
    names = ('sk_upper_arm', 'sk_lower_arm', 'sk_upper_leg', 'sk_lower_leg',
             'sk_spine', 'sk_chest', 'sk_shoulder_width', 'sk_hip_width',
             'sk_hip_height', 'sk_neck_head', 'sk_foot', 'sk_ankle',
             'sk_skeleton_ratio', 'sk_use_imported')
    values = tuple(getattr(props, name) for name in names)
    if props.sk_use_imported:
        def freeze(points):
            return None if points is None else tuple(tuple(float(v) for v in p) for p in points)
        values += (freeze(cached_imported_positions), freeze(cached_imported_foot_vertices))
    return values


def applied_skeleton_signature(props):
    """Stable fingerprint of the static inputs used to build tracking nodes."""
    import hashlib
    import json

    def normalize(value):
        if isinstance(value, float):
            return round(value, 6)
        if isinstance(value, (tuple, list)):
            return [normalize(item) for item in value]
        return value

    payload = json.dumps(normalize(skeleton_signature(props)), separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


def sync_tracking_nodes(scene):
    """Synchronize existing nodes after any successful configuration read."""
    root = scene.objects.get('Rebocap_Root')
    if root is None:
        return True
    rest = root.get('rebocap_rest_positions')
    if (rest is not None and len(rest) == 72 and
            root.get('rebocap_applied_skeleton_signature') == applied_skeleton_signature(scene.rebocap_bone_map)):
        # A later successful read may return to the geometry already applied
        # while an earlier preview refresh is queued. Keep that request, but
        # replace its imported snapshot with the latest successful read.
        if scene.rebocap_tracking_refresh_pending and preview_active(scene):
            defer_tracking_refresh(scene)
        return True
    if bpy.context.scene != scene:
        raise RuntimeError('Tracking nodes must be updated in their owning scene')
    return bpy.ops.rebocap.create_tracking_nodes() == {'FINISHED'}


def defer_tracking_refresh(scene):
    """Keep imported geometry with the pending request, including across saves."""
    scene.rebocap_tracking_refresh_pending = True
    props = scene.rebocap_bone_map
    keys = ('rebocap_pending_import_positions', 'rebocap_pending_import_feet',
            'rebocap_pending_import_source')
    if (props.sk_use_imported and cached_imported_positions is not None
            and len(cached_imported_positions) >= 24
            and _cached_imported_owner == _imported_cache_key(scene, props.ik_config_path)):
        scene[keys[0]] = [float(v) for p in cached_imported_positions[:24] for v in p]
        if cached_imported_foot_vertices is not None:
            scene[keys[1]] = [float(v) for p in cached_imported_foot_vertices for v in p]
        elif keys[1] in scene:
            del scene[keys[1]]
        scene[keys[2]] = props.ik_config_path
    elif (not props.sk_use_imported or keys[2] not in scene
          or _imported_cache_key(scene, scene[keys[2]]) != _imported_cache_key(scene, props.ik_config_path)):
        for key in keys:
            if key in scene:
                del scene[key]


def flush_pending_tracking_refresh(scene):
    global cached_imported_positions, cached_imported_foot_vertices, _cached_imported_owner
    if not scene.rebocap_tracking_refresh_pending or preview_active(scene):
        return True
    props = scene.rebocap_bone_map
    saved = scene.get('rebocap_pending_import_positions')
    saved_source = scene.get('rebocap_pending_import_source')
    if (props.sk_use_imported and saved is not None and len(saved) == 72
            and saved_source is not None
            and _imported_cache_key(scene, saved_source) == _imported_cache_key(scene, props.ik_config_path)):
        cached_imported_positions = [tuple(saved[i:i + 3]) for i in range(0, 72, 3)]
        feet = scene.get('rebocap_pending_import_feet')
        cached_imported_foot_vertices = ([tuple(feet[i:i + 3]) for i in range(0, len(feet), 3)]
                                         if feet and len(feet) % 3 == 0 else None)
        _cached_imported_owner = _imported_cache_key(scene, props.ik_config_path)
    if bpy.context.scene == scene:
        return bpy.ops.rebocap.create_tracking_nodes() == {'FINISHED'}
    with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
        return bpy.ops.rebocap.create_tracking_nodes() == {'FINISHED'}


def tracking_pose_driven(scene):
    from .rebocap_connection import live_control_active
    if live_control_active(scene):
        return True
    if not scene.rebocap_playback_active or preview_active(scene):
        return False
    mode = scene.rebocap_playback_mode
    if not mode:
        from .history import get_drive_type
        take = next((item for item in scene.rebocap_takes
                     if item.uuid == scene.rebocap_playback_take_uuid), None)
        mode = get_drive_type(scene, take) if take else ''
    return mode in ('IK', 'DUAL')


def tracking_location_animated_axes(obj, include_baked=True):
    """Return location axes controlled by actions, NLA, or drivers."""
    ad = obj.animation_data
    if not ad:
        return set()
    from .rebocap_connection import _action_iter_fcurves
    from .utils import _is_rebocap_baked, _action_curves_for_slots
    axes = set()

    def collect(curves):
        for curve in curves:
            if curve.data_path == 'location' and not curve.mute:
                index = curve.array_index
                axes.update((index,) if 0 <= index < 3 else (0, 1, 2))

    def action_curves(owner):
        action = owner.action
        slot = getattr(owner, 'action_slot', None)
        if hasattr(action, 'slots') and slot is not None:
            return _action_curves_for_slots(action, {slot.identifier})
        if hasattr(action, 'slots') and len(action.slots):
            return ()
        return _action_iter_fcurves(action)

    if ad.action and (include_baked or not _is_rebocap_baked(ad.action)):
        collect(action_curves(ad))
    collect(ad.drivers)
    for track in ad.nla_tracks:
        if track.mute:
            continue
        for strip in track.strips:
            if (not strip.mute and strip.action and
                    (include_baked or not _is_rebocap_baked(strip.action))):
                collect(action_curves(strip))
    return axes


def tracking_nla_issue(scene):
    from .rebocap_connection import TRACKING_JOINT_NAMES
    candidates = [scene.objects.get('Rebocap_' + name) for name in TRACKING_JOINT_NAMES]
    candidates.extend(obj for obj in scene.objects
                      if obj.type == 'ARMATURE' and obj.get('rebocap_demo_character'))
    for candidate in candidates:
        issue = nla_adaptation_issue(candidate) if candidate else None
        if issue:
            return candidate.name, issue
    return None


class _TrackingRefreshTransaction:
    """Restore scene objects and generated action copies if a refresh fails."""

    def __init__(self, scene):
        from .rebocap_connection import TRACKING_OBJECT_NAMES
        self.scene = scene
        self.configuration_snapshot = _snapshot_configuration(scene)
        names = set(TRACKING_OBJECT_NAMES) | {'Rebocap_L_Sole', 'Rebocap_R_Sole'}
        self.before_objects = set(bpy.data.objects)
        self.before_actions = set(bpy.data.actions)
        self.before_meshes = set(bpy.data.meshes)
        self.objects = [obj for obj in bpy.data.objects if obj.name in names]
        self.objects += [obj for obj in scene.objects
                         if obj.type == 'ARMATURE' and obj.get('rebocap_demo_character')]
        self.states = {}
        self.actions = []
        self.action_fake_users = {}
        self.holders = []
        self.dirty = False
        self.root_properties = {}
        self.pending = scene.rebocap_tracking_refresh_pending
        self.pending_properties = self._properties(scene, (
            'rebocap_pending_import_positions', 'rebocap_pending_import_feet',
            'rebocap_pending_import_source'))
        root = bpy.data.objects.get('Rebocap_Root')
        if root:
            self.root_properties = self._properties(root, (
                'rebocap_rest_positions', 'rebocap_rest_foot_vertices',
                'rebocap_rest_import_source', 'rebocap_applied_skeleton_signature'))
        for obj in self.objects:
            self.states[obj] = {
                'parent': obj.parent,
                'parent_inverse': obj.matrix_parent_inverse.copy(),
                'basis': obj.matrix_basis.copy(),
                'rotation_mode': obj.rotation_mode,
                'collections': tuple(obj.users_collection),
                'empty_display_type': obj.empty_display_type if obj.type == 'EMPTY' else None,
                'empty_display_size': obj.empty_display_size if obj.type == 'EMPTY' else None,
                'data': obj.data,
                'show_in_front': obj.show_in_front,
            }
            if obj.type == 'MESH' and obj.name in {'Rebocap_L_Sole', 'Rebocap_R_Sole'}:
                self.states[obj]['mesh_users'] = obj.data.users
                self.states[obj]['mesh_coords'] = tuple(v.co.copy() for v in obj.data.vertices)
            if obj.type == 'ARMATURE':
                from .demo_character import _adapter_snapshot
                self.states[obj]['adapter'] = _adapter_snapshot(obj)
                self.states[obj]['pose'] = {pb.name: (pb.matrix_basis.copy(), pb.rotation_mode,
                                                       pb.bone.inherit_scale)
                                            for pb in obj.pose.bones}
                self.states[obj]['display_type'] = obj.data.display_type
                self.states[obj]['properties'] = self._properties(obj, (
                    'rebocap_adapted_hip_location', 'rebocap_rest_pelvis_z',
                    'rebocap_demo_static_thigh_center'))
            ad = obj.animation_data
            if ad:
                owners = [ad] + [strip for track in ad.nla_tracks for strip in track.strips]
                for owner in owners:
                    action = owner.action
                    slot = getattr(owner, 'action_slot', None)
                    self.actions.append((owner, action, slot))
                    if action and action not in self.action_fake_users:
                        self.action_fake_users[action] = action.use_fake_user
        # Force copy-on-write for existing sole meshes so failure can restore
        # the original data block without modifying its geometry or attributes.
        try:
            for obj in self.objects:
                if obj.name in {'Rebocap_L_Sole', 'Rebocap_R_Sole'} and obj.type == 'MESH':
                    self.holders.append(bpy.data.objects.new('_rebocap_refresh_hold', obj.data))
        except Exception:
            self._remove_holders()
            raise

    @staticmethod
    def _properties(owner, names):
        result = {}
        for name in names:
            if name in owner:
                value = owner[name]
                result[name] = list(value) if hasattr(value, 'to_list') else value
        return result

    @staticmethod
    def _restore_properties(owner, names, values):
        for name in names:
            if name in values:
                owner[name] = values[name]
            elif name in owner:
                del owner[name]

    def _remove_holders(self):
        for holder in self.holders:
            bpy.data.objects.remove(holder, do_unlink=True)
        self.holders.clear()

    def commit(self):
        old_meshes = {self.states[obj]['data'] for obj in self.objects
                      if obj.name in {'Rebocap_L_Sole', 'Rebocap_R_Sole'} and obj.type == 'MESH'}
        for obj in self.objects:
            state = self.states[obj]
            if 'mesh_users' not in state or state['mesh_users'] != 1:
                continue
            original, staged = state['data'], obj.data
            if original == staged or not getattr(original, 'is_editable', original.library is None):
                continue
            same_topology = (len(original.vertices) == len(staged.vertices) and
                             len(original.edges) == len(staged.edges) and
                             len(original.polygons) == len(staged.polygons) and
                             all(tuple(a.vertices) == tuple(b.vertices)
                                 for a, b in zip(original.edges, staged.edges)) and
                             all(tuple(a.vertices) == tuple(b.vertices)
                                 for a, b in zip(original.polygons, staged.polygons)))
            if same_topology:
                # Keep the original single-user data block when its topology
                # did not change. The recorded coordinates allow rollback if
                # committing either sole fails midway.
                for vertex, updated in zip(original.vertices, staged.vertices):
                    vertex.co = updated.co
                original.update()
                obj.data = original
        self._remove_holders()
        for mesh in list(bpy.data.meshes):
            if mesh not in self.before_meshes and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        for mesh in old_meshes:
            try:
                if mesh and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
            except (ReferenceError, RuntimeError):
                pass

    def abort(self):
        try:
            if self.dirty:
                self.rollback()
            else:
                self._remove_holders()
        finally:
            _restore_configuration(self.scene, self.configuration_snapshot)

    def rollback(self):
        self._remove_holders()
        for owner, action, slot in self.actions:
            if owner.action != action:
                owner.action = action
            if slot is not None and hasattr(owner, 'action_slot') and owner.action_slot != slot:
                owner.action_slot = slot
        for action, fake_user in self.action_fake_users.items():
            action.use_fake_user = fake_user
        for obj, state in self.states.items():
            if 'mesh_coords' in state and len(state['data'].vertices) == len(state['mesh_coords']):
                changed = False
                for vertex, coordinate in zip(state['data'].vertices, state['mesh_coords']):
                    if vertex.co != coordinate:
                        vertex.co = coordinate
                        changed = True
                if changed:
                    state['data'].update()
            if obj.type == 'MESH' and obj.data != state['data']:
                obj.data = state['data']
            for collection in tuple(obj.users_collection):
                if collection not in state['collections']:
                    collection.objects.unlink(obj)
            obj.parent = state['parent']
            obj.matrix_parent_inverse = state['parent_inverse']
            obj.rotation_mode = state['rotation_mode']
            obj.matrix_basis = state['basis']
            obj.show_in_front = state['show_in_front']
            if obj.type == 'EMPTY':
                obj.empty_display_type = state['empty_display_type']
                obj.empty_display_size = state['empty_display_size']
            elif obj.type == 'ARMATURE':
                from .demo_character import _restore_adapter_snapshot
                _restore_adapter_snapshot(obj, state['adapter'])
                obj.data.display_type = state['display_type']
                for name, (basis, mode, inherit_scale) in state['pose'].items():
                    pb = obj.pose.bones.get(name)
                    if pb:
                        pb.bone.inherit_scale = inherit_scale
                        pb.rotation_mode = mode
                        pb.matrix_basis = basis
                self._restore_properties(obj, ('rebocap_adapted_hip_location',
                                               'rebocap_rest_pelvis_z',
                                               'rebocap_demo_static_thigh_center'), state['properties'])
        root = bpy.data.objects.get('Rebocap_Root')
        if root and root in self.before_objects:
            self._restore_properties(root, ('rebocap_rest_positions', 'rebocap_rest_foot_vertices',
                                            'rebocap_rest_import_source',
                                            'rebocap_applied_skeleton_signature'), self.root_properties)
        self.scene.rebocap_tracking_refresh_pending = self.pending
        self._restore_properties(self.scene, ('rebocap_pending_import_positions',
                                              'rebocap_pending_import_feet',
                                              'rebocap_pending_import_source'), self.pending_properties)
        for obj in list(bpy.data.objects):
            if obj not in self.before_objects and obj.name.startswith('Rebocap_'):
                bpy.data.objects.remove(obj, do_unlink=True)
        for action in list(bpy.data.actions):
            if action not in self.before_actions and action.get('rebocap_baked'):
                action.use_fake_user = False
                if action.users == 0:
                    bpy.data.actions.remove(action)
        for mesh in list(bpy.data.meshes):
            if mesh not in self.before_meshes and mesh.users == 0:
                bpy.data.meshes.remove(mesh)


class REBOCAP_OT_create_tracking_nodes(bpy.types.Operator):
    bl_idname = "rebocap.create_tracking_nodes"
    bl_label = "Generate Tracking Nodes"
    bl_description = "Generate the 24 tracking IK preview nodes from config data"

    def execute(self, context):
        if preview_active(context.scene):
            return self._execute(context)
        try:
            transaction = _TrackingRefreshTransaction(context.scene)
        except Exception as error:
            self.report({'ERROR'}, f"{T('Unable to update tracking nodes')}: {error}")
            return {'CANCELLED'}
        try:
            self._refresh_transaction = transaction
            result = self._execute(context)
            if result == {'FINISHED'}:
                transaction.commit()
                self.report({'INFO'}, "Generated Tracking Nodes successfully")
            else:
                transaction.abort()
            return result
        except Exception as error:
            try:
                transaction.abort()
            except Exception as rollback_error:
                print(f"[Rebocap] Tracking refresh rollback failed: {rollback_error}")
            self.report({'ERROR'}, f"{T('Unable to update tracking nodes')}: {error}")
            return {'CANCELLED'}

    def _execute(self, context):
        global cached_imported_positions, cached_imported_foot_vertices, _cached_imported_owner
        if preview_active(context.scene):
            defer_tracking_refresh(context.scene)
            self.report({'INFO'}, T("Tracking refresh will apply after A2T preview"))
            return {'FINISHED'}
        rebocap = context.scene.rebocap_bone_map
        if rebocap.sk_upper_leg <= 0.001 or rebocap.sk_lower_leg <= 0.001:
            cfg_path = rebocap.ik_config_path
            if not cfg_path and may_auto_detect_config(context.scene):
                cfg_path = find_rebocap_config_path()
            if cfg_path and os.path.exists(cfg_path):
                # This operator performs the refresh itself; avoid recursively
                # starting a second refresh while reading the candidate.
                read_and_sync_config(context.scene, cfg_path, sync=lambda _scene: True)
            
        if rebocap.sk_upper_leg <= 0.001 or rebocap.sk_lower_leg <= 0.001:
            self.report({'WARNING'}, T("Please load valid skeleton dimensions"))
            return {'CANCELLED'}

        root_name = "Rebocap_Root"
        cache_key = _imported_cache_key(context.scene, rebocap.ik_config_path)
        if rebocap.sk_use_imported and _cached_imported_owner != cache_key:
            clear_imported_cache()
        if rebocap.sk_use_imported and cached_imported_positions is None:
            # A saved .blend retains the static reference even after Python caches
            # disappear. Prefer rereading its configuration when it is available.
            cfg_path = rebocap.ik_config_path
            if cfg_path and os.path.exists(cfg_path):
                parse_and_update_ik_config(cfg_path, rebocap, None)
            if rebocap.sk_use_imported and cached_imported_positions is None:
                old_root = context.scene.objects.get(root_name)
                saved = old_root.get('rebocap_rest_positions') if old_root else None
                saved_path = old_root.get('rebocap_rest_import_source', '') if old_root else ''
                if not old_root or 'rebocap_rest_import_source' not in old_root:
                    saved = None
                if cfg_path and (not saved_path or _imported_cache_key(context.scene, cfg_path) != _imported_cache_key(context.scene, saved_path)):
                    saved = None
                if saved is None or len(saved) != 72:
                    self.report({'WARNING'}, T("Imported skeleton data is unavailable; read its configuration first"))
                    return {'CANCELLED'}
                cached_imported_positions = [(saved[i * 3], saved[i * 3 + 2], -saved[i * 3 + 1]) for i in range(24)]
                feet = old_root.get('rebocap_rest_foot_vertices')
                cached_imported_foot_vertices = ([(feet[i * 3], feet[i * 3 + 1], feet[i * 3 + 2])
                                                  for i in range(len(feet) // 3)] if feet and len(feet) % 3 == 0 else None)
                _cached_imported_owner = _imported_cache_key(context.scene, rebocap.ik_config_path)
        
        joints = [
            "Pelvis", "L_Upper_leg", "R_Upper_leg", "Spine1", "L_Lower_leg", "R_Lower_leg",
            "Spine2", "L_Foot", "R_Foot", "Spine3", "L_Toe", "R_Toe",
            "Neck", "L_Shoulder", "R_Shoulder", "Head", "L_Upper_arm", "R_Upper_arm",
            "L_Lower_arm", "R_Lower_arm", "L_Hand", "R_Hand", "L_Hand_end", "R_Hand_end",
        ]

        # The add-on uses fixed global node names throughout its drivers.
        # Refuse cross-scene reuse before touching any existing geometry.
        names = [root_name] + [f"Rebocap_{name}" for name in joints]
        names += ['Rebocap_L_Sole', 'Rebocap_R_Sole']
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj and any(scene != context.scene and scene.objects.get(obj.name) == obj
                           for scene in bpy.data.scenes):
                self.report({'WARNING'}, T("Tracking nodes are used by another scene"))
                return {'CANCELLED'}
        for obj in context.scene.objects:
            if (obj.type == 'ARMATURE' and obj.get('rebocap_demo_character')
                    and any(other.type == 'ARMATURE' and other.data == obj.data
                            for scene in bpy.data.scenes if scene != context.scene
                            for other in scene.objects)):
                self.report({'WARNING'}, T("Tracking nodes are used by another scene"))
                return {'CANCELLED'}
        
        parents = {
            1: 0, 2: 0, 3: 0,
            4: 1, 5: 2, 6: 3,
            7: 4, 8: 5, 9: 6,
            10: 7, 11: 8, 12: 9,
            13: 9, 14: 9, 15: 12,
            16: 13, 17: 14, 18: 16,
            19: 17, 20: 18, 21: 19,
            22: 20, 23: 21
        }
        
        raw_joints_world = {}
        
        if rebocap.sk_use_imported and cached_imported_positions is not None and len(cached_imported_positions) >= 24:
            # 1. Applied Skeleton: Use exact 3D coordinates from imported skeleton
            for i in range(24):
                p = cached_imported_positions[i]
                # Convert Unity/SMPL [X, Y(up), Z] to Blender [X, -Z, Y(up)]
                raw_joints_world[i] = (p[0], -p[2], p[1])
                
            # Toe logic: Exactly matches '2- toe Center' contact point from config.data
            if cached_imported_foot_vertices and len(cached_imported_foot_vertices) >= 12:
                p_lt = cached_imported_foot_vertices[1]
                p_rt = cached_imported_foot_vertices[7]
                raw_joints_world[10] = (p_lt[0], -p_lt[2], p_lt[1])
                raw_joints_world[11] = (p_rt[0], -p_rt[2], p_rt[1])
            else:
                fl = (rebocap.sk_foot if rebocap.sk_foot > 0 else 27.0) * 0.01
                raw_joints_world[10] = (raw_joints_world[7][0], raw_joints_world[7][1] - fl * 0.75, 0.0)
                raw_joints_world[11] = (raw_joints_world[8][0], raw_joints_world[8][1] - fl * 0.75, 0.0)
            
            # Same Hand End logic: Extends 10cm along forearm direction
            # Left Hand End (22)
            dx_l = raw_joints_world[20][0] - raw_joints_world[18][0]
            dy_l = raw_joints_world[20][1] - raw_joints_world[18][1]
            dz_l = raw_joints_world[20][2] - raw_joints_world[18][2]
            d_len_l = (dx_l*dx_l + dy_l*dy_l + dz_l*dz_l)**0.5
            if d_len_l > 1e-4:
                raw_joints_world[22] = (
                    raw_joints_world[20][0] + (dx_l / d_len_l) * 0.10,
                    raw_joints_world[20][1] + (dy_l / d_len_l) * 0.10,
                    raw_joints_world[20][2] + (dz_l / d_len_l) * 0.10
                )
            else:
                raw_joints_world[22] = (raw_joints_world[20][0] + 0.10, raw_joints_world[20][1], raw_joints_world[20][2])
                
            # Right Hand End (23)
            dx_r = raw_joints_world[21][0] - raw_joints_world[19][0]
            dy_r = raw_joints_world[21][1] - raw_joints_world[19][1]
            dz_r = raw_joints_world[21][2] - raw_joints_world[19][2]
            d_len_r = (dx_r*dx_r + dy_r*dy_r + dz_r*dz_r)**0.5
            if d_len_r > 1e-4:
                raw_joints_world[23] = (
                    raw_joints_world[21][0] + (dx_r / d_len_r) * 0.10,
                    raw_joints_world[21][1] + (dy_r / d_len_r) * 0.10,
                    raw_joints_world[21][2] + (dz_r / d_len_r) * 0.10
                )
            else:
                raw_joints_world[23] = (raw_joints_world[21][0] - 0.10, raw_joints_world[21][1], raw_joints_world[21][2])
        else:
            # 2. Manual Skeleton: Build accurate T-pose strictly from 12 manual parameters scaled by skeleton_ratio (final_height)
            ratio = rebocap.sk_skeleton_ratio if rebocap.sk_skeleton_ratio > 0.01 else 1.0
            scale = 0.01 * ratio
            hw = (rebocap.sk_hip_width / 2.0) * scale
            hh = rebocap.sk_hip_height * scale
            ul = rebocap.sk_upper_leg * scale
            ll = rebocap.sk_lower_leg * scale
            ah = (rebocap.sk_ankle if rebocap.sk_ankle > 0 else 9.0) * scale
            fl = (rebocap.sk_foot if rebocap.sk_foot > 0 else 27.0) * scale
            sp = (rebocap.sk_spine / 3.0) * scale
            ch = rebocap.sk_chest * scale
            nh = rebocap.sk_neck_head * scale
            sw = (rebocap.sk_shoulder_width / 2.0) * scale
            ua = rebocap.sk_upper_arm * scale
            la = rebocap.sk_lower_arm * scale
            
            pelvis_z = hh + ul + ll + ah
            spine_top_z = pelvis_z + sp * 3.0
            
            raw_joints_world = {
                0:  (0.0, 0.0, pelvis_z),
                1:  (hw, 0.0, pelvis_z - hh),
                2:  (-hw, 0.0, pelvis_z - hh),
                3:  (0.0, 0.0, pelvis_z + sp),
                4:  (hw, 0.0, pelvis_z - hh - ul),
                5:  (-hw, 0.0, pelvis_z - hh - ul),
                6:  (0.0, 0.0, pelvis_z + sp * 2.0),
                7:  (hw, 0.0, ah),
                8:  (-hw, 0.0, ah),
                9:  (0.0, 0.0, spine_top_z),
                10: (hw, -fl * 0.75, 0.0),
                11: (-hw, -fl * 0.75, 0.0),
                12: (0.0, 0.0, spine_top_z + ch),
                13: (sw * 0.2, 0.0, spine_top_z + ch),
                14: (-sw * 0.2, 0.0, spine_top_z + ch),
                15: (0.0, 0.0, spine_top_z + ch + nh),
                16: (sw, 0.0, spine_top_z + ch),
                17: (-sw, 0.0, spine_top_z + ch),
                18: (sw + ua, 0.0, spine_top_z + ch),
                19: (-sw - ua, 0.0, spine_top_z + ch),
                20: (sw + ua + la, 0.0, spine_top_z + ch),
                21: (-sw - ua - la, 0.0, spine_top_z + ch),
                22: (sw + ua + la + 0.1, 0.0, spine_top_z + ch),
                23: (-sw - ua - la - 0.1, 0.0, spine_top_z + ch),
            }
        
        # Calculate local offsets relative to parent directly from absolute 3D world positions
        offsets = {}
        for i in range(24):
            if i == 0:
                offsets[0] = raw_joints_world[0]
            else:
                p_idx = parents[i]
                w_cur = raw_joints_world[i]
                w_par = raw_joints_world[p_idx]
                offsets[i] = (w_cur[0] - w_par[0], w_cur[1] - w_par[1], w_cur[2] - w_par[2])
        
        # Preserve IDs: constraints and parent links refer to objects, not names.
        for name in [root_name] + [f"Rebocap_{name}" for name in joints]:
            existing = bpy.data.objects.get(name)
            if existing and existing.type != 'EMPTY':
                self.report({'ERROR'}, f"Tracking node name is occupied: {name}")
                return {'CANCELLED'}
            if existing and not getattr(existing, 'is_editable', existing.library is None):
                self.report({'ERROR'}, f"{T('Unable to update tracking nodes')}: {name} (read-only)")
                return {'CANCELLED'}
        for name in ('Rebocap_L_Sole', 'Rebocap_R_Sole'):
            existing = bpy.data.objects.get(name)
            if existing and (existing.type != 'MESH' or existing.data is None):
                self.report({'ERROR'}, f"{T('Unable to update tracking nodes')}: {name} ({existing.type})")
                return {'CANCELLED'}
            if existing and not getattr(existing, 'is_editable', existing.library is None):
                self.report({'ERROR'}, f"{T('Unable to update tracking nodes')}: {name} (read-only)")
                return {'CANCELLED'}
        existing_root = context.scene.objects.get(root_name)
        if existing_root and (existing_root.get('rebocap_applied_skeleton_signature') != applied_skeleton_signature(rebocap)
                              or len(existing_root.get('rebocap_rest_positions', ())) != 72):
            issue = tracking_nla_issue(context.scene)
            if issue:
                name, detail = issue
                self.report({'WARNING'}, f"{T('Unsupported NLA prevents tracking refresh')}: {name} ({detail})")
                return {'CANCELLED'}
        collection = context.collection
        
        node_size_m = context.scene.rebocap_tracking_node_size / 1000.0
        
        self._refresh_transaction.dirty = True
        root_empty = bpy.data.objects.get(root_name)
        if root_empty is None:
            root_empty = bpy.data.objects.new(root_name, None)
            collection.objects.link(root_empty)
        previous_rest = root_empty.get('rebocap_rest_positions')
        previous_rest = tuple(previous_rest) if previous_rest is not None else None
        # Persist static reference positions separately from the animated node transforms.
        root_empty['rebocap_rest_positions'] = [float(v) for i in range(24) for v in raw_joints_world[i]]
        if rebocap.sk_use_imported and cached_imported_foot_vertices is not None:
            root_empty['rebocap_rest_foot_vertices'] = [float(v) for p in cached_imported_foot_vertices for v in p]
        elif 'rebocap_rest_foot_vertices' in root_empty:
            del root_empty['rebocap_rest_foot_vertices']
        if rebocap.sk_use_imported:
            root_empty['rebocap_rest_import_source'] = rebocap.ik_config_path
        elif 'rebocap_rest_import_source' in root_empty:
            del root_empty['rebocap_rest_import_source']
        root_empty.empty_display_type = 'PLAIN_AXES'
        root_empty.empty_display_size = node_size_m * 2.0  # Root is twice as large
        if root_empty.name not in context.scene.objects:
            collection.objects.link(root_empty)
        
        objects = {}
        for i, name in enumerate(joints):
            empty = bpy.data.objects.get(f"Rebocap_{name}")
            is_new = empty is None
            if is_new:
                empty = bpy.data.objects.new(f"Rebocap_{name}", None)
                collection.objects.link(empty)
            empty.empty_display_type = 'PLAIN_AXES'
            empty.empty_display_size = node_size_m
            empty.rotation_mode = 'QUATERNION'
            if empty.name not in context.scene.objects:
                collection.objects.link(empty)
            objects[i] = empty
            
            if i == 0:
                empty.parent = root_empty
                if is_new:
                    empty.location = offsets[0]
                elif not tracking_pose_driven(context.scene):
                    animated_axes = tracking_location_animated_axes(empty)
                    if previous_rest is not None and len(previous_rest) == 72:
                        delta = Vector(offsets[0]) - Vector(previous_rest[:3])
                        for axis in range(3):
                            if axis not in animated_axes:
                                empty.location[axis] += delta[axis]
                    else:
                        for axis in range(3):
                            if axis not in animated_axes:
                                empty.location[axis] = offsets[0][axis]
            else:
                parent = objects[parents[i]]
                empty.parent = parent
                if previous_rest is not None and len(previous_rest) == 72:
                    old_pos = Vector(previous_rest[i * 3:i * 3 + 3])
                    parent_idx = parents[i]
                    old_parent = Vector(previous_rest[parent_idx * 3:parent_idx * 3 + 3])
                    delta = Vector(offsets[i]) - (old_pos - old_parent)
                    animated_axes = tracking_location_animated_axes(empty)
                    user_axes = tracking_location_animated_axes(empty, include_baked=False)
                    changes = {('location', axis): ('add', delta[axis]) for axis in range(3)
                               if axis not in user_axes}
                    adjusted = delta.length >= 1e-7 and adjust_baked_action(empty, changes)
                    for axis in range(3):
                        if axis in user_axes:
                            continue
                        if adjusted:
                            empty.location[axis] += delta[axis]
                        elif axis not in animated_axes and delta.length >= 1e-7:
                            empty.location[axis] = offsets[i][axis]
                else:
                    animated_axes = tracking_location_animated_axes(empty)
                    for axis in range(3):
                        if axis not in animated_axes:
                            empty.location[axis] = offsets[i][axis]
                
        # Refresh view layer so all tracking nodes have up-to-date matrix_world
        context.view_layer.update()
        
        # Generate wireframe foot soles
        ankle_h = raw_joints_world[7][2] if 7 in raw_joints_world else ((rebocap.sk_ankle if rebocap.sk_ankle > 0 else 9.0) * (scale if not rebocap.sk_use_imported else 0.01))
        foot_l = (rebocap.sk_foot if rebocap.sk_foot > 0 else 27.0) * (scale if not rebocap.sk_use_imported else 0.01)
        if 7 in objects:
            update_or_create_sole_mesh('L', objects[7], raw_joints_world.get(7), ankle_h, foot_l, collection)
        if 8 in objects:
            update_or_create_sole_mesh('R', objects[8], raw_joints_world.get(8), ankle_h, foot_l, collection)

        # Auto-adapt demo character scale isolated if present in scene
        try:
            from .demo_character import get_demo_character_armature, adapt_demo_character_scale_isolated
            demo_arm = next((obj for obj in context.scene.objects
                             if obj.type == 'ARMATURE' and obj.get('rebocap_demo_character')), None)
            if demo_arm:
                bpy.context.view_layer.update()
                adapt_demo_character_scale_isolated(demo_arm, raw_joints_world)
        except Exception as e:
            print(f"[Rebocap] auto-refresh demo character notice: {e}")
            self.report({'WARNING'}, f"{T('Unable to update tracking nodes')}: {e}")
            return {'CANCELLED'}
                
        root_empty['rebocap_applied_skeleton_signature'] = applied_skeleton_signature(rebocap)
        context.scene.rebocap_tracking_refresh_pending = False
        for key in ('rebocap_pending_import_positions', 'rebocap_pending_import_feet',
                    'rebocap_pending_import_source'):
            if key in context.scene:
                del context.scene[key]
        # Static adaptation changes the rest-height input.  Re-evaluate the
        # current native source instead of adding a transient offset to an
        # animation channel which Blender may overwrite on the next frame.
        if not preview_active(context.scene):
            if (context.scene.rebocap_playback_active and
                    context.scene.rebocap_playback_mode in ('IK', 'DUAL')):
                from .history import rebocap_timeline_playback_handler
                # The refresh transaction owns tracking and demo objects only.
                # Re-evaluating the DUAL FK target here would write outside its
                # rollback boundary if a later tracking/demo operation fails.
                rebocap_timeline_playback_handler(context.scene, tracking_only=True)
            else:
                from . import rebocap_connection as connection
                if connection.live_control_active(context.scene) and connection.rebocap_app:
                    packet = connection.rebocap_app.get_last_msg()
                    if packet is not None:
                        connection.drive_demo_character(
                            packet[0], packet[1], scene=context.scene,
                            pose_layer=connection.recording_pose_layer(context.scene))
        return {'FINISHED'}

def update_or_create_sole_mesh(side, foot_obj, ankle_world_pos=None, ankle_h=0.09, foot_l=0.27, collection=None):
    # side: 'L' or 'R'
    mesh_name = f"Rebocap_{side}_Sole_Mesh"
    obj_name = f"Rebocap_{side}_Sole"
    
    global cached_imported_foot_vertices
    
    # 1. If imported skeleton in config.data has 12 contact vertex positions (6 for each foot)
    if cached_imported_foot_vertices and len(cached_imported_foot_vertices) >= 12 and ankle_world_pos:
        # Points 0..5 are Right Foot in Unity (+X) -> Left Foot (Joint 7) in Blender
        # Points 6..11 are Left Foot in Unity (-X) -> Right Foot (Joint 8) in Blender
        pts = cached_imported_foot_vertices[0:6] if side == 'L' else cached_imported_foot_vertices[6:12]
        
        # Local offset relative to this foot ankle joint in Blender
        # Unity: [X, Y(up), Z] -> Blender: [X, -Z, Y(up)]
        def to_local(p):
            return (p[0] - ankle_world_pos[0], -p[2] - ankle_world_pos[1], p[1] - ankle_world_pos[2])
            
        v0 = to_local(pts[0]) # toe Right
        v1 = to_local(pts[1]) # toe Center
        v2 = to_local(pts[2]) # toe Left
        v3 = to_local(pts[5]) # heel Left
        v4 = to_local(pts[4]) # heel Center
        v5 = to_local(pts[3]) # heel Right
        v6 = (0.0, 0.0, 0.0)  # Ankle
        
        verts = [ v0, v1, v2, v3, v4, v5, v6 ]
        edges = [
            # Closed outer perimeter following exact vector contact points from config.data
            (0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0),
            # Center longitudinal line
            (1, 4),
            # Forefoot width crossbar
            (0, 2),
            # Heel width crossbar
            (5, 3),
            # Ankle struts
            (6, 0), (6, 1), (6, 2), (6, 3), (6, 4), (6, 5)
        ]
    else:
        # 2. Manual Mode: 6 standard vector contact points scaled strictly to foot_l and ankle_h from config.data
        sign = 1.0 if side == 'L' else -1.0
        ground_z = -ankle_h # Sole is at ground plane (Z = -ankle_height relative to ankle)
        
        v0 = (sign * foot_l * 0.16, -foot_l * 0.65, ground_z) # 1- toe Right
        v1 = (0.0, -foot_l * 0.75, ground_z)                  # 2- toe Center
        v2 = (-sign * foot_l * 0.14, -foot_l * 0.65, ground_z)# 3- toe Left
        v3 = (-sign * foot_l * 0.12, foot_l * 0.18, ground_z) # 6- heel Left
        v4 = (0.0, foot_l * 0.22, ground_z)                   # 5- heel Center
        v5 = (sign * foot_l * 0.15, foot_l * 0.18, ground_z)  # 4- heel Right
        v6 = (0.0, 0.0, 0.0)                                  # Ankle
        
        verts = [ v0, v1, v2, v3, v4, v5, v6 ]
        edges = [
            # Closed outer perimeter matching 6-point vector topology
            (0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0),
            # Center longitudinal line (Toe tip to Heel back)
            (1, 4),
            # Forefoot width crossbar (Toe Right to Toe Left)
            (0, 2),
            # Heel width crossbar (Heel Right to Heel Left)
            (5, 3),
            # Ankle connection struts
            (6, 0), (6, 1), (6, 2), (6, 3), (6, 4), (6, 5)
        ]
        
    faces = []
    
    obj = bpy.data.objects.get(obj_name)
    if not obj:
        mesh = bpy.data.meshes.new(mesh_name)
        mesh.from_pydata(verts, edges, faces)
        mesh.update()
        obj = bpy.data.objects.new(obj_name, mesh)
        obj.display_type = 'WIRE'
        obj.show_in_front = True
        target_col = collection if collection else bpy.context.collection
        if target_col and obj.name not in target_col.objects:
            target_col.objects.link(obj)
    else:
        mesh = obj.data
        same_vertices = (len(mesh.vertices) == len(verts) and all(
            vertex.co == Vector(co) for vertex, co in zip(mesh.vertices, verts)))
        # A differently named object can share this mesh, including in another
        # scene. Preserve its geometry when updating the tracking sole.
        if mesh.users > 1 and not same_vertices:
            mesh = mesh.copy()
            obj.data = mesh
        if same_vertices:
            pass
        elif len(mesh.vertices) == len(verts):
            for idx, v_co in enumerate(verts):
                mesh.vertices[idx].co = v_co
            mesh.update()
        else:
            mesh.clear_geometry()
            mesh.from_pydata(verts, edges, faces)
            mesh.update()
            
    obj.parent = foot_obj
    obj.location = (0, 0, 0)
    obj.rotation_quaternion = (1, 0, 0, 0)
    obj.rotation_euler = (0, 0, 0)
    return obj


