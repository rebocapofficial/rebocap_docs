from ..core.a2t_types import get_a2t_quat_for_node_idx, preview_active
from ..core.translation import T
import os
import sys
import time
from threading import Thread, Lock

import atexit
import json
import tempfile
import bpy
import random
from mathutils import Vector, Matrix, Quaternion, Euler
from ..rebocap_api import *
from typing import Optional
from .utils import show_message_box, restore_rotation_mode
from .recording_control import RecordingChannels, restore_saved_action_bindings
from ..rebocap_api.rebocap_ws_sdk import REBOCAP_JOINT_NAMES

TRACKING_JOINT_NAMES = (
    'Pelvis',
    'L_Upper_leg',
    'R_Upper_leg',
    'Spine1',
    'L_Lower_leg',
    'R_Lower_leg',
    'Spine2',
    'L_Foot',
    'R_Foot',
    'Spine3',
    'L_Toe',
    'R_Toe',
    'Neck',
    'L_Shoulder',
    'R_Shoulder',
    'Head',
    'L_Upper_arm',
    'R_Upper_arm',
    'L_Lower_arm',
    'R_Lower_arm',
    'L_Hand',
    'R_Hand',
    'L_Hand_end',
    'R_Hand_end',
)
TRACKING_OBJECT_NAMES = frozenset(["Rebocap_Root"] + ["Rebocap_" + name for name in TRACKING_JOINT_NAMES])
DEMO_BONE_NAMES = (
    'mixamorig:Hips', 'mixamorig:LeftUpLeg', 'mixamorig:RightUpLeg', 'mixamorig:Spine',
    'mixamorig:LeftLeg', 'mixamorig:RightLeg', 'mixamorig:Spine1', 'mixamorig:LeftFoot',
    'mixamorig:RightFoot', 'mixamorig:Spine2', 'mixamorig:LeftToeBase', 'mixamorig:RightToeBase',
    'mixamorig:Neck', 'mixamorig:LeftShoulder', 'mixamorig:RightShoulder', 'mixamorig:Head',
    'mixamorig:LeftArm', 'mixamorig:RightArm', 'mixamorig:LeftForeArm', 'mixamorig:RightForeArm',
    'mixamorig:LeftHand', 'mixamorig:RightHand',
)
UNDRIVEN_BONE_INDICES = (10, 11)
_RECORDING_INTENT = '_rebocap_recording_intent'
_recording_control = None

# ================= 强制上下文操作器 =================
def force_stop_animation(ctx):
    """强制且安全地停止时间轴，忽略 UI 上下文错误"""
    if getattr(getattr(ctx, 'screen', None), 'is_animation_playing', False):
        try:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        except Exception:
            # 强行覆写到 3D 视图上下文执行
            for window in ctx.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        with ctx.temp_override(window=window, area=area):
                            bpy.ops.screen.animation_cancel(restore_frame=False)
                        return

def force_start_animation(ctx):
    """强制开始播放，忽略 UI 上下文错误"""
    # animation_play is a toggle: calling it on an already-playing screen
    # pauses the timeline instead of starting it.
    if getattr(ctx.screen, 'is_animation_playing', False):
        return
    try:
        bpy.ops.screen.animation_play()
    except Exception:
        for window in ctx.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    with ctx.temp_override(window=window, area=area):
                        bpy.ops.screen.animation_play()
                    return
# =================================================

def _is_legacy_action(action):
    # 精准判断：Blender 4.4/4.5 以后引入了 slots，不再单纯依赖 fcurves 的存在与否
    return hasattr(action, 'fcurves') and not hasattr(action, 'slots')

def _get_fcurves_coll(owner, attrs):
    """Probe *owner* for a collection-like attribute from *attrs* that has ``.new()``."""
    for attr in attrs:
        coll = getattr(owner, attr, None)
        if coll is not None and hasattr(coll, 'new'):
            return coll
    avail = [a for a in dir(owner) if not a.startswith('_')]
    raise AttributeError(
        f"{type(owner).__name__} has no recognised FCurve collection. "
        f"Tried: {attrs}. Available: {avail}"
    )


def _action_setup_slot(action, obj):
    """Ensure the action has a slot for *obj* (Blender 5.x slotted actions).

    Call this right **before** ``obj.animation_data.action = action`` so that
    the assignment can bind the pre-created slot to the object.
    """
    if _is_legacy_action(action):
        return  # Blender 3.x-4.3: nothing to do

    if not hasattr(action, 'slots'):
        return

    # Create a slot for this object if none exists yet
    if len(action.slots) == 0:
        action.slots.new('OBJECT', name=obj.name if obj else 'Slot')

    # Ensure the layer → strip → channelbag chain exists
    if len(action.layers) == 0:
        action.layers.new('Layer')
    layer = action.layers[0]
    if len(layer.strips) == 0:
        layer.strips.new()
    strip = layer.strips[0]

    if hasattr(strip, 'channelbags') and len(strip.channelbags) == 0:
        slot = action.slots[0]
        strip.channelbags.new(slot=slot)


def _action_fcurve_new(action, data_path, index):
    """Create a new FCurve on an Action, compatible across Blender 3.x-5.x.

    Call ``_action_setup_slot(action, obj)`` **before** using this on Blender 5.x.
    """
    if _is_legacy_action(action) or not hasattr(action, 'slots'):
        return action.fcurves.new(data_path=data_path, index=index)

    # Blender 4.4+: hierarchy must already exist (set up by _action_setup_slot)
    strip = action.layers[0].strips[0]
    if hasattr(strip, 'channelbags') and len(strip.channelbags) > 0:
        bag = strip.channelbags[0]
    elif hasattr(strip, 'channelbag'):
        bag = strip.channelbag
    else:
        raise AttributeError(
            f"Strip has no channelbag. Call _action_setup_slot() first. "
            f"Available: {[a for a in dir(strip) if not a.startswith('_')]}"
        )

    coll = _get_fcurves_coll(bag, ('fcurves', 'channels'))
    return coll.new(data_path=data_path, index=index)


def _action_iter_fcurves(action):
    """Iterate over all FCurves in an Action, compatible across Blender versions."""
    if _is_legacy_action(action) or not hasattr(action, 'slots'):
        yield from action.fcurves
        return

    # Blender 4.4+: layers → strips → channelbags → fcurves
    for layer in action.layers:
        for strip in layer.strips:
            bags = (getattr(strip, 'channelbags', None)
                    or getattr(strip, 'channelbag', None))
            if bags is None:
                continue
            # Normalise to iterable
            if not hasattr(bags, '__iter__'):
                bags = [bags]
            for bag in bags:
                coll = getattr(bag, 'fcurves', None) or getattr(bag, 'channels', None)
                if coll is not None:
                    yield from coll


def safely_clear_action(obj):
    """Safely clear active action on an object without throwing if read-only or in tweak mode."""
    if not obj or not getattr(obj, 'animation_data', None):
        return
    ad = obj.animation_data
    try:
        if getattr(ad, 'use_tweak_mode', False):
            try:
                ad.use_tweak_mode = False
            except Exception:
                pass
        if hasattr(ad, 'is_property_readonly') and ad.is_property_readonly('action'):
            return
        if ad.action:
            ad.action.use_fake_user = True
        ad.action = None
        if hasattr(ad, 'action_slot'):
            try:
                ad.action_slot = None
            except Exception:
                pass
    except Exception as e:
        print(f"Warning: Could not clear action on {getattr(obj, 'name', 'unnamed')}: {e}")


def safely_set_action(obj, action):
    """Safely assign an action to an object's animation_data."""
    if not obj:
        return
    if not obj.animation_data:
        obj.animation_data_create()
    ad = obj.animation_data
    try:
        if getattr(ad, 'use_tweak_mode', False):
            try:
                ad.use_tweak_mode = False
            except Exception:
                pass
        if hasattr(ad, 'is_property_readonly') and ad.is_property_readonly('action'):
            print(f"Warning: Cannot set action on {getattr(obj, 'name', 'unnamed')}, animation_data.action is read-only")
            return
        ad.action = action
        if hasattr(ad, 'action_slot') and hasattr(action, 'slots') and len(action.slots) > 0:
            try:
                ad.action_slot = action.slots[0]
            except Exception:
                pass
    except Exception as e:
        print(f"Warning: Could not set action on {getattr(obj, 'name', 'unnamed')}: {e}")


class RebocapWsSdkV1(RebocapWsSdk):

    def __init__(self, coordinate_type: CoordinateType = CoordinateType.DefaultCoordinate, use_global_rotation=False):
        super().__init__(coordinate_type, use_global_rotation)
        super().set_pose_msg_callback(self.pose_msg_callback_own)
        self.last_msg = None
        self.record_list = None
        self._record_lock = Lock()
        self.recording_take_type = 'FK'
        self.connection_lost = False
        self.set_exception_close_callback(self._on_connection_lost)

    def pose_msg_callback_own(self, parent: RebocapWsSdk, trans: list, pose24: list, static_index: int, tp: float):
        self.last_msg = (trans, pose24, static_index, tp)
        with self._record_lock:
            if self.record_list is not None:
                self.record_list.append(self.last_msg)

    def get_last_msg(self):
        return self.last_msg

    def _on_connection_lost(self, parent):
        # SDK callbacks may run on a worker thread; only set a flag here.
        self.connection_lost = True

    def start_record(self):
        # Keep the type with the SDK buffer: Blender may have already removed
        # all scenes when Python's atexit callbacks are invoked.
        self.recording_take_type = recording_take_type(getattr(bpy.context, 'scene', None))
        with self._record_lock:
            self.record_list = []

    def stop_record(self):
        with self._record_lock:
            record_list = self.record_list
            self.record_list = None
        return record_list


rebocap_app: Optional[RebocapWsSdkV1] = None

rebocap_timer = None
rebocap_connected = False
connection_generation = 0
_active_connection_scene_name = ''
_active_connection_scene_pointer = 0
_active_live_library_binding = None
_active_live_library_unresolved = False
drive_direct_when_connect = True
cached_initial_pose = {}


class FrameData:
    def __init__(self, trans, pose24, static_index, ts) -> None:
        self.trans = trans
        self.pose24 = pose24
        self.static_index = static_index
        self.ts = ts


joints = [
    "mixamorig:Hips",
    "mixamorig:LeftUpLeg",
    "mixamorig:RightUpLeg",
    "mixamorig:Spine",
    "mixamorig:LeftLeg",
    "mixamorig:RightLeg",
    "mixamorig:Spine1",
    "mixamorig:LeftFoot",
    "mixamorig:RightFoot",
    "mixamorig:Spine2",
    "mixamorig:LeftToeBase",
    "mixamorig:RightToeBase",
    "mixamorig:Neck",
    "mixamorig:LeftShoulder",
    "mixamorig:RightShoulder",
    "mixamorig:Head",
    "mixamorig:LeftArm",
    "mixamorig:RightArm",
    "mixamorig:LeftForeArm",
    "mixamorig:RightForeArm",
    "mixamorig:LeftHand",
    "mixamorig:RightHand",
    "mixamorig:LeftHandIndex1",
    "mixamorig:RightHandIndex1"
]

idx_vec = [name.lower() for name in REBOCAP_JOINT_NAMES]
joints_lower = [name.lower() for name in joints]

stop_debug_thread = False


def live_control_active(scene):
    """Whether live input currently owns pose evaluation in this scene."""
    if not (scene.open and not scene.rebocap_pause_control
            and not scene.rebocap_playback_active and not preview_active(scene)):
        return False
    from ..core.control import drive_objects, find_conflict, ensure_live_source
    ensure_live_source(scene)
    return not find_conflict(scene, drive_objects(scene))

class BoneInfo:
    def __init__(self) -> None:
        self.rest_matrix_to_world = None
        self.rest_matrix_from_world = None
    
    def is_rest_init(self):
        if self.rest_matrix_to_world is None or self.rest_matrix_from_world is None:
            return False
        return True

    def rest_init(self, rest_matrix_to_world, rest_matrix_from_world):
        self.rest_matrix_to_world = rest_matrix_to_world
        self.rest_matrix_from_world = rest_matrix_from_world

    def get_rest_init(self):
        return (self.rest_matrix_to_world, self.rest_matrix_from_world)

class ObjInfo:
    def __init__(self) -> None:
        self.bone_map = {}
        self.root_bone = None
        self.matrix_global_hip = None
        self.matrix_global_2_root_inverse = None
        self.matrix_root_2_hip_inverse = None
        self.initial_mocap_trans = None
        self.initial_root_location = None
        self.context_key = None
        self.matrix_key = None

    def get_bone(self, name):
        if name in self.bone_map:
            return self.bone_map[name]
        return None

    def insert_bone(self, name):
        bone = BoneInfo()
        self.bone_map[name] = bone
        return bone

    def get_or_insert_bone(self, name):
        bone = self.get_bone(name)
        if bone is None:
            bone = self.insert_bone(name)
        return bone

    def set_root_info(self, root_bone, matrix_global_hip, matrix_global_2_root_inverse, matrix_root_2_hip_inverse):
        self.root_bone = root_bone
        self.matrix_global_hip = matrix_global_hip
        self.matrix_global_2_root_inverse = matrix_global_2_root_inverse
        self.matrix_root_2_hip_inverse = matrix_root_2_hip_inverse


class ObjInfoHelper:
    def __init__(self) -> None:
        self.obj_map = {}

    def get_obj(self, name):
        if name in self.obj_map:
            return self.obj_map[name]
        return None

    def insert_obj(self, name):
        obj = ObjInfo()
        self.obj_map[name] = obj
        return obj

    def get_or_insert_obj(self, name):
        obj = self.get_obj(name)
        if obj is None:
            obj = self.insert_obj(name)
        return obj


obj_info_helper = ObjInfoHelper()


@bpy.app.handlers.persistent
def clear_retarget_after_undo(_):
    global obj_info_helper
    obj_info_helper = ObjInfoHelper()
    restore_saved_recording_control()
    if rebocap_connected:
        scene = _find_connection_scene(_active_connection_scene_name, _active_connection_scene_pointer)
        if scene:
            scene.open = True
            _restore_live_library_binding_after_undo(scene)
            # SDK recording is not part of Blender's undo stack.
            if getattr(rebocap_app, 'record_list', None) is not None:
                scene.recording = True
            else:
                scene.recording = False
    # The restored snapshot contains authored animation and playback intent.
    # Rebuild the temporary pose before the next redraw, even on the same frame.
    from .history import rebocap_timeline_playback_handler
    for scene in bpy.data.scenes:
        if scene.rebocap_playback_active:
            rebocap_timeline_playback_handler(scene)


def _find_connection_scene(name, pointer):
    """Find the owning scene after undo without adopting an unrelated scene."""
    scene = bpy.data.scenes.get(name) if name else None
    if scene is not None and (not pointer or scene.as_pointer() == pointer):
        return scene
    if pointer:
        return next((item for item in bpy.data.scenes if item.as_pointer() == pointer), None)
    return None


def _restore_live_library_binding_after_undo(scene):
    """Restore the last actual live link, never a replacement with its name."""
    global _active_live_library_unresolved
    binding = _active_live_library_binding
    if not binding:
        return
    try:
        scene_uid = getattr(scene, 'session_uid', None)
        if scene_uid is None or scene_uid != binding['scene_uid'] or binding['source_uid'] is None:
            raise ValueError('Live linked source identity cannot be restored')
        matches = [obj for obj in scene.objects if getattr(obj, 'session_uid', None) == binding['source_uid']]
        if len(matches) != 1 or matches[0].data != binding['data']:
            raise ValueError('Live linked source identity cannot be restored')
        source = matches[0]
        from .history import record_linked_binding
        record_linked_binding(scene, source, binding['fingerprint'], structure=binding['structure'])
        _active_live_library_unresolved = False
    except (ReferenceError, RuntimeError, TypeError, ValueError) as error:
        print(f'[Rebocap] {error}')
        _active_live_library_unresolved = True
        scene.rebocap_live_binding_warning = 'Live linked identity requires reconnect'
        from .history import preserve_project_for_linked_library_conflict
        preserve_project_for_linked_library_conflict(force=True)


def t_run():
    global stop_debug_thread
    print(f'started!!!!!!!')
    while True:
        time.sleep(1.0)
        continue


# 注册退出函数
if sys.gettrace() is not None:
    t = Thread(target=t_run)
    t.start()


def init_rebocap_api():
    global rebocap_app
    print(f'first init rebocap api')
    rebocap_app = RebocapWsSdkV1(coordinate_type=CoordinateType.BlenderCoordinate)
    # Blender 3.6 and 4.2 do not expose an exit_pre handler. Python atexit
    # still runs on normal Blender exit, while the SDK buffer is available.
    atexit.unregister(preserve_recording_on_exit)
    atexit.register(preserve_recording_on_exit)
    discover_exit_recording_recovery()
    print(f'finish init rebocap api')


def uninit_rebocap_api():
    global rebocap_app
    for scene in bpy.data.scenes:
        if getattr(scene, 'recording', False):
            try:
                stop_record(bpy.context, scene=scene)
            except Exception as error:
                print(f"[Rebocap] Could not finalize recording: {error}")
    force_disconnect()
    rebocap_app = None
    if not has_pending_recording():
        atexit.unregister(preserve_recording_on_exit)


def show_error_message(self, ctx):
    self.layout.label(text=ctx.scene.error_msg)


def get_pose_idx(bone: bpy.types.PoseBone):
    if bone.rebocap_init:
        return bone.rebocap_pose_idx
    name_l = bone.name.lower()
    for idx, name in enumerate(idx_vec):
        if name.lower() == name_l:
            bone.rebocap_pose_idx = idx
            bone.rebocap_init = True
            return bone.rebocap_pose_idx
    for idx, name in enumerate(joints_lower):
        if name == name_l:
            bone.rebocap_pose_idx = idx
            bone.rebocap_init = True
            return bone.rebocap_pose_idx
    bone.rebocap_init = True
    return bone.rebocap_pose_idx


def show_error(msg, ctx):
    ctx.scene.error_msg = msg
    bpy.context.window_manager.popup_menu(
        show_error_message, title="Error", icon='ERROR')


def compute_hierarchical_t_pose(source_obj, scene, is_retarget=False, bone_names=None):
    t_pose_matrices = {}
    bone_name_to_idx = {}
    
    if is_retarget:
        rebocap_bone_map = scene.rebocap_bone_map
        for i in range(22):
            bname = bone_names[i] if bone_names is not None else getattr(rebocap_bone_map, f'node_{i}')
            if bname:
                bone_name_to_idx[bname] = i
    else:
        for pb in source_obj.pose.bones:
            idx = get_pose_idx(pb)
            if idx != -1:
                bone_name_to_idx[pb.name] = idx
                
    def get_matrix(bone):
        if bone.name in t_pose_matrices:
            return t_pose_matrices[bone.name]
            
        parent = bone.parent
        if parent:
            parent_t_pose = get_matrix(parent)
            rest_local = parent.matrix_local.inverted() @ bone.matrix_local
        else:
            parent_t_pose = Matrix.Identity(4)
            rest_local = bone.matrix_local
            
        a2t_quat = Quaternion()
        if bone.name in bone_name_to_idx:
            idx = bone_name_to_idx[bone.name]
            if idx not in (10, 11, 22, 23):
                a2t_quat = get_a2t_quat_for_node_idx(scene, idx)
                
        t_pose = parent_t_pose @ rest_local @ a2t_quat.to_matrix().to_4x4()
        t_pose_matrices[bone.name] = t_pose
        return t_pose

    for bone in source_obj.data.bones:
        get_matrix(bone)
        
    return t_pose_matrices


class CustomObj:
    def __init__(self, obj: bpy.types.Object) -> None:
        self.obj = None
        self.vec = []
        self.update_obj(obj)

    def update(self, obj: bpy.types.Object):
        if self.obj == obj:
            return
        self.update_obj(obj)

    def update_obj(self, obj: bpy.types.Object):
        self.vec = [None for _ in range(24)]
        for bone in obj.pose.bones:
            name = bone.name.lower()
            for idx, item in enumerate(idx_vec):
                if item.lower() in name or joints_lower[idx] in name:
                    self.vec[idx] = (bone, obj.data.bones.get(bone.name))
                    break
        self.obj = obj


class RebocapConnect(bpy.types.Operator):
    bl_idname = 'rebocap.connect'
    bl_label = 'Connect'
    pelvis_offset = [0.0, 0.0, 0.0]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.reinit_data()
        self.root_bone_matrix_inverse = None

    def reinit_data(self):
        self.obj_map = {}
        self.root_bone = None
        global obj_info_helper
        obj_info_helper = ObjInfoHelper()
        self.root_relative_position = Vector((0.0, 0.0, 0.0))
        self.root_bone_matrix_inverse = None
        self.initial_mocap_trans = None
        self.initial_root_location = None
        self._retarget_context = None
        self._retarget_identity = None
        self._retarget_library_source = None
        self._retarget_library_source_name = ''
        self._retarget_library_hash = ''
        self._retarget_library_data_pointer = 0
        self._retarget_same_library_reload = False
        self.cached_t_pose_matrices = None
        self._demo_initial_trans = None
        self._demo_initial_poses = None

    def execute(self, ctx):
        global rebocap_app, rebocap_connected, drive_direct_when_connect, connection_generation, _active_connection_scene_name, _active_connection_scene_pointer
        if rebocap_connected:
            return {'CANCELLED'}
        if rebocap_app is None:
            self.report({'ERROR'}, T("Rebocap SDK is unavailable"))
            return {'CANCELLED'}

        from .history import playback_identity_conflict
        if (ctx.scene.rebocap_playback_active and
                ctx.scene.rebocap_playback_mode in ('FK', 'DUAL') and
                playback_identity_conflict(ctx.scene)):
            self.report({'WARNING'}, T('Playback bone binding cannot be confirmed'))
            return {'CANCELLED'}

        from ..core.control import drive_objects, find_conflict, conflict_message
        conflict = find_conflict(ctx.scene, drive_objects(ctx.scene))
        if conflict:
            self.report({'WARNING'}, conflict_message(conflict))
            return {'CANCELLED'}

        source_obj = bpy.data.objects.get(ctx.scene.rebocap_source_armature)

        rebocap_bone_map = ctx.scene.rebocap_bone_map
        
        # A saved or manually configured skeleton is not an invitation to
        # import a different running host's configuration on connect.
        try:
            from .ik_tracking import get_rebocap_config_path, may_auto_detect_config, read_and_sync_config
            config_path = rebocap_bone_map.ik_config_path
            if may_auto_detect_config(ctx.scene):
                config_path = get_rebocap_config_path()
            if config_path and os.path.exists(config_path):
                status = read_and_sync_config(ctx.scene, config_path)
                if status == 'SYNC_ERROR':
                    self.report({'WARNING'}, T("Unable to update tracking nodes"))
                    return {'CANCELLED'}
                if status == 'READ_ERROR':
                    self.report({'WARNING'}, T("Unable to read skeleton configuration"))
        except Exception as e:
            print(f"Error auto-refreshing IK config on connect: {e}")
            self.report({'WARNING'}, T("Unable to update tracking nodes"))
            return {'CANCELLED'}
                
        if source_obj is not None and source_obj.type != 'ARMATURE':
            self.report({'ERROR'}, T("Please select an armature as the source"))
            return {'CANCELLED'}
        if source_obj is not None:
            avatar = source_obj
            down_body = [
                0, 1, 4, 7, 2, 5, 8  # root, left legs,  right legs
            ]

            bones = [avatar.pose.bones.get(getattr(rebocap_bone_map, f'node_{e}', '')) for e in down_body]
            if None in bones:
                show_message_box(message='down body not all bind, please set target bone for Legs and Pelvis')
                return {'CANCELLED'}

        rebocap_app.last_msg = None
        rebocap_app.connection_lost = False
        from .history import linked_library, linked_data_key
        bound_library_source = source_obj if source_obj and linked_library(source_obj.data) else None
        bound_library_source_name = bound_library_source.name if bound_library_source else ''
        bound_library_data_pointer = linked_data_key(bound_library_source.data) if bound_library_source else 0
        if bound_library_source:
            from .history import _linked_library_hash
            bound_library_hash = _linked_library_hash(bound_library_source.data)
        else:
            bound_library_hash = None
        res = rebocap_app.open(ctx.scene.port, uid=random.randint(1, 100000))
        if res != 0:
            show_error(f"Connect Fail. ret={res}", ctx)
            return {'CANCELLED'}

        # Cache the initial pose for restoring later
        global cached_initial_pose
        cached_initial_pose.clear()
        source_obj = bpy.data.objects.get(ctx.scene.rebocap_source_armature)
        if source_obj and source_obj.type == 'ARMATURE':
            for pb in source_obj.pose.bones:
                cached_initial_pose[pb.name] = (pb.location.copy(), pb.rotation_quaternion.copy(), pb.rotation_euler.copy())
                
        # Also cache tracking nodes
        for obj in bpy.context.scene.objects:
            if obj.name.startswith("Rebocap_") and obj.type == 'EMPTY':
                cached_initial_pose[obj.name] = (obj.location.copy(), obj.rotation_quaternion.copy(), obj.rotation_euler.copy())

        from .history import stop_playback
        stop_playback(ctx.scene)
        from ..core.a2t_types import set_live_pause
        set_live_pause(ctx.scene, False)
        self.reinit_data()
        if bound_library_hash:
            self._retarget_library_source = bound_library_source
            self._retarget_library_source_name = bound_library_source_name
            self._retarget_library_hash = bound_library_hash
            self._retarget_library_data_pointer = bound_library_data_pointer
        self._scene = ctx.scene
        self._scene_name = ctx.scene.name
        self._scene_pointer = ctx.scene.as_pointer()
        _active_connection_scene_name = ctx.scene.name
        _active_connection_scene_pointer = self._scene_pointer
        connection_generation += 1
        self._generation = connection_generation
        self._last_data_ts = None
        ctx.window_manager.modal_handler_add(self)
        global rebocap_timer
        rebocap_timer = ctx.window_manager.event_timer_add(1 / 60, window=ctx.window)
        ctx.scene.open = True
        rebocap_connected = True
        from ..core.control import remember_live_source, synchronize_owners
        remember_live_source(ctx.scene)
        synchronize_owners()
        return {'RUNNING_MODAL'}

    def drive_demo_character(self, trans, pose24):
        drive_demo_character(trans, pose24, scene=self._scene, pose_layer=recording_pose_layer(self._scene))

    def drive_ik_tracking(self, trans, pose24):
        drive_ik_tracking(trans, pose24, scene=self._scene, pose_layer=recording_pose_layer(self._scene))

    def drive_retarget(self, trans, pose24, static_index, ts):
        scene = self._scene
        if _active_live_library_unresolved:
            scene.rebocap_live_binding_warning = 'Live linked identity requires reconnect'
            return
        source_obj, hip, root, context_key = retarget_context(scene)
        if context_key is None:
            # Mapping edits can temporarily remove the target. Keep the last
            # baseline until a valid target proves that it really changed.
            return
        session = _recording_control
        if (session is not None and session.scene == scene and
                (source_obj, source_obj.data, hip, root) != session.fk_binding):
            # An object replacement or hierarchy change can bypass the RNA
            # update. Wait for a validated binding before writing any FK pose.
            return
        if not _live_library_binding_valid(self, scene, source_obj):
            return
        identity = retarget_bone_identity(source_obj, hip)
        try:
            same_target = (getattr(self, '_retarget_identity', None) == identity or
                           getattr(self, '_retarget_context', None) == context_key)
        except ReferenceError:
            same_target = getattr(self, '_retarget_context', None) == context_key
        old_context = getattr(self, '_retarget_context', None)
        if (getattr(self, '_retarget_same_library_reload', False) and old_context and
                old_context[2] == context_key[2]):
            same_target = True
        if not same_target:
            self.initial_mocap_trans = Vector(trans)
            self.initial_root_location = root.location.copy()
        self._retarget_identity = identity
        self._retarget_context = context_key
        drive_retarget(trans, pose24, static_index, ts, scene=scene,
                       initial_mocap_trans=self.initial_mocap_trans,
                       initial_root_location=self.initial_root_location,
                       pose_layer=recording_pose_layer(scene))

    def modal(self, ctx, evt):
        global rebocap_app, rebocap_connected, drive_direct_when_connect, _active_connection_scene_name, _active_connection_scene_pointer
        if (not rebocap_connected or rebocap_app is None
                or self._generation != connection_generation):
            return {'FINISHED'}
        try:
            self._scene.name
        except ReferenceError:
            # The scene has been reconstructed by undo/redo. Rebind without
            # discarding the initial motion origin or the SDK recording buffer.
            self._scene = _find_connection_scene(getattr(self, '_scene_name', ''),
                                                 getattr(self, '_scene_pointer', 0))
            if self._scene is None:
                # The owner was deleted, not merely reconstructed by undo.
                # force_disconnect retains any SDK recording for explicit retry.
                force_disconnect()
                return {'FINISHED'}
            if getattr(rebocap_app, 'record_list', None) is not None:
                self._scene.recording = True
        if ctx.scene != self._scene or rebocap_app.connection_lost:
            try:
                if self._scene.recording:
                    stop_record(ctx, scene=self._scene)
            finally:
                force_disconnect()
            return {'FINISHED'}
        self._scene_name = self._scene.name
        self._scene_pointer = self._scene.as_pointer()
        _active_connection_scene_name = self._scene_name
        _active_connection_scene_pointer = self._scene_pointer

        # ONLY process animation & mocap drive on TIMER ticks (prevents mousemove spam)
        if evt.type == 'TIMER':
            if getattr(ctx.scene, 'recording', False):
                rebocap_app.recording_take_type = recording_take_type(ctx.scene)
                if not _synchronize_recording_animation(ctx.scene):
                    return {'PASS_THROUGH'}
            if not live_control_active(ctx.scene):
                return {'PASS_THROUGH'}

            if getattr(ctx.scene, 'recording', False) and getattr(ctx.scene, 'rebocap_auto_extend_end', True):
                if ctx.scene.frame_current >= ctx.scene.frame_end - 2:
                    ctx.scene.frame_end += 60

            try:
                last_data = rebocap_app.get_last_msg()
                if last_data is not None and last_data[3] != self._last_data_ts:
                    # Only force redraw if we actually received real-time data
                    # Check if user wants to throttle redraws to Scene FPS
                    sync_fps = getattr(ctx.scene, 'rebocap_sync_viewport_fps', True)

                    if not sync_fps:
                        # Full speed redraw (60Hz default)
                        trans, pose24, static_index, ts = last_data
                        self._last_data_ts = ts
                        self.drive_retarget(trans, pose24, static_index, ts)
                        self.drive_demo_character(trans, pose24)
                        self.drive_ik_tracking(trans, pose24)
                        for window in ctx.window_manager.windows:
                            for area in window.screen.areas:
                                if area.type in ('VIEW_3D', 'PROPERTIES'):
                                    area.tag_redraw()
                    else:
                        import time
                        current_time = time.time()
                        if not hasattr(self, "_last_redraw_time"):
                            self._last_redraw_time = 0

                        scene_fps = ctx.scene.render.fps / ctx.scene.render.fps_base
                        scene_fps = max(10.0, min(120.0, scene_fps)) # clamp sensible range
                        redraw_interval = 1.0 / scene_fps

                        if current_time - self._last_redraw_time >= redraw_interval:
                            self._last_redraw_time = current_time

                            # Move math inside throttle! Mutating RNA forces Blender depsgraph redraw.
                            trans, pose24, static_index, ts = last_data
                            self._last_data_ts = ts
                            self.drive_retarget(trans, pose24, static_index, ts)
                            self.drive_demo_character(trans, pose24)
                            self.drive_ik_tracking(trans, pose24)

                            for window in ctx.window_manager.windows:
                                for area in window.screen.areas:
                                    if area.type in ('VIEW_3D', 'PROPERTIES'):
                                        area.tag_redraw()
            except Exception as e:
                # Safe disconnect if connection broke down
                print(f"[Rebocap] Driver error: {e}")

        return {'PASS_THROUGH'}



def evaluated_world_matrix(scene, obj):
    """Read the object's evaluated transform in the scene that owns the drive."""
    layers = list(scene.view_layers)
    if bpy.context.scene == scene and bpy.context.view_layer in layers:
        layers.remove(bpy.context.view_layer)
        layers.insert(0, bpy.context.view_layer)
    for layer in layers:
        if layer.objects.get(obj.name) == obj:
            return obj.evaluated_get(layer.depsgraph).matrix_world.copy()
    return obj.matrix_world.copy()


def _demo_armature(scene):
    return next((obj for obj in scene.objects
                 if obj.get("rebocap_demo_character") and obj.type == 'ARMATURE'), None)


def recording_pose_layer(scene):
    session = _recording_control
    return session.pose if session is not None and session.scene == scene and not session.suspended else None


def _write_drive_transform(target, prop, value, pose_layer, before_rotation_mode=None):
    if pose_layer is not None and pose_layer.write(target, prop, value):
        return
    if prop == 'rotation_quaternion' and isinstance(target, bpy.types.PoseBone):
        if before_rotation_mode and target.rotation_mode != 'QUATERNION':
            before_rotation_mode(target)
        target.rotation_mode = 'QUATERNION'
    setattr(target, prop, value)


def drive_demo_character(trans, pose24, scene=None, *, before_rotation_mode=None, pose_layer=None):
    scene = scene if scene is not None else bpy.context.scene
    demo_robot = _demo_armature(scene)
    if demo_robot:
        object_world = evaluated_world_matrix(scene, demo_robot)
        hip_pbone = demo_robot.pose.bones.get('mixamorig:Hips')
        hip_bone_data = demo_robot.data.bones.get('mixamorig:Hips')
        if hip_pbone and hip_bone_data:
            # 获取标定好的静止基础贴地位移
            base_loc = Vector(demo_robot.get('rebocap_adapted_hip_location', (0.0, 0.0, 0.0)))

            # 获取当前模式下的静止骨盆高
            rest_pelvis_z = demo_robot.get('rebocap_rest_pelvis_z', None)
            if rest_pelvis_z is None:
                node_pelvis = scene.objects.get('Rebocap_Pelvis')
                rest_pelvis_z = node_pelvis.matrix_world.translation.z if node_pelvis else trans[2]
                demo_robot['rebocap_rest_pelvis_z'] = float(rest_pelvis_z)

            delta_z = trans[2] - rest_pelvis_z
            delta_trans = Vector((trans[0], trans[1], delta_z))

            # 将世界增量转换到骨骼局部空间并叠加，静止时增量为0保持绝对贴地
            world_to_local_rot = (object_world.to_3x3() @ hip_bone_data.matrix_local.to_3x3()).inverted()
            delta_local = world_to_local_rot @ delta_trans
            # The adapter layer already applies the static pelvis baseline.
            location = (delta_local if demo_robot.get('rebocap_demo_adapter_version')
                        else base_loc + delta_local)
            _write_drive_transform(hip_pbone, 'location', location, pose_layer)

        all_pose = [Quaternion([pose[3], pose[0], pose[1], pose[2]]) for pose in pose24]

        for idx, bone_name in enumerate(DEMO_BONE_NAMES):
            if idx in UNDRIVEN_BONE_INDICES:
                continue
            pbone = demo_robot.pose.bones.get(bone_name)
            data_bone = demo_robot.data.bones.get(bone_name)
            if pbone and data_bone:
                rest_to_world = object_world.to_quaternion() @ data_bone.matrix_local.to_quaternion()
                rest_from_world = rest_to_world.inverted()
                _write_drive_transform(pbone, 'rotation_quaternion',
                                       rest_from_world @ all_pose[idx] @ rest_to_world,
                                       pose_layer, before_rotation_mode)


def drive_ik_tracking(trans, pose24, scene=None, *, pose_layer=None):
    scene = scene if scene is not None else bpy.context.scene
    root_name = "Rebocap_Root"
    root = scene.objects.get(root_name)
    if not root or root.type != 'EMPTY':
        return

    joints = TRACKING_JOINT_NAMES

    pelvis_node = scene.objects.get("Rebocap_Pelvis")
    if pelvis_node and pelvis_node.type == 'EMPTY' and pelvis_node.parent == root:
        _write_drive_transform(pelvis_node, 'location', Vector(trans[:3]), pose_layer)

    for i, name in enumerate(joints):
        node = scene.objects.get(f"Rebocap_{name}")
        if node and node.type == 'EMPTY':
            pose = pose24[i]
            _write_drive_transform(node, 'rotation_quaternion',
                                   Quaternion([pose[3], pose[0], pose[1], pose[2]]), pose_layer)
    return


def retarget_context(scene, source_override=None, hip_name_override=None):
    """Identify the actual armature, mapped pelvis and its rest hierarchy."""
    obj = source_override if source_override is not None else scene.objects.get(scene.rebocap_source_armature)
    if obj is None or obj.type != 'ARMATURE':
        return None, None, None, None
    hip_name = hip_name_override if hip_name_override is not None else scene.rebocap_bone_map.node_0
    hip = obj.pose.bones.get(hip_name)
    if hip is None:
        return obj, None, None, None
    root = hip
    chain = []
    while root:
        rest = obj.data.bones.get(root.name)
        if rest is None:
            return obj, hip, None, None
        chain.append((root.name, tuple(tuple(row) for row in rest.matrix_local)))
        if root.parent is None:
            break
        root = root.parent
    key = (obj.as_pointer(), obj.data.as_pointer(), tuple(chain))
    return obj, hip, root, key


def retarget_bone_identity(source, hip):
    """Identify the rest hierarchy by bones and matrices, independently of names."""
    chain = []
    bone = hip
    while bone:
        rest = bone.bone
        chain.append((rest, tuple(tuple(row) for row in rest.matrix_local)))
        bone = bone.parent
    return source, source.data, tuple(chain)


def _live_library_binding_valid(connection, scene, source):
    """Stop live FK when its linked skeleton no longer has the bound bytes."""
    global _active_live_library_binding
    from .history import linked_library, linked_data_key
    if not linked_library(source.data):
        _active_live_library_binding = None
        connection._retarget_library_source = None
        connection._retarget_library_source_name = ''
        connection._retarget_library_hash = ''
        connection._retarget_library_data_pointer = 0
        connection._retarget_same_library_reload = False
        scene.rebocap_live_binding_warning = ''
        return True
    previous = getattr(connection, '_retarget_library_source', None)
    try:
        same_source = previous is not None and previous == source
        if (previous is not None and not same_source and
                scene.objects.get(previous.name) != previous):
            same_source = getattr(connection, '_retarget_library_source_name', '') == source.name
    except ReferenceError:
        # A stale wrapper after undo is not proof of identity; a matching name
        # can only retain the existing protection, never authorize a rebind.
        same_source = getattr(connection, '_retarget_library_source_name', '') == source.name
    from .history import _linked_library_hash, record_linked_binding
    previous_data = getattr(connection, '_retarget_library_data_pointer', 0)
    data_pointer = linked_data_key(source.data)
    reloaded = bool(same_source and previous_data and previous_data != data_pointer)
    fingerprint = _linked_library_hash(source.data, refresh=reloaded)
    expected = getattr(connection, '_retarget_library_hash', '')
    if not fingerprint or (same_source and expected and fingerprint != expected):
        scene.rebocap_live_binding_warning = 'Live linked skeleton changed'
        return False
    try:
        structure = record_linked_binding(scene, source, fingerprint)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as error:
        print(f'[Rebocap] Cannot retain linked skeleton binding: {error}')
        scene.rebocap_live_binding_warning = 'Live linked identity requires reconnect'
        return False
    if not structure:
        scene.rebocap_live_binding_warning = 'Live linked identity requires reconnect'
        return False
    connection._retarget_library_source = source
    connection._retarget_library_source_name = source.name
    connection._retarget_library_hash = fingerprint
    connection._retarget_library_data_pointer = data_pointer
    connection._retarget_same_library_reload = bool(reloaded and expected == fingerprint)
    _active_live_library_binding = {
        'scene_uid': getattr(scene, 'session_uid', None),
        'source_uid': getattr(source, 'session_uid', None),
        'data': source.data,
        'fingerprint': fingerprint,
        'structure': structure,
    }
    scene.rebocap_live_binding_warning = ''
    return True


def drive_retarget(trans, pose24, static_index=0, ts=0.0, scene=None, initial_mocap_trans=None, initial_root_location=None,
                   source_override=None, mapping_override=None, *, before_rotation_mode=None, pose_layer=None):
    if scene is None:
        scene = bpy.context.scene
    source_obj = source_override if source_override is not None else scene.objects.get(scene.rebocap_source_armature)
    if source_obj is None or source_obj.type != 'ARMATURE':
        return
    object_world = evaluated_world_matrix(scene, source_obj)

    rebocap_bone_map = scene.rebocap_bone_map
    map_bones_names = list(mapping_override) if mapping_override is not None else [
        getattr(rebocap_bone_map, f'node_{i}') for i in range(22)
    ]
    if len(map_bones_names) != 22:
        raise ValueError('Retarget mapping must contain 22 bone names')
    map_bones = [
        source_obj.pose.bones.get(map_bones_names[i]) if map_bones_names[i] != '' else None for i in range(22)
    ]

    global obj_info_helper
    obj_info = obj_info_helper.get_or_insert_obj(source_obj.name)

    # handle merge pose for spine and chest
    hip_bone = map_bones[0]
    spine_bone = map_bones[3]
    chest_bone = map_bones[6]
    up_chest_bone = map_bones[9]
    left_shoulder_bone = map_bones[13]
    right_shoulder_bone = map_bones[14]
    left_arm_bone = map_bones[16]
    right_arm_bone = map_bones[17]
    all_pose = []
    for pose in pose24:
        all_pose.append(Quaternion([pose[3], pose[0], pose[1], pose[2]]))

    if spine_bone is not None or chest_bone is not None or up_chest_bone is not None:
        if spine_bone is None:
            all_pose[6] = all_pose[3] @ all_pose[6]
        if chest_bone is None and up_chest_bone is None:
            all_pose[3] = all_pose[3] @ all_pose[6] @ all_pose[9]
        elif chest_bone is None:
            all_pose[9] = all_pose[6] @ all_pose[9]
        elif up_chest_bone is None:
            all_pose[6] = all_pose[6] @ all_pose[9]
    if left_shoulder_bone is None and left_arm_bone is not None:
        all_pose[16] = all_pose[13] @ all_pose[16]
    if right_shoulder_bone is None and right_arm_bone is not None:
        all_pose[17] = all_pose[14] @ all_pose[17]

    # Compute hierarchical T-pose matrices (reflects real-time A2T calibration adjustments)
    t_pose_matrices = compute_hierarchical_t_pose(source_obj, scene, is_retarget=True, bone_names=map_bones_names)

    # Solve root translation
    if hip_bone is not None:
        _, current_hip_bone, root_bone, context_key = retarget_context(scene, source_obj, map_bones_names[0])
        if context_key is None:
            return
        if obj_info.context_key != context_key:
            obj_info = obj_info_helper.insert_obj(source_obj.name)
            obj_info.context_key = context_key
        matrix_key = (context_key, tuple(tuple(row) for row in object_world))
        if obj_info.matrix_key != matrix_key:
            matrix_root_2_hip = source_obj.data.bones[root_bone.name].matrix_local.inverted() @ source_obj.data.bones[current_hip_bone.name].matrix_local
            matrix_global_2_root = object_world @ source_obj.data.bones.get(root_bone.name).matrix_local
            matrix_global_hip = object_world @ source_obj.data.bones[current_hip_bone.name].matrix_local
            obj_info.set_root_info(root_bone, matrix_global_hip, matrix_global_2_root.inverted(), matrix_root_2_hip.inverted())
            obj_info.matrix_key = matrix_key

        origin_hip_trans = Vector((trans[0], trans[1], trans[2]))
        keep_pos = getattr(scene, 'rebocap_keep_character_position', False)
        if keep_pos:
            if initial_mocap_trans is None:
                if obj_info.initial_mocap_trans is None:
                    obj_info.initial_mocap_trans = origin_hip_trans.copy()
                initial_mocap_trans = obj_info.initial_mocap_trans
            if initial_root_location is None and obj_info.root_bone:
                if obj_info.initial_root_location is None:
                    obj_info.initial_root_location = obj_info.root_bone.location.copy()
                initial_root_location = obj_info.initial_root_location

            delta_trans = origin_hip_trans - initial_mocap_trans
            root_bone_data = source_obj.data.bones.get(obj_info.root_bone.name)
            world_to_root_rot = (object_world.to_3x3() @ root_bone_data.matrix_local.to_3x3()).inverted()
            local_delta = world_to_root_rot @ delta_trans
            if initial_root_location is not None:
                _write_drive_transform(root_bone, 'location', initial_root_location + local_delta, pose_layer)
        else:
            new_global_hip: Matrix = obj_info.matrix_global_hip.copy()
            new_global_hip.translation = origin_hip_trans
            new_local_matrix = obj_info.matrix_global_2_root_inverse @ new_global_hip @ obj_info.matrix_root_2_hip_inverse
            _write_drive_transform(root_bone, 'location', new_local_matrix.translation, pose_layer)

    # Solve rotations
    for idx, bone in enumerate(map_bones):
        if bone is None or idx in UNDRIVEN_BONE_INDICES:
            if idx == 0 and bone is None:
                break
            continue
        bone_name = bone.name
        bone_info = obj_info.get_or_insert_bone(bone_name)
        data_bone = source_obj.data.bones.get(map_bones_names[idx])
        a2t_quat = get_a2t_quat_for_node_idx(scene, idx)
        t_mat = t_pose_matrices.get(bone_name)
        if t_mat:
            virtual_rest_to_world = object_world.to_quaternion() @ t_mat.to_quaternion()
            virtual_rest_from_world = virtual_rest_to_world.inverted()
        else:
            virtual_rest_to_world = object_world.to_quaternion()
            virtual_rest_from_world = virtual_rest_to_world.inverted()

        pose = all_pose[idx]
        mocap_delta_T = virtual_rest_from_world @ pose @ virtual_rest_to_world
        _write_drive_transform(bone, 'rotation_quaternion', a2t_quat @ mocap_delta_T,
                               pose_layer, before_rotation_mode)



def _recording_binding(scene):
    source, hip, root, _ = retarget_context(scene)
    mapping = tuple(getattr(scene.rebocap_bone_map, f'node_{i}') for i in range(22))
    return (source, source.data if source is not None else None, hip, root), mapping


def _recording_channels(scene, binding, mapping):
    """Resolve the properties actually written by the live solvers."""
    channels, rotation_bones = {}, set()

    def add(target, *properties):
        if target is not None:
            channels.setdefault(target.id_data, set()).update(
                target.path_from_id(prop) for prop in properties)

    def add_rotations(obj, names):
        for index, name in enumerate(names):
            bone = obj.pose.bones.get(name)
            if bone is not None and index not in UNDRIVEN_BONE_INDICES:
                rotation_bones.add(bone)
                add(bone, 'rotation_quaternion', 'rotation_euler', 'rotation_axis_angle', 'rotation_mode')

    source, _, _, root = binding
    if root is not None:
        add(root, 'location')
        add_rotations(source, mapping)
    demo = _demo_armature(scene)
    if demo is not None:
        add(demo.pose.bones.get(DEMO_BONE_NAMES[0]), 'location')
        add_rotations(demo, DEMO_BONE_NAMES)
    tracking_root = scene.objects.get('Rebocap_Root')
    if tracking_root and tracking_root.type == 'EMPTY':
        for name in TRACKING_JOINT_NAMES:
            node = scene.objects.get(f'Rebocap_{name}')
            if node and node.type == 'EMPTY':
                add(node, 'rotation_quaternion')
                if name == 'Pelvis' and node.parent == tracking_root:
                    add(node, 'location')
    return channels, rotation_bones


def update_recording_binding(scene):
    """Transfer the recording's FK isolation before the next live write."""
    session = _recording_control
    if session is None or session.scene != scene or session.rebinding:
        return
    from ..core.control import conflict_message, find_conflict, remember_live_source
    from .history import _linked_library_hash, linked_library
    session.rebinding = True
    try:
        binding, mapping = _recording_binding(scene)
        if (binding, mapping) == (session.fk_binding, session.mapping):
            return
        source, data, _, root = binding
        if scene.rebocap_source_armature and (
                root is None or data.is_editmode or source.is_missing or data.is_missing
                or (linked_library(data) and not _linked_library_hash(data))):
            raise ValueError(scene.rebocap_source_armature)
        channels, rotation_bones = _recording_channels(scene, binding, mapping)
        conflict = find_conflict(scene, channels)
        if conflict:
            raise ValueError(conflict_message(conflict))
        session.rebind(channels, rotation_bones, refresh_frame=True)
        session.fk_binding, session.mapping = binding, mapping
        session.undo_intent.update(_recording_channel_intent(session))
        scene[_RECORDING_INTENT] = session.undo_intent
    except (ReferenceError, RuntimeError, TypeError, ValueError) as error:
        previous = session.fk_binding[0]
        previous_name = ''
        try:
            if previous is not None and scene.objects.get(previous.name) == previous:
                previous_name = previous.name
        except ReferenceError:
            pass
        if scene.rebocap_source_armature != previous_name:
            scene.rebocap_source_armature = previous_name
        for index, name in enumerate(session.mapping):
            attribute = f'node_{index}'
            if getattr(scene.rebocap_bone_map, attribute) != name:
                setattr(scene.rebocap_bone_map, attribute, name)
        remember_live_source(scene)
        print(f"[Rebocap] {T('Cannot isolate recording animation channels')}: {error}")
    finally:
        session.rebinding = False


def _recording_driver_intent(session):
    return [{'target': obj, 'curves': [{'path': curve.data_path, 'index': curve.array_index,
                                       'evaluation_only': True} for curve in curves]}
            for obj, curves in session.drivers.items()]


def _synchronize_recording_animation(scene):
    session = _recording_control
    if session is None or session.scene != scene or session.suspended:
        return True
    try:
        session.refresh()
        drivers = _recording_driver_intent(session)
        if drivers != session.undo_intent['drivers']:
            session.undo_intent['drivers'] = drivers
            scene[_RECORDING_INTENT] = session.undo_intent
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as error:
        if session.animation_error != str(error):
            print(f"[Rebocap] {T('Cannot isolate recording animation channels')}: {error}")
        session.animation_error = str(error)
        return False
    session.animation_error = None
    return True


@bpy.app.handlers.persistent
def synchronize_recording_before_frame(scene, _depsgraph=None):
    if getattr(scene, 'recording', False):
        _synchronize_recording_animation(scene)


@bpy.app.handlers.persistent
def restore_duplicated_recording_state(_scene, depsgraph):
    from .channel_pose import release_copied_constraints
    from .playback_control import has_active_sessions
    session = _recording_control
    if session is None and not has_active_sessions():
        return
    for update in depsgraph.updates:
        obj = update.id.original
        if isinstance(obj, bpy.types.Object):
            if session is not None and not session.suspended:
                session.restore_foreign_state(obj)
            else:
                release_copied_constraints(obj)


def _recording_channel_intent(session):
    modes = {}
    for bone, mode in session.rotation_modes.items():
        if mode != 'QUATERNION':
            modes.setdefault(bone.id_data, {})[bone.name] = mode
    return {
        'modes': [{'target': obj, 'bones': bones} for obj, bones in modes.items()],
        'drivers': _recording_driver_intent(session),
    }


def _recording_undo_intent(session):
    # An undo step can include temporary properties and RNA reconstructed by
    # Blender. Keep a small ID-backed snapshot with that step only.
    scene = session.scene
    return {
        'paused': session.paused,
        'take': scene.rebocap_playback_take_uuid if session.playback is not None else '',
        'resume_live': scene.rebocap_playback_resume_live,
        'frame_start': scene.frame_start,
        'frame_end': scene.frame_end,
        'frame': session.frame[0],
        'subframe': session.frame[1],
        **_recording_channel_intent(session),
    }


def restore_saved_recording_control():
    from .history import restore_playback_rotation_modes
    restore_saved_action_bindings()
    for scene in bpy.data.scenes:
        if _RECORDING_INTENT in scene:
            _restore_recording_intent(scene)
        # Preview recovery snapshots can contain the direct playback pose.
        # Do not adopt its temporary rotation mode as the authored mode.
        restore_playback_rotation_modes(scene)


def _restore_recording_intent(scene):
    intent = scene[_RECORDING_INTENT].to_dict()
    del scene[_RECORDING_INTENT]
    scene.recording = False
    for record in intent['modes']:
        target = record['target']
        if target is None or target.type != 'ARMATURE' or scene.objects.get(target.name) != target:
            continue
        for name, mode in record['bones'].items():
            bone = target.pose.bones.get(name)
            if bone is not None:
                restore_rotation_mode(bone, mode)
    for record in intent.get('drivers', ()):
        target = record['target']
        if target is None or scene.objects.get(target.name) != target or not target.animation_data:
            continue
        keys = {(curve['path'], curve['index']): curve for curve in record['curves']}
        for driver in target.animation_data.drivers:
            saved = keys.get((driver.data_path, driver.array_index))
            if saved and saved.get('evaluation_only'):
                driver.is_valid = True
            elif saved:
                driver.mute = False
        target.update_tag()
    take_id = intent['take']
    if take_id and any(take.uuid == take_id for take in scene.rebocap_takes):
        scene.frame_start, scene.frame_end = intent['frame_start'], intent['frame_end']
        scene.rebocap_playback_take_uuid = take_id
        scene.rebocap_playback_resume_live = intent['resume_live']
        scene.rebocap_playback_active = True
        scene.frame_set(intent['frame'], subframe=intent['subframe'])
    scene.rebocap_pause_control = intent['paused']


def _end_recording_control(ctx, scene=None, *, rollback=False):
    global _recording_control
    session = _recording_control
    if session is None or (scene is not None and session.scene != scene):
        return
    _recording_control = None
    state = session.playback
    scene = session.scene
    try:
        session.close()
    except (RuntimeError, ValueError) as error:
        print(f'[Rebocap] Recording animation restoration failed: {error}')
    finally:
        from .history import restore_playback
        try:
            if _RECORDING_INTENT in scene:
                del scene[_RECORDING_INTENT]
            if state is not None:
                restore_playback(scene, state)
            else:
                scene.rebocap_pause_control = session.paused
            if state is not None or rollback:
                frame, subframe = session.frame
                scene.frame_set(frame, subframe=subframe)
            else:
                scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
        except ReferenceError:
            pass
        finally:
            if not session.timeline_was_playing:
                force_stop_animation(ctx)
            elif scene == ctx.scene and ctx.screen is not None:
                force_start_animation(ctx)


@bpy.app.handlers.persistent
def suspend_recording_channels_for_save(_):
    session = _recording_control
    if session is None or session.suspended:
        return
    from .history import restore_playback, snapshot_playback
    scene = session.scene
    session.saved_recording_control = (
        scene.rebocap_pause_control,
        (scene.frame_current, scene.frame_subframe),
        snapshot_playback(scene) if session.playback is not None else None,
    )
    if _RECORDING_INTENT in scene:
        del scene[_RECORDING_INTENT]
    session.suspend_for_save()
    if session.playback is None:
        scene.rebocap_pause_control = session.paused
    else:
        restore_playback(scene, session.playback)
        # Write the recalled frame without evaluating another controller inside
        # the save transaction. The normal load handler evaluates this frame.
        scene.frame_current, scene.frame_subframe = session.frame


@bpy.app.handlers.persistent
def resume_recording_channels_after_save(_):
    session = _recording_control
    if session is not None:
        from .history import restore_playback
        scene = session.scene
        saved = session.saved_recording_control
        try:
            if saved is not None:
                paused, frame, state = saved
                if state is not None:
                    restore_playback(scene, state)
                    scene.frame_current, scene.frame_subframe = frame
                else:
                    scene.rebocap_pause_control = paused
        finally:
            session.saved_recording_control = None
            session.resume_after_save()
            scene[_RECORDING_INTENT] = session.undo_intent


@bpy.app.handlers.persistent
def stop_recording_before_undo(_):
    session = _recording_control
    if session is not None:
        stop_record(bpy.context, scene=session.scene, for_file_load=True)


_pending_recording = None
_pending_recording_backlog = []
_pending_checkpoint_paths = {}
_file_load_recording_notice = None
_last_recording_recovery_path = ''
_exit_recovery_paths = []
_EXIT_RECOVERY_MARKER = '.last-exit-recovery'
_recording_checkpoints = {}


def recording_take_type(scene):
    if scene is None:
        return 'FK'
    source = scene.objects.get(scene.rebocap_source_armature)
    has_fk = source is not None and source.type == 'ARMATURE'
    has_ik = scene.objects.get('Rebocap_Pelvis') is not None
    return 'DUAL' if has_fk and has_ik else 'IK' if has_ik else 'FK'


def preserve_recording_on_exit():
    """Persist raw buffers on normal exit, without accessing Blender scenes."""
    global _pending_recording, _last_recording_recovery_path
    from .history import write_recovery_recording

    buffers = []
    if _pending_recording is not None:
        buffers.append(_pending_recording)
    buffers.extend(_pending_recording_backlog)
    sdk = rebocap_app
    if sdk is not None:
        try:
            frames = sdk.stop_record()
            if frames:
                buffers.append((frames, getattr(sdk, 'recording_take_type', 'FK')))
        except Exception as error:
            print(f'[Rebocap] Could not finalize the SDK recording on exit: {error}')
    for frames, take_type in buffers:
        name = f'Take_{take_type}_exit_recovery'
        path = _pending_checkpoint_paths.get(id(frames))
        if not path or not os.path.isfile(path):
            try:
                path = write_recovery_recording(name, take_type, 60.0, frames,
                                                directory=recording_recovery_directory())
            except Exception as error:
                # The stable directory can be unwritable. A temporary recovery
                # is preferable to discarding the only copy.
                print(f'[Rebocap] Recovery directory is unavailable: {error}')
                try:
                    path = write_recovery_recording(name, take_type, 60.0, frames)
                except Exception as fallback_error:
                    print(f'[Rebocap] Could not preserve recording on exit: {fallback_error}')
                    continue
        _last_recording_recovery_path = str(path)
        remember_exit_recording_recovery(str(path))
        print(f'[Rebocap] Recording saved to a recovery file: {path}', flush=True)
        if _pending_recording is not None and frames is _pending_recording[0]:
            _pending_recording = None
        else:
            for index, pending in enumerate(_pending_recording_backlog):
                if frames is pending[0]:
                    del _pending_recording_backlog[index]
                    break
        _pending_checkpoint_paths.pop(id(frames), None)


def has_pending_recording():
    return _pending_recording is not None or bool(_pending_recording_backlog)


def _queue_pending_recording(frames, take_type):
    """Never replace a previously retained native buffer."""
    global _pending_recording
    if not frames:
        return
    record = (frames, take_type)
    if _pending_recording is None:
        _pending_recording = record
    else:
        _pending_recording_backlog.append(record)
    # Disconnect can happen before a Scene is available for a Take. Persist
    # the buffer immediately, while retaining it for an explicit retry.
    try:
        _pending_checkpoint_paths[id(frames)] = _checkpoint_recording(
            f'Take_{take_type}_pending', take_type, 60.0, frames)
    except Exception as error:
        print(f'[Rebocap] Pending recording remains in memory: {error}')


def _advance_pending_recording():
    global _pending_recording
    if _pending_recording is not None:
        _pending_checkpoint_paths.pop(id(_pending_recording[0]), None)
    _pending_recording = (_pending_recording_backlog.pop(0)
                          if _pending_recording_backlog else None)


def recording_recovery_path():
    return _last_recording_recovery_path


def recording_recovery_paths():
    """Return all discovered exit recoveries and the current load recovery."""
    paths = list(_exit_recovery_paths)
    if _last_recording_recovery_path and _last_recording_recovery_path not in paths:
        paths.append(_last_recording_recovery_path)
    return [path for path in paths if os.path.isfile(path)]


def recording_recovery_directory(create=True):
    # Local application data survives ordinary temporary-file cleanup.
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    directory = os.path.join(base, 'Rebocap', 'BlenderRecordingRecovery')
    if create:
        os.makedirs(directory, exist_ok=True)
    return directory


def _checkpoint_recording(name, take_type, fps, frames):
    """Retain a verified copy until a project containing this take is saved."""
    from .history import write_recovery_recording
    global _last_recording_recovery_path
    try:
        path = write_recovery_recording(name, take_type, fps, frames,
                                        directory=recording_recovery_directory())
    except Exception as error:
        print(f'[Rebocap] Recovery directory is unavailable: {error}')
        path = write_recovery_recording(name, take_type, fps, frames)
    path = str(path)
    _last_recording_recovery_path = path
    remember_exit_recording_recovery(path)
    return path


def _pending_checkpoint(name, take_type, fps, frames):
    path = _pending_checkpoint_paths.get(id(frames))
    if path and os.path.isfile(path):
        return path
    path = _checkpoint_recording(name, take_type, fps, frames)
    _pending_checkpoint_paths[id(frames)] = path
    return path


@bpy.app.handlers.persistent
def commit_recording_checkpoints_after_save(_):
    """Mark backups saved only when the saved project contains the same take."""
    from ..core.save_context import is_recovery_copy
    if is_recovery_copy():
        return
    from .history import read_take_stream
    global _last_recording_recovery_path
    if not bpy.data.filepath:
        return
    for take_id, path in list(_recording_checkpoints.items()):
        try:
            with open(path, encoding='utf-8') as source:
                document = json.load(source)
            for scene in bpy.data.scenes:
                take = next((item for item in scene.rebocap_takes if item.uuid == take_id), None)
                if take is None:
                    continue
                stream, _, _ = read_take_stream(take, refresh=True)
                if (stream == document.get('stream') and take.take_type == document.get('type')
                        and take.recorded_fps == document.get('recorded_fps')):
                    # Keep the backup on disk, but exclude it from recovery discovery.
                    os.replace(path, path + '.saved')
                    _recording_checkpoints.pop(take_id, None)
                    if path in _exit_recovery_paths:
                        _exit_recovery_paths.remove(path)
                    if _last_recording_recovery_path == path:
                        _last_recording_recovery_path = ''
                    break
        except (OSError, ValueError, TypeError, ReferenceError) as error:
            print(f'[Rebocap] Recording backup retained: {error}')


def _read_exit_recovery_marker(directory):
    try:
        with open(os.path.join(directory, _EXIT_RECOVERY_MARKER), encoding='utf-8') as source:
            names = json.load(source)
        if not isinstance(names, list):
            return []
        # The marker is a hint, not a trusted path: never accept names that
        # escape this directory or point to non-recovery files.
        return [name for name in names if isinstance(name, str)
                and name == os.path.basename(name)
                and name.startswith('rebocap-recovery-') and name.endswith('.json')
                and os.path.isfile(os.path.join(directory, name))]
    except (OSError, ValueError, TypeError):
        return []


def _scan_recording_recoveries(directory):
    """Find durable payloads even if an index write was interrupted."""
    try:
        with os.scandir(directory) as entries:
            return [entry.name for entry in entries
                    if entry.name.startswith('rebocap-recovery-')
                    and entry.name.endswith('.json')
                    and entry.is_file(follow_symlinks=False)]
    except OSError:
        return []


def remember_exit_recording_recovery(path):
    directory, name = os.path.split(path)
    names = _read_exit_recovery_marker(directory)
    for existing in _scan_recording_recoveries(directory):
        if existing not in names:
            names.append(existing)
    if name not in names:
        names.append(name)
    if path not in _exit_recovery_paths:
        _exit_recovery_paths.append(path)
    temp_path = None
    try:
        # Never truncate the last good index before the replacement is ready.
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=directory,
                                         prefix='.rebocap-index-', suffix='.tmp', delete=False) as output:
            temp_path = output.name
            json.dump(names, output)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_path, os.path.join(directory, _EXIT_RECOVERY_MARKER))
        temp_path = None
    except OSError as error:
        # The JSON payload already exists even if the UI hint cannot be written.
        print(f'[Rebocap] Could not save the recovery notice: {error}')
    finally:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                pass


def discover_exit_recording_recovery():
    """Show recoveries from both the stable and fallback directory after restart."""
    global _last_recording_recovery_path
    _exit_recovery_paths.clear()
    directories = [recording_recovery_directory(create=False)]
    try:
        directories.append(tempfile.gettempdir())
    except OSError:
        pass
    for directory in directories:
        names = _read_exit_recovery_marker(directory)
        names.extend(name for name in _scan_recording_recoveries(directory) if name not in names)
        for name in names:
            path = os.path.join(directory, name)
            if path not in _exit_recovery_paths:
                _exit_recovery_paths.append(path)
    if _exit_recovery_paths:
        _last_recording_recovery_path = _exit_recovery_paths[-1]


def stop_record(ctx, scene=None, operator=None, for_file_load=False):
    from uuid import uuid4
    from .history import add_native_take, read_take_stream, save_take_stream

    global _pending_recording, _file_load_recording_notice, _last_recording_recovery_path
    scene = scene if scene is not None else ctx.scene
    if _pending_recording is None and _pending_recording_backlog:
        _advance_pending_recording()
    if scene.recording:
        frames = rebocap_app.stop_record() if rebocap_app else None
        if frames:
            take_type = recording_take_type(scene)
            _queue_pending_recording(frames, take_type)
        scene.recording = False
        scene.rebocap_last_record_stop_time = time.time()
    _end_recording_control(ctx, scene)
    if _pending_recording is None:
        return True

    frames, take_type = _pending_recording
    fps = 60.0
    counter = scene.rebocap_record_counter + 1
    take_name = f"Take_{take_type}_{counter}"
    if for_file_load:
        # The outgoing scene is about to be discarded, so a Text/Take stored in
        # that scene is not durable.  Leave the recovered stream independent of
        # the incoming project and let the user explicitly import it.
        _last_recording_recovery_path = ''
        try:
            path = _pending_checkpoint(take_name, take_type, fps, frames)
        except Exception as error:
            print(f"[Rebocap] Recovery file could not be written: {error}")
            _file_load_recording_notice = (T('Recording retained in memory. Retry saving before closing Blender.'), 'ERROR')
            return False
        _advance_pending_recording()
        _last_recording_recovery_path = str(path)
        message = f"{T('Recording saved to a recovery file')}: {path}"
        _file_load_recording_notice = (message, 'INFO')
        print(f"[Rebocap] {message}")
        if _pending_recording is not None:
            # More than one buffer may be retained after a failed save and an
            # unexpected disconnect. Persist each before replacing the scene.
            return stop_record(ctx, scene=scene, operator=operator, for_file_load=True)
        return True
    try:
        checkpoint = _pending_checkpoint(take_name, take_type, fps, frames)
    except Exception as error:
        print(f"[Rebocap] Recording backup could not be written: {error}")
        message = T('Recording retained in memory. Retry saving before closing Blender.')
        if operator:
            operator.report({'WARNING'}, message)
        else:
            print(f"[Rebocap] {message}")
        return False
    try:
        take_id = uuid4().hex
        text_name = save_take_stream(take_id, frames, fps, allow_clock_reset=True)
        take = add_native_take(scene, take_id, take_name, take_type, fps, frames, text_name)
    except Exception as error:
        print(f"[Rebocap] Recording save failed: {error}")
        _advance_pending_recording()
        message = f"{T('Recording saved to a recovery file')}: {checkpoint}"
        if operator:
            operator.report({'WARNING'}, message)
        else:
            print(f"[Rebocap] {message}")
        return False
    _recording_checkpoints[take_id] = checkpoint
    _advance_pending_recording()
    scene.rebocap_record_counter = counter
    scene.rebocap_has_new_take = True
    if read_take_stream(take)[2]:
        message = T('A recording clock reset was detected. Original timestamps were preserved.')
        if operator:
            operator.report({'WARNING'}, message)
        else:
            print(f"[Rebocap] {message}")
    print(f"[Rebocap] Recorded native stream {take_name}: {len(frames)} frames (saved to {text_name})")
    return True


@bpy.app.handlers.persistent
def notify_recording_after_file_load(_=None):
    """Show the recovery path or the existing in-memory retry instruction."""
    global _file_load_recording_notice
    if _file_load_recording_notice is None:
        return
    message, icon = _file_load_recording_notice
    _file_load_recording_notice = None
    show_message_box(message=message, icon=icon)


def force_disconnect():
    global rebocap_app, rebocap_connected, rebocap_timer, obj_info_helper, connection_generation, _active_connection_scene_name, _active_connection_scene_pointer, _active_live_library_binding, _active_live_library_unresolved
    connection_generation += 1
    if rebocap_app:
        # A scene switch can race a recording flag update. Drain the SDK under
        # its lock before disconnecting, even if no scene currently claims it.
        try:
            frames = rebocap_app.stop_record()
            _queue_pending_recording(frames, getattr(rebocap_app, 'recording_take_type', 'FK'))
        except Exception as error:
            print(f'[Rebocap] Could not retain recording on disconnect: {error}')
        try:
            rebocap_app.close()
        except:
            pass
    _end_recording_control(bpy.context)
    if rebocap_timer:
        try:
            bpy.context.window_manager.event_timer_remove(rebocap_timer)
        except:
            pass
    rebocap_timer = None
    rebocap_connected = False
    _active_connection_scene_name = ''
    _active_connection_scene_pointer = 0
    _active_live_library_binding = None
    _active_live_library_unresolved = False
    obj_info_helper = ObjInfoHelper()
    for scene in bpy.data.scenes:
        if hasattr(scene, 'open'):
            scene.open = False
            scene.recording = False
            scene.rebocap_live_binding_warning = ''
    if rebocap_app:
        rebocap_app.last_msg = None

class RebocapDisconnect(bpy.types.Operator):
    bl_idname = 'rebocap.disconnect'
    bl_label = 'Disconnect'

    def execute(self, ctx):
        scene = _recording_control.scene if _recording_control is not None else ctx.scene
        try:
            if getattr(scene, 'recording', False):
                stop_record(ctx, scene=scene, operator=self)
        finally:
            force_disconnect()
        return {'FINISHED'}


class RebocapStartRecord(bpy.types.Operator):
    bl_idname = 'rebocap.start_record'
    bl_label = 'Start Record'

    @classmethod
    def poll(cls, ctx):
        scene = getattr(ctx, 'scene', None)
        return (scene is not None and rebocap_connected and scene.open
                and (not _active_connection_scene_name or scene.name == _active_connection_scene_name)
                and not scene.recording and not has_pending_recording() and not preview_active(scene))

    def execute(self, ctx):
        global _recording_control
        if not self.poll(ctx) or rebocap_app is None:
            return {'CANCELLED'}
        from ..core.control import drive_objects, find_conflict, conflict_message
        from .history import restore_playback_rotation_modes, snapshot_playback, stop_playback
        scene = ctx.scene
        conflict = find_conflict(scene, drive_objects(scene))
        if conflict:
            self.report({'WARNING'}, conflict_message(conflict))
            return {'CANCELLED'}
        frame = (scene.frame_current, scene.frame_subframe)
        try:
            paused = scene.rebocap_pause_control
            playback = snapshot_playback(scene) if scene.rebocap_playback_active else None
            binding, mapping = _recording_binding(scene)
            # Capture the authored modes before recording takes ownership.
            # Playback stays active until the new bindings have been prepared.
            if playback is not None:
                from .playback_control import release
                release(scene)
                restore_playback_rotation_modes(scene)
            session = RecordingChannels(scene, *_recording_channels(scene, binding, mapping))
            session.fk_binding = binding
            session.mapping = mapping
            session.rebinding = False
            session.paused = paused
            session.playback = playback
            session.frame = frame
            session.timeline_was_playing = bool(getattr(ctx.screen, 'is_animation_playing', False))
            _recording_control = session
            session.undo_intent = _recording_undo_intent(session)
            session.start()
            if session.playback is not None:
                stop_playback(scene, preserve_anchors=True)
            scene.rebocap_pause_control = False
            scene.frame_set(1)
            if ctx.screen is not None:
                force_start_animation(ctx)
            scene[_RECORDING_INTENT] = session.undo_intent
            rebocap_app.start_record()
            scene.recording = True
        except Exception as error:
            if _recording_control is None and scene.rebocap_playback_active:
                scene.frame_set(frame[0], subframe=frame[1])
            _end_recording_control(ctx, scene, rollback=True)
            self.report({'WARNING'}, f"{T('Cannot isolate recording animation channels')}: {error}")
            return {'CANCELLED'}
        return {'FINISHED'}


class RebocapStopRecord(bpy.types.Operator):
    bl_idname = 'rebocap.stop_record'
    bl_label = 'Stop Record'

    def execute(self, ctx):
        return {'FINISHED'} if stop_record(ctx, operator=self) else {'CANCELLED'}


class RebocapRestorePose(bpy.types.Operator):
    bl_idname = 'rebocap.restore_pose'
    bl_label = 'Restore Pose'
    bl_description = 'Restore the character to the temporary pose it had before connection'

    def execute(self, ctx):
        from mathutils import Vector, Quaternion, Euler
        if preview_active(ctx.scene):
            self.report({'WARNING'}, T('Exit A2T preview before restoring pose'))
            return {'CANCELLED'}
        from ..core.control import drive_objects, find_conflict, conflict_message
        conflict = find_conflict(ctx.scene, drive_objects(ctx.scene))
        if conflict:
            self.report({'WARNING'}, conflict_message(conflict))
            return {'CANCELLED'}
        
        # Safely clear active actions only on source armature and tracking empties
        source_obj = bpy.data.objects.get(ctx.scene.rebocap_source_armature)
        if source_obj and source_obj.type == 'ARMATURE':
            safely_clear_action(source_obj)
        for obj in bpy.context.scene.objects:
            if obj.name in TRACKING_OBJECT_NAMES or (obj.type == 'ARMATURE' and obj.get("rebocap_demo_character")):
                safely_clear_action(obj)

        # 1. Restore FK source armature to clean T-Pose / Rest Pose
        source_obj = bpy.data.objects.get(ctx.scene.rebocap_source_armature)
        if source_obj and source_obj.type == 'ARMATURE':
            for pb in source_obj.pose.bones:
                pb.location = Vector((0.0, 0.0, 0.0))
                pb.rotation_quaternion = Quaternion((1.0, 0.0, 0.0, 0.0))
                pb.rotation_euler = Euler((0.0, 0.0, 0.0))
                pb.scale = Vector((1.0, 1.0, 1.0))
            
            # If A2T calibration is enabled, apply calibrated T-Pose offsets
            a2t = getattr(ctx.scene, 'rebocap_a2t', None)
            if a2t and a2t.enable_a2t:
                try:
                    from ..core.a2t_types import apply_a2t_preview_to_armature
                    apply_a2t_preview_to_armature(ctx.scene, source_obj, force_apply=True)
                except Exception as e:
                    print(f"A2T restore error: {e}")
                    
        # 2. Restore IK Tracking nodes (Rebocap_*)
        for obj in bpy.context.scene.objects:
            if obj.name.startswith("Rebocap_") and obj.type == 'EMPTY':
                obj.rotation_quaternion = Quaternion((1.0, 0.0, 0.0, 0.0))
                obj.rotation_euler = Euler((0.0, 0.0, 0.0))
                if obj.name == "Rebocap_Pelvis":
                    obj.location.x = 0.0
                    obj.location.y = 0.0

        # 3. Force viewport update
        try:
            ctx.view_layer.update()
            wm = getattr(ctx, 'window_manager', None) or bpy.context.window_manager
            if wm:
                for window in wm.windows:
                    for area in window.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()
        except Exception:
            pass

        return {'FINISHED'}
