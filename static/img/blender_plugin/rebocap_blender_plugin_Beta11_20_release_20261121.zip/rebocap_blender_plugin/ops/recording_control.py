"""Keep recording isolation separate from the user's animation edits."""

import hashlib
import json

import bpy

from .channel_pose import ChannelPose, release_copied_constraints, restore_saved_pose_layers
from .utils import _action_curves_for_slots, restore_rotation_mode, show_message_box


_ORIGINAL_ACTION = '_rebocap_recording_original'
_ORIGINAL_SLOT = '_rebocap_recording_slot'
_BASELINE = '_rebocap_recording_baseline'
_MASK = '_rebocap_recording_mask'
_CURVE_MASK = '_rebocap_recording_curve_mask'
_ROTATION_MASK = '_rebocap_recording_rotation_modes'
_DRIVER_MASK = '_rebocap_recording_driver_mask'


def _strip_bindings(strips):
    for strip in strips:
        if strip.action is not None:
            yield strip
        yield from _strip_bindings(getattr(strip, 'strips', ()))


def _action_bindings(obj):
    animation = obj.animation_data
    if not animation:
        return
    if animation.action is not None:
        yield animation
    for track in animation.nla_tracks:
        yield from _strip_bindings(track.strips)


def _slot(binding):
    slot = getattr(binding, 'action_slot', None)
    return slot.identifier if slot else ''


def _set_action(binding, action, slot_id):
    binding.action = action
    if hasattr(action, 'slots'):
        binding.action_slot = next((slot for slot in action.slots if slot.identifier == slot_id), None)


def _curves(action):
    for slot_id in [slot.identifier for slot in action.slots] if hasattr(action, 'slots') else ['']:
        for curve in _action_curves_for_slots(action, {slot_id}):
            yield (slot_id, curve.data_path, curve.array_index), curve


def _rna_values(item):
    for prop in item.bl_rna.properties:
        if prop.identifier == 'rna_type' or prop.type == 'POINTER':
            continue
        value = getattr(item, prop.identifier)
        if prop.type == 'COLLECTION':
            value = tuple(tuple(_rna_values(child)) for child in value)
        elif getattr(prop, 'is_array', False) or isinstance(value, set):
            value = tuple(value) if not isinstance(value, set) else tuple(sorted(value))
        yield prop.identifier, value


def _curve_mask(action):
    return {tuple(tag): (tuple(color), mode)
            for tag, color, mode in json.loads(action.get(_CURVE_MASK, '[]'))}


def _legacy_mask(action):
    return {tuple(key) for key in json.loads(action.get(_MASK, '[]'))}


def _signature(action):
    """Compare authored edits, including curve mute, and normalize old snapshots."""
    mask = _curve_mask(action)
    legacy = _legacy_mask(action)
    digest = hashlib.sha256()
    header = (action.name, action.use_fake_user, action.use_frame_range,
              action.frame_start, action.frame_end, action.use_cyclic,
              [slot.identifier for slot in getattr(action, 'slots', ())])
    digest.update(repr(header).encode('utf-8'))
    for key, fcurve in _curves(action):
        group = fcurve.group
        color = tuple(fcurve.color)
        color_mode = fcurve.color_mode
        if color in mask:
            color, original_mode = mask[color]
            if color_mode == 'CUSTOM':
                color_mode = original_mode
        fields = (key, fcurve.mute and tuple(fcurve.color) not in mask and key not in legacy,
                  fcurve.extrapolation, fcurve.auto_smoothing, color_mode, color,
                  group.name if group else None)
        digest.update(repr(fields).encode('utf-8'))
        for collection in (fcurve.keyframe_points, fcurve.sampled_points, fcurve.modifiers):
            digest.update(repr(len(collection)).encode('utf-8'))
            for item in collection:
                values = _rna_values(item)
                if collection == fcurve.keyframe_points:
                    # Selection and handle selection don't change the animation.
                    values = (field for field in values if not field[0].startswith('select_'))
                digest.update(repr(tuple(values)).encode('utf-8'))
    return digest.hexdigest()


def _edited(copy):
    baseline = copy.get(_BASELINE)
    return baseline is not None and _signature(copy) != baseline


def _authored_action(copy):
    if _ORIGINAL_ACTION not in copy or _edited(copy):
        return copy
    return copy.get(_ORIGINAL_ACTION) or copy


def _restore_curve_color(curve, authored):
    color, mode = authored
    if curve.color_mode == 'CUSTOM':
        curve.color_mode = mode
    curve.color = color


def _keep_edited_action(copy):
    mask = _curve_mask(copy)
    legacy = _legacy_mask(copy)
    for key, curve in _curves(copy):
        original = mask.get(tuple(curve.color))
        if original is not None:
            _restore_curve_color(curve, original)
        if original is not None or key in legacy:
            curve.mute = False
    for key in (_ORIGINAL_ACTION, _ORIGINAL_SLOT, _BASELINE, _MASK, _CURVE_MASK,
                '_rebocap_recording_action_token'):
        if key in copy:
            del copy[key]
    if copy.users == 0:
        copy.use_fake_user = True
    copy.update_tag()


def _restore_copied_bindings(copies):
    """Promote edited copies intact. Restore unchanged copies to the latest slot."""
    originals = {}
    for copy in copies:
        original = _authored_action(copy)
        if original == copy:
            _keep_edited_action(copy)
        else:
            originals[copy] = original
    if not originals:
        return
    warned = set()
    for obj in bpy.data.objects:
        if not getattr(obj, 'is_editable', obj.library is None):
            continue
        for binding in _action_bindings(obj):
            copy = binding.action
            original = originals.get(copy)
            if original is not None:
                slot = getattr(binding, 'action_slot', None)
                handle = slot.handle if slot is not None else None
                slot_id = _slot(binding)
                if handle is not None and hasattr(original, 'slots'):
                    original_slot = next((item for item in original.slots if item.handle == handle), None)
                    if original_slot is not None:
                        slot_id = original_slot.identifier
                    else:
                        slot_id = ''
                        if (original, handle) not in warned:
                            warned.add((original, handle))
                            show_message_box(
                                message=f"Action slot was removed: {original.name}",
                                title="ReboCap", icon='ERROR')
                _set_action(binding, original, slot_id)


def restore_marked_drivers(obj):
    """A duplicated Object carries its Driver flags and the recorder's marker."""
    if _DRIVER_MASK not in obj:
        return
    keys = {tuple(key) for key in json.loads(obj[_DRIVER_MASK])}
    del obj[_DRIVER_MASK]
    if obj.animation_data:
        for driver in obj.animation_data.drivers:
            if (driver.data_path, driver.array_index) in keys:
                driver.is_valid = True
        obj.update_tag()


def _restore_marked_modes(obj):
    if _ROTATION_MASK not in obj:
        return
    modes = json.loads(obj[_ROTATION_MASK])
    del obj[_ROTATION_MASK]
    if obj.pose:
        for name, mode in modes.items():
            bone = obj.pose.bones.get(name)
            if bone and bone.rotation_mode == 'QUATERNION':
                restore_rotation_mode(bone, mode)


class RecordingChannels:
    """Track the current animation bindings for the live writer's channels."""

    def __init__(self, scene, channels, rotation_bones, *, previous=None):
        self.scene = scene
        self.channels = channels
        if previous is not None:
            previous._restore_foreign_state()
        old_modes = previous.rotation_modes if previous else {}
        self.rotation_modes = {bone: old_modes.get(bone, bone.rotation_mode) for bone in rotation_bones}
        self.rotation_bone_owners = {bone: bone.id_data for bone in self.rotation_modes}
        self.rotation_targets = set(self.rotation_bone_owners.values())
        self.bindings = {}
        self.drivers = {}
        self.copies = []
        self.pose = ChannelPose(scene)
        self.suspended = False
        self.display_modes = []
        self.saved_recording_control = None
        self.animation_error = None
        try:
            for obj, paths in channels.items():
                if not obj.animation_data:
                    continue
                for binding in _action_bindings(obj):
                    action = _authored_action(binding.action)
                    self._prepare_binding(obj, binding, action, paths)
                self._validate_drivers(obj, paths)
        except Exception:
            self._release_copies()
            raise

    def _prepare_binding(self, obj, binding, action, paths):
        slot_id = _slot(binding)
        if not any(curve.data_path in paths
                   for curve in _action_curves_for_slots(action, {slot_id})):
            return None
        if (not getattr(obj, 'is_editable', obj.library is None) or
                obj.animation_data.use_tweak_mode or binding.is_property_readonly('action')):
            raise ValueError(obj.name)
        copy = action.copy()
        self.copies.append(copy)
        copy.use_fake_user = False
        copy[_ORIGINAL_ACTION] = action
        copy[_ORIGINAL_SLOT] = slot_id
        copy[_BASELINE] = _signature(copy)
        self.bindings.setdefault(obj, {})[binding.as_pointer()] = (action, copy)
        return copy

    def _validate_drivers(self, obj, paths):
        if any(curve.data_path in paths and not curve.mute and curve.is_valid
               and (not getattr(obj, 'is_editable', obj.library is None)
                    or curve.is_property_readonly('is_valid'))
               for curve in obj.animation_data.drivers):
            raise ValueError(obj.name)

    def _refresh_drivers(self, obj, paths):
        selected = self.drivers.get(obj, set())
        if not selected:
            restore_marked_drivers(obj)
        if obj.animation_data is None:
            self.drivers.pop(obj, None)
            return
        self._validate_drivers(obj, paths)
        current = set()
        changed = False
        for curve in obj.animation_data.drivers:
            if curve.data_path in paths and (curve in selected or (curve.is_valid and not curve.mute)):
                current.add(curve)
                if curve.is_valid:
                    curve.is_valid = False
                    changed = True
            elif curve in selected:
                curve.is_valid = True
                changed = True
        if current:
            self.drivers[obj] = current
            marker = json.dumps(sorted((curve.data_path, curve.array_index) for curve in current))
            if obj.get(_DRIVER_MASK) != marker:
                obj[_DRIVER_MASK] = marker
        else:
            self.drivers.pop(obj, None)
            if _DRIVER_MASK in obj:
                del obj[_DRIVER_MASK]
        if changed:
            obj.update_tag()

    def restore_foreign_state(self, obj):
        # Another scene may be using the same isolation mechanism. Its
        # temporary driver and rotation state belongs to that session.
        from . import playback_control
        from . import rebocap_connection
        sessions = list(playback_control._sessions.values())
        if rebocap_connection._recording_control is not None:
            sessions.append(rebocap_connection._recording_control)
        if any(other is not self and obj in other.channels for other in sessions):
            return
        release_copied_constraints(obj)
        if obj not in self.drivers:
            restore_marked_drivers(obj)
        if obj not in self.rotation_targets:
            _restore_marked_modes(obj)

    def _publish_rotation_modes(self):
        modes = {}
        objects = set(bpy.data.objects)
        for bone, mode in self.rotation_modes.items():
            try:
                if self.rotation_bone_owners.get(bone) not in objects:
                    continue
                if mode != 'QUATERNION':
                    modes.setdefault(bone.id_data, {})[bone.name] = mode
            except ReferenceError:
                continue
        for obj, bones in modes.items():
            marker = json.dumps(bones, sort_keys=True)
            if obj.get(_ROTATION_MASK) != marker:
                obj[_ROTATION_MASK] = marker

    def _restore_foreign_state(self):
        for obj in bpy.data.objects:
            self.restore_foreign_state(obj)

    def _release_shared_working_actions(self):
        if not self.copies:
            return
        owned = {}
        for obj in self.channels:
            try:
                for binding in _action_bindings(obj):
                    action = binding.action
                    owned[action] = owned.get(action, 0) + 1
            except ReferenceError:
                continue
        candidates = set()
        for action in self.copies:
            try:
                if (_ORIGINAL_ACTION in action and
                        action.users > owned.get(action, 0) + int(action.use_fake_user)):
                    candidates.add(action)
            except ReferenceError:
                continue
        if not candidates:
            return
        shared = set()
        for obj in bpy.data.objects:
            if obj not in self.channels:
                shared.update(binding.action for binding in _action_bindings(obj)
                              if binding.action in candidates)
        if shared:
            _restore_copied_bindings(shared)
            # When a shared working Action is edited it becomes the clean
            # authored Action. Only the controlled bindings borrow it again.
            self.copies[:] = [copy for copy in self.copies if _ORIGINAL_ACTION in copy]
            self._restore_foreign_state()

    def refresh(self):
        if self.suspended:
            return
        self._publish_rotation_modes()
        self._release_shared_working_actions()
        active_paths = {}
        for obj, paths in self.channels.items():
            try:
                if not obj.animation_data:
                    self.drivers.pop(obj, None)
                    continue
                for binding in _action_bindings(obj):
                    action = binding.action
                    slot_id = _slot(binding)
                    if action not in self.copies or _ORIGINAL_ACTION not in action:
                        copy = self._prepare_binding(obj, binding, action, paths)
                        if copy is not None:
                            _set_action(binding, copy, slot_id)
                            action = copy
                    conflicts = {curve.data_path for curve in _action_curves_for_slots(action, {slot_id})
                                 if curve.data_path in paths}
                    if conflicts:
                        active_paths.setdefault(obj, set()).update(conflicts)
                self._refresh_drivers(obj, paths)
            except ReferenceError:
                continue
        self.pose.set_paths(active_paths)

    def start(self):
        for obj, bindings in self.bindings.items():
            try:
                for binding in _action_bindings(obj):
                    entry = bindings.get(binding.as_pointer())
                    if entry and binding.action == entry[0] and _ORIGINAL_ACTION in entry[1]:
                        _set_action(binding, entry[1], _slot(binding))
            except ReferenceError:
                continue
        self.refresh()

    def rebind(self, channels, rotation_bones, *, refresh_frame=False):
        prepared = RecordingChannels(self.scene, channels, rotation_bones, previous=self)
        try:
            self.suspend_for_save()
            prepared.start()
            self._restore_modes((bone, mode) for bone, mode in self.display_modes
                                if bone in prepared.rotation_modes)
            if refresh_frame:
                self.scene.frame_set(self.scene.frame_current, subframe=self.scene.frame_subframe)
        except Exception:
            try:
                prepared.close()
            finally:
                self.resume_after_save()
            raise
        self._release_copies()
        self.channels = prepared.channels
        self.bindings = prepared.bindings
        self.drivers = prepared.drivers
        self.copies = prepared.copies
        self.pose = prepared.pose
        self.rotation_modes = prepared.rotation_modes
        self.rotation_bone_owners = prepared.rotation_bone_owners
        self.rotation_targets = prepared.rotation_targets
        self.display_modes.clear()
        self.suspended = False

    def close(self):
        self._restore_authored_animation()
        self.display_modes.clear()
        self._release_copies()

    def _release_copies(self):
        for copy in self.copies:
            try:
                if _ORIGINAL_ACTION in copy and copy.users == 0:
                    bpy.data.actions.remove(copy)
            except ReferenceError:
                continue
        self.copies.clear()

    def _restore_modes(self, modes):
        objects = set(bpy.data.objects)
        for bone, mode in modes:
            try:
                if self.rotation_bone_owners.get(bone) not in objects:
                    continue
                restore_rotation_mode(bone, mode)
            except ReferenceError:
                continue

    def suspend_for_save(self):
        if self.suspended:
            return
        objects = set(bpy.data.objects)
        for bone in self.rotation_modes:
            try:
                if self.rotation_bone_owners.get(bone) not in objects:
                    continue
                self.display_modes.append((bone, bone.rotation_mode))
            except ReferenceError:
                continue
        self.suspended = True
        self._restore_authored_animation()

    def _restore_authored_animation(self):
        self._restore_foreign_state()
        self.pose.clear()
        _restore_copied_bindings(self.copies)
        self.copies[:] = [copy for copy in self.copies if _ORIGINAL_ACTION in copy]
        for obj, selected in self.drivers.items():
            try:
                if obj.animation_data:
                    for curve in obj.animation_data.drivers:
                        if curve in selected:
                            curve.is_valid = True
                    obj.update_tag()
                if _DRIVER_MASK in obj:
                    del obj[_DRIVER_MASK]
            except ReferenceError:
                continue
        self.drivers.clear()
        self._restore_modes(self.rotation_modes.items())
        for obj in self.rotation_targets:
            try:
                if _ROTATION_MASK in obj:
                    del obj[_ROTATION_MASK]
            except ReferenceError:
                continue

    def resume_after_save(self):
        if not self.suspended:
            return
        self.suspended = False
        self.start()
        self.pose.resume()
        self._restore_modes(self.display_modes)
        self.display_modes.clear()


def restore_saved_action_bindings():
    """Undo and recovery files may contain edited working Actions."""
    restore_saved_pose_layers()
    copies = [action for action in bpy.data.actions if _ORIGINAL_ACTION in action]
    _restore_copied_bindings(copies)
    for copy in copies:
        if _ORIGINAL_ACTION in copy and copy.users == 0:
            bpy.data.actions.remove(copy)
    for obj in bpy.data.objects:
        restore_marked_drivers(obj)
        _restore_marked_modes(obj)
