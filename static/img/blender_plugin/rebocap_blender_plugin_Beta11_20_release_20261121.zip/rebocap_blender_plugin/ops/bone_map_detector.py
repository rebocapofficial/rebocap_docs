import bpy


class AutoMapBone(bpy.types.Operator):
    bl_idname = 'rebocap.auto_map_bone'
    bl_label = 'Auto Map Bone'

    @classmethod
    def poll(cls, ctx):
        source = bpy.data.objects.get(ctx.scene.rebocap_source_armature)
        return source is not None and source.type == 'ARMATURE'

    def execute(self, ctx):
        all_names = ('hips', 'spine', 'chest', 'upperChest', 'neck', 'head', 'leftEye', 'rightEye', 'jaw', 'leftUpperLeg', 'leftLowerLeg', 'leftFoot', 'leftToes', 'rightUpperLeg', 'rightLowerLeg', 'rightFoot', 'rightToes', 'leftShoulder', 'leftUpperArm', 'leftLowerArm', 'leftHand', 'rightShoulder', 'rightUpperArm', 'rightLowerArm', 'rightHand', 'leftThumbProximal', 'leftThumbIntermediate', 'leftThumbDistal', 'leftIndexProximal', 'leftIndexIntermediate', 'leftIndexDistal', 'leftMiddleProximal', 'leftMiddleIntermediate', 'leftMiddleDistal', 'leftRingProximal', 'leftRingIntermediate', 'leftRingDistal', 'leftLittleProximal', 'leftLittleIntermediate', 'leftLittleDistal', 'rightThumbProximal', 'rightThumbIntermediate', 'rightThumbDistal', 'rightIndexProximal', 'rightIndexIntermediate', 'rightIndexDistal', 'rightMiddleProximal', 'rightMiddleIntermediate', 'rightMiddleDistal', 'rightRingProximal', 'rightRingIntermediate', 'rightRingDistal', 'rightLittleProximal', 'rightLittleIntermediate', 'rightLittleDistal')
        required_names = ('hips', 'spine', 'chest', 'neck', 'head', 'leftUpperLeg', 'leftLowerLeg', 'leftFoot', 'rightUpperLeg', 'rightLowerLeg', 'rightFoot', 'leftUpperArm', 'leftLowerArm', 'leftHand', 'rightUpperArm', 'rightLowerArm', 'rightHand')
        optional_names = ('upperChest', 'leftEye', 'rightEye', 'jaw', 'leftToes', 'rightToes', 'leftShoulder', 'rightShoulder', 'leftThumbProximal', 'leftThumbIntermediate', 'leftThumbDistal', 'leftIndexProximal', 'leftIndexIntermediate', 'leftIndexDistal', 'leftMiddleProximal', 'leftMiddleIntermediate', 'leftMiddleDistal', 'leftRingProximal', 'leftRingIntermediate', 'leftRingDistal', 'leftLittleProximal', 'leftLittleIntermediate', 'leftLittleDistal', 'rightThumbProximal', 'rightThumbIntermediate', 'rightThumbDistal', 'rightIndexProximal', 'rightIndexIntermediate', 'rightIndexDistal', 'rightMiddleProximal', 'rightMiddleIntermediate', 'rightMiddleDistal', 'rightRingProximal', 'rightRingIntermediate', 'rightRingDistal', 'rightLittleProximal', 'rightLittleIntermediate', 'rightLittleDistal')

        self.bones = [
            "Pelvis", "L_UpLeg", "R_UpLeg", "Spine", "L_DownLeg", "R_DownLeg",
            "Chest", "L_Foot", "R_Foot", "UpChest", "L_Toe", "R_Toe",
            "Neck", "L_Shoulder", "R_Shoulder", "Head", "L_UpArm", "R_UpArm",
            "L_DownArm", "R_DownArm", "L_Palm", "R_Palm", "L_Fingers", "R_Fingers",
        ]
        vrm_bone_list = ['hips', 'leftUpperLeg', 'rightUpperLeg', 'spine', 'leftLowerLeg', 'rightLowerLeg',
                         'chest', 'leftFoot', 'rightFoot', 'upperChest', 'leftToes', 'rightToes',
                         'neck', 'leftShoulder', 'rightShoulder', 'head', 'leftUpperArm', 'rightUpperArm',
                         'leftLowerArm', 'rightLowerArm', 'leftHand', 'rightHand']
        mixamo_bone_list = [
            "mixamorig:Hips", "mixamorig:LeftUpLeg", "mixamorig:RightUpLeg", "mixamorig:Spine", 
            "mixamorig:LeftLeg", "mixamorig:RightLeg", "mixamorig:Spine1", "mixamorig:LeftFoot", 
            "mixamorig:RightFoot", "mixamorig:Spine2", "mixamorig:LeftToeBase", "mixamorig:RightToeBase",
            "mixamorig:Neck", "mixamorig:LeftShoulder", "mixamorig:RightShoulder", "mixamorig:Head", 
            "mixamorig:LeftArm", "mixamorig:RightArm", "mixamorig:LeftForeArm", "mixamorig:RightForeArm",
            "mixamorig:LeftHand", "mixamorig:RightHand"
        ]
        source = bpy.data.objects.get(ctx.scene.rebocap_source_armature)
        if source and source.type == 'ARMATURE':
            armature_data = source.data
            rebocap_bone_map = ctx.scene.rebocap_bone_map
            
            # 1. VRM Detection
            if hasattr(armature_data, 'vrm_addon_extension'):
                mappings = {}
                for human_bone in armature_data.vrm_addon_extension.vrm0.humanoid.human_bones:
                    if human_bone.bone not in all_names:
                        continue
                    if not human_bone.node.bone_name:
                        continue
                    mappings[human_bone.bone] = human_bone.node.bone_name
                
                if mappings:
                    for i in range(22):
                        if vrm_bone_list[i] in mappings:
                            setattr(rebocap_bone_map, f'node_{i}', mappings[vrm_bone_list[i]])
                        else:
                            setattr(rebocap_bone_map, f'node_{i}', '')
                    self.report({'INFO'}, "Detected VRM Armature")
                    return {'FINISHED'}
                    
            # 2. Unreal Engine (UE4/UE5/MetaHuman) Detection
            ue_bone_list = [
                "pelvis", "thigh_l", "thigh_r", "spine_02", "calf_l", "calf_r",
                "spine_04", "foot_l", "foot_r", "spine_05", "ball_l", "ball_r",
                "neck_01", "clavicle_l", "clavicle_r", "head", "upperarm_l", "upperarm_r",
                "lowerarm_l", "lowerarm_r", "hand_l", "hand_r"
            ]
            if 'spine_05' not in armature_data.bones:
                # UE4 mannequin has three spine bones; UE5 has five.
                ue_bone_list[3], ue_bone_list[6], ue_bone_list[9] = 'spine_01', 'spine_02', 'spine_03'
            has_ue = all(b in armature_data.bones for b in ('pelvis', 'thigh_l', 'thigh_r', 'upperarm_l', 'upperarm_r'))
            if has_ue:
                for i in range(22):
                    if ue_bone_list[i] in armature_data.bones:
                        setattr(rebocap_bone_map, f'node_{i}', ue_bone_list[i])
                    else:
                        setattr(rebocap_bone_map, f'node_{i}', '')
                self.report({'INFO'}, "Detected Unreal Engine Armature")
                return {'FINISHED'}

            # 3. Rebocap Standard Detection
            rebo_bone_list = [
                "Pelvis", "L_Hip", "R_Hip", "Spine1", "L_Knee", "R_Knee",
                "Spine2", "L_Ankle", "R_Ankle", "Spine3", "L_Foot", "R_Foot",
                "Neck", "L_Collar", "R_Collar", "Head", "L_Shoulder", "R_Shoulder",
                "L_Elbow", "R_Elbow", "L_Wrist", "R_Wrist"
            ]
            has_rebo = all(b in armature_data.bones for b in ('Pelvis', 'L_Hip', 'R_Hip', 'L_Shoulder', 'R_Shoulder'))
            if has_rebo:
                for i in range(22):
                    if rebo_bone_list[i] in armature_data.bones:
                        setattr(rebocap_bone_map, f'node_{i}', rebo_bone_list[i])
                    else:
                        setattr(rebocap_bone_map, f'node_{i}', '')
                self.report({'INFO'}, "Detected Rebocap Standard Armature")
                return {'FINISHED'}

            # 4. Mixamo Detection (with prefix)
            has_mixamo = all(b in armature_data.bones for b in ('mixamorig:Hips', 'mixamorig:LeftUpLeg', 'mixamorig:RightUpLeg'))
            if has_mixamo:
                for i in range(22):
                    if mixamo_bone_list[i] in armature_data.bones:
                        setattr(rebocap_bone_map, f'node_{i}', mixamo_bone_list[i])
                    else:
                        setattr(rebocap_bone_map, f'node_{i}', '')
                self.report({'INFO'}, "Detected Mixamo Armature")
                return {'FINISHED'}
                
            # 5. Mixamo Detection (without prefix)
            bare_mixamo = [name.split(':', 1)[-1] for name in mixamo_bone_list]
            if all(b in armature_data.bones for b in ('Hips', 'LeftUpLeg', 'RightUpLeg')):
                for i, name in enumerate(bare_mixamo):
                    setattr(rebocap_bone_map, f'node_{i}', name if name in armature_data.bones else '')
                self.report({'INFO'}, "Detected Mixamo Armature")
                return {'FINISHED'}

            # 6. Auto-Rig Pro (ARP) FK Detection
            arp_bone_list = [
                "c_root_master.x", "c_thigh_fk.l", "c_thigh_fk.r", "c_spine_01.x",
                "c_leg_fk.l", "c_leg_fk.r", "c_spine_02.x", "c_foot_fk.l",
                "c_foot_fk.r", "c_spine_03.x", "c_toes_fk.l", "c_toes_fk.r",
                "c_neck.x", "c_shoulder.l", "c_shoulder.r", "c_head.x",
                "c_arm_fk.l", "c_arm_fk.r", "c_forearm_fk.l", "c_forearm_fk.r",
                "c_hand_fk.l", "c_hand_fk.r"
            ]
            has_arp = any(b in armature_data.bones for b in ["c_thigh_fk.l", "c_arm_fk.l", "c_root_master.x"])
            if has_arp:
                for i in range(22):
                    if arp_bone_list[i] in armature_data.bones:
                        setattr(rebocap_bone_map, f'node_{i}', arp_bone_list[i])
                    else:
                        setattr(rebocap_bone_map, f'node_{i}', '')
                self.report({'INFO'}, "Detected Auto-Rig Pro (ARP) Armature")
                return {'FINISHED'}

            # 7. Rigify FK Detection
            rigify_bone_list = [
                "torso", "thigh_fk.L", "thigh_fk.R", "spine",
                "shin_fk.L", "shin_fk.R", "spine.002", "foot_fk.L",
                "foot_fk.R", "spine.003", "toe_fk.L", "toe_fk.R",
                "neck", "shoulder.L", "shoulder.R", "head",
                "upper_arm_fk.L", "upper_arm_fk.R", "forearm_fk.L", "forearm_fk.R",
                "hand_fk.L", "hand_fk.R"
            ]
            has_rigify = any(b in armature_data.bones for b in ["thigh_fk.L", "upper_arm_fk.L", "torso"])
            if has_rigify:
                for i in range(22):
                    bname = rigify_bone_list[i]
                    if bname in armature_data.bones:
                        setattr(rebocap_bone_map, f'node_{i}', bname)
                    elif i == 0 and "root" in armature_data.bones:
                        setattr(rebocap_bone_map, 'node_0', 'root')
                    elif i == 6 and "spine.001" in armature_data.bones:
                        setattr(rebocap_bone_map, 'node_6', 'spine.001')
                    else:
                        setattr(rebocap_bone_map, f'node_{i}', '')
                self.report({'INFO'}, "Detected Rigify (FK) Armature")
                return {'FINISHED'}

            self.report({'WARNING'}, "Armature not recognized by any predefined templates")

        return {'FINISHED'}
