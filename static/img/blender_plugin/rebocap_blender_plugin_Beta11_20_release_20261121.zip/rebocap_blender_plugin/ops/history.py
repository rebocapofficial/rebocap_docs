import bpy
import json
import math
import os
import hashlib
import tempfile
import uuid
from pathlib import Path
from bisect import bisect_right
from mathutils import Vector, Quaternion
from bpy_extras.io_utils import ExportHelper, ImportHelper
from ..core.translation import T, T_static
from ..core.a2t_types import preview_active, preview_saving, preview_frame_suspended, rebind_playback_target
from .utils import restore_rotation_mode
from .rebocap_connection import (
    _action_fcurve_new,
    safely_set_action, safely_clear_action, _action_setup_slot,
    drive_retarget, drive_ik_tracking, drive_demo_character, TRACKING_OBJECT_NAMES
)

STREAM_FORMAT = 'rebocap_mocap_stream'
STREAM_VERSION = '1.0'
STREAM_METADATA = {
    'coordinate_system': 'Blender',
    'quaternion_order': 'xyzw',
    'rotation_space': 'local',
    'timestamp_unit': 'seconds',
}
STREAM_OWNER = 'rebocap_stream_uuid'
_take_stream_cache = {}
_library_hash_cache = {}
_playback_library_data = {}
_linked_binding_data = {}
_project_recovery_epoch = None


def _frame_limit():
    return bpy.types.Scene.bl_rna.properties['frame_end'].hard_max


def _finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def validate_stream(stream, recorded_fps=60.0, allow_clock_reset=False):
    """Validate native frames and build playback offsets without changing packets."""
    if not isinstance(stream, (list, tuple)) or not stream:
        raise ValueError('Motion capture stream is empty')
    if not _finite_number(recorded_fps) or not 1e-38 <= recorded_fps <= 3.4e38:
        raise ValueError('Invalid recorded FPS')
    frame_limit = _frame_limit()
    times = [0.0]
    clock_reset = False
    previous = None
    for frame in stream:
        if not isinstance(frame, (list, tuple)) or len(frame) != 4:
            raise ValueError('Invalid motion capture frame shape')
        trans, pose, contact, timestamp = frame
        if (not isinstance(trans, (list, tuple)) or len(trans) != 3
                or not isinstance(pose, (list, tuple)) or len(pose) != 24):
            raise ValueError('Invalid motion capture frame shape')
        if not all(_finite_number(v) and abs(v) <= 1e9 for v in trans):
            raise ValueError('Invalid pelvis translation')
        for quat in pose:
            if (not isinstance(quat, (list, tuple)) or len(quat) != 4
                    or not all(_finite_number(v) and abs(v) <= 2 for v in quat)
                    or not 0.98 <= sum(v * v for v in quat) <= 1.02):
                raise ValueError('Invalid motion capture quaternion')
        if type(contact) is not int or not -1 <= contact <= 11:
            raise ValueError('Invalid foot contact index')
        if not _finite_number(timestamp):
            raise ValueError('Invalid motion capture timestamp')
        if previous is not None:
            delta = timestamp - previous
            if not math.isfinite(delta):
                raise ValueError('Motion capture duration exceeds the Blender timeline')
            if delta < 0:
                if not allow_clock_reset:
                    raise ValueError('Motion capture timestamps must be ordered')
                clock_reset = True
                delta = 1 / recorded_fps
            times.append(times[-1] + delta)
            if not math.isfinite(times[-1]) or times[-1] >= frame_limit:
                raise ValueError('Motion capture duration exceeds the Blender timeline')
        previous = timestamp
    if times[-1] == 0 and len(stream) > 1:
        times = [index / recorded_fps for index in range(len(stream))]
        if times[-1] >= frame_limit:
            raise ValueError('Motion capture duration exceeds the Blender timeline')
    return times, clock_reset


def make_stream_document(name, take_type, recorded_fps, stream, clock_reset):
    return {
        'format': STREAM_FORMAT,
        'version': STREAM_VERSION,
        **STREAM_METADATA,
        'name': name,
        'type': take_type,
        'frame_count': len(stream),
        'recorded_fps': recorded_fps,
        'clock_reset': clock_reset,
        'stream': stream,
    }


def write_recovery_recording(name, take_type, fps, stream, directory=None):
    """Atomically write and verify a standalone copy of the original frames."""
    try:
        _, clock_reset = validate_stream(stream, fps, allow_clock_reset=True)
        document = make_stream_document(name, take_type, fps, stream, clock_reset)
    except (ValueError, TypeError, OverflowError):
        # Invalid packets are kept for recovery without exposing them as an importable take.
        document = {'format': 'rebocap_recording_recovery', 'name': name, 'stream': stream}
    path = None
    try:
        digest = hashlib.sha256()
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='', dir=directory,
                                         prefix='.rebocap-recovery-', suffix='.tmp', delete=False) as output:
            path = Path(output.name)
            for chunk in json.JSONEncoder(separators=(',', ':')).iterencode(document):
                output.write(chunk)
                digest.update(chunk.encode('utf-8'))
            output.flush()
            os.fsync(output.fileno())
        verified = hashlib.sha256()
        with path.open('rb') as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b''):
                verified.update(chunk)
        if digest.digest() != verified.digest():
            raise OSError('Recording recovery verification failed')
        destination = path.with_name(path.name[1:-4] + '.json')
        os.replace(str(path), str(destination))
        return destination
    except Exception:
        if path is not None:
            path.unlink(missing_ok=True)
        raise


def save_take_stream(take_id, stream, recorded_fps=60.0, allow_clock_reset=False):
    times, clock_reset = validate_stream(stream, recorded_fps, allow_clock_reset)
    stream = [[list(trans), [list(quat) for quat in pose], contact, timestamp]
              for trans, pose, contact, timestamp in stream]
    text_name = f'rebocap_stream_{take_id}'
    if bpy.data.texts.get(text_name) is not None:
        raise ValueError('Duplicate motion capture stream ID')
    payload = json.dumps(stream, separators=(',', ':'), allow_nan=False)
    text = bpy.data.texts.new(text_name)
    try:
        text.write(payload)
        text[STREAM_OWNER] = take_id
        text.use_fake_user = True
    except Exception:
        bpy.data.texts.remove(text)
        raise
    _take_stream_cache[take_id] = (text.as_pointer(), recorded_fps, stream, times, clock_reset)
    return text.name


def owned_stream_text(take):
    if not take.uuid:
        return None
    text = take.stream_text
    if text is not None:
        return text if text.get(STREAM_OWNER) == take.uuid else None
    # Original native recordings used an exact Text name before storing an ID reference.
    name = f'rebocap_stream_{take.uuid}'
    if take.stream_text_name == name:
        text = bpy.data.texts.get(name)
        if text is not None:
            owner = text.get(STREAM_OWNER)
            legacy_id = len(take.uuid) == 8 and all(c in '0123456789abcdef' for c in take.uuid)
            if owner == take.uuid or (owner is None and legacy_id):
                return text
    return None


def read_take_stream(take, refresh=False):
    text = owned_stream_text(take)
    if text is None:
        raise ValueError('No original motion data available for export')
    identity = (text.as_pointer(), take.recorded_fps)
    cached = _take_stream_cache.get(take.uuid)
    if not refresh and cached and cached[:2] == identity:
        return cached[2:]
    try:
        stream = json.loads(text.as_string())
        times, clock_reset = validate_stream(stream, take.recorded_fps, allow_clock_reset=True)
    except (ValueError, TypeError, OverflowError) as error:
        raise ValueError('Motion capture data is damaged') from error
    _take_stream_cache[take.uuid] = (*identity, stream, times, clock_reset)
    return stream, times, clock_reset


def get_take_stream(take):
    try:
        return read_take_stream(take)[0]
    except ValueError:
        return None


@bpy.app.handlers.persistent
def clear_runtime_cache(*_):
    _take_stream_cache.clear()
    _library_hash_cache.clear()
    _playback_library_data.clear()
    _linked_binding_data.clear()


def _timeline_frame_count(times, fps):
    span = times[-1] * fps
    if not math.isfinite(span) or span > _frame_limit() - 1:
        raise ValueError('Motion capture duration exceeds the Blender timeline')
    return max(1, math.ceil(span - 1e-6) + 1)


def get_take_frame_count(take, fps):
    try:
        _, times, _ = read_take_stream(take)
        return _timeline_frame_count(times, fps)
    except ValueError:
        return take.frame_count


def sample_take_stream(stream, times, seconds):
    right = bisect_right(times, seconds)
    if right == 0:
        return stream[0]
    if right >= len(stream):
        return stream[-1]
    left = right - 1
    factor = (seconds - times[left]) / (times[right] - times[left])
    a, b = stream[left], stream[right]
    trans = [a[0][i] + (b[0][i] - a[0][i]) * factor for i in range(3)]
    poses = []
    for qa, qb in zip(a[1], b[1]):
        q = Quaternion((qa[3], *qa[:3])).normalized().slerp(
            Quaternion((qb[3], *qb[:3])).normalized(), factor)
        poses.append([q.x, q.y, q.z, q.w])
    return trans, poses, a[2], a[3] + (b[3] - a[3]) * factor


_PLAYBACK_ACTION = '_rebocap_playback_action'


def _acquire_playback_action(scene, obj):
    # Restore a binding saved by the previous playback implementation before
    # the shared isolation layer takes over the object.
    _release_playback_action(scene, obj)
    from .playback_control import synchronize
    take = next((item for item in scene.rebocap_takes
                 if item.uuid == scene.rebocap_playback_take_uuid), None)
    if take is None and 0 <= scene.rebocap_active_take_index < len(scene.rebocap_takes):
        take = scene.rebocap_takes[scene.rebocap_active_take_index]
    if take is not None:
        synchronize(scene, take)


def _release_playback_action(scene, obj):
    marker = obj.get(_PLAYBACK_ACTION)
    if not marker or marker['scene'] != scene:
        return
    ad = obj.animation_data
    action = marker['action']
    if ad and ad.action is None and action is not None:
        ad.action = action
        slot_id = marker['slot']
        if slot_id and hasattr(ad, 'action_slot'):
            handle = marker.get('slot_handle', 0)
            if handle:
                ad.action_slot = next((slot for slot in action.slots if slot.handle == handle), None)
            else:
                ad.action_slot = next((slot for slot in action.slots if slot.identifier == slot_id), None)
    del obj[_PLAYBACK_ACTION]


def release_playback_target(scene, obj):
    if obj is None or not getattr(obj, 'is_editable', obj.library is None):
        return
    _release_playback_action(scene, obj)
    if obj.type == 'ARMATURE':
        for bone in obj.pose.bones:
            marker = bone.get(_PLAYBACK_ROTATION)
            if marker and marker['scene'] == scene:
                if bone.rotation_mode == 'QUATERNION':
                    restore_rotation_mode(bone, marker['mode'])
                del bone[_PLAYBACK_ROTATION]
    obj.update_tag()


_PLAYBACK_ROTATION = '_rebocap_playback_rotation'


def _remember_playback_rotation(scene, bone):
    # PoseBone properties survive save/undo and follow a bone through rename.
    # The scene ID identifies the controller even when the armature is shared.
    bone[_PLAYBACK_ROTATION] = {'scene': scene, 'mode': bone.rotation_mode}


def _playback_rotations(scene):
    for obj in bpy.data.objects:
        if obj.type != 'ARMATURE' or not getattr(obj, 'is_editable', obj.library is None):
            continue
        for bone in obj.pose.bones:
            marker = bone.get(_PLAYBACK_ROTATION)
            if marker is not None and marker['scene'] == scene:
                yield bone, marker


def restore_playback_rotation_modes(scene):
    for bone, marker in _playback_rotations(scene):
        if bone.rotation_mode == 'QUATERNION':
            restore_rotation_mode(bone, marker['mode'])
        del bone[_PLAYBACK_ROTATION]


def stop_playback(scene, preserve_anchors=False):
    _playback_library_data.pop(scene.as_pointer(), None)
    scene.rebocap_playback_active = False
    scene.rebocap_playback_take_uuid = ""
    from .playback_control import release
    release(scene)
    restore_playback_rotation_modes(scene)
    for obj in bpy.data.objects:
        _release_playback_action(scene, obj)
    if scene.rebocap_playback_resume_live:
        from ..core.a2t_types import set_live_pause
        set_live_pause(scene, False)
    scene.rebocap_playback_resume_live = False
    if not preserve_anchors:
        scene.rebocap_playback_anchors.clear()


PLAYBACK_FIELDS = (
    'rebocap_playback_active', 'rebocap_playback_take_uuid',
    'rebocap_playback_resume_live', 'rebocap_pause_control',
    'rebocap_playback_start_frame', 'rebocap_playback_fps', 'rebocap_playback_mode',
    'rebocap_playback_root_name', 'rebocap_playback_source_name',
    'rebocap_playback_hip_id', 'rebocap_playback_hip_name',
    'rebocap_playback_library_hash',
    'rebocap_playback_library_structure',
    'rebocap_playback_source_object', 'rebocap_playback_armature_data',
    'rebocap_playback_mapping',
    'rebocap_playback_root_location', 'frame_start', 'frame_end',
)


def snapshot_playback(scene):
    values = {name: getattr(scene, name) for name in PLAYBACK_FIELDS}
    values['rebocap_playback_root_location'] = tuple(scene.rebocap_playback_root_location)
    values['_anchors'] = [(item.source, item.armature_data, item.root_name, tuple(item.location), item.root_id)
                          for item in scene.rebocap_playback_anchors]
    return values, scene.render.fps, scene.render.fps_base


def restore_playback(scene, state):
    values, fps, fps_base = state
    scene.render.fps, scene.render.fps_base = fps, fps_base
    for name, value in values.items():
        if name != '_anchors':
            setattr(scene, name, value)
    scene.rebocap_playback_anchors.clear()
    for source, armature_data, root_name, location, root_id in values['_anchors']:
        item = scene.rebocap_playback_anchors.add()
        item.source, item.armature_data = source, armature_data
        item.root_name, item.location = root_name, location
        item.root_id = root_id


def _sync_anchor_bone_names(scene):
    """Follow a live bone rename without treating a replacement as that bone."""
    for item in scene.rebocap_playback_anchors:
        if not item.root_id or not item.source or not item.armature_data:
            continue
        if item.source.data != item.armature_data:
            continue
        matches = [bone for bone in item.armature_data.bones
                   if getattr(bone, 'rebocap_anchor_id', '') == item.root_id]
        if len(matches) == 1 and matches[0].name != item.root_name:
            old_name = item.root_name
            item.root_name = matches[0].name
            if (scene.rebocap_playback_source_object == item.source and
                    scene.rebocap_playback_root_name == old_name):
                scene.rebocap_playback_root_name = item.root_name


@bpy.app.handlers.persistent
def synchronize_anchor_names_before_lifecycle(_):
    for scene in bpy.data.scenes:
        _sync_anchor_bone_names(scene)
        _sync_playback_hip(scene)


_syncing_playback_hips = set()


def linked_reference(data):
    """Overrides remain local/editable but their reference library is a dependency."""
    visited = set()
    while data and data.override_library and data.as_pointer() not in visited:
        visited.add(data.as_pointer())
        data = data.override_library.reference
    return data


def linked_library(data):
    reference = linked_reference(data)
    return reference.library if reference else None


def linked_data_key(data):
    reference = linked_reference(data)
    library = linked_library(data)
    return (data.as_pointer(), reference.as_pointer() if reference else 0,
            library.as_pointer() if library else 0,
            library.packed_file.as_pointer() if library and library.packed_file else 0)


def _linked_library_hash(armature, *, refresh=False):
    library = linked_library(armature)
    if not library:
        return ''
    try:
        packed = library.packed_file
        if packed is not None:
            # Blender resolves a packed library from these bytes, even if its
            # original disk path is now absent or contains a different version.
            key = ('PACKED', library.as_pointer(), packed.as_pointer(), packed.size)
            if refresh or key not in _library_hash_cache:
                digest = hashlib.sha256(bytes(packed.data)).hexdigest()
                while len(_library_hash_cache) >= 32:
                    _library_hash_cache.pop(next(iter(_library_hash_cache)))
                _library_hash_cache[key] = digest
            return _library_hash_cache[key]
        # Save Copy can prepend a long chain of relative parent segments.
        # Use the resolved path for file I/O and for the fingerprint cache.
        path = os.path.normcase(os.path.normpath(bpy.path.abspath(library.filepath, library=library.parent)))
        info = os.stat(path)
        key = (path, info.st_size, info.st_mtime_ns)
        if refresh or key not in _library_hash_cache:
            digest = hashlib.sha256()
            with open(path, 'rb') as source:
                for chunk in iter(lambda: source.read(1024 * 1024), b''):
                    digest.update(chunk)
            after = os.stat(path)
            if (after.st_size, after.st_mtime_ns) != (info.st_size, info.st_mtime_ns):
                return None
            # Multiple scenes may query different linked assets each frame.
            # Expire only this path's old revision and bound the runtime cache.
            for old_key in tuple(_library_hash_cache):
                if old_key[0] == path:
                    del _library_hash_cache[old_key]
            while len(_library_hash_cache) >= 32:
                _library_hash_cache.pop(next(iter(_library_hash_cache)))
            _library_hash_cache[key] = digest.hexdigest()
        return _library_hash_cache[key]
    except (OSError, ValueError, AttributeError):
        return None


def _observed_library_hash(scene, source, observations, *, key=None):
    """Rehash whenever the actual linked ID was reconstructed."""
    key = scene.as_pointer() if key is None else key
    entry = observations.get(key)
    try:
        reloaded = bool(entry and entry[0] == scene and
                        (entry[1] != source or entry[2] != linked_data_key(source.data)))
    except ReferenceError:
        reloaded = bool(entry)
    structure = (linked_structure_signature(source.data) if not entry or reloaded or len(entry) < 4
                 else entry[3])
    fingerprint = _linked_library_hash(source.data, refresh=reloaded)
    if fingerprint:
        observations[key] = (scene, source, linked_data_key(source.data), structure)
    return fingerprint, reloaded, structure


def linked_structure_signature(armature):
    """Identify the linked rest skeleton currently loaded into Blender."""
    payload = [(bone.name, bone.parent.name if bone.parent else '',
                [float(value) for row in bone.matrix_local for value in row],
                float(bone.length), bool(bone.use_deform))
               for bone in sorted(armature.bones, key=lambda item: item.name)]
    return hashlib.sha256(json.dumps(payload, ensure_ascii=True, allow_nan=False,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def record_linked_binding(scene, source, fingerprint, *, structure=None):
    """Remember each successfully controlled linked object for recovery only."""
    if (not source or not source.data or not linked_library(source.data) or not fingerprint or
            scene.objects.get(source.name) != source):
        return ''
    matches = [item for item in scene.rebocap_linked_bindings
               if item.source == source and item.armature_data == source.data]
    if len(matches) > 1:
        raise ValueError('Duplicate linked skeleton bindings')
    item = matches[0] if matches else None
    if item and item.fingerprint == fingerprint and structure is None and item.structure:
        structure = item.structure
    if structure is None:
        structure = linked_structure_signature(source.data)
    if item and (item.fingerprint != fingerprint or item.structure != structure):
        # An explicit new binding must not discard the only old project copy.
        preserve_project_for_linked_library_conflict(force=True)
        if not scene.rebocap_library_recovery_path:
            raise ValueError('Cannot preserve the previous linked skeleton binding')
    if item is None:
        item = scene.rebocap_linked_bindings.add()
        item.source, item.armature_data = source, source.data
    if item.fingerprint != fingerprint:
        item.fingerprint = fingerprint
    if item.structure != structure:
        item.structure = structure
    key = (scene.as_pointer(), item.as_pointer())
    _linked_binding_data[key] = (scene, source, linked_data_key(source.data), structure)
    from .library_recovery import request_checkpoint
    request_checkpoint(scene, binding=(scene, source, fingerprint))
    return structure


def _sync_playback_hip(scene):
    """Follow a renamed mapped pelvis before its old name can be reused."""
    key = scene.as_pointer()
    if key in _syncing_playback_hips or not scene.rebocap_playback_active:
        return
    source = scene.rebocap_playback_source_object
    identity = scene.rebocap_playback_hip_id
    old_name = scene.rebocap_playback_hip_name
    if (not source or not identity or not old_name or
            scene.rebocap_bone_map.node_0 != old_name or
            source.data != scene.rebocap_playback_armature_data or
            scene.objects.get(source.name) != source):
        return
    matches = [bone for bone in source.data.bones
               if getattr(bone, 'rebocap_anchor_id', '') == identity]
    if len(matches) == 1 and matches[0].name != old_name:
        _syncing_playback_hips.add(key)
        try:
            scene.rebocap_playback_hip_name = matches[0].name
            scene.rebocap_bone_map.node_0 = matches[0].name
        finally:
            _syncing_playback_hips.discard(key)


def set_playback_anchor(scene, preserve=False):
    from . import rebocap_connection as connection
    _sync_anchor_bone_names(scene)
    if preserve:
        _sync_playback_hip(scene)
    source, hip, root, context_key = connection.retarget_context(scene)
    # A mapping may be temporarily empty while the user edits it.  Keep the
    # last valid anchor until a real target can be compared against it; using
    # the already-driven pose as a new origin would accumulate displacement.
    if preserve and context_key is None:
        return
    library_structure = ''
    if context_key is not None and linked_library(source.data):
        library_structure = linked_structure_signature(source.data)
        _playback_library_data[scene.as_pointer()] = (scene, source, linked_data_key(source.data), library_structure)
    else:
        _playback_library_data.pop(scene.as_pointer(), None)
    same_source = (source is not None and
                   scene.rebocap_playback_source_object == source and
                   scene.rebocap_playback_armature_data == source.data)
    # Older files have names and an anchor, but no saved object references.
    if (scene.rebocap_playback_source_object is None and
            not scene.rebocap_playback_mapping and source is not None):
        same_source = scene.rebocap_playback_source_name == source.name
    preserve_location = (preserve and same_source and root is not None and
                         scene.rebocap_playback_root_name == root.name)
    cached_anchor = None
    root_id = getattr(root.bone, 'rebocap_anchor_id', '') if root else ''
    if preserve and source is not None and root is not None:
        cached_anchor = next((item for item in scene.rebocap_playback_anchors
                              if item.source == source and item.armature_data == source.data
                              and ((root_id and item.root_id == root_id) or
                                   (not item.root_id and item.root_name == root.name))), None)
    scene.rebocap_playback_root_name = ""
    scene.rebocap_playback_source_name = scene.rebocap_source_armature
    scene.rebocap_playback_source_object = source if context_key else None
    scene.rebocap_playback_armature_data = source.data if context_key else None
    scene.rebocap_playback_mapping = json.dumps((hip.name, context_key[2])) if context_key else ""
    if root:
        scene.rebocap_playback_root_name = root.name
        if cached_anchor is not None:
            scene.rebocap_playback_root_location = cached_anchor.location
        elif not preserve_location:
            scene.rebocap_playback_root_location = root.location
        if cached_anchor is None:
            cached_anchor = scene.rebocap_playback_anchors.add()
            cached_anchor.source, cached_anchor.armature_data = source, source.data
            cached_anchor.root_name = root.name
            cached_anchor.location = scene.rebocap_playback_root_location
        editable_data = getattr(source.data, 'is_editable', source.data.library is None)
        if not root_id and editable_data:
            try:
                from uuid import uuid4
                root_id = uuid4().hex
                root.bone.rebocap_anchor_id = root_id
            except (AttributeError, RuntimeError, TypeError):
                root_id = ''
        if root_id:
            cached_anchor.root_id = root_id
        hip_id = getattr(hip.bone, 'rebocap_anchor_id', '')
        if not hip_id and editable_data:
            try:
                from uuid import uuid4
                hip_id = uuid4().hex
                hip.bone.rebocap_anchor_id = hip_id
            except (AttributeError, RuntimeError, TypeError):
                hip_id = ''
        scene.rebocap_playback_hip_id = hip_id
        scene.rebocap_playback_hip_name = hip.name
        if linked_library(source.data):
            fingerprint = _linked_library_hash(source.data)
            scene.rebocap_playback_library_hash = fingerprint or ''
            scene.rebocap_playback_library_structure = library_structure
        else:
            scene.rebocap_playback_library_hash = ''
            scene.rebocap_playback_library_structure = ''
    # Rest matrices must belong to the current mapping, not an earlier session.
    connection.obj_info_helper = connection.ObjInfoHelper()

    from .library_recovery import request_checkpoint
    request_checkpoint(scene, binding=(scene, source, scene.rebocap_playback_library_hash))


def playback_anchor_matches(scene):
    from .rebocap_connection import retarget_context
    _sync_anchor_bone_names(scene)
    source, hip, root, context_key = retarget_context(scene)
    if context_key is None:
        return False
    return (scene.rebocap_playback_source_object == source
            and scene.rebocap_playback_armature_data == source.data
            and scene.rebocap_playback_root_name == root.name
            and scene.rebocap_playback_mapping == json.dumps((hip.name, context_key[2])))


def _missing_linked_playback_target(scene):
    """Blender may load a missing linked armature Object as an EMPTY ID."""
    if (not getattr(scene, 'rebocap_playback_active', False) or
            getattr(scene, 'rebocap_playback_mode', '') not in ('FK', 'DUAL') or
            not scene.rebocap_playback_library_hash):
        return False
    try:
        source = scene.rebocap_playback_source_object
        data = scene.rebocap_playback_armature_data
        return (not source or not data or getattr(source, 'is_missing', False) or
                getattr(data, 'is_missing', False) or source.data is None)
    except (AttributeError, ReferenceError, RuntimeError):
        return True


def playback_linked_library_conflict(scene):
    """Identify a changed or unverifiable linked library for user guidance."""
    if not getattr(scene, 'rebocap_playback_active', False):
        return False
    if _missing_linked_playback_target(scene):
        return True
    source = scene.objects.get(scene.rebocap_source_armature)
    if not source or source.type != 'ARMATURE':
        return False
    if source.data is None:
        return bool(scene.rebocap_playback_library_hash and
                    scene.rebocap_playback_source_object in (None, source))
    if (not linked_library(source.data) or
            scene.rebocap_playback_source_object not in (None, source) or
            scene.rebocap_playback_armature_data not in (None, source.data)):
        return False
    expected = scene.rebocap_playback_library_hash
    fingerprint, _, structure = _observed_library_hash(scene, source, _playback_library_data)
    expected_structure = scene.rebocap_playback_library_structure
    if not expected and scene.rebocap_playback_hip_id:
        return bool(expected_structure and structure != expected_structure)
    return (not expected or fingerprint != expected or
            bool(expected_structure and structure != expected_structure))


def linked_binding_conflict(scene):
    """Check saved live/preview linked sources without claiming control."""
    for item in scene.rebocap_linked_bindings:
        source, data = item.source, item.armature_data
        if not source or not item.fingerprint or scene.objects.get(source.name) != source:
            continue
        if source.data is None:
            return True
        if source.data != data or not data or not linked_library(data):
            continue
        key = (scene.as_pointer(), item.as_pointer())
        current, _, structure = _observed_library_hash(scene, source, _linked_binding_data, key=key)
        if current != item.fingerprint or structure != item.structure:
            return True
    return False


def _copy_project_for_library_recovery(source, directory):
    """Write and verify a new copy without modifying the original project."""
    def filesystem_path(path):
        path = str(path)
        if os.name == 'nt' and os.path.isabs(path) and len(path) >= 240 and not path.startswith('\\\\?\\'):
            return ('\\\\?\\UNC\\' + path[2:]) if path.startswith('\\\\') else ('\\\\?\\' + path)
        return path

    os.makedirs(filesystem_path(directory), exist_ok=True)
    original = Path(source)
    destination = Path(directory) / (original.stem[:48] + '_RBC_recovery_' + uuid.uuid4().hex[:16] + '.blend')
    source_path, destination_path = filesystem_path(source), filesystem_path(destination)
    created = False
    try:
        before = os.stat(source_path)
        digest = hashlib.sha256()
        with open(source_path, 'rb') as reader, open(destination_path, 'xb') as writer:
            created = True
            for chunk in iter(lambda: reader.read(1024 * 1024), b''):
                writer.write(chunk)
                digest.update(chunk)
            writer.flush()
            os.fsync(writer.fileno())
        after = os.stat(source_path)
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise OSError('Original project changed while copying')
        verify = hashlib.sha256()
        with open(destination_path, 'rb') as copied:
            for chunk in iter(lambda: copied.read(1024 * 1024), b''):
                verify.update(chunk)
        if verify.digest() != digest.digest():
            raise OSError('Project recovery copy verification failed')
        return destination_path
    except Exception:
        if created:
            try:
                os.unlink(destination_path)
            except OSError:
                pass
        raise


def reset_project_recovery_epoch():
    """A recovery epoch belongs to one loaded project, not to an undo state."""
    global _project_recovery_epoch
    _project_recovery_epoch = None


def _scene_linked_library_conflict(scene):
    return ((getattr(scene, 'rebocap_playback_mode', '') in ('FK', 'DUAL')
             and playback_linked_library_conflict(scene)) or linked_binding_conflict(scene))


def _publish_project_recovery(path, relocate):
    for scene in bpy.data.scenes:
        try:
            scene.rebocap_library_recovery_path = path
            scene.rebocap_library_recovery_failed = not bool(path)
            scene.rebocap_library_recovery_relocate = relocate
        except (AttributeError, ReferenceError, RuntimeError) as error:
            print(f'[Rebocap] Could not display project recovery status: {error}')


@bpy.app.handlers.persistent
def finish_project_recovery_epoch_after_save(*_):
    """A new conflict needs a fresh copy after a resolved project is saved."""
    from ..core.save_context import is_recovery_copy
    if is_recovery_copy():
        return
    global _project_recovery_epoch
    if not _project_recovery_epoch:
        return
    try:
        from . import rebocap_connection
        if rebocap_connection._active_live_library_unresolved:
            return
        if any(_scene_linked_library_conflict(scene) for scene in bpy.data.scenes):
            return
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as error:
        print(f'[Rebocap] Could not finish linked library recovery: {error}')
        return
    # Keep the previous on-disk copy and its visible path; only the active
    # conflict epoch ends. A later conflict must not reuse that old copy.
    _project_recovery_epoch = None


@bpy.app.handlers.persistent
def preserve_project_for_linked_library_conflict(*_, force=False):
    """Retain the on-disk project before a missing library can be re-saved."""
    from ..core.save_context import is_recovery_copy
    if is_recovery_copy():
        return
    global _project_recovery_epoch
    affected = []
    for scene in bpy.data.scenes:
        try:
            if _scene_linked_library_conflict(scene):
                affected.append(scene)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as error:
            print(f'[Rebocap] Could not inspect linked library binding: {error}')
            affected.append(scene)
    if not affected and not force:
        return
    if _project_recovery_epoch and os.path.isfile(_project_recovery_epoch[0]):
        # Undo can replace Scene properties; restore the view without replacing
        # the earliest copy of the still-unresolved conflict.
        _publish_project_recovery(*_project_recovery_epoch)
        return
    source = bpy.data.filepath
    recovery = ''
    relocate = False
    try:
        if not source:
            raise OSError('Original project is unavailable')
        try:
            recovery = _copy_project_for_library_recovery(source, str(Path(source).parent))
        except OSError as error:
            print(f'[Rebocap] Could not back up project next to original: {error}')
            base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
            directory = os.path.join(base, 'Rebocap', 'BlenderProjectRecovery')
            recovery = _copy_project_for_library_recovery(source, directory)
            relocate = True
    except (OSError, ValueError) as error:
        print(f'[Rebocap] Could not back up project before library recovery: {error}')
    # The copy protects the whole project, including shared objects in scenes
    # which are not the current playback owner.
    _project_recovery_epoch = (recovery, relocate) if recovery else None
    _publish_project_recovery(recovery, relocate)


def playback_identity_conflict(scene, synchronize=True):
    """Refuse to guess when a duplicated bone carries the same persistent ID."""
    if _missing_linked_playback_target(scene):
        return True
    from .rebocap_connection import retarget_context
    if synchronize:
        _sync_anchor_bone_names(scene)
        _sync_playback_hip(scene)
    source, hip, root, context_key = retarget_context(scene)
    if not source:
        return False
    if not hip or not root:
        # A deleted mapped bone is an unresolved old binding.  An intentionally
        # cleared or different mapping is handled as a separate user request.
        return bool(scene.rebocap_playback_active and
                    scene.rebocap_playback_source_object == source and
                    scene.rebocap_playback_hip_name and
                    scene.rebocap_bone_map.node_0 == scene.rebocap_playback_hip_name)
    for current in (root.bone, hip.bone):
        identity = getattr(current, 'rebocap_anchor_id', '')
        if identity and sum(1 for bone in source.data.bones
                            if getattr(bone, 'rebocap_anchor_id', '') == identity) > 1:
            return True
    editable_data = getattr(source.data, 'is_editable', source.data.library is None)
    if (linked_library(source.data) and scene.rebocap_playback_active and
            scene.rebocap_playback_source_object == source and
            scene.rebocap_playback_armature_data == source.data):
        current, reloaded, structure = _observed_library_hash(scene, source, _playback_library_data)
        expected = scene.rebocap_playback_library_hash
        expected_structure = scene.rebocap_playback_library_structure
        if (expected and current != expected) or (expected_structure and structure != expected_structure):
            return True
        if reloaded and not expected:
            return True
    if (not editable_data and linked_library(source.data) and
            not getattr(hip.bone, 'rebocap_anchor_id', '') and
            _linked_library_hash(source.data) is None):
        return True
    if not scene.rebocap_playback_active:
        # A stopped take can be deliberately mounted again as a fresh binding.
        return False
    saved_hip_id = scene.rebocap_playback_hip_id
    if (not editable_data and not saved_hip_id and not scene.rebocap_playback_library_hash
            and scene.rebocap_playback_source_object in (None, source)
            and scene.rebocap_playback_armature_data in (None, source.data)):
        # A legacy project may lack all saved binding fields, including the
        # mapping and source pointers.  Name alone cannot establish identity.
        return True
    if (saved_hip_id and scene.rebocap_playback_source_object == source
            and scene.rebocap_playback_armature_data == source.data
            and scene.rebocap_bone_map.node_0 == scene.rebocap_playback_hip_name):
        if sum(1 for bone in source.data.bones
               if getattr(bone, 'rebocap_anchor_id', '') == saved_hip_id) != 1:
            return True
    if (not editable_data and not saved_hip_id and scene.rebocap_playback_mapping
            and scene.rebocap_playback_source_object == source
            and scene.rebocap_playback_armature_data == source.data):
        try:
            old_hip, old_chain = json.loads(scene.rebocap_playback_mapping)
            if (hip.name == old_hip and (not scene.rebocap_playback_library_hash or
                    _linked_library_hash(source.data) != scene.rebocap_playback_library_hash)):
                return True
            current_chain = json.loads(json.dumps(context_key[2]))
            if hip.name == old_hip and old_chain != current_chain:
                return True
        except (TypeError, ValueError, IndexError):
            return True
    for anchor in scene.rebocap_playback_anchors:
        if anchor.source != source or anchor.armature_data != source.data:
            continue
        if anchor.root_id:
            matches = [bone for bone in source.data.bones
                       if getattr(bone, 'rebocap_anchor_id', '') == anchor.root_id]
            if len(matches) != 1:
                return True
        elif anchor.root_name and not source.data.bones.get(anchor.root_name):
            return True
    return False


def get_drive_type(scene, take):
    mode = scene.rebocap_playback_targets
    return take.take_type if mode == 'RECORDED' else mode


def get_drive_objects(scene, take):
    mode = get_drive_type(scene, take)
    objects = []
    if mode in ('FK', 'DUAL'):
        source = scene.objects.get(scene.rebocap_source_armature)
        if not source or source.type != 'ARMATURE' or not source.pose.bones.get(scene.rebocap_bone_map.node_0):
            raise ValueError("Please bind a source armature and its pelvis first")
        objects.append(source)
    if mode in ('IK', 'DUAL'):
        root = scene.objects.get('Rebocap_Root')
        pelvis = scene.objects.get('Rebocap_Pelvis')
        if not root or root.type != 'EMPTY' or not pelvis or pelvis.type != 'EMPTY' or pelvis.parent != root:
            raise ValueError("Please generate tracking nodes first")
        objects.extend(obj for obj in scene.objects if
                       (obj.type == 'EMPTY' and obj.name in TRACKING_OBJECT_NAMES) or
                       (obj.type == 'ARMATURE' and obj.get('rebocap_demo_character')))
    return list(dict.fromkeys(objects))


def _get_effective_target_fps(scene):
    mode = getattr(scene, 'rebocap_fps_mode', 'SCENE')
    if mode == 'SCENE':
        fps_base = getattr(scene.render, 'fps_base', 1.0)
        return scene.render.fps / fps_base if abs(fps_base - 1.0) > 1e-4 and fps_base > 0 else float(scene.render.fps)
    elif mode == 'FPS_24':
        return 24.0
    elif mode == 'FPS_30':
        return 30.0
    elif mode == 'FPS_60':
        return 60.0
    elif mode == 'CUSTOM':
        return float(getattr(scene, 'rebocap_target_fps', 60))
    return float(scene.render.fps)


@bpy.app.handlers.persistent
def rebocap_timeline_playback_handler(scene, depsgraph=None, *, tracking_only=False):
    """纯原生流时间轴驱动器：根据当前时间轴帧位置，动态解算并实时驱动角色骨骼或追踪点。"""
    if (preview_frame_suspended(scene) or (preview_active(scene) and not preview_saving(scene))
            or not getattr(scene, 'rebocap_playback_active', False)):
        return

    rebind_playback_target(scene)

    active_uuid = getattr(scene, 'rebocap_playback_take_uuid', '')
    if not active_uuid:
        return

    take = next((take for take in scene.rebocap_takes if take.uuid == active_uuid), None)
    if take is None:
        return
    if (scene.rebocap_playback_mode in ('FK', 'DUAL') and
            playback_identity_conflict(scene)):
        print('[Rebocap] ' + T('Playback bone binding cannot be confirmed'))
        return
    from ..core.control import drive_objects, find_conflict
    mode = scene.rebocap_playback_mode or get_drive_type(scene, take)
    if find_conflict(scene, drive_objects(scene, mode)):
        return
    try:
        stream, times, _ = read_take_stream(take)
    except ValueError:
        return

    from .playback_control import synchronize
    try:
        synchronize(scene, take)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as error:
        print('[Rebocap] Playback isolation failed:', error)
        return
    target_fps = scene.rebocap_playback_fps or scene.render.fps / scene.render.fps_base
    current_frame = scene.frame_current + scene.frame_subframe
    time_offset = (current_frame - scene.rebocap_playback_start_frame) / target_fps
    trans, pose24, static_index, ts = sample_take_stream(stream, times, time_offset)

    apply_stream_pose(scene, take, stream, trans, pose24, static_index, ts,
                      tracking_only=tracking_only)


def apply_stream_pose(scene, take, stream, trans, pose24, static_index, ts, *, tracking_only=False):
    from .playback_control import pose_layer_for
    pose_layer = pose_layer_for(scene)
    first_trans = stream[0][0]
    init_trans_vec = Vector((first_trans[0], first_trans[1], first_trans[2]))

    take_type = scene.rebocap_playback_mode or get_drive_type(scene, take)

    def remember_rotation(bone):
        _remember_playback_rotation(scene, bone)

    # FK 模式：操控绑定的自定义角色骨架
    if not tracking_only and take_type in ('FK', 'DUAL'):
        if not playback_anchor_matches(scene):
            target = scene.objects.get(scene.rebocap_source_armature)
            previous = scene.rebocap_playback_source_object
            if target is not None and target != previous:
                _acquire_playback_action(scene, target)
                release_playback_target(scene, previous)
            set_playback_anchor(scene, preserve=True)
        drive_retarget(trans, pose24, static_index, ts, scene=scene,
                       initial_mocap_trans=init_trans_vec,
                       initial_root_location=Vector(scene.rebocap_playback_root_location),
                       before_rotation_mode=remember_rotation, pose_layer=pose_layer)

    # IK 模式：操控追踪拼装人形骨架与示范角色
    if take_type in ('IK', 'DUAL'):
        drive_ik_tracking(trans, pose24, scene=scene, pose_layer=pose_layer)
        drive_demo_character(trans, pose24, scene=scene, before_rotation_mode=remember_rotation,
                             pose_layer=pose_layer)


def evaluate_saved_fk_target(scene, target, mapping):
    """Evaluate the reserved FK target without changing the selected target."""
    if (not scene.rebocap_playback_active or scene.rebocap_playback_mode not in ('FK', 'DUAL')
            or scene.rebocap_playback_source_object != target):
        return False
    from .rebocap_connection import retarget_context
    source, hip, root, key = retarget_context(scene, target, mapping[0])
    if not source or not hip or not root or key is None or scene.rebocap_playback_armature_data != source.data:
        raise ValueError('Playback bone binding cannot be confirmed')
    hip_id = scene.rebocap_playback_hip_id
    if hip_id and (getattr(hip.bone, 'rebocap_anchor_id', '') != hip_id or
                   sum(getattr(b, 'rebocap_anchor_id', '') == hip_id for b in source.data.bones) != 1):
        raise ValueError('Playback bone binding cannot be confirmed')
    if linked_library(source.data):
        fingerprint = scene.rebocap_playback_library_hash
        expected_structure = scene.rebocap_playback_library_structure
        current, _, structure = _observed_library_hash(scene, source, _playback_library_data)
        if ((not fingerprint and not hip_id) or (fingerprint and current != fingerprint) or
                (expected_structure and structure != expected_structure)):
            raise ValueError('Playback bone binding cannot be confirmed')
    root_id = getattr(root.bone, 'rebocap_anchor_id', '')
    anchors = [item for item in scene.rebocap_playback_anchors
               if item.source == source and item.armature_data == source.data and
               ((root_id and item.root_id == root_id) or
                (not item.root_id and item.root_name == root.name))]
    if len(anchors) != 1 or (root_id and sum(getattr(b, 'rebocap_anchor_id', '') == root_id
                                            for b in source.data.bones) != 1):
        raise ValueError('Playback bone binding cannot be confirmed')
    take = next((item for item in scene.rebocap_takes if item.uuid == scene.rebocap_playback_take_uuid), None)
    if take is None:
        raise ValueError('This take has no original motion data')
    stream, times, _ = read_take_stream(take)
    fps = scene.rebocap_playback_fps or scene.render.fps / scene.render.fps_base
    offset = (scene.frame_current + scene.frame_subframe - scene.rebocap_playback_start_frame) / fps
    trans, pose24, static_index, ts = sample_take_stream(stream, times, offset)
    drive_retarget(trans, pose24, static_index, ts, scene=scene,
                   initial_mocap_trans=Vector(stream[0][0]),
                   initial_root_location=Vector(anchors[0].location),
                   source_override=target, mapping_override=mapping,
                   before_rotation_mode=lambda bone: _remember_playback_rotation(scene, bone))
    return True


class REBOCAP_OT_apply_take(bpy.types.Operator):
    bl_idname = "rebocap.apply_take"
    bl_label = T_static("挂载到时间轴 (Apply Take)")
    bl_description = T_static("将选中的原生动捕流挂载到当前时间轴实时解算驱动")

    @classmethod
    def poll(cls, context):
        return (0 <= context.scene.rebocap_active_take_index < len(context.scene.rebocap_takes)
                and not context.scene.recording
                and not preview_active(context.scene))

    def execute(self, context):
        scene = context.scene
        idx = scene.rebocap_active_take_index
        take = scene.rebocap_takes[idx]

        try:
            stream, times, _ = read_take_stream(take, refresh=True)
            drive_objects = get_drive_objects(scene, take)
            if get_drive_type(scene, take) in ('FK', 'DUAL') and playback_identity_conflict(scene):
                raise ValueError('Playback bone binding cannot be confirmed')
            target_fps = _get_effective_target_fps(scene)
            frame_count = _timeline_frame_count(times, target_fps)
        except ValueError as error:
            if str(error) == 'No original motion data available for export':
                self.report({'WARNING'}, T('This take has no original motion data'))
            else:
                self.report({'WARNING'}, T(str(error)))
            return {'CANCELLED'}

        from ..core.control import find_conflict, conflict_message
        conflict = find_conflict(scene, drive_objects)
        if conflict:
            self.report({'WARNING'}, conflict_message(conflict))
            return {'CANCELLED'}

        preserve_anchor = scene.rebocap_playback_active
        old_state = snapshot_playback(scene)
        old_frame = scene.frame_current, scene.frame_subframe
        old_actions = {}
        old_playback_actions = [(obj, obj[_PLAYBACK_ACTION].to_dict())
                                for obj in bpy.data.objects
                                if _PLAYBACK_ACTION in obj
                                and obj[_PLAYBACK_ACTION]['scene'] == scene]
        old_pose = []
        old_rotations = [(bone, marker.to_dict()) for bone, marker in _playback_rotations(scene)]
        for obj in drive_objects:
            ad = obj.animation_data
            if ad and ad.action:
                from .recording_control import _authored_action
                action = _authored_action(ad.action)
                slot = getattr(ad, 'action_slot', None)
                handle = slot.handle if slot else 0
                identifier = slot.identifier if slot else ''
                old_actions[obj] = (action, handle, identifier, action.use_fake_user)
            old_pose.extend((target, target.matrix_basis.copy(), target.rotation_mode)
                            for target in ([obj, *obj.pose.bones] if obj.type == 'ARMATURE' else [obj]))
        try:
            stop_playback(scene, preserve_anchors=preserve_anchor)
            scene.rebocap_playback_resume_live = scene.open and not scene.rebocap_pause_control
            if scene.open:
                scene.rebocap_pause_control = True
            if scene.rebocap_fps_mode != 'SCENE':
                scene.render.fps = int(round(target_fps))
                scene.render.fps_base = 1.0
            for obj in drive_objects:
                _acquire_playback_action(scene, obj)
            set_playback_anchor(scene, preserve=preserve_anchor)
            scene.rebocap_playback_mode = get_drive_type(scene, take)
            scene.rebocap_playback_start_frame = 1
            scene.rebocap_playback_fps = target_fps
            scene.frame_start = scene.rebocap_playback_start_frame
            scene.frame_end = frame_count
            scene.frame_set(scene.rebocap_playback_start_frame)
            # Evaluate explicitly so an error in the solver is catchable by the operator.
            apply_stream_pose(scene, take, stream, *sample_take_stream(stream, times, 0.0))
            scene.rebocap_playback_take_uuid = take.uuid
            scene.rebocap_playback_active = True
            from ..core.control import synchronize_owners
            synchronize_owners()
        except Exception as error:
            from .playback_control import release
            release(scene)
            restore_playback_rotation_modes(scene)
            for obj in drive_objects:
                _release_playback_action(scene, obj)
            for bone, marker in old_rotations:
                bone.rotation_mode = 'QUATERNION'
                bone[_PLAYBACK_ROTATION] = marker
            for obj, (action, handle, identifier, fake_user) in old_actions.items():
                ad = obj.animation_data
                if ad.action != action:
                    ad.action = action
                if hasattr(ad, 'action_slot'):
                    slot = next((item for item in action.slots if item.handle == handle), None) if handle else None
                    if slot is None and not handle and identifier:
                        slot = next((item for item in action.slots if item.identifier == identifier), None)
                    ad.action_slot = slot
                if action.use_fake_user != fake_user:
                    action.use_fake_user = fake_user
            for target, basis, rotation_mode in old_pose:
                target.rotation_mode = rotation_mode
                target.matrix_basis = basis
            restore_playback(scene, old_state)
            for obj, marker in old_playback_actions:
                if obj.animation_data and obj.animation_data.action == marker['action']:
                    obj[_PLAYBACK_ACTION] = marker
                    safely_clear_action(obj)
            scene.frame_set(old_frame[0], subframe=old_frame[1])
            self.report({'ERROR'}, f"{T('Could not apply motion capture take')}: {error}")
            return {'CANCELLED'}

        scene.rebocap_has_new_take = False
        self.report({'INFO'}, f"Take {take.name} 原生动捕流已挂载到时间轴 (1 ~ {frame_count} 帧 @ {target_fps:g} FPS)")
        return {'FINISHED'}


class REBOCAP_OT_bake_take(bpy.types.Operator):
    bl_idname = "rebocap.bake_take"
    bl_label = T_static("Bake to Action")
    bl_description = T_static("Bake to Action")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if preview_active(scene) or scene.recording or not 0 <= scene.rebocap_active_take_index < len(scene.rebocap_takes):
            return False
        take = scene.rebocap_takes[scene.rebocap_active_take_index]
        return bool(get_take_stream(take))

    def execute(self, context):
        scene = context.scene
        take = scene.rebocap_takes[scene.rebocap_active_take_index]
        try:
            objects = get_drive_objects(scene, take)
        except ValueError as error:
            self.report({'WARNING'}, T(str(error)))
            return {'CANCELLED'}
        from ..core.control import find_conflict, conflict_message
        conflict = find_conflict(scene, objects)
        if conflict:
            self.report({'WARNING'}, conflict_message(conflict))
            return {'CANCELLED'}
        old_frame, old_subframe = scene.frame_current, scene.frame_subframe
        old_state = snapshot_playback(scene)
        from .rebocap_connection import _recording_binding
        _, _, _, bake_root = _recording_binding(scene)[0]
        root_path = bake_root.path_from_id('location') if bake_root else None
        from .baked_drivers import _MARKER as baked_driver_marker, _OWNED as baked_driver_owned
        root_object = bake_root.id_data if bake_root else None
        old_driver_markers = None
        old_driver_owned = None
        if root_object:
            if baked_driver_marker in root_object:
                old_driver_markers = [entry.to_dict() for entry in root_object[baked_driver_marker]]
            old_driver_owned = root_object.get(baked_driver_owned)
        from .recording_control import _authored_action
        old_actions = {}
        for obj in objects:
            ad = obj.animation_data
            action = _authored_action(ad.action) if ad and ad.action else None
            slot = getattr(ad, 'action_slot', None) if ad else None
            old_actions[obj] = (action, slot.handle if slot else 0,
                                action.use_fake_user if action else False)
        old_pose = {obj: {pb.name: (pb.matrix_basis.copy(), pb.rotation_mode)
                         for pb in obj.pose.bones} for obj in objects if obj.type == 'ARMATURE'}
        from . import playback_control
        session = playback_control._sessions.get(scene.as_pointer())
        authored_modes = {
            bone: mode for bone, mode in session.rotation_modes.items()
        } if session else {}
        created = []
        try:
            from .playback_control import pose_layer_for
            if bpy.ops.rebocap.apply_take() != {'FINISHED'}:
                return {'CANCELLED'}
            channels = {}
            for obj in objects:
                if obj.type == 'ARMATURE':
                    for pb in obj.pose.bones:
                        basis = pb.matrix_basis.copy()
                        pb.rotation_mode = 'QUATERNION'
                        pb.matrix_basis = basis
                        for prop in ('location', 'rotation_quaternion', 'scale'):
                            channels[(pb, prop)] = []
                else:
                    for prop in ('location', 'rotation_quaternion', 'scale'):
                        channels[(obj, prop)] = []
            # Use precisely the same solver and source timestamps as preview.
            for frame in range(scene.frame_start, scene.frame_end + 1):
                scene.frame_set(frame)
                layer = pose_layer_for(scene)
                for (target, prop), values in channels.items():
                    # Sample the solver before authored constraints. The baked
                    # Action will still be evaluated with those constraints.
                    values.append(layer.sample(target, prop) if layer is not None
                                  else tuple(getattr(target, prop)))
            for obj in objects:
                # The authored Action can be the only copy of an edited working
                # Action. Keep it available after replacing the active binding.
                previous_action = old_actions[obj][0]
                if previous_action is not None:
                    previous_action.use_fake_user = True
                action = bpy.data.actions.new(name=f"rebocap_baked_{take.name}_{obj.name}")
                action['rebocap_baked'] = True
                created.append(action)
                action.use_fake_user = True
                _action_setup_slot(action, obj)
                for (target, prop), values in channels.items():
                    if target.id_data != obj:
                        continue
                    output_prop = prop
                    if prop == 'rotation_quaternion' and obj.type == 'ARMATURE':
                        marker = target.get(_PLAYBACK_ROTATION)
                        mode = authored_modes.get(target, marker['mode'] if marker
                                                  else old_pose[obj][target.name][1])
                        if mode == 'AXIS_ANGLE':
                            output_prop = 'rotation_axis_angle'
                            converted = []
                            for value in values:
                                axis, angle = Quaternion(value).to_axis_angle()
                                converted.append((angle, *axis))
                            values = converted
                        elif mode != 'QUATERNION':
                            output_prop = 'rotation_euler'
                            converted = []
                            previous = None
                            for value in values:
                                quat = Quaternion(value)
                                euler = quat.to_euler(mode, previous) if previous is not None else quat.to_euler(mode)
                                converted.append(tuple(euler))
                                previous = euler
                            values = converted
                    path = target.path_from_id(output_prop)
                    for axis in range(len(values[0])):
                        curve = _action_fcurve_new(action, path, axis)
                        curve.keyframe_points.add(len(values))
                        coords = []
                        for index, value in enumerate(values):
                            coords.extend((scene.frame_start + index, value[axis]))
                        curve.keyframe_points.foreach_set('co', coords)
                        for point in curve.keyframe_points:
                            point.interpolation = 'LINEAR'
                        curve.update()
                safely_set_action(obj, action)
            # Baked actions now own playback; leave live control paused.
            scene.rebocap_playback_resume_live = False
            stop_playback(scene)
            from .baked_drivers import remember, synchronize
            if bake_root and root_path:
                remember(bake_root.id_data, bake_root.id_data.animation_data.action, {root_path})
                synchronize()
            scene.rebocap_pause_control = True
            scene.frame_set(old_frame, subframe=old_subframe)
            self.report({'INFO'}, T("Bake to Action"))
            return {'FINISHED'}
        except Exception as error:
            if root_object:
                if old_driver_markers is None:
                    if baked_driver_marker in root_object:
                        del root_object[baked_driver_marker]
                else:
                    root_object[baked_driver_marker] = old_driver_markers
                if old_driver_owned is None:
                    if baked_driver_owned in root_object:
                        del root_object[baked_driver_owned]
                else:
                    root_object[baked_driver_owned] = old_driver_owned
            for obj, (action, handle, fake_user) in old_actions.items():
                if obj.animation_data:
                    obj.animation_data.action = action
                    if action and handle and hasattr(obj.animation_data, 'action_slot'):
                        obj.animation_data.action_slot = next(
                            (slot for slot in action.slots if slot.handle == handle), None)
                if action:
                    action.use_fake_user = fake_user
            for action in created:
                bpy.data.actions.remove(action)
            for obj, pose in old_pose.items():
                for pb in obj.pose.bones:
                    basis, mode = pose[pb.name]
                    pb.rotation_mode = mode
                    pb.matrix_basis = basis
            restore_playback(scene, old_state)
            scene.frame_set(old_frame, subframe=old_subframe)
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class REBOCAP_OT_resolve_duplicate_bone_binding(bpy.types.Operator):
    bl_idname = 'rebocap.resolve_duplicate_bone_binding'
    bl_label = T_static('Keep selected bone binding')
    bl_description = T_static('Keep the selected original bone and give its duplicates new identities')
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        pose_bone = context.active_pose_bone
        if (not obj or obj.type != 'ARMATURE' or not pose_bone or
                not getattr(obj.data, 'is_editable', obj.data.library is None)):
            self.report({'ERROR'}, T('Select the original editable pose bone'))
            return {'CANCELLED'}
        bone = pose_bone.bone
        identity = getattr(bone, 'rebocap_anchor_id', '')
        duplicates = [b for b in obj.data.bones if identity and
                      getattr(b, 'rebocap_anchor_id', '') == identity]
        if len(duplicates) < 2:
            self.report({'ERROR'}, T('Selected bone has no duplicate identity'))
            return {'CANCELLED'}
        # Do not alter a different scene's known binding to one of these bones.
        # A missing name is ambiguous too: an explicit selection in one scene
        # must not silently choose a bone for another saved binding.
        for scene in bpy.data.scenes:
            if (scene.rebocap_playback_active and scene.rebocap_playback_armature_data == obj.data
                    and scene.rebocap_playback_hip_id == identity):
                if scene.rebocap_playback_hip_name != bone.name:
                    self.report({'ERROR'}, T('Another binding needs this identity'))
                    return {'CANCELLED'}
            for anchor in scene.rebocap_playback_anchors:
                if anchor.armature_data == obj.data and anchor.root_id == identity and anchor.root_name != bone.name:
                    self.report({'ERROR'}, T('Another binding needs this identity'))
                    return {'CANCELLED'}
        changed = []
        try:
            for other in duplicates:
                if other != bone:
                    changed.append((other, other.rebocap_anchor_id))
                    other.rebocap_anchor_id = uuid.uuid4().hex
        except Exception as exc:
            for other, old_id in changed:
                other.rebocap_anchor_id = old_id
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, T('Duplicate bone identities resolved'))
        return {'FINISHED'}


class REBOCAP_OT_stop_playback(bpy.types.Operator):
    bl_idname = "rebocap.stop_playback"
    bl_label = T_static("停止时间轴驱动 (Stop Drive)")
    bl_description = T_static("停止时间轴上的原生动捕流驱动，恢复角色自由控制")

    def execute(self, context):
        scene = context.scene
        stop_playback(scene)
        scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in ('VIEW_3D', 'TIMELINE'):
                    area.tag_redraw()
        self.report({'INFO'}, "已停止时间轴动捕流驱动")
        return {'FINISHED'}


class REBOCAP_OT_delete_take(bpy.types.Operator):
    bl_idname = "rebocap.delete_take"
    bl_label = T_static("删除记录 (Delete Take)")
    bl_description = T_static("删除当前选中的历史记录及其实际数据")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (0 <= context.scene.rebocap_active_take_index < len(context.scene.rebocap_takes)
                and not context.scene.recording)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        if len(scene.rebocap_takes) > 0 and 0 <= scene.rebocap_active_take_index < len(scene.rebocap_takes):
            take = scene.rebocap_takes[scene.rebocap_active_take_index]
            layout.label(text=T("确定要删除此动捕记录吗？"), icon='QUESTION')
            box = layout.box()
            row = box.row(align=True)
            row.label(text=f"Take: {take.name} [{take.take_type}]", icon='ACTION')
            layout.label(text=T("此操作将永久删除相关动捕数据。"), icon='INFO')

    def execute(self, context):
        scene = context.scene
        if not 0 <= scene.rebocap_active_take_index < len(scene.rebocap_takes):
            return {'CANCELLED'}
        idx = scene.rebocap_active_take_index
        take = scene.rebocap_takes[idx]
        take_name = take.name
        if scene.rebocap_playback_take_uuid and scene.rebocap_playback_take_uuid == take.uuid:
            stop_playback(scene)
        text = owned_stream_text(take)
        _take_stream_cache.pop(take.uuid, None)
        scene.rebocap_takes.remove(idx)
        if text is not None and not any(
                other.stream_text == text or owned_stream_text(other) == text
                for item in bpy.data.scenes for other in item.rebocap_takes):
            bpy.data.texts.remove(text)
        if idx > 0:
            scene.rebocap_active_take_index = idx - 1
        elif len(scene.rebocap_takes) == 0:
            scene.rebocap_active_take_index = 0

        self.report({'INFO'}, f"{T('动捕记录已删除')}: {take_name}")
        return {'FINISHED'}


class REBOCAP_OT_export_take(bpy.types.Operator, ExportHelper):
    bl_idname = "rebocap.export_take"
    bl_label = T_static("导出片段json (Export JSON)")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return (0 <= context.scene.rebocap_active_take_index < len(context.scene.rebocap_takes)
                and not context.scene.recording)

    def invoke(self, context, event):
        scene = context.scene
        if len(scene.rebocap_takes) > 0 and 0 <= scene.rebocap_active_take_index < len(scene.rebocap_takes):
            take = scene.rebocap_takes[scene.rebocap_active_take_index]
            safe_name = "".join(c for c in take.name if c.isalnum() or c in ('_', '-'))
            self.filepath = f"{safe_name}_{take.frame_count}F.json"
        return super().invoke(context, event)

    def execute(self, context):
        scene = context.scene
        idx = scene.rebocap_active_take_index
        take = scene.rebocap_takes[idx]
        temp_path = None
        try:
            stream, _, clock_reset = read_take_stream(take, refresh=True)
            document = make_stream_document(take.name, take.take_type, take.recorded_fps, stream, clock_reset)
            destination = Path(self.filepath)
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=destination.parent,
                                             prefix='.rebocap-', suffix='.tmp', delete=False) as output:
                temp_path = Path(output.name)
                json.dump(document, output, separators=(',', ':'), allow_nan=False)
            temp_path.replace(destination)
        except ValueError as error:
            self.report({'WARNING'}, T(str(error)))
            return {'CANCELLED'}
        except OSError as error:
            self.report({'ERROR'}, f"{T('Motion capture export failed')} ({error})")
            return {'CANCELLED'}
        finally:
            if temp_path is not None:
                try:
                    temp_path.unlink(missing_ok=True)
                except OSError:
                    pass
        self.report({'INFO'}, f"Take 原生动捕流导出成功: {self.filepath}")
        return {'FINISHED'}


class REBOCAP_OT_import_take(bpy.types.Operator, ImportHelper):
    bl_idname = "rebocap.import_take"
    bl_label = T_static("导入片段json (Import JSON)")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        from uuid import uuid4

        scene = context.scene
        take_id = uuid4().hex
        try:
            with open(self.filepath, encoding='utf-8-sig') as source:
                document = json.load(source)
            if (not isinstance(document, dict) or document.get('format') != STREAM_FORMAT
                    or document.get('version') != STREAM_VERSION):
                raise ValueError('Unsupported motion capture format or version')
            if any(document.get(key, value) != value for key, value in STREAM_METADATA.items()):
                raise ValueError('Unsupported motion capture format or version')
            name = document.get('name', 'Imported Take')
            take_type = document.get('type')
            stream = document.get('stream')
            fps = document.get('recorded_fps')
            clock_reset = document.get('clock_reset', False)
            frame_count = document.get('frame_count')
            if (not isinstance(name, str) or take_type not in ('FK', 'IK', 'DUAL')
                    or type(clock_reset) is not bool or not isinstance(stream, list)
                    or type(frame_count) is not int or frame_count != len(stream)):
                raise ValueError('Invalid motion capture metadata')

            text_name = save_take_stream(take_id, stream, fps, clock_reset)
            add_native_take(scene, take_id, name, take_type, fps, stream, text_name)
        except (ValueError, TypeError, OverflowError, OSError, RuntimeError) as error:
            self.report({'ERROR'}, f"{T('Import failed')}: {T(str(error))}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"原生流 Take {name} 导入成功 ({len(stream)} 帧)")
        return {'FINISHED'}


def add_native_take(scene, take_id, name, take_type, fps, stream, text_name):
    text = bpy.data.texts[text_name]
    index = len(scene.rebocap_takes)
    try:
        take = scene.rebocap_takes.add()
        take.name = name
        take.take_type = take_type
        take.uuid = take_id
        take.stream_text_name = text_name
        take.stream_text = text
        take.frame_count = len(stream)
        take.recorded_fps = fps
        scene.rebocap_active_take_index = index
        return take
    except Exception:
        if len(scene.rebocap_takes) > index:
            scene.rebocap_takes.remove(index)
        _take_stream_cache.pop(take_id, None)
        bpy.data.texts.remove(text)
        raise


classes = [
    REBOCAP_OT_bake_take,
    REBOCAP_OT_apply_take,
    REBOCAP_OT_stop_playback,
    REBOCAP_OT_resolve_duplicate_bone_binding,
    REBOCAP_OT_delete_take,
    REBOCAP_OT_export_take,
    REBOCAP_OT_import_take,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    if rebocap_timeline_playback_handler not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(rebocap_timeline_playback_handler)


def unregister():
    if rebocap_timeline_playback_handler in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(rebocap_timeline_playback_handler)
    for scene in bpy.data.scenes:
        restore_playback_rotation_modes(scene)
        for obj in bpy.data.objects:
            _release_playback_action(scene, obj)
    for cls in classes:
        bpy.utils.unregister_class(cls)
