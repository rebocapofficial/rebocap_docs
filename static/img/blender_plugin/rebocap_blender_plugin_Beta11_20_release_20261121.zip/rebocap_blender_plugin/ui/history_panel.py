import bpy
from ..core.translation import T
from ..ops.rebocap_connection import has_pending_recording, recording_recovery_paths
from ..ops.history import (_get_effective_target_fps, get_take_frame_count,
                           playback_identity_conflict, playback_linked_library_conflict)

class REBOCAP_UL_history_takes(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        take = item
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            take_uuid = take.uuid
            is_active_play = getattr(context.scene, 'rebocap_playback_active', False) and (getattr(context.scene, 'rebocap_playback_take_uuid', '') == take_uuid)

            row.prop(take, "name", text="", emboss=False, icon='PLAY' if is_active_play else 'ACTION')
            type_icon = 'ARMATURE_DATA' if take.take_type == 'FK' else ('EMPTY_DATA' if take.take_type == 'IK' else 'LINKED')
            row.label(text=f"[{take.take_type}]", icon=type_icon)
            
            target_fps = _get_effective_target_fps(context.scene)
            recorded_fps = take.recorded_fps if hasattr(take, 'recorded_fps') and take.recorded_fps > 0 else 60.0
            converted_frames = get_take_frame_count(take, target_fps)
            
            if take.frame_count == converted_frames and abs(recorded_fps - target_fps) < 0.1:
                row.label(text=f"{take.frame_count} F")
            else:
                row.label(text=f"{take.frame_count} F ➔ {converted_frames} F")
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='ACTION')

class REBOCAP_PT_history_panel(bpy.types.Panel):
    bl_idname = "REBOCAP_PT_history_panel"
    bl_label = " "
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "REBOCAP CONNECTION"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 1
    
    def draw_header(self, context):
        scene = context.scene
        count = len(scene.rebocap_takes)
        has_new = getattr(scene, 'rebocap_has_new_take', False) and count > 0
        if count == 0:
            self.layout.label(text=T("History & Takes"), icon='FILE_FOLDER')
        else:
            badge = f"[{count}] 🔴" if has_new else f"[{count}]"
            icon_name = 'REC' if has_new else 'ACTION'
            self.layout.label(text=f"{T('History & Takes')}  {badge}", icon=icon_name)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        from ..ops.library_recovery import discover, checkpoint_time
        box = layout.box()
        box.operator('rebocap.create_library_checkpoint', text=T('Create verified recovery point'), icon='FILE_TICK')
        if scene.rebocap_health_status:
            box.label(text=T(scene.rebocap_health_status))
        if discover(scene):
            box.label(text=T('Recovery restores the last verified state'))
            box.label(text=checkpoint_time(scene))
            box.operator('rebocap.restore_library_checkpoint', text=T('Restore into a new project'), icon='RECOVER_LAST')

        if has_pending_recording():
            layout.operator("rebocap.stop_record", text=T("Retry saving recording"), icon='FILE_TICK')

        recovery_paths = recording_recovery_paths()
        if recovery_paths:
            box = layout.box()
            box.label(text=T('Recording saved to a recovery file'), icon='FILE_TICK')
            for recovery_path in recovery_paths:
                row = box.row(align=True)
                row.label(text=recovery_path)
                copy = row.operator('wm.context_set_string', text='', icon='COPYDOWN')
                copy.data_path = 'window_manager.clipboard'
                copy.value = recovery_path

        library_backup = scene.rebocap_library_recovery_path
        if library_backup or scene.rebocap_library_recovery_failed:
            box = layout.box()
            if library_backup:
                box.label(text=T('Original project backup saved'), icon='FILE_TICK')
                row = box.row(align=True)
                row.label(text=library_backup)
                copy = row.operator('wm.context_set_string', text='', icon='COPYDOWN')
                copy.data_path = 'window_manager.clipboard'
                copy.value = library_backup
                if scene.rebocap_library_recovery_relocate:
                    box.label(text=T('Return backup to original folder before opening'))
            else:
                box.label(text=T('Project backup failed; do not overwrite original'), icon='ERROR')

        if getattr(scene, 'rebocap_playback_active', False):
            box_pb = layout.box()
            row_pb = box_pb.row(align=True)
            row_pb.label(text=T("原生流时间轴驱动中 (Active)"), icon='PLAY')
            row_pb.operator("rebocap.stop_playback", icon='CANCEL', text=T("停止驱动"))
            if scene.rebocap_playback_mode in ('FK', 'DUAL') and playback_identity_conflict(scene, synchronize=False):
                box_pb.label(text=T('Playback bone binding cannot be confirmed'), icon='ERROR')
                if playback_linked_library_conflict(scene):
                    box_pb.label(text=T('Linked library may have remapped saved poses'))
                    box_pb.label(text=T('Restore the original library and reopen the project'))

        obj = context.object
        selected = context.active_pose_bone
        if obj and obj.type == 'ARMATURE' and selected:
            identity = getattr(selected.bone, 'rebocap_anchor_id', '')
            if identity and sum(getattr(bone, 'rebocap_anchor_id', '') == identity for bone in obj.data.bones) > 1:
                layout.operator('rebocap.resolve_duplicate_bone_binding', text=T('Keep selected bone binding'))

        row = layout.row(align=True)
        row.operator("rebocap.apply_take", icon='PLAY', text=T("Apply Take"))
        layout.prop(scene, "rebocap_playback_targets", text=T("Playback Targets"))
        layout.operator("rebocap.bake_take", icon='ACTION', text=T("Bake to Action"))
        
        # 表头 (Table Header)
        target_fps = _get_effective_target_fps(scene)
        tgt_str = f"{target_fps:g}fps" if abs(target_fps - round(target_fps)) < 1e-3 else f"{target_fps:.2f}fps"
        
        row_hdr = layout.row(align=True)
        row_hdr.label(text=T("片段名称"))
        row_hdr.label(text=T("类型"))
        row_hdr.label(text=f"{T('总帧数')} ➔ {tgt_str}")

        row = layout.row()
        row.template_list(
            "REBOCAP_UL_history_takes",
            "",
            scene,
            "rebocap_takes",
            scene,
            "rebocap_active_take_index"
        )
        
        col = layout.column(align=True)
        col.operator("rebocap.delete_take", icon='X', text=T("Delete Take"))
        
        layout.separator()
        
        box = layout.box()
        col = box.column(align=True)
        col.label(text=T("Apply FPS Mode"), icon='TIME')
        col.prop(scene, "rebocap_fps_mode", text="")
        if getattr(scene, 'rebocap_fps_mode', 'SCENE') == 'CUSTOM':
            col.prop(scene, "rebocap_target_fps", text=T("自定义帧率 (Target FPS)"))
            
        col.separator()
        col_note = col.column(align=True)
        col_note.enabled = False
        col_note.label(text=T("通过该选项转换帧率挂载到blender时间轴上。"), icon='INFO')
            
        layout.separator()
        
        row = layout.row(align=True)
        row.operator("rebocap.export_take", icon='EXPORT', text=T("导出片段json"))
        row.operator("rebocap.import_take", icon='IMPORT', text=T("导入片段json"))

classes = [
    REBOCAP_UL_history_takes,
    REBOCAP_PT_history_panel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
