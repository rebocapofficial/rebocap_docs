"""Coordinate pose writers across scenes which share Blender objects.

Scene properties and preview sessions remain the saved source of truth.  The
runtime map only chooses the first owner if active contexts later overlap.
"""
import bpy

_owners = {}
_live_sources = {}
_OWNER_PROPERTY = 'rebocap_control_owner_scene'


def register_control_runtime():
    if not hasattr(bpy.types.Object, _OWNER_PROPERTY):
        setattr(bpy.types.Object, _OWNER_PROPERTY,
                bpy.props.PointerProperty(type=bpy.types.Scene, options={'HIDDEN'}))
    if not hasattr(bpy.types.Bone, 'rebocap_anchor_id'):
        bpy.types.Bone.rebocap_anchor_id = bpy.props.StringProperty(options={'HIDDEN'})


def unregister_control_runtime():
    clear_runtime_owners()
    if hasattr(bpy.types.Object, _OWNER_PROPERTY):
        delattr(bpy.types.Object, _OWNER_PROPERTY)
    if hasattr(bpy.types.Bone, 'rebocap_anchor_id'):
        del bpy.types.Bone.rebocap_anchor_id


def clear_runtime_owners(*_):
    _owners.clear()
    _live_sources.clear()


def synchronize_owners():
    _reconcile()


def remember_live_source(scene):
    _live_sources[scene.as_pointer()] = (scene, scene.objects.get(scene.rebocap_source_armature),
                                         scene.rebocap_source_armature)


def ensure_live_source(scene):
    if scene.as_pointer() not in _live_sources:
        remember_live_source(scene)


def validate_live_source_change(scene):
    """Reject a conflicting retarget while keeping the live source intact."""
    entry = _live_sources.get(scene.as_pointer())
    if not entry:
        remember_live_source(scene)
        return True
    try:
        owner, previous, old_name = entry
        if owner != scene:
            remember_live_source(scene)
            return True
        current_name = scene.rebocap_source_armature
        if (previous and current_name == old_name and previous.name != old_name
                and scene.objects.get(previous.name) == previous):
            _live_sources[scene.as_pointer()] = (scene, previous, previous.name)
            scene.rebocap_source_armature = previous.name
            return False
        requested = scene.objects.get(current_name)
        conflict = find_conflict(scene, [requested]) if requested else None
        if conflict:
            print('[Rebocap] ' + conflict_message(conflict))
            restored = previous.name if previous and scene.objects.get(previous.name) == previous else ''
            if current_name != restored:
                scene.rebocap_source_armature = restored
            return False
        remember_live_source(scene)
        return True
    except ReferenceError:
        remember_live_source(scene)
        return True


def sync_live_source_rename(scene):
    if not getattr(scene, 'open', False):
        return
    entry = _live_sources.get(scene.as_pointer())
    if not entry:
        return
    try:
        owner, previous, old_name = entry
        if (owner == scene and previous and scene.rebocap_source_armature == old_name
                and previous.name != old_name):
            validate_live_source_change(scene)
    except ReferenceError:
        remember_live_source(scene)


def on_live_pause_changed(scene, _context):
    if (scene.rebocap_pause_control or not getattr(scene, 'open', False)
            or getattr(scene, 'rebocap_playback_active', False)):
        return
    from .a2t_types import preview_active
    if preview_active(scene):
        return
    conflict = find_conflict(scene, drive_objects(scene))
    if conflict:
        scene.rebocap_pause_control = True
        print('[Rebocap] ' + conflict_message(conflict))


def drive_objects(scene, mode='DUAL'):
    from ..ops.rebocap_connection import TRACKING_OBJECT_NAMES
    objects = []
    if mode in ('FK', 'DUAL'):
        source = scene.objects.get(scene.rebocap_source_armature)
        if source and source.type == 'ARMATURE':
            objects.append(source)
    if mode in ('IK', 'DUAL'):
        objects.extend(obj for obj in scene.objects if
                       (obj.type == 'EMPTY' and obj.name in TRACKING_OBJECT_NAMES) or
                       (obj.type == 'ARMATURE' and obj.get('rebocap_demo_character')))
    return list(dict.fromkeys(objects))


def _active_objects(scene):
    from .a2t_types import _preview_sessions
    objects = []
    session = _preview_sessions.get(scene.as_pointer())
    if session and session.armature:
        objects.append(session.armature)
    if getattr(scene, 'rebocap_playback_active', False):
        mode = scene.rebocap_playback_mode
        if not mode:
            take = next((item for item in scene.rebocap_takes
                         if item.uuid == scene.rebocap_playback_take_uuid), None)
            if take:
                mode = take.take_type if scene.rebocap_playback_targets == 'RECORDED' else scene.rebocap_playback_targets
        objects.extend(drive_objects(scene, mode))
    # A preview or playback temporarily suspends live control, but retains its
    # reservation so it can safely resume when the temporary owner exits.
    live_reserved = (getattr(scene, 'open', False) and
                     (not scene.rebocap_pause_control or
                      (session is not None and not session.was_paused) or
                      getattr(scene, 'rebocap_playback_resume_live', False)))
    if live_reserved:
        objects.extend(drive_objects(scene))
    return list(dict.fromkeys(objects))


def _reconcile():
    current = []
    for scene in bpy.data.scenes:
        try:
            current.append((scene, _active_objects(scene)))
        except (AttributeError, ReferenceError):
            continue
    for key, (obj, owner) in list(_owners.items()):
        try:
            if not any(scene == owner and obj in objects for scene, objects in current):
                del _owners[key]
        except ReferenceError:
            del _owners[key]
    candidates = {}
    for scene, objects in current:
        for obj in objects:
            try:
                candidates.setdefault(obj.as_pointer(), (obj, []))[1].append(scene)
            except ReferenceError:
                continue
    copied_playbacks = set()
    for key, (obj, scenes) in candidates.items():
        saved = getattr(obj, _OWNER_PROPERTY, None)
        previous = _owners.get(key)
        if saved in scenes and saved.objects.get(obj.name) == obj:
            owner = saved
        elif previous and previous[1] in scenes:
            owner = previous[1]
        elif len(scenes) == 1:
            # Full Copy before Blender 4.4 may retain a reference to the old
            # scene. Only adopt an independent object with one claimant.
            owner = scenes[0]
        else:
            # Ambiguous legacy state: deny all writers until it is resolved.
            owner = None
        _owners[key] = (obj, owner)
        if owner is not None and getattr(owner, 'rebocap_playback_active', False):
            owner_take = owner.rebocap_playback_take_uuid
            for other in scenes:
                if (other != owner and owner_take and other.rebocap_playback_active
                        and other.rebocap_playback_take_uuid == owner_take):
                    copied_playbacks.add(other)
        if owner is not None and saved != owner:
            try:
                setattr(obj, _OWNER_PROPERTY, owner)
            except (AttributeError, RuntimeError, TypeError):
                pass
    if copied_playbacks:
        for scene in copied_playbacks:
            scene.rebocap_playback_active = False
            scene.rebocap_playback_take_uuid = ''
            scene.rebocap_playback_resume_live = False
        _reconcile()


def find_conflict(scene, objects):
    """Return the already owning scene and object, without changing it."""
    from .a2t_types import _prune_orphaned_previews
    _prune_orphaned_previews()
    _reconcile()
    for obj in objects:
        if obj is None:
            continue
        try:
            owner = _owners.get(obj.as_pointer())
            if owner and owner[0] == obj and owner[1] != scene:
                return owner[1], obj
        except ReferenceError:
            continue
    return None


def conflict_message(conflict):
    from .translation import T
    owner, obj = conflict
    return f"{T('Object is controlled by another scene')}: {obj.name} ({owner.name if owner else '?'})"
