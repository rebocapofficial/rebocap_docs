# -*- coding: utf-8 -*-
import bpy
import math
import json
import uuid
from mathutils import Euler, Quaternion, Vector, Matrix
from . import preview_layer

_is_updating_flag = False
_preview_sessions = {}
_preview_history = {}
_preview_frame_suspended = set()
_playback_refreshing = set()
_preview_target_reverting = set()
_preview_mapping_reverting = set()
_preview_warning_timers = set()
_reconciling_previews = False
_SESSION_KEY = '_rebocap_preview_session'
_BONE_TOKENS = 'rebocap_preview_tokens'


def register_preview_runtime():
    preview_layer.register()
    # Registered RNA properties are not included in Bone.keys(), so exporters
    # that export custom ID properties cannot leak our temporary markers.
    for rna_type in (bpy.types.Bone, bpy.types.Object):
        if not hasattr(rna_type, _BONE_TOKENS):
            setattr(rna_type, _BONE_TOKENS,
                    bpy.props.StringProperty(options={'HIDDEN', 'SKIP_SAVE'}))
    if reconcile_copied_previews not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(reconcile_copied_previews)


def unregister_preview_runtime():
    cancel_preview_warning_timers()
    if reconcile_copied_previews in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(reconcile_copied_previews)
    for rna_type in (bpy.types.Bone, bpy.types.Object):
        if hasattr(rna_type, _BONE_TOKENS):
            delattr(rna_type, _BONE_TOKENS)
    preview_layer.cleanup_all()
    preview_layer.unregister()


def cancel_preview_warning_timers():
    for callback in list(_preview_warning_timers):
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    _preview_warning_timers.clear()


def _notify_save_fallback(scene, message='Save used a fallback pose; check playback and save again'):
    if bpy.app.background:
        return
    def notify():
        _preview_warning_timers.discard(notify)
        try:
            if bpy.data.scenes.get(scene.name) != scene:
                return None
            from ..ops.utils import show_message_box
            from .translation import T
            show_message_box(T(message),
                             title='ReboCap', icon='ERROR')
        except ReferenceError:
            pass
        return None
    _preview_warning_timers.add(notify)
    bpy.app.timers.register(notify, first_interval=0.1)


def _get_bone_tokens(bone):
    try:
        value = getattr(bone, _BONE_TOKENS, '')
        result = json.loads(value) if value else {}
        return result if isinstance(result, dict) else {}
    except (ValueError, TypeError, ReferenceError):
        return {}


def _set_bone_tokens(bone, tokens):
    setattr(bone, _BONE_TOKENS, json.dumps(tokens, separators=(',', ':')) if tokens else '')


def _pose_bone(arm, name, refs=None):
    ref = refs.get(name) if refs else None
    if ref is not None:
        try:
            # Never dereference a cached RNA wrapper: edit/undo can invalidate
            # it without consistently raising ReferenceError on access.
            matches = [bone for bone in arm.pose.bones if bone == ref]
            if len(matches) == 1:
                return matches[0]
        except ReferenceError:
            pass
    return arm.pose.bones.get(name) if refs is None else None


def _restore_preview_pose(arm, pose, refs=None):
    try:
        if arm is None or arm.type != 'ARMATURE':
            return
        for name, (basis, mode) in pose.items():
            bone = _pose_bone(arm, name, refs)
            if bone:
                bone.rotation_mode = mode
                bone.matrix_basis = basis
    except ReferenceError:
        # The target may have been deleted while the preview was open.
        return


def _preview_linked(target):
    from ..ops.history import linked_library
    return bool(target and target.data and linked_library(target.data))


def _preview_data_key(target):
    from ..ops.history import linked_data_key
    return linked_data_key(target.data)


def _preview_library_fingerprint(target):
    if not target or target.type != 'ARMATURE' or not target.data or not _preview_linked(target):
        return ''
    from ..ops.history import _linked_library_hash
    return _linked_library_hash(target.data)


def _preview_library_structure(target):
    """Fingerprint the in-memory rest skeleton used to create the layer."""
    if not target or not target.data or not _preview_linked(target):
        return ''
    from ..ops.history import linked_structure_signature
    return linked_structure_signature(target.data)


def _preview_library_valid(session):
    try:
        target = session.armature
        if not target:
            return True
        if target.data and _preview_linked(target):
            if session.library_data_pointer != _preview_data_key(target):
                return False
        elif session.library_data_pointer:
            return False
        current = _preview_library_fingerprint(target)
        return current is not None and current == session.library_hash
    except (AttributeError, ReferenceError, RuntimeError):
        return False


class PreviewSession:
    def __init__(self, paused, playing, scene=None):
        self.armature = None
        self.helper = None
        self.library_hash = ''
        self.library_structure = ''
        self.library_data_pointer = 0
        self.scene = scene
        self.armature_name = ''
        self.scene_name = scene.name if scene else ''
        self.start_frame = (scene.frame_current, scene.frame_subframe) if scene else None
        self.pose = {}
        self.pose_refs = {}
        self.session_id = uuid.uuid4().hex
        self.bone_tags = {}
        self.object_tags = {}
        self.saved_tags = []
        # Keep detached bones' baselines for undo/redo of mapping or target.
        self.saved_poses = {}
        self.was_paused = paused
        self.was_playing = playing
        self.saving = False
        self.saved_preview_pose = {}
        self.saved_pause = paused
        self.saved_playback = None
        self.save_warning = ''
        self.edit_exit_warning = ''
        self.native_mapping = ([getattr(scene.rebocap_bone_map, f'node_{i}') for i in range(22)]
                               if scene and getattr(scene, 'rebocap_playback_active', False) else [])
        self.applied_mapping = ([getattr(scene.rebocap_bone_map, f'node_{i}') for i in range(24)]
                                if scene else [])

    def select_armature(self, armature):
        if self.armature == armature:
            return
        fingerprint = _preview_library_fingerprint(armature)
        if fingerprint is None:
            raise ValueError('A2T linked skeleton changed')
        structure = _preview_library_structure(armature)
        data_pointer = (_preview_data_key(armature) if armature and armature.data and
                        _preview_linked(armature) else 0)
        if self.armature:
            restore_preview_target_at_current_frame(self.scene, self, self.armature)
        self.armature = armature
        self.library_hash = fingerprint
        self.library_structure = structure
        self.library_data_pointer = data_pointer
        self.armature_name = armature.name if armature else ''
        self.pose = {}
        self.pose_refs = {}
        self.helper = None
        preview_layer.bind(self.scene, armature, None)

    def remember_bone(self, bone):
        if bone.name in self.pose:
            # A different bone may have acquired this name since preview began.
            return _pose_bone(self.armature, bone.name, self.pose_refs) == bone
        if bone.name not in self.pose:
            try:
                object_tokens = _get_bone_tokens(self.armature)
                object_token = object_tokens.get(self.session_id) or uuid.uuid4().hex
                object_tokens[self.session_id] = object_token
                _set_bone_tokens(self.armature, object_tokens)
                self.object_tags[self.armature_name] = object_token
                tokens = _get_bone_tokens(bone.bone)
                token = tokens.get(self.session_id) or uuid.uuid4().hex
                tokens[self.session_id] = token
                _set_bone_tokens(bone.bone, tokens)
                if _get_bone_tokens(bone.bone).get(self.session_id) != token:
                    return False
                self.bone_tags.setdefault(self.armature_name, {})[bone.name] = token
                self.pose[bone.name] = (bone.matrix_basis.copy(), bone.rotation_mode)
                self.pose_refs[bone.name] = bone
                self.saved_poses.setdefault(self.armature_name, {})[bone.name] = self.pose[bone.name]
            except (TypeError, RuntimeError, AttributeError):
                return False
        return True


def _remove_preview_tags(session):
    removed = []
    # A helper can be deleted during failed save restoration. Its copied Bone
    # wrappers are not durable and must never enter the saved tag snapshot.
    helper_data = {obj.data for obj in bpy.data.objects if preview_layer.is_helper(obj)}
    for obj in bpy.data.objects:
        if preview_layer.is_helper(obj):
            continue
        tokens = _get_bone_tokens(obj)
        if session.session_id in tokens:
            removed.append((obj, tokens.pop(session.session_id)))
            _set_bone_tokens(obj, tokens)
    for armature in bpy.data.armatures:
        if armature in helper_data:
            continue
        for bone in armature.bones:
            tokens = _get_bone_tokens(bone)
            if session.session_id in tokens:
                removed.append((bone, tokens.pop(session.session_id)))
                _set_bone_tokens(bone, tokens)
    return removed


def _restore_preview_tags(session):
    for bone, value in session.saved_tags:
        try:
            tokens = _get_bone_tokens(bone)
            tokens[session.session_id] = value
            _set_bone_tokens(bone, tokens)
        except (ReferenceError, TypeError, RuntimeError):
            pass
    session.saved_tags = []


def _find_tagged_bone(armature, session, name):
    token = session.bone_tags.get(session.armature_name, {}).get(name)
    if token:
        matches = [bone for bone in armature.pose.bones
                   if _get_bone_tokens(bone.bone).get(session.session_id) == token]
        if len(matches) == 1:
            return matches[0]
    return None


def preview_frame_suspended(scene):
    return scene.as_pointer() in _preview_frame_suspended


def restore_preview_target_at_current_frame(scene, session, armature, pose=None):
    """Restore a preview target using this scene's current evaluation frame."""
    if not scene or not armature:
        return
    if not session.saving:
        if pose is None:
            preview_layer.clear(scene, session.helper)
            session.helper = None
        else:
            names = [bone.name for name in pose
                     for bone in [_pose_bone(armature, name, session.pose_refs)] if bone]
            preview_layer.remove_bones(session.helper, armature, names)
    key = scene.as_pointer()
    already_suspended = key in _preview_frame_suspended
    _preview_frame_suspended.add(key)
    try:
        if (session.start_frame != (scene.frame_current, scene.frame_subframe)
                or getattr(scene, 'rebocap_playback_active', False)):
            scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
        if (session.native_mapping and scene.rebocap_playback_mode in ('FK', 'DUAL')
                and scene.rebocap_playback_source_object == armature):
            mapping = list(session.native_mapping)
            for index, name in enumerate(mapping):
                if name and name in session.bone_tags.get(session.armature_name, {}):
                    bone = _find_tagged_bone(armature, session, name)
                    if bone is None:
                        raise ValueError('Playback bone binding cannot be confirmed')
                    mapping[index] = bone.name
            from ..ops.history import evaluate_saved_fk_target
            evaluate_saved_fk_target(scene, armature, mapping)
    finally:
        if not already_suspended:
            _preview_frame_suspended.discard(key)


def _encode_pose(pose):
    return {name: ([float(v) for row in matrix for v in row], mode)
            for name, (matrix, mode) in pose.items()}


def _decode_pose(pose):
    return {name: (Matrix([values[i:i + 4] for i in range(0, 16, 4)]), mode)
            for name, (values, mode) in pose.items()}


def _save_preview_state(scene, session):
    # This state travels with Blender's undo steps, unlike Python references.
    scene[_SESSION_KEY] = json.dumps({
        'id': session.session_id, 'armature': session.armature_name,
        'paused': session.was_paused, 'playing': session.was_playing,
        'frame': session.start_frame, 'pose': _encode_pose(session.pose),
        'native_mapping': session.native_mapping,
        'library_hash': session.library_hash,
        'library_structure': session.library_structure,
        'applied_mapping': session.applied_mapping,
        'saved': {name: _encode_pose(pose) for name, pose in session.saved_poses.items()},
        'tags': session.bone_tags, 'objects': session.object_tags,
    }, separators=(',', ':'))


def _session_from_state(scene):
    raw = scene.get(_SESSION_KEY)
    if not raw:
        return None
    try:
        data = json.loads(raw)
        session = PreviewSession(data['paused'], data['playing'], scene)
        session.session_id = data['id']
        session.start_frame = tuple(data['frame']) if data['frame'] else None
        session.native_mapping = data.get('native_mapping', session.native_mapping)
        session.library_hash = data.get('library_hash', None)
        session.library_structure = data.get('library_structure', None)
        session.applied_mapping = data.get('applied_mapping', session.applied_mapping)
        session.armature_name = data['armature']
        session.pose = _decode_pose(data['pose'])
        session.saved_poses = {name: _decode_pose(pose) for name, pose in data['saved'].items()}
        session.bone_tags = data.get('tags', {})
        session.object_tags = data.get('objects', {})
        # Unlike duplicated names/tokens, Blender's runtime pointer tracks the
        # actual Object through rename, undo and independently copied scenes.
        target = preview_layer.target_for(scene)
        session.helper = preview_layer.helper_for(scene)
        if (target and target.type == 'ARMATURE' and
                scene.objects.get(target.name) == target):
            session.armature = target
        elif session.armature_name:
            return None
        if session.armature and session.armature.type == 'ARMATURE':
            if session.armature.data and _preview_linked(session.armature):
                if _preview_library_structure(session.armature) == session.library_structure:
                    session.library_data_pointer = _preview_data_key(session.armature)
            session.pose_refs = {name: _find_tagged_bone(session.armature, session, name)
                                 for name in session.pose}
            new_name = session.armature.name
            if new_name != session.armature_name:
                old_name = session.armature_name
                if old_name in session.saved_poses:
                    session.saved_poses[new_name] = session.saved_poses.pop(old_name)
                if old_name in session.bone_tags:
                    session.bone_tags[new_name] = session.bone_tags.pop(old_name)
                if old_name in session.object_tags:
                    session.object_tags[new_name] = session.object_tags.pop(old_name)
                session.armature_name = new_name
        return session
    except (KeyError, TypeError, ValueError):
        return None


def _rekey_copied_session(session, keep_old=False):
    old_id = session.session_id
    session.session_id = uuid.uuid4().hex
    if session.armature and session.armature.type == 'ARMATURE':
        tokens = _get_bone_tokens(session.armature)
        if old_id in tokens:
            tokens[session.session_id] = tokens.pop(old_id)
            _set_bone_tokens(session.armature, tokens)
        for bone in session.armature.data.bones:
            tokens = _get_bone_tokens(bone)
            if old_id in tokens:
                tokens[session.session_id] = tokens[old_id]
                if not keep_old:
                    del tokens[old_id]
                _set_bone_tokens(bone, tokens)


def _install_preview_session(scene, session):
    owner = preview_layer.owner_of(session.helper)
    if (owner and owner != scene and preview_layer.helper_for(owner) == session.helper
            and getattr(owner, 'rebocap_a2t', None) and owner.rebocap_a2t.preview_mode):
        scene.rebocap_a2t.preview_mode = False
        scene.rebocap_pause_control = session.was_paused
        preview_layer.bind(scene, None, None)
        if _SESSION_KEY in scene:
            del scene[_SESSION_KEY]
        _report_preview_conflict()
        return False
    # A linked copy shares the actual Object and cannot own it independently.
    for other in _preview_sessions.values():
        if session.armature is not None and other.armature == session.armature:
            if other.session_id != session.session_id:
                _remove_preview_tags(session)
            scene.rebocap_playback_active = False
            scene.rebocap_playback_take_uuid = ''
            scene.rebocap_a2t.preview_mode = False
            scene.rebocap_pause_control = session.was_paused
            if _SESSION_KEY in scene:
                del scene[_SESSION_KEY]
            _report_preview_conflict()
            return False
        if other.session_id != session.session_id:
            continue
        # A full copy has an independent rig but duplicated undo metadata.
        shared_data = (other.armature is not None and session.armature is not None and
                       other.armature.data == session.armature.data)
        _rekey_copied_session(session, keep_old=shared_data)
        break
    if not _preview_library_valid(session):
        _end_changed_library_preview(scene, session)
        return False
    from .control import find_conflict
    if session.armature and find_conflict(scene, [session.armature]):
        scene.rebocap_a2t.preview_mode = False
        scene.rebocap_pause_control = session.was_paused
        if _SESSION_KEY in scene:
            del scene[_SESSION_KEY]
        _report_preview_conflict()
        return False
    _preview_sessions[scene.as_pointer()] = session
    preview_layer.bind(scene, session.armature, session.helper)
    scene.rebocap_pause_control = True
    if session.armature and scene.rebocap_source_armature != session.armature_name:
        scene.rebocap_source_armature = session.armature_name
    _save_preview_state(scene, session)
    return True


def _prune_orphaned_previews():
    """Restore preview poses before forgetting sessions of deleted scenes."""
    if not _preview_sessions:
        return
    for key in list(_preview_sessions):
        session = _preview_sessions[key]
        try:
            owner = session.scene
            alive = (owner is not None and owner.as_pointer() == key and
                     bpy.data.scenes.get(owner.name) == owner)
        except ReferenceError:
            alive = False
        if alive:
            continue
        _preview_sessions.pop(key)
        preview_layer.discard(session.helper)
        _remove_preview_tags(session)
        try:
            armature = session.armature
            survivors = [scene for scene in bpy.data.scenes
                         if armature and scene.objects.get(armature.name) == armature]
            if len(survivors) == 1:
                scene = survivors[0]
                scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
            elif len(survivors) > 1:
                print('[Rebocap] Cannot choose a current frame for an orphaned shared preview')
        except ReferenceError:
            pass


def rebind_playback_target(scene):
    """Follow a renamed or full-copied target without overriding a new selection."""
    if not getattr(scene, 'rebocap_playback_active', False):
        return False
    source = scene.rebocap_playback_source_object
    if not source or source.type != 'ARMATURE' or scene.objects.get(source.name) != source:
        return False
    current_name = scene.rebocap_source_armature
    old_name = scene.rebocap_playback_source_name
    if scene.objects.get(current_name) == source:
        if old_name != source.name:
            scene.rebocap_playback_source_name = source.name
        return False
    if not old_name or current_name != old_name:
        return False
    key = scene.as_pointer()
    already_refreshing = key in _playback_refreshing
    _playback_refreshing.add(key)
    try:
        scene.rebocap_playback_source_name = source.name
        scene.rebocap_source_armature = source.name
    finally:
        if not already_refreshing:
            _playback_refreshing.discard(key)
    return True


def _preview_target_missing(scene, session):
    if not session.armature_name:
        return False
    try:
        target = preview_layer.target_for(scene)
        return not target or scene.objects.get(target.name) != target
    except ReferenceError:
        return True


def _end_missing_preview(scene, session):
    _preview_sessions.pop(scene.as_pointer(), None)
    preview_layer.clear(scene, session.helper)
    _remove_preview_tags(session)
    if _SESSION_KEY in scene:
        del scene[_SESSION_KEY]
    scene.rebocap_a2t.preview_mode = False
    scene.rebocap_pause_control = session.was_paused
    print('[Rebocap] Preview ended because its target was removed')


def _end_changed_library_preview(scene, session):
    """Remove the temporary layer without writing a pose to an unknown bone."""
    _preview_sessions.pop(scene.as_pointer(), None)
    preview_layer.clear(scene, session.helper)
    _remove_preview_tags(session)
    if _SESSION_KEY in scene:
        del scene[_SESSION_KEY]
    scene.rebocap_a2t.preview_mode = False
    scene.rebocap_pause_control = session.was_paused
    scene.rebocap_a2t_library_warning = True
    from ..ops.history import preserve_project_for_linked_library_conflict
    preserve_project_for_linked_library_conflict(force=True)
    screen = getattr(bpy.context, 'screen', None)
    if session.was_playing and screen and bpy.context.scene == scene and not screen.is_animation_playing:
        from ..ops.rebocap_connection import force_start_animation
        force_start_animation(bpy.context)
    print('[Rebocap] A2T preview ended because the linked skeleton changed')


@bpy.app.handlers.persistent
def reconcile_copied_previews(_scene=None, _depsgraph=None):
    global _reconciling_previews
    if _reconciling_previews or preview_layer.saving():
        return
    _reconciling_previews = True
    try:
        _prune_orphaned_previews()
        for scene in bpy.data.scenes:
            session = _preview_sessions.get(scene.as_pointer())
            if session and _preview_target_missing(scene, session):
                _end_missing_preview(scene, session)
                continue
            if session and not _preview_library_valid(session):
                _end_changed_library_preview(scene, session)
                continue
            try:
                editing = bool(session and session.armature and session.armature.data.is_editmode)
            except ReferenceError:
                editing = False
            if editing:
                # Stop before the first edit can copy or delete bone identity.
                scene.rebocap_a2t.preview_mode = False
                _report_preview_edit(session.edit_exit_warning)
            from .control import sync_live_source_rename
            sync_live_source_rename(scene)
            if (getattr(scene, 'rebocap_a2t', None) and scene.rebocap_a2t.preview_mode
                    and scene.as_pointer() not in _preview_sessions):
                session = _session_from_state(scene)
                if session:
                    _install_preview_session(scene, session)
                elif scene.get(_SESSION_KEY):
                    try:
                        state = json.loads(scene[_SESSION_KEY])
                        paused = state.get('paused', True)
                    except (ValueError, TypeError):
                        paused = True
                    del scene[_SESSION_KEY]
                    scene.rebocap_a2t.preview_mode = False
                    scene.rebocap_pause_control = paused
                    preview_layer.bind(scene, None, None)
                    print('[Rebocap] Preview target identity could not be restored')
            elif not getattr(scene, 'rebocap_a2t', None) or not scene.rebocap_a2t.preview_mode:
                if rebind_playback_target(scene):
                    _refresh_playback(scene)
        preview_layer.reconcile(_preview_sessions.values())
    finally:
        _reconciling_previews = False


def _refresh_playback(scene):
    key = scene.as_pointer()
    if (key in _playback_refreshing or preview_active(scene)
            or not getattr(scene, 'rebocap_playback_active', False)):
        return
    _playback_refreshing.add(key)
    try:
        from ..ops.history import rebocap_timeline_playback_handler
        rebocap_timeline_playback_handler(scene)
    finally:
        _playback_refreshing.discard(key)


def _sync_preview_target_name(scene, session):
    """Keep the target string in sync with the live object when it is renamed."""
    try:
        target = session.armature
        old_name = session.armature_name
        if (not target or not old_name or scene.rebocap_source_armature != old_name
                or scene.objects.get(target.name) != target or target.name == old_name):
            return
        new_name = target.name
        for mapping in (session.saved_poses, session.bone_tags, session.object_tags):
            if old_name in mapping:
                mapping[new_name] = mapping.pop(old_name)
        if (scene.rebocap_playback_source_object == target and
                scene.rebocap_playback_source_name == old_name):
            scene.rebocap_playback_source_name = new_name
        session.armature_name = new_name
        scene.rebocap_source_armature = new_name
    except ReferenceError:
        pass


def _preview_conflict(scene, armature):
    _prune_orphaned_previews()
    if not armature:
        return False
    for key, session in _preview_sessions.items():
        if key == scene.as_pointer():
            continue
        try:
            if session.armature == armature:
                return True
        except ReferenceError:
            continue
    from .control import find_conflict
    return bool(find_conflict(scene, [armature]))


def _report_preview_conflict():
    message = 'Object is controlled by another scene'
    print('[Rebocap] ' + message)
    if bpy.app.background:
        return
    try:
        from .translation import T
        bpy.context.window_manager.popup_menu(
            lambda self, context: self.layout.label(text=T(message)),
            title='ReboCap', icon='ERROR')
    except Exception:
        pass


def _report_preview_edit(error=''):
    from .translation import T
    message = T('A2T preview ended using a fallback pose; check playback') if error else T('A2T preview ended before editing the armature')
    print('[Rebocap] ' + message)
    if not bpy.app.background:
        try:
            bpy.context.window_manager.popup_menu(
                lambda self, context: self.layout.label(text=message),
                title='ReboCap', icon='INFO')
        except Exception:
            pass


def _report_preview_error(message):
    from .translation import T
    message = T(message)
    print('[Rebocap] ' + message)
    if not bpy.app.background:
        try:
            bpy.context.window_manager.popup_menu(
                lambda self, context: self.layout.label(text=message),
                title='ReboCap', icon='ERROR')
        except Exception:
            pass


def _report_preview_unsupported():
    _report_preview_error('A2T preview requires an editable object')


def set_live_pause(scene, paused):
    session = _preview_sessions.get(scene.as_pointer())
    if session:
        session.was_paused = paused
        scene.rebocap_pause_control = True
        _save_preview_state(scene, session)
    else:
        scene.rebocap_pause_control = paused


def _snapshot_target_switch(scene, session, target):
    state = (session.armature, session.armature_name, dict(session.pose), dict(session.pose_refs),
             {k: dict(v) for k, v in session.saved_poses.items()},
             {k: dict(v) for k, v in session.bone_tags.items()}, dict(session.object_tags),
             list(session.applied_mapping), session.library_hash, session.library_structure,
             session.library_data_pointer)
    transforms = []
    for obj in scene.objects:
        # Helpers can be removed while switching. Never retain their RNA
        # wrappers as part of a rollback snapshot of user objects.
        if preview_layer.is_helper(obj):
            continue
        transforms.append((obj, obj.matrix_basis.copy(), obj.rotation_mode))
        if obj.type == 'ARMATURE' and obj.pose:
            transforms.extend((bone, bone.matrix_basis.copy(), bone.rotation_mode) for bone in obj.pose.bones)
    tokens = []
    data_seen = set()
    for obj in (session.armature, target):
        if not obj or obj.type != 'ARMATURE':
            continue
        tokens.append((obj, _get_bone_tokens(obj)))
        if obj.data.as_pointer() not in data_seen:
            data_seen.add(obj.data.as_pointer())
            tokens.extend((bone, _get_bone_tokens(bone)) for bone in obj.data.bones)
    return state, transforms, tokens, preview_layer.capture(scene)


def _rollback_target_switch(scene, session, snapshot):
    state, transforms, tokens, layer = snapshot
    preview_layer.clear(scene, session.helper)
    (session.armature, session.armature_name, session.pose, session.pose_refs,
     session.saved_poses, session.bone_tags, session.object_tags, session.applied_mapping,
     session.library_hash, session.library_structure, session.library_data_pointer) = state
    session.helper = preview_layer.restore_capture(scene, layer)
    for item, token in tokens:
        try:
            _set_bone_tokens(item, token)
        except (ReferenceError, RuntimeError, TypeError):
            pass
    for item, matrix, mode in transforms:
        try:
            item.rotation_mode = mode
            item.matrix_basis = matrix
        except (ReferenceError, RuntimeError, TypeError):
            pass
    key = scene.as_pointer()
    _preview_target_reverting.add(key)
    try:
        scene.rebocap_source_armature = session.armature_name
    finally:
        _preview_target_reverting.discard(key)
    _save_preview_state(scene, session)


def on_preview_target_changed(scene, context):
    if scene.as_pointer() in _preview_target_reverting:
        return
    if getattr(scene, 'open', False):
        from .control import validate_live_source_change
        if not validate_live_source_change(scene):
            return
    if getattr(scene, 'recording', False):
        from ..ops.rebocap_connection import update_recording_binding
        update_recording_binding(scene)
    if preview_active(scene):
        session = _preview_sessions[scene.as_pointer()]
        _sync_preview_target_name(scene, session)
        target = scene.objects.get(scene.rebocap_source_armature)
        if target and target.type == 'ARMATURE' and target.data.is_editmode:
            _report_preview_edit()
            scene.rebocap_source_armature = session.armature_name
            return
        if not preview_layer.supported(target):
            _report_preview_unsupported()
            scene.rebocap_source_armature = session.armature_name
            return
        if _preview_conflict(scene, target):
            _report_preview_conflict()
            scene.rebocap_source_armature = session.armature_name
            return
        snapshot = _snapshot_target_switch(scene, session, target)
        try:
            apply_a2t_preview_to_armature(scene)
        except Exception as error:
            _rollback_target_switch(scene, session, snapshot)
            print(f'[Rebocap] Could not switch preview target: {error}')
    else:
        if getattr(scene, 'rebocap_playback_active', False):
            rebind_playback_target(scene)
            mode = scene.rebocap_playback_mode
            target = scene.objects.get(scene.rebocap_source_armature)
            previous = scene.rebocap_playback_source_object
            if mode in ('FK', 'DUAL') and target and previous and target != previous:
                from .control import find_conflict, conflict_message
                conflict = find_conflict(scene, [target])
                if conflict:
                    print('[Rebocap] ' + conflict_message(conflict))
                    if scene.objects.get(previous.name) == previous:
                        scene.rebocap_source_armature = previous.name
                    return
                from ..ops.history import _acquire_playback_action, release_playback_target
                try:
                    _acquire_playback_action(scene, target)
                    release_playback_target(scene, previous)
                except (ValueError, RuntimeError, TypeError) as error:
                    print(f'[Rebocap] Could not transfer playback control: {error}')
                    scene.rebocap_source_armature = previous.name
                    return
        _refresh_playback(scene)


def on_preview_mapping_changed(bone_map, context):
    scene = bone_map.id_data
    if scene and scene.as_pointer() in _preview_mapping_reverting:
        return
    if scene and getattr(scene, 'recording', False):
        from ..ops.rebocap_connection import update_recording_binding
        update_recording_binding(scene)
    if scene and preview_active(scene):
        session = _preview_sessions[scene.as_pointer()]
        snapshot = _snapshot_target_switch(scene, session, session.armature)
        try:
            apply_a2t_preview_to_armature(scene)
        except Exception as error:
            _rollback_target_switch(scene, session, snapshot)
            key = scene.as_pointer()
            _preview_mapping_reverting.add(key)
            try:
                for index, name in enumerate(session.applied_mapping):
                    if getattr(bone_map, f'node_{index}') != name:
                        setattr(bone_map, f'node_{index}', name)
            finally:
                _preview_mapping_reverting.discard(key)
            print(f'[Rebocap] Could not change preview mapping: {error}')
    elif scene:
        _refresh_playback(scene)


@bpy.app.handlers.persistent
def restore_preview_after_undo(_):
    # Undo recreates RNA wrappers even when the underlying pointer is reused.
    _preview_sessions.clear()
    for scene in bpy.data.scenes:
        session = _session_from_state(scene)
        if not session or not scene.rebocap_a2t.preview_mode:
            continue
        if _install_preview_session(scene, session):
            apply_a2t_preview_to_armature(scene)
    reconcile_copied_previews()


@bpy.app.handlers.persistent
def maintain_preview_on_frame_change(scene, depsgraph=None):
    if (scene.as_pointer() not in _preview_frame_suspended and preview_active(scene)
            and scene.rebocap_a2t.preview_mode):
        apply_a2t_preview_to_armature(scene)


@bpy.app.handlers.persistent
def prepare_preview_for_save(_):
    # An orphaned copied scene can be saved before its first depsgraph tick.
    reconcile_copied_previews()
    preview_layer.suspend_for_save()
    for scene in bpy.data.scenes:
        session = _preview_sessions.get(scene.as_pointer())
        if not session or session.saving:
            continue
        session.saving = True
        session.saved_pause = scene.rebocap_pause_control
        session.saved_preview_pose = {}
        session.save_warning = ''
        try:
            from ..ops.history import snapshot_playback
            session.saved_playback = snapshot_playback(scene)
            armature = session.armature
            try:
                if armature and armature.type == 'ARMATURE':
                    for name in session.pose:
                        bone = _pose_bone(armature, name, session.pose_refs)
                        if bone:
                            session.saved_preview_pose[name] = (bone.matrix_basis.copy(), bone.rotation_mode)
            except ReferenceError:
                session.armature = None
                session.pose = {}
            _sync_preview_target_name(scene, session)
            restore_preview_target_at_current_frame(scene, session, armature)
            session.saved_tags = _remove_preview_tags(session)
            if _SESSION_KEY in scene:
                del scene[_SESSION_KEY]
            scene.rebocap_a2t.preview_mode = False
            scene.rebocap_pause_control = session.was_paused
            # The entry snapshot is only a starting point. Re-evaluate Action,
            # NLA and native playback at the frame being saved.
            if (session.start_frame != (scene.frame_current, scene.frame_subframe)
                    or getattr(scene, 'rebocap_playback_active', False)):
                scene.frame_set(scene.frame_current, subframe=scene.frame_subframe)
        except Exception as error:
            # Blender continues saving even when save_pre raises.  Keep the
            # non-preview baseline in the file and restore the live preview
            # only from save_post/save_post_fail; report the fallback clearly.
            session.save_warning = str(error)
            print(f'[Rebocap] Save used the non-preview fallback pose: {error}')
            _restore_preview_pose(session.armature, session.saved_preview_pose, session.pose_refs)
            if not session.saved_tags:
                session.saved_tags = _remove_preview_tags(session)
            if _SESSION_KEY in scene:
                del scene[_SESSION_KEY]
            scene.rebocap_a2t.preview_mode = False
            scene.rebocap_pause_control = session.was_paused


@bpy.app.handlers.persistent
def restore_preview_after_save(_):
    try:
        preview_layer.restore_after_save()
    except Exception as error:
        print(f'[Rebocap] Could not restore the preview layer after save: {error}')
        for scene in bpy.data.scenes:
            session = _preview_sessions.get(scene.as_pointer())
            if not session or not session.saving:
                continue
            try:
                if session.saved_playback is not None:
                    from ..ops.history import restore_playback
                    restore_playback(scene, session.saved_playback)
                _restore_preview_tags(session)
                _remove_preview_tags(session)
            finally:
                _preview_sessions.pop(scene.as_pointer(), None)
                session.saving = False
                if _SESSION_KEY in scene:
                    del scene[_SESSION_KEY]
                scene.rebocap_a2t.preview_mode = False
                scene.rebocap_pause_control = session.was_paused
                _notify_save_fallback(scene, 'A2T preview could not be restored after save')
        force_viewport_redraw()
        return
    for scene in bpy.data.scenes:
        session = _preview_sessions.get(scene.as_pointer())
        if not session or not session.saving:
            continue
        try:
            if session.saved_playback is not None:
                from ..ops.history import restore_playback
                restore_playback(scene, session.saved_playback)
            scene.rebocap_a2t.preview_mode = True
            scene.rebocap_pause_control = session.saved_pause
            _restore_preview_pose(session.armature, session.saved_preview_pose, session.pose_refs)
            _restore_preview_tags(session)
            _save_preview_state(scene, session)
        finally:
            session.saving = False
            session.saved_preview_pose = {}
            session.saved_playback = None
        if session.save_warning:
            _notify_save_fallback(scene)
    force_viewport_redraw()


SEMANTIC_TO_NODE_MAP = {
    'pelvis': 0,
    'left_thigh': 1,
    'right_thigh': 2,
    'spine': 3,
    'left_calf': 4,
    'right_calf': 5,
    'chest': 6,
    'left_foot': 7,
    'right_foot': 8,
    'up_chest': 9,
    'neck': 12,
    'left_clavicle': 13,
    'right_clavicle': 14,
    'head': 15,
    'left_upperarm': 16,
    'right_upperarm': 17,
    'left_lowerarm': 18,
    'right_lowerarm': 19,
    'left_hand': 20,
    'right_hand': 21,
}

NODE_TO_ATTR_MAP = {
    0: 'pelvis_offset',
    1: 'left_thigh_offset',
    2: 'right_thigh_offset',
    3: 'spine_offset',
    4: 'left_calf_offset',
    5: 'right_calf_offset',
    6: 'chest_offset',
    7: 'left_foot_offset',
    8: 'right_foot_offset',
    9: 'up_chest_offset',
    12: 'neck_offset',
    13: 'left_clavicle_offset',
    14: 'right_clavicle_offset',
    15: 'head_offset',
    16: 'left_upperarm_offset',
    17: 'right_upperarm_offset',
    18: 'left_lowerarm_offset',
    19: 'right_lowerarm_offset',
    20: 'left_hand_offset',
    21: 'right_hand_offset',
}

SEMANTIC_TO_ATTR_MAP = {
    'left_clavicle': 'left_clavicle_offset',
    'left_upperarm': 'left_upperarm_offset',
    'left_lowerarm': 'left_lowerarm_offset',
    'left_hand': 'left_hand_offset',
    'right_clavicle': 'right_clavicle_offset',
    'right_upperarm': 'right_upperarm_offset',
    'right_lowerarm': 'right_lowerarm_offset',
    'right_hand': 'right_hand_offset',
    'left_thigh': 'left_thigh_offset',
    'left_calf': 'left_calf_offset',
    'left_foot': 'left_foot_offset',
    'right_thigh': 'right_thigh_offset',
    'right_calf': 'right_calf_offset',
    'right_foot': 'right_foot_offset',
    'pelvis': 'pelvis_offset',
    'spine': 'spine_offset',
    'chest': 'chest_offset',
    'up_chest': 'up_chest_offset',
    'neck': 'neck_offset',
    'head': 'head_offset',
}

RIGHT_TO_LEFT_ATTR_MAP = {
    'right_clavicle_offset': 'left_clavicle_offset',
    'right_upperarm_offset': 'left_upperarm_offset',
    'right_lowerarm_offset': 'left_lowerarm_offset',
    'right_hand_offset': 'left_hand_offset',
    'right_thigh_offset': 'left_thigh_offset',
    'right_calf_offset': 'left_calf_offset',
    'right_foot_offset': 'left_foot_offset',
}


def force_viewport_redraw():
    try:
        wm = bpy.context.window_manager if hasattr(bpy.context, 'window_manager') else None
        if wm:
            for window in wm.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
    except Exception:
        pass


def get_bone_name_from_semantic(scene, semantic_key):
    if not scene:
        return ""
    bone_map = getattr(scene, 'rebocap_bone_map', None)
    if not bone_map:
        return ""
    node_idx = SEMANTIC_TO_NODE_MAP.get(semantic_key)
    if node_idx is None:
        return ""
    return getattr(bone_map, f"node_{node_idx}", "")


def get_a2t_quat_for_node_idx(scene, node_idx):
    if not scene:
        return Quaternion((1.0, 0.0, 0.0, 0.0))
    a2t = getattr(scene, 'rebocap_a2t', None)
    if not a2t or not a2t.enable_a2t or a2t.alpha <= 0.0001:
        return Quaternion((1.0, 0.0, 0.0, 0.0))

    attr_name = NODE_TO_ATTR_MAP.get(node_idx)
    if not attr_name:
        return Quaternion((1.0, 0.0, 0.0, 0.0))

    if a2t.mirror_edit and attr_name in RIGHT_TO_LEFT_ATTR_MAP:
        left_attr = RIGHT_TO_LEFT_ATTR_MAP[attr_name]
        left_rot = getattr(a2t, left_attr, (0.0, 0.0, 0.0))
        rot_deg = a2t.calculate_mirrored_rot(left_rot)
    else:
        rot_deg = getattr(a2t, attr_name, (0.0, 0.0, 0.0))

    if rot_deg[0] == 0.0 and rot_deg[1] == 0.0 and rot_deg[2] == 0.0:
        return Quaternion((1.0, 0.0, 0.0, 0.0))

    alpha = a2t.alpha
    eul = Euler((
        math.radians(rot_deg[0] * alpha),
        math.radians(rot_deg[1] * alpha),
        math.radians(rot_deg[2] * alpha)
    ), 'YXZ')
    return eul.to_quaternion()


def apply_a2t_preview_to_armature(scene, arm_obj=None, force_apply=False):
    global _is_updating_flag
    if not scene:
        return
    session = _preview_sessions.get(scene.as_pointer())
    if not force_apply:
        if not session or session.saving:
            return
        if not _preview_library_valid(session):
            _end_changed_library_preview(scene, session)
            return
        # Resolve a rename from the held object before looking up the old name:
        # another object may already have acquired that name.
        _sync_preview_target_name(scene, session)
        target = scene.objects.get(scene.rebocap_source_armature)
        if target is None and scene.rebocap_source_armature == session.armature_name:
            # An object rename does not update this StringProperty. Preserve
            # its live preview instead of interpreting the old name as a reset.
            try:
                current = session.armature
                if current and scene.objects.get(current.name) == current:
                    _sync_preview_target_name(scene, session)
                    target = current
            except ReferenceError:
                pass
        if target is not None and target.type != 'ARMATURE':
            target = None
        session.select_armature(target)
        arm_obj = target
    elif not arm_obj:
        arm_name = getattr(scene, 'rebocap_source_armature', '')
        if not arm_name:
            return
        arm_obj = bpy.data.objects.get(arm_name)
    if not arm_obj or arm_obj.type != 'ARMATURE' or not arm_obj.pose:
        return

    a2t = getattr(scene, 'rebocap_a2t', None)
    if not a2t:
        return

    if not force_apply and not a2t.preview_mode:
        return

    if a2t.mirror_edit:
        previous_updating = _is_updating_flag
        _is_updating_flag = True
        try:
            a2t.sync_mirror_offsets()
        finally:
            _is_updating_flag = previous_updating

    alpha = a2t.alpha
    if session and not force_apply:
        mapped = {get_bone_name_from_semantic(scene, key) for key in SEMANTIC_TO_ATTR_MAP}
        removed = {name: value for name, value in session.pose.items() if name not in mapped}
        if removed:
            restore_preview_target_at_current_frame(scene, session, arm_obj, removed)
            for name in removed:
                session.pose.pop(name, None)
                session.pose_refs.pop(name, None)
    for sem_key, attr_name in SEMANTIC_TO_ATTR_MAP.items():
        bone_name = get_bone_name_from_semantic(scene, sem_key)
        if not bone_name:
            continue
        pb = arm_obj.pose.bones.get(bone_name)
        if not pb:
            continue
        if session and not force_apply:
            if not session.remember_bone(pb):
                continue

        if a2t.mirror_edit and attr_name in RIGHT_TO_LEFT_ATTR_MAP:
            left_attr = RIGHT_TO_LEFT_ATTR_MAP[attr_name]
            left_rot = getattr(a2t, left_attr, (0.0, 0.0, 0.0))
            rot_deg = a2t.calculate_mirrored_rot(left_rot)
        else:
            rot_deg = getattr(a2t, attr_name, (0.0, 0.0, 0.0))

        eul = Euler((
            math.radians(rot_deg[0] * alpha),
            math.radians(rot_deg[1] * alpha),
            math.radians(rot_deg[2] * alpha)
        ), 'YXZ')
        if session and not force_apply:
            helper = session.helper
            if helper and set(helper.data.bones.keys()) != set(arm_obj.data.bones.keys()):
                preview_layer.clear(scene, helper)
                session.helper = helper = None
            if not helper:
                session.helper = helper = preview_layer.create(scene, arm_obj)
            preview_layer.apply_bone(helper, pb, eul.to_quaternion())
        else:
            # Explicit force_apply is used by existing export/bake workflows,
            # which own their own pose transaction.
            pb.rotation_mode = 'QUATERNION'
            pb.rotation_quaternion = eul.to_quaternion()

    if session and not force_apply:
        session.applied_mapping = [getattr(scene.rebocap_bone_map, f'node_{i}') for i in range(24)]
        if session.armature and session.library_hash:
            from ..ops.history import record_linked_binding
            record_linked_binding(scene, session.armature, session.library_hash,
                                  structure=session.library_structure)
        _save_preview_state(scene, session)
    force_viewport_redraw()


def on_a2t_property_updated(self, context):
    global _is_updating_flag
    if _is_updating_flag:
        return

    _is_updating_flag = True
    try:
        scene = getattr(self, 'id_data', None)
        if not scene:
            return
        a2t = getattr(scene, 'rebocap_a2t', None)
        if not a2t:
            return

        if a2t.mirror_edit:
            a2t.sync_mirror_offsets()

        if a2t.preview_mode and preview_active(scene):
            apply_a2t_preview_to_armature(scene)
        elif not a2t.preview_mode:
            _refresh_playback(scene)
    finally:
        _is_updating_flag = False


def preview_active(scene):
    if not _reconciling_previews:
        _prune_orphaned_previews()
        session = _preview_sessions.get(scene.as_pointer())
        if (session and not preview_layer.saving() and
                _preview_target_missing(scene, session)):
            _end_missing_preview(scene, session)
        elif session and not preview_layer.saving() and not _preview_library_valid(session):
            _end_changed_library_preview(scene, session)
    if (scene.as_pointer() not in _preview_sessions and
            getattr(scene, 'rebocap_a2t', None) and scene.rebocap_a2t.preview_mode and
            scene.get(_SESSION_KEY) and not _reconciling_previews):
        reconcile_copied_previews()
    return scene.as_pointer() in _preview_sessions


def preview_saving(scene):
    session = _preview_sessions.get(scene.as_pointer())
    return bool(session and session.saving)


def preview_save_warning(scene):
    session = _preview_sessions.get(scene.as_pointer())
    return session.save_warning if session else ''


def on_preview_mode_toggle(self, context):
    scene = getattr(self, 'id_data', None)
    if not scene:
        return
    key = scene.as_pointer()
    current = _preview_sessions.get(key)
    if current and current.saving:
        return
    if self.preview_mode:
        if getattr(scene, 'recording', False):
            self.preview_mode = False
            print('[Rebocap] Stop recording before entering A2T preview')
            return
        if key in _preview_sessions:
            return
        target = scene.objects.get(scene.rebocap_source_armature)
        if target and target.type == 'ARMATURE' and target.data.is_editmode:
            self.preview_mode = False
            _report_preview_edit()
            return
        if not preview_layer.supported(target):
            self.preview_mode = False
            _report_preview_unsupported()
            return
        if target and target.type == 'ARMATURE' and target.data and _preview_linked(target):
            from ..ops.history import playback_identity_conflict, preserve_project_for_linked_library_conflict
            if (_preview_library_fingerprint(target) is None or
                    (scene.rebocap_playback_active and scene.rebocap_playback_mode in ('FK', 'DUAL')
                     and playback_identity_conflict(scene))):
                self.preview_mode = False
                scene.rebocap_a2t_library_warning = True
                preserve_project_for_linked_library_conflict(force=True)
                _report_preview_error('A2T linked skeleton changed')
                return
        if _preview_conflict(scene, target):
            _report_preview_conflict()
            self.preview_mode = False
            return
        scene.rebocap_a2t_library_warning = False
        if scene.rebocap_playback_active:
            from ..ops.playback_control import release
            release(scene)
        screen = getattr(context, 'screen', None)
        playing = bool(screen and screen.is_animation_playing)
        _preview_sessions[key] = PreviewSession(scene.rebocap_pause_control, playing, scene)
        _save_preview_state(scene, _preview_sessions[key])
        scene.rebocap_pause_control = True
        if playing:
            from ..ops.rebocap_connection import force_stop_animation
            force_stop_animation(context)
        try:
            apply_a2t_preview_to_armature(scene)
        except Exception as error:
            session = _preview_sessions.pop(key)
            preview_layer.clear(scene, session.helper)
            _remove_preview_tags(session)
            if _SESSION_KEY in scene:
                del scene[_SESSION_KEY]
            self.preview_mode = False
            scene.rebocap_pause_control = session.was_paused
            if playing:
                from ..ops.rebocap_connection import force_start_animation
                force_start_animation(context)
            print(f'[Rebocap] Could not start A2T preview: {error}')
            _report_preview_error('A2T preview could not be started')
            return
        from .control import synchronize_owners
        synchronize_owners()
    else:
        state = _preview_sessions.get(key)
        if not state:
            return
        _sync_preview_target_name(scene, state)
        preview_pose = {}
        if state.armature:
            for name in state.pose:
                bone = _pose_bone(state.armature, name, state.pose_refs)
                if bone:
                    preview_pose[name] = (bone.matrix_basis.copy(), bone.rotation_mode)
        try:
            restore_preview_target_at_current_frame(scene, state, state.armature)
        except Exception as error:
            print(f'[Rebocap] Could not restore preview target: {error}')
            if state.armature and state.armature.data.is_editmode:
                # Mode changes cannot be cancelled from a depsgraph handler.
                # Remove preview before structural edits even if current-frame
                # playback evaluation fails; never leave preview active there.
                _restore_preview_pose(state.armature, preview_pose, state.pose_refs)
                state.edit_exit_warning = str(error)
            else:
                _restore_preview_pose(state.armature, preview_pose, state.pose_refs)
                self.preview_mode = True
                return
        _preview_sessions.pop(key, None)
        _remove_preview_tags(state)
        if _SESSION_KEY in scene:
            del scene[_SESSION_KEY]
        scene.rebocap_pause_control = state.was_paused
        if scene.rebocap_playback_active:
            # The preview's reserved-target evaluation may have written a
            # quaternion directly. Resume normal playback from authored modes.
            from ..ops.history import restore_playback_rotation_modes
            restore_playback_rotation_modes(scene)
        from ..ops.ik_tracking import flush_pending_tracking_refresh
        try:
            if not flush_pending_tracking_refresh(scene):
                print('[Rebocap] Deferred tracking refresh failed; it will be retried.')
        except Exception as error:
            print(f'[Rebocap] Deferred tracking refresh failed: {error}')
        if scene.rebocap_playback_active:
            from ..ops.history import rebocap_timeline_playback_handler
            try:
                rebocap_timeline_playback_handler(scene)
            except Exception as error:
                if not (state.armature and state.armature.data.is_editmode):
                    raise
                # The mode change cannot be rolled back here. Keep the
                # non-preview fallback and let the edit warning report failure.
                print(f'[Rebocap] Could not resume playback after preview: {error}')
                state.edit_exit_warning = str(error)
        screen = getattr(context, 'screen', None)
        if state.was_playing and not (screen and screen.is_animation_playing):
            from ..ops.rebocap_connection import force_start_animation
            force_start_animation(context)
        force_viewport_redraw()


class RebocapA2TSettings(bpy.types.PropertyGroup):
    enable_a2t: bpy.props.BoolProperty(
        name="Enable A2T Calibration",
        default=False,
        description="Enable A-Pose to T-Pose calibration layer in runtime retargeting",
        update=on_a2t_property_updated
    )



    def on_preset_changed(self, context):
        global _is_updating_flag
        if _is_updating_flag:
            return
        _is_updating_flag = True
        try:
            self.apply_preset(self.preset_template)
            scene = getattr(self, 'id_data', None)
            if scene and self.preview_mode and preview_active(scene):
                apply_a2t_preview_to_armature(scene)
            elif scene:
                _refresh_playback(scene)
        finally:
            _is_updating_flag = False

    preset_template: bpy.props.EnumProperty(
        name="Preset Template",
        items=[
            ('UE5_Manny_Quinn', 'UE5 (Manny / Quinn / MetaHuman)', 'Standard UE5 A-Pose preset'),
            ('Mixamo_APose', 'Mixamo A-Pose (~40°)', 'Standard Mixamo A-Pose preset'),
            ('VRoid_VRM', 'VRoid / VRM (~35°)', 'Standard VRoid / VRM A-Pose preset'),
            ('MMD_Standard', 'MMD Standard (~35°)', 'Standard MMD A-Pose preset'),
            ('Custom', 'Custom', 'User-defined custom offsets'),
        ],
        default='UE5_Manny_Quinn',
        description="Quick presets for common character A-Poses",
        update=on_preset_changed
    )

    mirror_edit: bpy.props.BoolProperty(
        name="Symmetrical Edit",
        default=True,
        description="Automatically mirror left limb modifications to right limb",
        update=on_a2t_property_updated
    )

    mirror_invert_roll: bpy.props.BoolProperty(
        name="Invert Roll (X)",
        default=False,
        description="Invert Roll (X axis) when mirroring",
        update=on_a2t_property_updated
    )

    mirror_invert_pitch: bpy.props.BoolProperty(
        name="Invert Pitch (Y)",
        default=True,
        description="Invert Pitch (Y axis) when mirroring",
        update=on_a2t_property_updated
    )

    mirror_invert_yaw: bpy.props.BoolProperty(
        name="Invert Yaw (Z)",
        default=True,
        description="Invert Yaw (Z axis) when mirroring",
        update=on_a2t_property_updated
    )

    alpha: bpy.props.FloatProperty(
        name="Alpha",
        default=1.0,
        min=0.0,
        max=1.0,
        description="A2T Calibration Strength Weight",
        update=on_a2t_property_updated
    )

    preview_mode: bpy.props.BoolProperty(
        name="Preview in Viewport",
        default=False,
        description="Preview A2T calibration pose directly on the character in 3D viewport",
        update=on_preview_mode_toggle
    )

    # 1. Left Arm (Default UE5 Manny/Quinn)
    left_clavicle_offset: bpy.props.FloatVectorProperty(name="Left Clavicle", size=3, default=(-15.0, 0.0, 0.0), update=on_a2t_property_updated)
    left_upperarm_offset: bpy.props.FloatVectorProperty(name="Left UpperArm", size=3, default=(-40.0, 0.0, 0.0), update=on_a2t_property_updated)
    left_lowerarm_offset: bpy.props.FloatVectorProperty(name="Left LowerArm", size=3, default=(0.0, 0.0, -40.0), update=on_a2t_property_updated)
    left_hand_offset: bpy.props.FloatVectorProperty(name="Left Hand", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)

    # 2. Right Arm (Mirrored defaults)
    right_clavicle_offset: bpy.props.FloatVectorProperty(name="Right Clavicle", size=3, default=(-15.0, 0.0, 0.0), update=on_a2t_property_updated)
    right_upperarm_offset: bpy.props.FloatVectorProperty(name="Right UpperArm", size=3, default=(-40.0, 0.0, 0.0), update=on_a2t_property_updated)
    right_lowerarm_offset: bpy.props.FloatVectorProperty(name="Right LowerArm", size=3, default=(0.0, 0.0, 40.0), update=on_a2t_property_updated)
    right_hand_offset: bpy.props.FloatVectorProperty(name="Right Hand", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)

    # 3. Left Leg
    left_thigh_offset: bpy.props.FloatVectorProperty(name="Left Thigh", size=3, default=(3.0, 5.0, 0.0), update=on_a2t_property_updated)
    left_calf_offset: bpy.props.FloatVectorProperty(name="Left Calf", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    left_foot_offset: bpy.props.FloatVectorProperty(name="Left Foot", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)

    # 4. Right Leg (Mirrored defaults: Y inverted to -5.0)
    right_thigh_offset: bpy.props.FloatVectorProperty(name="Right Thigh", size=3, default=(3.0, -5.0, 0.0), update=on_a2t_property_updated)
    right_calf_offset: bpy.props.FloatVectorProperty(name="Right Calf", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    right_foot_offset: bpy.props.FloatVectorProperty(name="Right Foot", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)

    # 5. Root & Spine & Head
    pelvis_offset: bpy.props.FloatVectorProperty(name="Pelvis", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    spine_offset: bpy.props.FloatVectorProperty(name="Spine", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    chest_offset: bpy.props.FloatVectorProperty(name="Chest", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    up_chest_offset: bpy.props.FloatVectorProperty(name="Up Chest", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    neck_offset: bpy.props.FloatVectorProperty(name="Neck", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)
    head_offset: bpy.props.FloatVectorProperty(name="Head", size=3, default=(0.0, 0.0, 0.0), update=on_a2t_property_updated)

    def calculate_mirrored_rot(self, in_rot):
        x = -in_rot[0] if self.mirror_invert_roll else in_rot[0]
        y = -in_rot[1] if self.mirror_invert_pitch else in_rot[1]
        z = -in_rot[2] if self.mirror_invert_yaw else in_rot[2]
        return (x, y, z)

    def sync_mirror_offsets(self):
        if not self.mirror_edit:
            return
        self.right_clavicle_offset = self.calculate_mirrored_rot(self.left_clavicle_offset)
        self.right_upperarm_offset = self.calculate_mirrored_rot(self.left_upperarm_offset)
        self.right_lowerarm_offset = self.calculate_mirrored_rot(self.left_lowerarm_offset)
        self.right_hand_offset = self.calculate_mirrored_rot(self.left_hand_offset)

        self.right_thigh_offset = self.calculate_mirrored_rot(self.left_thigh_offset)
        self.right_calf_offset = self.calculate_mirrored_rot(self.left_calf_offset)
        self.right_foot_offset = self.calculate_mirrored_rot(self.left_foot_offset)

    def apply_preset(self, preset_name):
        if preset_name == 'UE5_Manny_Quinn':
            self.mirror_invert_roll = False
            self.mirror_invert_pitch = True
            self.mirror_invert_yaw = True

            self.left_clavicle_offset = (-15.0, 0.0, 0.0)
            self.left_upperarm_offset = (-40.0, 0.0, 0.0)
            self.left_lowerarm_offset = (0.0, 0.0, -40.0)
            self.left_hand_offset = (0.0, 0.0, 0.0)

            self.left_thigh_offset = (3.0, 5.0, 0.0)
            self.left_calf_offset = (0.0, 0.0, 0.0)
            self.left_foot_offset = (0.0, 0.0, 0.0)

            self.pelvis_offset = (0.0, 0.0, 0.0)
            self.spine_offset = (0.0, 0.0, 0.0)
            self.chest_offset = (0.0, 0.0, 0.0)
            self.up_chest_offset = (0.0, 0.0, 0.0)
            self.neck_offset = (0.0, 0.0, 0.0)
            self.head_offset = (0.0, 0.0, 0.0)
            self.sync_mirror_offsets()

        elif preset_name in ('MMD_Standard', 'VRoid_VRM'):
            self.mirror_invert_roll = False
            self.mirror_invert_pitch = True
            self.mirror_invert_yaw = True

            self.left_clavicle_offset = (0.0, 0.0, 0.0)
            self.left_upperarm_offset = (0.0, 0.0, 35.0)
            self.left_lowerarm_offset = (0.0, 0.0, 0.0)
            self.left_hand_offset = (0.0, 0.0, 0.0)

            self.left_thigh_offset = (0.0, 0.0, 0.0)
            self.left_calf_offset = (0.0, 0.0, 0.0)
            self.left_foot_offset = (0.0, 0.0, 0.0)

            self.pelvis_offset = (0.0, 0.0, 0.0)
            self.spine_offset = (0.0, 0.0, 0.0)
            self.chest_offset = (0.0, 0.0, 0.0)
            self.up_chest_offset = (0.0, 0.0, 0.0)
            self.neck_offset = (0.0, 0.0, 0.0)
            self.head_offset = (0.0, 0.0, 0.0)
            self.sync_mirror_offsets()

        elif preset_name == 'Mixamo_APose':
            self.mirror_invert_roll = False
            self.mirror_invert_pitch = True
            self.mirror_invert_yaw = True

            self.left_clavicle_offset = (0.0, 0.0, 0.0)
            self.left_upperarm_offset = (0.0, 0.0, 40.0)
            self.left_lowerarm_offset = (0.0, 0.0, 0.0)
            self.left_hand_offset = (0.0, 0.0, 0.0)

            self.left_thigh_offset = (0.0, 0.0, 0.0)
            self.left_calf_offset = (0.0, 0.0, 0.0)
            self.left_foot_offset = (0.0, 0.0, 0.0)

            self.pelvis_offset = (0.0, 0.0, 0.0)
            self.spine_offset = (0.0, 0.0, 0.0)
            self.chest_offset = (0.0, 0.0, 0.0)
            self.up_chest_offset = (0.0, 0.0, 0.0)
            self.neck_offset = (0.0, 0.0, 0.0)
            self.head_offset = (0.0, 0.0, 0.0)
            self.sync_mirror_offsets()
