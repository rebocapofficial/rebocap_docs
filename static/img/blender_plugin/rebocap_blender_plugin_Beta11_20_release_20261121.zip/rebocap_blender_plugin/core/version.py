# Single Source of Truth for Rebocap Plugin Version
VERSION = (11, 20, 0)
VERSION_STR = f"Beta {VERSION[0]}.{VERSION[1]}"

