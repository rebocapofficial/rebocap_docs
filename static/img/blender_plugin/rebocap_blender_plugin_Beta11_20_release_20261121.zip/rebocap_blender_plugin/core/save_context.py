"""Scope internal copies without treating them as a user project save."""
from contextlib import contextmanager
import bpy

_recovery_copy_depth = 0
_saved_hooks = []


def is_recovery_copy():
    return _recovery_copy_depth > 0


@contextmanager
def recovery_copy(on_saved=None):
    global _recovery_copy_depth
    _recovery_copy_depth += 1
    _saved_hooks.append(on_saved)
    try:
        yield
    finally:
        _saved_hooks.pop()
        _recovery_copy_depth -= 1


@bpy.app.handlers.persistent
def capture_recovery_save(_):
    if _saved_hooks and _saved_hooks[-1]:
        _saved_hooks[-1]()
