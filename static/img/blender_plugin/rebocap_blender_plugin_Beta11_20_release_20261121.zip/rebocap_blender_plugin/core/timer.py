import bpy
import os
from ..ops.ik_tracking import (
    parse_and_update_ik_config, sync_tracking_nodes, tracking_nla_issue,
    flush_pending_tracking_refresh, may_auto_detect_config, read_and_sync_config,
)

last_mtime = None
last_config = None
_cooldown_counter = 0
_sync_errors = {}


def sync_error(scene):
    return _sync_errors.get(scene.as_pointer(), '')


def _set_error(scene, message):
    key = scene.as_pointer()
    previous = _sync_errors.get(key, '')
    if message:
        _sync_errors[key] = message
    else:
        _sync_errors.pop(key, None)
    if message != previous:
        if message:
            print('[Rebocap] Tracking refresh failed (will retry): ' + message)
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()


def config_watchdog():
    global last_mtime, last_config, _cooldown_counter
    scene = getattr(bpy.context, 'scene', None)
    if not scene:
        return 2.0
    if scene.rebocap_tracking_refresh_pending:
        try:
            if not flush_pending_tracking_refresh(scene):
                _set_error(scene, 'Unable to update tracking nodes')
                return 5.0
        except Exception as error:
            _set_error(scene, str(error))
            return 5.0
    rebocap = getattr(scene, 'rebocap_bone_map', None)
    if not rebocap or not getattr(rebocap, 'ik_auto_refresh', False):
        _set_error(scene, '')
        return 2.0
    try:
        path = rebocap.ik_config_path
        if not path and may_auto_detect_config(scene):
            from ..ops.ik_tracking import find_rebocap_config_path
            path = find_rebocap_config_path()
        if not path:
            _set_error(scene, '')
            return 2.0
        if not os.path.exists(path):
            _set_error(scene, 'Unable to read skeleton configuration')
            return 5.0

        current_mtime = os.path.getmtime(path)
        config_key = (scene.as_pointer(), os.path.abspath(path))
        changed = config_key != last_config or current_mtime != last_mtime
        if changed:
            status = read_and_sync_config(scene, path, read=parse_and_update_ik_config,
                                          sync=sync_tracking_nodes)
            if status == 'READ_ERROR':
                _set_error(scene, 'Unable to read skeleton configuration')
                return 5.0
            if status != 'OK':
                issue = tracking_nla_issue(scene)
                _set_error(scene, 'NLA:' + issue[0] if issue else 'Unable to update tracking nodes')
                return 5.0
        elif not sync_tracking_nodes(scene):
            issue = tracking_nla_issue(scene)
            _set_error(scene, 'NLA:' + issue[0] if issue else 'Unable to update tracking nodes')
            return 5.0
        if changed:
            last_mtime = current_mtime
            last_config = config_key
        _set_error(scene, '')
        return 1.5
    except Exception as error:
        _set_error(scene, str(error))
        return 5.0


def reset_cache():
    global last_mtime, last_config, _cooldown_counter
    last_mtime = None
    last_config = None
    _cooldown_counter = 0
    _sync_errors.clear()


def register():
    if not bpy.app.timers.is_registered(config_watchdog):
        bpy.app.timers.register(config_watchdog, persistent=True)


def unregister():
    reset_cache()
    if bpy.app.timers.is_registered(config_watchdog):
        bpy.app.timers.unregister(config_watchdog)
