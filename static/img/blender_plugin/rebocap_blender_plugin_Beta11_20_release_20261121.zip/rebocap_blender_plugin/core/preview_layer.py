"""Non-destructive A2T preview layer and its temporary Blender data.

The Scene pointers and the helper's owner pointer are runtime/undo references,
not durable identities.  A constraint belongs to a layer only when it targets
that exact helper; copied names and copied custom properties are insufficient.
"""
import bpy
import uuid

_TAG = '_rebocap_a2t_preview_helper'
_PREFIX = '_ReboCap_A2T_preview_'
_TARGET = 'rebocap_preview_target_runtime'
_HELPER = 'rebocap_preview_helper_runtime'
_OWNER = 'rebocap_preview_owner_runtime'
_save_state = None


def register():
    for name in (_TARGET, _HELPER):
        if not hasattr(bpy.types.Scene, name):
            setattr(bpy.types.Scene, name, bpy.props.PointerProperty(
                type=bpy.types.Object, options={'HIDDEN', 'SKIP_SAVE'}))
    if not hasattr(bpy.types.Object, _OWNER):
        setattr(bpy.types.Object, _OWNER, bpy.props.PointerProperty(
            type=bpy.types.Scene, options={'HIDDEN', 'SKIP_SAVE'}))


def unregister():
    global _save_state
    _save_state = None
    for name in (_TARGET, _HELPER):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
    if hasattr(bpy.types.Object, _OWNER):
        delattr(bpy.types.Object, _OWNER)


def target_for(scene):
    return getattr(scene, _TARGET, None)


def helper_for(scene):
    return getattr(scene, _HELPER, None)


def is_helper(obj):
    try:
        return bool(obj and obj.type == 'ARMATURE' and obj.get(_TAG))
    except ReferenceError:
        return False


def saving():
    return _save_state is not None


def supported(target):
    if not target or target.type != 'ARMATURE':
        return True
    return (not target.data.is_editmode and
            not (target.library is not None and target.override_library is None) and
            getattr(target, 'is_editable', True))


def owner_of(helper):
    return getattr(helper, _OWNER, None) if is_helper(helper) else None


def bind(scene, target, helper):
    setattr(scene, _TARGET, target)
    setattr(scene, _HELPER, helper)
    if helper:
        setattr(helper, _OWNER, scene)


def _constraints(helper, only_object=None, only_names=None):
    for obj in list(bpy.data.objects) if only_object is None else (only_object,):
        try:
            if obj.type != 'ARMATURE' or not obj.pose:
                continue
            for bone in obj.pose.bones:
                if only_names is not None and bone.name not in only_names:
                    continue
                for index, constraint in enumerate(bone.constraints):
                    if (constraint.type == 'COPY_ROTATION' and
                            constraint.name.startswith(_PREFIX) and constraint.target == helper):
                        yield obj, bone, index, constraint
        except ReferenceError:
            continue


def _remove_constraints(helper, only_object=None, only_names=None):
    for _, bone, _, constraint in list(_constraints(helper, only_object, only_names)):
        bone.constraints.remove(constraint)


def _destroy_helper(helper):
    if not is_helper(helper):
        return
    _remove_constraints(helper)
    data = helper.data
    for collection in list(helper.users_collection):
        collection.objects.unlink(helper)
    _clear_unreferenced_helper_users([helper])
    bpy.data.objects.remove(helper, do_unlink=True)
    if data and data.users == 0:
        bpy.data.armatures.remove(data)


def clear(scene, helper=None):
    helper = helper if helper is not None else helper_for(scene)
    setattr(scene, _TARGET, None)
    setattr(scene, _HELPER, None)
    if not is_helper(helper):
        return
    # A linked scene copy may temporarily contain the same runtime references.
    # It must not remove the real owner's layer.
    if any(other != scene and helper_for(other) == helper and owner_of(helper) == other
           for other in bpy.data.scenes):
        return
    _destroy_helper(helper)


def create(scene, target):
    if not supported(target):
        raise ValueError('A2T preview requires an editable object')
    helper = bpy.data.objects.new('_ReboCap_A2T_preview', target.data.copy())
    helper[_TAG] = uuid.uuid4().hex
    try:
        scene.collection.objects.link(helper)
        helper.hide_render = True
        helper.hide_select = True
        bind(scene, target, helper)
        # New armature objects have no pose until the view layer evaluates.
        scene.view_layers[0].update()
        try:
            helper.hide_set(True)
        except RuntimeError:
            pass
        if not helper.pose:
            raise RuntimeError('Could not initialize the preview skeleton')
        return helper
    except Exception:
        setattr(scene, _TARGET, None)
        setattr(scene, _HELPER, None)
        _destroy_helper(helper)
        raise


def discard(helper):
    _destroy_helper(helper)


def apply_bone(helper, bone, quaternion):
    helper_bone = helper.pose.bones.get(bone.name)
    if helper_bone is None:
        raise ValueError('Preview skeleton does not match the target')
    helper_bone.rotation_mode = 'QUATERNION'
    helper_bone.rotation_quaternion = quaternion
    existing = [c for c in bone.constraints if c.type == 'COPY_ROTATION' and
                c.name.startswith(_PREFIX) and c.target == helper]
    if existing:
        constraint = existing[0]
    else:
        constraint = bone.constraints.new('COPY_ROTATION')
        try:
            constraint.name = _PREFIX + helper[_TAG]
            constraint.target = helper
            constraint.subtarget = bone.name
            constraint.owner_space = 'LOCAL'
            constraint.target_space = 'LOCAL'
            constraint.mix_mode = 'REPLACE'
            if constraint.target != helper or constraint.subtarget != bone.name:
                raise RuntimeError('Could not bind the preview constraint')
            bone.constraints.move(len(bone.constraints) - 1, 0)
        except Exception:
            bone.constraints.remove(constraint)
            raise
    return constraint


def remove_bones(helper, target, names):
    if is_helper(helper) and target:
        _remove_constraints(helper, target, set(names))


def capture(scene):
    helper, target = helper_for(scene), target_for(scene)
    if not is_helper(helper) or not target:
        return None
    quats = {bone.name: bone.rotation_quaternion.copy() for bone in helper.pose.bones
             if bone.rotation_mode == 'QUATERNION'}
    constraints = [(bone.name, con.subtarget, index) for _, bone, index, con in
                   _constraints(helper, target)]
    return target, quats, constraints


def restore_capture(scene, snapshot):
    if snapshot is None:
        bind(scene, None, None)
        return None
    target, quats, constraints = snapshot
    helper = create(scene, target)
    try:
        for bone_name, subtarget, index in constraints:
            bone = target.pose.bones.get(bone_name)
            if not bone or subtarget not in quats:
                raise ValueError('Preview skeleton no longer matches the target')
            con = apply_bone(helper, bone, quats[subtarget])
            # The target bone can have been renamed since the old helper was
            # created. Its rest transform survived the rename; bind the copied
            # helper's current name while retaining the old preview rotation.
            bone.constraints.move(list(bone.constraints).index(con), index)
        return helper
    except Exception:
        clear(scene, helper)
        raise


def reconcile(sessions):
    """Remove copied/orphan layers only after all scene owners were resolved."""
    owned = {}
    for session in sessions:
        try:
            scene, target = session.scene, session.armature
            helper = helper_for(scene)
            if target and is_helper(helper):
                owned[helper] = target
                setattr(helper, _OWNER, scene)
        except ReferenceError:
            continue
    for helper in [obj for obj in list(bpy.data.objects) if is_helper(obj)]:
        target = owned.get(helper)
        if target is None:
            _destroy_helper(helper)
            continue
        # Object copies inherit the temporary constraint. Their unmodified
        # pose is already correct; do not let the preview spread to the copy.
        for obj, bone, _, con in list(_constraints(helper)):
            if obj != target:
                bone.constraints.remove(con)


def _detach_for_save(bone, constraint):
    bone.constraints.remove(constraint)


def _clear_unreferenced_helper_users(helpers):
    # Blender 3.6/4.2 can leave a phantom ID user on the original helper
    # after a Full Copy scene operation.  Clear it only after all our links,
    # constraints and runtime pointers are detached AND Blender reports no
    # actual data-block users; otherwise the unlinked helper is written out.
    users = bpy.data.user_map(subset=set(helpers)) if helpers else {}
    for helper in helpers:
        if helper.users and not helper.use_fake_user and not users.get(helper):
            helper.user_clear()


def suspend_for_save():
    """Remove temporary layers from the file; restore them after either result."""
    global _save_state
    if _save_state is not None:
        return
    helpers = [obj for obj in list(bpy.data.objects) if is_helper(obj)]
    scenes, constraints, links, removals = [], [], [], []
    for scene in bpy.data.scenes:
        helper = helper_for(scene)
        if is_helper(helper):
            scenes.append((scene, target_for(scene), helper))
    for helper in helpers:
        for obj, bone, index, con in reversed(list(_constraints(helper))):
            constraints.append((obj, bone.name, con.name, helper, con.subtarget, index))
            removals.append((bone, con))
        for collection in list(helper.users_collection):
            links.append((collection, helper))
    _save_state = (scenes, constraints, links)
    try:
        for scene, _, _ in scenes:
            setattr(scene, _TARGET, None)
            setattr(scene, _HELPER, None)
        for bone, constraint in removals:
            _detach_for_save(bone, constraint)
        for helper in helpers:
            setattr(helper, _OWNER, None)
        for collection, helper in links:
            collection.objects.unlink(helper)
    except Exception as error:
        # save_pre exceptions do not cancel Blender's save. Retry the complete
        # detach from the precomputed snapshot before Blender writes the file.
        print(f'[Rebocap] Retrying preview cleanup before save: {error}')
        for scene, _, _ in scenes:
            setattr(scene, _TARGET, None)
            setattr(scene, _HELPER, None)
        for bone, constraint in removals:
            if constraint in bone.constraints[:]:
                bone.constraints.remove(constraint)
        for helper in helpers:
            setattr(helper, _OWNER, None)
        for collection, helper in links:
            if helper in collection.objects[:]:
                collection.objects.unlink(helper)
    _clear_unreferenced_helper_users(helpers)


def _restore_saved_constraint(record):
    obj, bone_name, name, helper, subtarget, index = record
    bone = obj.pose.bones.get(bone_name)
    if not bone:
        return
    constraint = bone.constraints.new('COPY_ROTATION')
    try:
        constraint.name = name
        constraint.target = helper
        constraint.subtarget = subtarget
        constraint.owner_space = 'LOCAL'
        constraint.target_space = 'LOCAL'
        constraint.mix_mode = 'REPLACE'
        if constraint.target != helper or constraint.subtarget != subtarget:
            raise RuntimeError('Could not restore the preview constraint')
        bone.constraints.move(len(bone.constraints) - 1, index)
    except Exception:
        bone.constraints.remove(constraint)
        raise


def restore_after_save():
    global _save_state
    if _save_state is None:
        return
    scenes, constraints, links = _save_state
    try:
        for collection, helper in links:
            collection.objects.link(helper)
        for record in reversed(constraints):
            _restore_saved_constraint(record)
        for scene, target, helper in scenes:
            bind(scene, target, helper)
    except Exception:
        # Saving already completed without the layer. If rebuilding it fails,
        # remove any partially restored constraints instead of leaving an
        # unmanaged preview or a dangling helper in the current project.
        for scene, _, _ in scenes:
            setattr(scene, _TARGET, None)
            setattr(scene, _HELPER, None)
        for helper in {item[2] for item in scenes} | {item[1] for item in links}:
            _destroy_helper(helper)
        raise
    finally:
        _save_state = None


def cleanup_all():
    global _save_state
    _save_state = None
    for scene in bpy.data.scenes:
        setattr(scene, _TARGET, None)
        setattr(scene, _HELPER, None)
    for obj in list(bpy.data.objects):
        if is_helper(obj):
            _destroy_helper(obj)
