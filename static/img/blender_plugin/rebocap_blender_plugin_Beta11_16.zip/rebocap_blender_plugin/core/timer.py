import bpy
import os
from ..ops.ik_tracking import parse_and_update_ik_config

last_mtime = 0.0
_cooldown_counter = 0

def config_watchdog():
    global last_mtime, _cooldown_counter
    
    # Safely get context property
    if not hasattr(bpy.context, 'scene') or not bpy.context.scene:
        return 2.0
        
    try:
        rebocap = getattr(bpy.context.scene, 'rebocap_bone_map', None)
        if not rebocap or not getattr(rebocap, 'ik_auto_refresh', False):
            return 2.0
            
        path = rebocap.ik_config_path
        if not path or not os.path.exists(path):
            # Only probe candidate paths once every 5 ticks to avoid redundant checks
            _cooldown_counter += 1
            if _cooldown_counter >= 5 or last_mtime == 0.0:
                _cooldown_counter = 0
                from ..ops.ik_tracking import find_rebocap_config_path
                auto_path = find_rebocap_config_path()
                if auto_path and os.path.exists(auto_path):
                    rebocap.ik_config_path = auto_path
                    path = auto_path
            else:
                return 2.0

        if path and os.path.exists(path):
            current_mtime = os.path.getmtime(path)
            # Only refresh when file actually modified (or on first initial start)
            if last_mtime == 0.0 or current_mtime != last_mtime:
                last_mtime = current_mtime
                parse_and_update_ik_config(path, rebocap, None)
                
                # Auto refresh tracking nodes in viewport only if they already exist
                if "Rebocap_Root" in bpy.data.objects:
                    try:
                        bpy.ops.rebocap.create_tracking_nodes()
                    except Exception:
                        pass
    except Exception as e:
        # Ignore errors during timer to prevent crashing blender UI
        pass
        
    return 1.5

def register():
    if not bpy.app.timers.is_registered(config_watchdog):
        bpy.app.timers.register(config_watchdog, persistent=True)

def unregister():
    if bpy.app.timers.is_registered(config_watchdog):
        bpy.app.timers.unregister(config_watchdog)
